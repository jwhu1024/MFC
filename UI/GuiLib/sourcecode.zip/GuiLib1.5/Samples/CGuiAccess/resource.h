//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CGuiAccess.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CGUIACTYPE                  129
#define IDB_BITMAP1                     130
#define IDD_SPLITTERS                   131
#define IDD_DIALOG1                     131
#define IDR_MENU1                       132
#define IDC_SPLITTER                    1000
#define ID_PRUEBA1                      1025
#define ID_PRUEBA2                      1026
#define ID_SPLITTERS                    32771
#define ID_OPTION1                      32772
#define ID_OPTION2                      32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
