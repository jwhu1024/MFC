// GuiComboFont.h: interface for the CGuiComboFont class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GUICOMBOFONT_H__F90413A3_060F_425E_BD8E_3CAC9448E306__INCLUDED_)
#define AFX_GUICOMBOFONT_H__F90413A3_060F_425E_BD8E_3CAC9448E306__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGuiComboFont : public CGuiComboBoxExt  
{
public:
	CGuiComboFont();
	virtual ~CGuiComboFont();

};

#endif // !defined(AFX_GUICOMBOFONT_H__F90413A3_060F_425E_BD8E_3CAC9448E306__INCLUDED_)
