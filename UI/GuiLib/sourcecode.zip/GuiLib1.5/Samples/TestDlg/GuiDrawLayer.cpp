// GuiDrawLayer.cpp: implementation of the GuiDrawLayer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestDlg.h"
#include "GuiDrawLayer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GuiDrawLayer::GuiDrawLayer()
{

}

GuiDrawLayer::~GuiDrawLayer()
{

}
