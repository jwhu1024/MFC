// GuiDrawLayer.h: interface for the GuiDrawLayer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GUIDRAWLAYER_H__22E2F43A_F545_4C2C_BC2D_B02EFC3D7A11__INCLUDED_)
#define AFX_GUIDRAWLAYER_H__22E2F43A_F545_4C2C_BC2D_B02EFC3D7A11__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GuiDrawLayer  
{
public:
	GuiDrawLayer();
	virtual ~GuiDrawLayer();

};

#endif // !defined(AFX_GUIDRAWLAYER_H__22E2F43A_F545_4C2C_BC2D_B02EFC3D7A11__INCLUDED_)
