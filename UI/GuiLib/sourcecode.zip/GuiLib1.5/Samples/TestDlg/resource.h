//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestDlg.rc
//
#define ID_OPTION1                      0
#define ID_OPCION2                      0
#define ID_OPCION3                      0
#define ID_OPTION3                      0
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTDLG_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_TOOLMINI                    132
#define IDB_BOTON                       133
#define IDI_ICON1                       134
#define IDR_MENU1                       135
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_COMBO1                      1002
#define IDC_BTNEMAL                     1003
#define IDC_BTNARROW                    1004
#define IDC_SLIDER1                     1005
#define IDC_SLIDER2                     1006
#define IDC_SLIDER3                     1007
#define IDC_MINITOOL                    1008
#define IDC_EDITFLAT                    1009
#define IDC_MONTHCALENDAR1              1012
#define IDC_GROUPBOX                    1013
#define IDC_CHECK3                      1014
#define IDC_RADIO1                      1016
#define IDC_RADIO2                      1017
#define IDC_LINKBUTTON                  1019
#define ID_NEW                          32771
#define ID_OLD                          32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
