//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GuiLib.rc
//

#define IDR_GUI_DEFAULT						18001
#define IDR_GUI_MENUSYS						18002
#define IDD_GUI_WINDOW_MANAGE				18010
#define IDB_GUI_MDIICONS					18040
#define IDB_GUI_DOCKBAR						18041
#define IDB_GUI_DOCKBAROFFICE				18042
#define IDI_GUI_ARROWDOWN					18060
#define IDI_GUI_ARROWRIGHT					18061
#define IDC_GUI_WINDOWLIST_ACTIVATE         18080
#define IDC_GUI_WINDOWLIST_CLOSE            18081
#define IDC_GUI_WINDOWLIST_SAVE             18082
#define IDC_GUI_WINDOWLIST_TILEHORZ         18083
#define IDC_GUI_WINDOWLIST_MINIMIZE         18084
#define IDC_GUI_WINDOWLIST_CASCADE          18085
#define IDC_GUI_WINDOWLIST_TILEVERT         18086
#define IDC_GUI_WINDOWLIST_LIST             18087
#define IDC_GUI_WINDOWLIST_HELP             18088
#define ID_GUI_SHOWTITLE                    18500
#define ID_GUI_TOOLUP                       18501
#define ID_GUI_TOOLDOWN                     18502
#define ID_GUI_FILE_SAVE					18503
#define ID_GUI_FILE_CLOSE					18505
#define ID_GUI_VIEW_FULLSCREEN              18505
#define ID_GUI_WINDOW_NEXT                  18506
#define ID_GUI_WINDOW_PREVIOUS              18507
#define ID_GUI_WINDOW_CLOSE_ALL             18508
#define ID_GUI_WINDOW_SAVE_ALL              18508
#define ID_GUI_WINDOW_MANAGE                18510
#define ID_GUI_WINDOW_NEW                   18511
#define ID_GUI_WINDOW_CASCADE               18512
#define ID_GUI_WINDOW_TILE_HORZ             18513
#define ID_GUI_WINDOW_TILE_VERT             18514
#define IDS_GUI_WINDOW_MANAGE               18700

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        18003
#define _APS_NEXT_COMMAND_VALUE         18520
#define _APS_NEXT_CONTROL_VALUE         18090
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
