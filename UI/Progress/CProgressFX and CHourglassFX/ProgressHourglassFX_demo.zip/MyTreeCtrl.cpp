// MyTreeCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "Demo.h"
#include "MyTreeCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyTreeCtrl

CMyTreeCtrl::CMyTreeCtrl()
{
	m_bEndless = FALSE;
}

CMyTreeCtrl::~CMyTreeCtrl()
{
}


BEGIN_MESSAGE_MAP(CMyTreeCtrl, CWaitingTreeCtrl)
	//{{AFX_MSG_MAP(CMyTreeCtrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeCtrl message handlers

BOOL CMyTreeCtrl::PopulateItem(HTREEITEM hParent)
{
	DWORD level = 1;
	
	if (hParent != TVI_ROOT)
		level = GetItemData(hParent)+1;

	if (m_bEndless)
		SetPopulationCount(0);
	else
		SetPopulationCount(20-level);

	CString sText;
	for (DWORD i=1; i<20-level; i++)
	{
		sText.Format("Item %u at level %u", i, level);
		HTREEITEM hItem = InsertItem(sText, hParent);
		// enable button
		TVITEM tvi;
		tvi.cChildren = 1;
		tvi.hItem = hItem;
		tvi.mask = TVIF_HANDLE | TVIF_CHILDREN;
		SetItem(&tvi);
		// save level data
		SetItemData(hItem, level);
	
		IncreasePopulation();
		if (hParent != TVI_ROOT)
			Sleep(300);
	}

	SetPopulationCount(1,1);
	Sleep(100);

	return TRUE;
}

void CMyTreeCtrl::PreSubclassWindow() 
{
	PopulateRoot();
}

void CMyTreeCtrl::SetProgressType(BOOL bEndless)
{
	m_bEndless = bEndless;
}
