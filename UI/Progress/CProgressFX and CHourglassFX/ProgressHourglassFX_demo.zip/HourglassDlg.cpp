// HourglassDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Demo.h"
#include "HourglassDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHourglassDlg dialog


CHourglassDlg::CHourglassDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHourglassDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHourglassDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CHourglassDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHourglassDlg)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_MYTREE, m_ctlMyTree);
}


BEGIN_MESSAGE_MAP(CHourglassDlg, CDialog)
	//{{AFX_MSG_MAP(CHourglassDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHourglassDlg message handlers

BOOL CHourglassDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_imgList.Create(IDR_TREEICONS, 16, 16, RGB(192,192,192));
	m_ctlMyTree.SetImageList(&m_imgList, TVSIL_NORMAL);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
