#if !defined(AFX_HOURGLASSDLG_H__2055A4B2_4489_4625_AD6A_853165E87A95__INCLUDED_)
#define AFX_HOURGLASSDLG_H__2055A4B2_4489_4625_AD6A_853165E87A95__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HourglassDlg.h : header file
//

#include "MyTreeCtrl.h"
#include "HourglassFX.h"

/////////////////////////////////////////////////////////////////////////////
// CHourglassDlg dialog

class CHourglassDlg : public CDialog
{
// Construction
public:
	CImageList m_imgList;
	CHourglassDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHourglassDlg)
	enum { IDD = IDD_HOURGLASSFX_DIALOG };
	//}}AFX_DATA
	CHourglassFX<CMyTreeCtrl> m_ctlMyTree;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHourglassDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHourglassDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOURGLASSDLG_H__2055A4B2_4489_4625_AD6A_853165E87A95__INCLUDED_)
