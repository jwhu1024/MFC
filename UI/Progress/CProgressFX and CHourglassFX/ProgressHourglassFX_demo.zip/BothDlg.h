#if !defined(AFX_BOTHDLG_H__0A5277EF_505A_4764_80CE_8C9336F3F830__INCLUDED_)
#define AFX_BOTHDLG_H__0A5277EF_505A_4764_80CE_8C9336F3F830__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BothDlg.h : header file
//

#include "MyTreeCtrl.h"
#include "HourglassFX.h"
#include "ProgressFX.h"

/////////////////////////////////////////////////////////////////////////////
// CBothDlg dialog

class CBothDlg : public CDialog
{
// Construction
public:
	CImageList m_imgList;
	CBothDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBothDlg)
	enum { IDD = IDD_BOTHFX_DIALOG };
	//}}AFX_DATA
	CProgressFX< CHourglassFX< CMyTreeCtrl > > m_ctlMyTree;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBothDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBothDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOTHDLG_H__0A5277EF_505A_4764_80CE_8C9336F3F830__INCLUDED_)
