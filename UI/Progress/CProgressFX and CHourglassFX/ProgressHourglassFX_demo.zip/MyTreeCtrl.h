#if !defined(AFX_MYTREECTRL_H__B3BBAC62_D19D_4361_A86F_5F5B5E29276E__INCLUDED_)
#define AFX_MYTREECTRL_H__B3BBAC62_D19D_4361_A86F_5F5B5E29276E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyTreeCtrl.h : header file
//

#include "WaitingTreeCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CMyTreeCtrl window

class CMyTreeCtrl : public CWaitingTreeCtrl
{
// Construction
public:
	CMyTreeCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL m_bEndless;
	void SetProgressType(BOOL bEndless);
	virtual ~CMyTreeCtrl();

	// Generated message map functions
protected:
	virtual BOOL PopulateItem(HTREEITEM hParent);
	//{{AFX_MSG(CMyTreeCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTREECTRL_H__B3BBAC62_D19D_4361_A86F_5F5B5E29276E__INCLUDED_)
