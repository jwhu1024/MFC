//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Demo.rc
//
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDD_PROGRESSFX_DIALOG           129
#define IDR_TREEICONS                   130
#define IDD_HOURGLASSFX_DIALOG          130
#define IDD_BOTHFX_DIALOG               131
#define IDR_HOURGLASS                   133
#define IDC_BTN_PROGRESS                1001
#define IDC_MYTREE                      1002
#define IDC_BTN_HOURGLASS               1002
#define IDC_CHECK1                      1003
#define IDC_BTN_BOTH                    1003
#define ID_BUTTON32772                  32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
