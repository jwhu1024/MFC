// TextProgressCtrl_DemoDlg.h : header file
//

#pragma once


#include "TextProgressCtrl.h"


// CTextProgressCtrl_DemoDlg dialog
class CTextProgressCtrl_DemoDlg : public CDialog
{
// Construction
public:
	CTextProgressCtrl_DemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_TEXTPROGRESSCTRL_DEMO_DIALOG };

	BOOL				m_bShowPercent;
	BOOL				m_bShowText;
	BOOL				m_bRight;
	BOOL				m_bCenter;
	BOOL				m_bLeft;
	CSliderCtrl			m_MarqueeSlider;
	CTextProgressCtrl	m_ProgressNormal;
	CTextProgressCtrl	m_ProgressVertical;
	CTextProgressCtrl	m_ProgressNormalMarquee;
	CTextProgressCtrl	m_ProgressVerticalMarquee;
	int					m_nMarqueeSliderValue;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void OnOK();


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnStop();
	afx_msg void OnShowPercent();
	afx_msg void OnShowText();
	afx_msg void OnRight();
	afx_msg void OnCenter();
	afx_msg void OnLeft();
	afx_msg void OnBarColor();
	afx_msg void OnBarBkColor();
	afx_msg void OnTextColor();
	afx_msg void OnTextBkColor();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	DECLARE_MESSAGE_MAP()
};
