//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TextProgressCtrl_Demo.RC
//
#define IDR_MAINFRAME					128
#define IDD_TEXTPROGRESSCTRL_DEMO_DIALOG				102
#define IDT_TIMER                       129
#define IDC_PROGRESS_NORMAL             1000
#define IDC_PROGRESS_NORMAL_MARQUEE     1001
#define IDC_PROGRESS_VERTICAL           1002
#define IDC_PROGRESS_VERTICAL_MARQUEE   1003
#define IDC_SHOW_PERCENT                1004
#define IDC_SHOW_TEXT                   1005
#define IDC_RIGHT                       1006
#define IDC_CENTER                      1007
#define IDC_LEFT                        1008
#define IDC_BAR_COLOR                   1009
#define IDC_BARBK_COLOR                 1010
#define IDC_TEXT_COLOR                  1011
#define IDC_TEXTBK_COLOR                1012
#define IDC_MARQUEE_SLIDER              1013
#define IDC_START                       1014
#define IDC_STOP                        1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	130
#define _APS_NEXT_CONTROL_VALUE		1016
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
