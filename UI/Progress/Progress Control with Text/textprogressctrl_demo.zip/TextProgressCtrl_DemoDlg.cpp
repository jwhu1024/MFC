// TextProgressCtrl_DemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TextProgressCtrl_Demo.h"
#include "TextProgressCtrl_DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// local prototype
void SetWndRepositionHook();


// CTextProgressCtrl_DemoDlg dialog


CTextProgressCtrl_DemoDlg::CTextProgressCtrl_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTextProgressCtrl_DemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTextProgressCtrl_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_NORMAL, m_ProgressNormal);
	DDX_Control(pDX, IDC_PROGRESS_VERTICAL, m_ProgressVertical);
	DDX_Control(pDX, IDC_PROGRESS_NORMAL_MARQUEE, m_ProgressNormalMarquee);
	DDX_Control(pDX, IDC_PROGRESS_VERTICAL_MARQUEE, m_ProgressVerticalMarquee);
	DDX_Control(pDX, IDC_MARQUEE_SLIDER, m_MarqueeSlider);
	DDX_Check(pDX, IDC_SHOW_PERCENT, m_bShowPercent);
	DDX_Check(pDX, IDC_SHOW_TEXT, m_bShowText);
	DDX_Check(pDX, IDC_LEFT, m_bLeft);
	DDX_Check(pDX, IDC_RIGHT, m_bRight);
	DDX_Check(pDX, IDC_CENTER, m_bCenter);
}

BEGIN_MESSAGE_MAP(CTextProgressCtrl_DemoDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_SHOW_PERCENT, OnShowPercent)
	ON_BN_CLICKED(IDC_SHOW_TEXT, OnShowText)
	ON_BN_CLICKED(IDC_LEFT, OnLeft)
	ON_BN_CLICKED(IDC_RIGHT, OnRight)
	ON_BN_CLICKED(IDC_CENTER, OnCenter)
	ON_BN_CLICKED(IDC_BAR_COLOR, OnBarColor)
	ON_BN_CLICKED(IDC_BARBK_COLOR, OnBarBkColor)
	ON_BN_CLICKED(IDC_TEXT_COLOR, OnTextColor)
	ON_BN_CLICKED(IDC_TEXTBK_COLOR, OnTextBkColor)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CTextProgressCtrl_DemoDlg message handlers

BOOL CTextProgressCtrl_DemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// initialize progress bars to not show anything
	CheckDlgButton(IDC_SHOW_PERCENT, BST_UNCHECKED);
	CheckDlgButton(IDC_SHOW_TEXT, BST_UNCHECKED);
	OnShowPercent();
	OnShowText();

	// initialize desired button states
	CheckDlgButton(IDC_SHOW_PERCENT, BST_CHECKED);
	CheckDlgButton(IDC_SHOW_TEXT, BST_CHECKED);
	CheckRadioButton(IDC_RIGHT, IDC_LEFT, IDC_CENTER);

	// initialize the slider for marquee bar size
	m_nMarqueeSliderValue = 20;
	m_MarqueeSlider.SetRange(10, 90, false);
	m_MarqueeSlider.SetPos(m_nMarqueeSliderValue);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTextProgressCtrl_DemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTextProgressCtrl_DemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CTextProgressCtrl_DemoDlg::OnStart()
{
	OnShowPercent();
	OnShowText();

	// adjust Start/Stop button states
	GetDlgItem(IDC_START)->EnableWindow(false);
	GetDlgItem(IDC_STOP)->EnableWindow(true);

	// set timer to update normal progress bars
	SetTimer(IDT_TIMER, 30, NULL);

	// start marquee style progress bars
	m_ProgressNormalMarquee.SetMarquee(true, 30);
	m_ProgressVerticalMarquee.SetMarquee(true, 30);
}

void CTextProgressCtrl_DemoDlg::OnStop()
{
	// kill timer for normal progress bars
	KillTimer(IDT_TIMER);

	// stop marquee style progress bars
	m_ProgressNormalMarquee.SetMarquee(false, 0);
	m_ProgressVerticalMarquee.SetMarquee(false, 0);

	// set progress back to zero to erase bars while idle
	m_ProgressNormal.SetPos(0);
	m_ProgressVertical.SetPos(0);
	m_ProgressNormalMarquee.SetPos(0);
	m_ProgressVerticalMarquee.SetPos(0);

	// set text variable to not show anything while idle, preserving check box state
	UINT uPercent = IsDlgButtonChecked(IDC_SHOW_PERCENT);
	UINT uText = IsDlgButtonChecked(IDC_SHOW_TEXT);
	CheckDlgButton(IDC_SHOW_PERCENT, BST_UNCHECKED);
	CheckDlgButton(IDC_SHOW_TEXT, BST_UNCHECKED);
	OnShowPercent();
	OnShowText();
	CheckDlgButton(IDC_SHOW_PERCENT, uPercent);
	CheckDlgButton(IDC_SHOW_TEXT, uText);

	// adjust Start/Stop button states
	GetDlgItem(IDC_START)->EnableWindow(true);
	GetDlgItem(IDC_STOP)->EnableWindow(false);
}

void CTextProgressCtrl_DemoDlg::OnOK()
{
	// kill timer for normal progress bars
	KillTimer(IDT_TIMER);

	// stop marquee style progress bars
	m_ProgressNormalMarquee.SetMarquee(false, 0);
	m_ProgressVerticalMarquee.SetMarquee(false, 0);

	CDialog::OnOK();
}

void CTextProgressCtrl_DemoDlg::OnTimer(UINT_PTR nIDEvent)
{
#define DIRECTION_CHANGE_DELAY	20

	static int nDirection = +1;
	static int nDirectionChangeDelay = 0;

	if (nDirectionChangeDelay > 0)
	{
		nDirectionChangeDelay--;
		m_ProgressNormal.RedrawWindow();
		m_ProgressVertical.RedrawWindow();
	}
	else if (nIDEvent == IDT_TIMER)
	{
		int nPosition = m_ProgressNormal.GetPos();
		ASSERT(nPosition == m_ProgressVertical.GetPos());

		if ((nDirection == 1) && (nPosition >= 100))
		{
			nDirection = -1;
			nDirectionChangeDelay = DIRECTION_CHANGE_DELAY;
		}
		else if ((nDirection == -1) && (nPosition <= 0))
		{
			nDirection = +1;
			nDirectionChangeDelay = DIRECTION_CHANGE_DELAY;
		}

		if (nDirectionChangeDelay == 0)
		{
			m_ProgressNormal.SetPos(nPosition + nDirection);
			m_ProgressVertical.SetPos(nPosition + nDirection);
		}
	}
}

void CTextProgressCtrl_DemoDlg::OnShowPercent() 
{
	UpdateData(true);
	m_ProgressNormal.SetShowPercent(m_bShowPercent);
	m_ProgressVertical.SetShowPercent(m_bShowPercent);
	m_ProgressNormalMarquee.SetShowPercent(false);
	m_ProgressVerticalMarquee.SetShowPercent(false);
}

void CTextProgressCtrl_DemoDlg::OnShowText() 
{
	UpdateData(true);
	if (m_bShowText)
	{
		m_ProgressNormal.SetWindowText(_T("Completed "));
		m_ProgressVertical.SetWindowText(_T("Completed "));
		m_ProgressNormalMarquee.SetWindowText(_T("Working..."));
		m_ProgressVerticalMarquee.SetWindowText(_T("Working..."));
	}
	else
	{
		m_ProgressNormal.SetWindowText(_T(""));
		m_ProgressVertical.SetWindowText(_T(""));
		m_ProgressNormalMarquee.SetWindowText(_T(""));
		m_ProgressVerticalMarquee.SetWindowText(_T(""));
	}
	m_ProgressNormal.Invalidate();
	m_ProgressVertical.Invalidate();
	m_ProgressNormalMarquee.Invalidate();
	m_ProgressVerticalMarquee.Invalidate();
}

void CTextProgressCtrl_DemoDlg::OnLeft() 
{
	UpdateData(true);
	if (m_bLeft)
	{
		// set left alignment if button pressed
		m_ProgressNormal.AlignText(DT_LEFT);
		m_ProgressVertical.AlignText(DT_LEFT);
		m_ProgressNormalMarquee.AlignText(DT_LEFT);
		m_ProgressVerticalMarquee.AlignText(DT_LEFT);
	}
}

void CTextProgressCtrl_DemoDlg::OnRight() 
{
	UpdateData(true);
	if (m_bRight)
	{
		// set right alignment if button pressed
		m_ProgressNormal.AlignText(DT_RIGHT);
		m_ProgressVertical.AlignText(DT_RIGHT);
		m_ProgressNormalMarquee.AlignText(DT_RIGHT);
		m_ProgressVerticalMarquee.AlignText(DT_RIGHT);
	}
}

void CTextProgressCtrl_DemoDlg::OnCenter() 
{
	UpdateData(true);
	if (m_bCenter)
	{
		// set center alignment if button pressed
		m_ProgressNormal.AlignText(DT_CENTER);
		m_ProgressVertical.AlignText(DT_CENTER);
		m_ProgressNormalMarquee.AlignText(DT_CENTER);
		m_ProgressVerticalMarquee.AlignText(DT_CENTER);
	}
}

void CTextProgressCtrl_DemoDlg::OnBarColor() 
{
	// get the desired color
	CColorDialog coldlg(m_ProgressNormal.GetBarColor(), CC_FULLOPEN | CC_RGBINIT, this);
	SetWndRepositionHook();
	int nResponse = (int)coldlg.DoModal();

	// save the color if one selected
	if (nResponse == IDOK)
	{
		m_ProgressNormal.SetBarColor(coldlg.GetColor());
		m_ProgressVertical.SetBarColor(coldlg.GetColor());
		m_ProgressNormalMarquee.SetBarColor(coldlg.GetColor());
		m_ProgressVerticalMarquee.SetBarColor(coldlg.GetColor());
	}
}

void CTextProgressCtrl_DemoDlg::OnBarBkColor() 
{
	// get the desired color
	CColorDialog coldlg(m_ProgressNormal.GetBarBkColor(), CC_FULLOPEN | CC_RGBINIT, this);
	SetWndRepositionHook();
	int nResponse = (int)coldlg.DoModal();

	// save the color if one selected
	if (nResponse == IDOK)
	{
		m_ProgressNormal.SetBarBkColor(coldlg.GetColor());
		m_ProgressVertical.SetBarBkColor(coldlg.GetColor());
		m_ProgressNormalMarquee.SetBarBkColor(coldlg.GetColor());
		m_ProgressVerticalMarquee.SetBarBkColor(coldlg.GetColor());
	}
}

void CTextProgressCtrl_DemoDlg::OnTextColor() 
{
	// get the desired color
	CColorDialog coldlg(m_ProgressNormal.GetTextColor(), CC_FULLOPEN | CC_RGBINIT, this);
	SetWndRepositionHook();
	int nResponse = (int)coldlg.DoModal();

	// save the color if one selected
	if (nResponse == IDOK)
	{
		m_ProgressNormal.SetTextColor(coldlg.GetColor());
		m_ProgressVertical.SetTextColor(coldlg.GetColor());
		m_ProgressNormalMarquee.SetTextColor(coldlg.GetColor());
		m_ProgressVerticalMarquee.SetTextColor(coldlg.GetColor());
	}
}

void CTextProgressCtrl_DemoDlg::OnTextBkColor() 
{
	// get the desired color
	CColorDialog coldlg(m_ProgressNormal.GetTextBkColor(), CC_FULLOPEN | CC_RGBINIT, this);
	SetWndRepositionHook();
	int nResponse = (int)coldlg.DoModal();

	// save the color if one selected
	if (nResponse == IDOK)
	{
		m_ProgressNormal.SetTextBkColor(coldlg.GetColor());
		m_ProgressVertical.SetTextBkColor(coldlg.GetColor());
		m_ProgressNormalMarquee.SetTextBkColor(coldlg.GetColor());
		m_ProgressVerticalMarquee.SetTextBkColor(coldlg.GetColor());
	}
}

void CTextProgressCtrl_DemoDlg::OnHScroll(UINT /*nSBCode*/, UINT /*nPos*/, CScrollBar* pScrollBar) 
{
	// resize the marquee bar
	if (pScrollBar == GetDlgItem(IDC_MARQUEE_SLIDER))
	{
		m_nMarqueeSliderValue = (int)pScrollBar->SendMessage(TBM_GETPOS, 0, 0);
		m_ProgressNormalMarquee.SetMarqueeOptions(m_nMarqueeSliderValue);
		m_ProgressVerticalMarquee.SetMarqueeOptions(m_nMarqueeSliderValue);
	}
}

// Hook handle for repositioning CColorDialog window on creation (thread-local variable)
_declspec (thread) HHOOK	hhk;

//
// "Hook" routine to reposition CColorDialog window, so it doesn't overlap its parent dialog box
//
LRESULT CALLBACK CBTProc(INT nCode, WPARAM wParam, LPARAM lParam)
{
	HWND			hChildWnd;
	HWND			hParentWnd;
	int				nHeight;
	int				nWidth;
	POINT			pStart;
	RECT			rChild;
	RECT			rDesktop;
	RECT			rParent;

	// if window is about to be activated, reposition it
	if (nCode == HCBT_ACTIVATE)
	{
		// get the size of the child window about to be activated
		hChildWnd  = (HWND)wParam;
		GetWindowRect(hChildWnd, &rChild);
		nWidth  = (rChild.right - rChild.left);
		nHeight = (rChild.bottom - rChild.top);

		// get the size of the usable desktop
		if (!SystemParametersInfo(SPI_GETWORKAREA, 0, &rDesktop, 0))
			GetWindowRect(GetDesktopWindow(), &rDesktop);

		// get the size and position of the first visible window in the parentage chain
		// if the child window has no visible parent, position it in relation to the usable desktop
		hParentWnd = hChildWnd;
		do
			hParentWnd = GetParent(hParentWnd);
		while ((hParentWnd != NULL) && !IsWindowVisible(hParentWnd));
		if ((hParentWnd != NULL) && !IsIconic(hParentWnd))
			GetWindowRect(hParentWnd, &rParent);
		else
			rParent = rDesktop;

		// calculate new child window starting point
		pStart.x = rParent.left;
		pStart.y = rParent.bottom + 20;

		// adjust if child window is off usable desktop
		if (pStart.x < rDesktop.left)
			pStart.x = rDesktop.left;
		if (pStart.y < rDesktop.top)
			pStart.y = rDesktop.top;
		if (pStart.x + nWidth > rDesktop.right)
			pStart.x = rDesktop.right - nWidth;
		if (pStart.y + nHeight > rDesktop.bottom)
			pStart.y = rDesktop.bottom - nHeight;

		// move child window
		MoveWindow(hChildWnd, pStart.x, pStart.y, nWidth, nHeight, FALSE);

		// unhook from CBT chain
		UnhookWindowsHookEx(hhk);
	}

	// exit by calling next hook procedure
	return (CallNextHookEx(hhk, nCode, wParam, lParam));
}

//
//	Set "hook" so next window that is activated can be repositioned
//
void SetWndRepositionHook()
{
	// set the "hook"
	hhk = SetWindowsHookEx(WH_CBT, CBTProc, NULL, GetCurrentThreadId());
}
