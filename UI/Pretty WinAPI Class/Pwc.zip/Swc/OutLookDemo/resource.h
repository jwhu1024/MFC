//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OutoolkDemo.rc
//
#define IDC_MYICON                      2
#define IDD_OUTOOLKDEMO_DIALOG          102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_OUTOOLKDEMO                 107
#define IDI_SMALL                       108
#define IDC_OUTOOLKDEMO                 109
#define IDB_GUI_DOCKBAR                 110
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDR_TOOLBAR                     130
#define IDB_Toolbox                     133
#define IDB_TOOLBOX                     133
#define IDB_DB                          134
#define IDB_TREE                        134
#define IDB_TOOLBAR                     135
#define ID_FILE_NEW                     32771
#define ID_FILE_OPEN                    32772
#define ID_FILE_PRINTER                 32772
#define ID_FILE_SAVE                    32773
#define ID_FIND                         32773
#define ID_APP_ABOUT                    32774
#define ID_NEW_MAIL                     32777
#define ID_NEW_FAX                      32778
#define ID_NEW_POST_FOLDER              32779
#define ID_NEW_FOLDER                   32780
#define ID_NEW_SHORTCUT                 32781
#define ID_NEW_APPOINMENT               32782
#define ID_NEW_MEETING                  32783
#define ID_NEW_CONTRACT                 32784
#define ID_NEW_DISTRIBUTION_LIST        32785
#define ID_NEW_TASK                     32786
#define ID_NEW_TASK_REQUEST             32787
#define ID_NEW_JOURNAL_ENTRY            32788
#define ID_NEW_NOTE                     32789
#define ID_MAIL_SEND                    32790
#define ID_MAIL_SAVE                    32791
#define ID_FILE_SAVE_AS                 32792
#define ID_MAIL_SAVE_ATTACHMENTS        32793
#define ID_MAIL_SAVE_STATIONERY         32794
#define ID_MAIL_DELETE                  32795
#define ID_MAIL_MOVE_TO_FOLDER          32796
#define ID_MAIL_COPY_TO_FOLDER          32797
#define ID_FILE_PRINT_PREVIEW           32798
#define ID_FILE_PRINT                   32799
#define ID_MAIL_PROPERTIES              32800
#define ID_MAIL_CLOSE                   32801
#define ID_EDIT_UNDO                    32802
#define ID_EDIT_REDO                    32803
#define ID_EDIT_CUT                     32804
#define ID_EDIT_COPY                    32805
#define ID_COMBOBOX                     32805
#define ID_EDIT_PASTE                   32806
#define ID_MAIL_SPELL                   32807
#define ID_MAIL_CHECK_NAMES             32808
#define ID_ADDRESS_BOOK                 32809
#define ID_TOOLS_ENTRY                  32810
#define ID_VIEW_CUSTOMIZE               32811
#define ID_ADDRESBOOK                   32812
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32813
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
