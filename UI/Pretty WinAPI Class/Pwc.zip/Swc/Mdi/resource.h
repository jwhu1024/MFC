//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinClass.rc
//
#define IDC_MYICON                      2
#define IDD_WINCLASS_DIALOG             102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_WINCLASS                    107
#define IDI_SMALL                       108
#define IDC_WINCLASS                    109
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR                     129
#define IDR_MENUHELLO                   132
#define IDR_TOOLBAR1                    134
#define IDI_ICONDOC                     139
#define IDR_SYSTEMBAR                   140
#define IDr_BITMAP1                     146
#define IDB_TOOLBAR                     150
#define IDR_RS1                         152
#define ID_TOOLBAR                      551
#define IDC_COMBONOMBRE                 1000
#define IDC_GROUPBOX                    1001
#define IDC_EDITAR                      1002
#define IDC_LISTA                       1004
#define IDC_EDIT                        1006
#define ID_MENU_NEW                     32771
#define ID_FILE_NEW                     32773
#define ID_FILE_OPEN                    32774
#define ID_FILE_SAVE                    32775
#define ID_EDIT_CUT                     32776
#define ID_STATUSBAR                    32777
#define ID_FILE_CLOSE                   32778
#define ID_WINDOW_NEW                   32779
#define ID_WINDOW_CASCADE               32780
#define ID_WINDOW_TILE_HORZ             32781
#define ID_WINDOW_ARRANGE               32782
#define ID_BOTONNEGRO                   32783
#define ID_BOTONROJO                    32784
#define ID_BUTTON32785                  32785
#define ID_BUTTON32786                  32786
#define ID_BUTTON32787                  32787
#define ID_BUTTON32788                  32788
#define ID_BUTTON32789                  32789
#define ID_BUTTON32790                  32790
#define IDM_OPEN1                       32791
#define IDM_OPEN2                       32792
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
