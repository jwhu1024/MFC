//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testapp.rc
//
#define IDS_DDX_GF_TT_MODIFY            1
#define IDS_DDX_GF_OK                   2
#define IDS_DDX_GF_EDIT_TEXT            3
#define IDS_DDX_GF_OVERWRITE_PROMPT     4
#define IDD_DYNIP_DIALOG                102
#define IDD_MAINFRM                     102
#define IDR_MAINFRAME                   128
#define IDR_SMALL_MAINFRAME             129
#define IDI_SMALL1                      130
#define IDI_SMALL2                      131
#define IDI_SMALL3                      132
#define IDI_SMALL4                      133
#define IDI_SMALL5                      134
#define IDI_SMALL6                      135
#define IDI_SMALL7                      136
#define IDI_SMALL8                      137
#define IDI_BIG1                        138
#define IDI_BIG4                        139
#define IDI_BIG2                        140
#define IDI_BIG3                        141
#define IDC_CONNECTED_LOCAL             1000
#define IDC_FTPSITE                     1002
#define IDC_USERNAME                    1003
#define IDC_PASSWORD                    1004
#define IDC_SEND_CONNECTED              1005
#define IDC_REFRESH                     1006
#define IDC_FTP_FILENAME                1009
#define IDC_FTP_DIRECTORY               1010
#define IDC_ADDRESS                     1011
#define IDC_NOTCONNECTED_LOCAL          1012
#define IDC_SEND_NOTCONNECTED           1013
#define IDC_BINARY1                     1015
#define IDC_BINARY2                     1016
#define IDC_COMBO1                      1016
#define IDC_COMBO2                      1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
