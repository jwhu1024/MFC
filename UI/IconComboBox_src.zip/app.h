#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


class CTestApp : public CWinApp
{
public:
	CTestApp();

protected:
	//{{AFX_VIRTUAL(CTestApp)
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CTestApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

