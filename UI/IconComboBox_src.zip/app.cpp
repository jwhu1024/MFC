#include "stdafx.h"
#include "app.h"
#include "IconComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


class CTestDialog : public CDialog
{
public:
	CTestDialog(CWnd* pParent = NULL);   // standard constructor

	//{{AFX_DATA(CTestDialog)
	enum { IDD = IDD_MAINFRM };
	//}}AFX_DATA
	CSmallIconComboBox m_ctrlCombo1;
	UINT m_nIconID1;
	CLargeIconComboBox m_ctrlCombo2;
	UINT m_nIconID2;

protected:
	//{{AFX_VIRTUAL(CTestDialog)
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CTestDialog)
	afx_msg HCURSOR OnQueryDragIcon();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	HICON m_hIcon;
};





CTestDialog::CTestDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDialog)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nIconID1 = IDI_SMALL2;
	m_nIconID2 = IDI_BIG3;
}


void CTestDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDialog)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_ctrlCombo1);
	DDX_CBIcon(pDX, IDC_COMBO1, m_nIconID1);
	DDX_Control(pDX, IDC_COMBO2, m_ctrlCombo2);
	DDX_CBIcon(pDX, IDC_COMBO2, m_nIconID2);
}

BEGIN_MESSAGE_MAP(CTestDialog, CDialog)
	//{{AFX_MSG_MAP(CTestDialog)
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

HCURSOR CTestDialog::OnQueryDragIcon() 
{
	return (HCURSOR) m_hIcon;
}

BOOL CTestDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	//Set up the dialog menu
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);


	//Set up the icons which are contained 
	//within the icon combo boxes

  //Add all the small icons available
  m_ctrlCombo1.AddIcon(IDI_SMALL1);
  m_ctrlCombo1.AddIcon(IDI_SMALL2);
  m_ctrlCombo1.AddIcon(IDI_SMALL3);
  m_ctrlCombo1.AddIcon(IDI_SMALL4);
  m_ctrlCombo1.AddIcon(IDI_SMALL5);
  m_ctrlCombo1.AddIcon(IDI_SMALL6);
  m_ctrlCombo1.AddIcon(IDI_SMALL7);
  m_ctrlCombo1.AddIcon(IDI_SMALL8);
  
	//Add all the large icons available
  m_ctrlCombo2.AddIcon(IDI_BIG1);
  m_ctrlCombo2.AddIcon(IDI_BIG2);
  m_ctrlCombo2.AddIcon(IDI_BIG3);
  m_ctrlCombo2.AddIcon(IDI_BIG4);

  //Force a DoDataExchange after adding the 
	//icons to the combo box
	UpdateData(FALSE);

	return TRUE;
}



BEGIN_MESSAGE_MAP(CTestApp, CWinApp)
	//{{AFX_MSG_MAP(CTestApp)
	//}}AFX_MSG
END_MESSAGE_MAP()

CTestApp::CTestApp()
{
}

CTestApp theApp;

BOOL CTestApp::InitInstance()
{ 
  Enable3dControls();

  //Bring up the test dialog
  CTestDialog dlg;
  dlg.DoModal();

	return FALSE;
}

