// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "MDITabs_Demo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
  //{{AFX_MSG_MAP(CMainFrame)
  ON_WM_CREATE()
	ON_BN_CLICKED(IDC_TOP, OnTop)
	ON_BN_CLICKED(IDC_IMAGES, OnImages)
	ON_CBN_SELCHANGE(IDC_MINVIEWS, OnSelChangeMinViews)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
  ID_SEPARATOR,           // status line indicator
  ID_INDICATOR_CAPS,
  ID_INDICATOR_NUM,
  ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
  m_bTop = false;
  m_bImages = false;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
    return -1;

  // MFC toolbar support begin
  /*
  if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
    | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
    !m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
  {
    TRACE0("Failed to create toolbar\n");
    return -1;      // fail to create
  }

  if (!m_wndStatusBar.Create(this) ||
    !m_wndStatusBar.SetIndicators(indicators,
      sizeof(indicators)/sizeof(UINT)))
  {
    TRACE0("Failed to create status bar\n");
    return -1;      // fail to create
  }

  // TODO: Delete these three lines if you don't want the toolbar to
  //  be dockable
  m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
  EnableDocking(CBRS_ALIGN_ANY);
  DockControlBar(&m_wndToolBar);
  */
  // MFC toolbar support end

  // I like the rebars more ;-)

  // Rebar support begin
  if (!m_wndToolBar.CreateEx(this) ||
    !m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
  {
    TRACE0("Failed to create toolbar\n");
    return -1;      // fail to create
  }
  if (!m_wndDlgBar.Create(this, IDR_MAINFRAME,
    CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
  {
    TRACE0("Failed to create dialogbar\n");
    return -1;    // fail to create
  }
  ::SendMessage(::GetDlgItem(m_wndDlgBar, IDC_MINVIEWS), CB_SETCURSEL, 1, 0);

  if (!m_wndReBar.Create(this) ||
    !m_wndReBar.AddBar(&m_wndToolBar) ||
    !m_wndReBar.AddBar(&m_wndDlgBar))
  {
    TRACE0("Failed to create rebar\n");
    return -1;      // fail to create
  }

  if (!m_wndStatusBar.Create(this) || !m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT)))
  {
    TRACE0("Failed to create status bar\n");
    return -1;      // fail to create
  }

  m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);
  // Rebar support end


  // CMDITabs must be createt at last to ensure correct layout!!!
  // ------------------------------------------------------------
  DWORD dwStyle = (m_bTop ? MT_TOP : 0) | (m_bImages ? MT_IMAGES : 0);
  m_wndMDITabs.Create(this, dwStyle);

  return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
  if( !CMDIFrameWnd::PreCreateWindow(cs) )
    return FALSE;
  return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
  CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
  CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnUpdateFrameTitle(BOOL bAddToTitle)
{
  CMDIFrameWnd::OnUpdateFrameTitle(bAddToTitle);

  m_wndMDITabs.Update(); // sync the mditabctrl with all views
}

void CMainFrame::ReCreateMDITabs()
{
  m_wndMDITabs.DestroyWindow();
  DWORD dwStyle = (m_bTop ? MT_TOP : 0) | (m_bImages ? MT_IMAGES : 0);
  m_wndMDITabs.Create(this, dwStyle);
  m_wndMDITabs.Update();
  RecalcLayout();
}

void CMainFrame::OnTop() 
{
  m_bTop = !m_bTop;
  ReCreateMDITabs();
}

void CMainFrame::OnImages() 
{
	m_bImages = !m_bImages;
  ReCreateMDITabs();
}

void CMainFrame::OnSelChangeMinViews() 
{
  int minViews = ::SendMessage(::GetDlgItem(m_wndDlgBar, IDC_MINVIEWS), CB_GETCURSEL, 0, 0);
  m_wndMDITabs.SetMinViews(minViews);
  RecalcLayout();
}
