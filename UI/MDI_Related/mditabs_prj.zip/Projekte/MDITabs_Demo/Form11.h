#if !defined(AFX_FORM11_H__0CBC959A_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
#define AFX_FORM11_H__0CBC959A_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Form11.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Form1 form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class Form1 : public CFormView
{
protected:
	Form1();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(Form1)

// Form Data
public:
	//{{AFX_DATA(Form1)
	enum { IDD = IDD_FORM1_FORM };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Form1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~Form1();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(Form1)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORM11_H__0CBC959A_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
