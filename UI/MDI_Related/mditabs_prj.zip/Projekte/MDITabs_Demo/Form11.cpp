// Form11.cpp : implementation file
//

#include "stdafx.h"
#include "MDITabs_Demo.h"
#include "Form11.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Form1

IMPLEMENT_DYNCREATE(Form1, CFormView)

Form1::Form1()
	: CFormView(Form1::IDD)
{
	//{{AFX_DATA_INIT(Form1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

Form1::~Form1()
{
}

void Form1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Form1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Form1, CFormView)
	//{{AFX_MSG_MAP(Form1)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Form1 diagnostics

#ifdef _DEBUG
void Form1::AssertValid() const
{
	CFormView::AssertValid();
}

void Form1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// Form1 message handlers
