//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDITabs_Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_FORM1_TMPL                  103
#define IDD_FORMA_FORM                  104
#define IDR_FORMA_TMPL                  105
#define IDD_FORMB_FORM                  106
#define IDR_FORMB_TMPL                  107
#define IDR_MAINFRAME                   128
#define IDR_MDITABTYPE                  129
#define IDC_TOP                         1000
#define IDC_IMAGES                      1001
#define IDC_MINVIEWS                    1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
