// MDITabs_DemoView.h : interface of the CMDITabs_DemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDITABS_DEMOVIEW_H__0CBC958E_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
#define AFX_MDITABS_DEMOVIEW_H__0CBC958E_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMDITabs_DemoView : public CView
{
protected: // create from serialization only
	CMDITabs_DemoView();
	DECLARE_DYNCREATE(CMDITabs_DemoView)

// Attributes
public:
	CMDITabs_DemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDITabs_DemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDITabs_DemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMDITabs_DemoView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MDITabs_DemoView.cpp
inline CMDITabs_DemoDoc* CMDITabs_DemoView::GetDocument()
   { return (CMDITabs_DemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDITABS_DEMOVIEW_H__0CBC958E_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
