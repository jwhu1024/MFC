// FormB.cpp : implementation file
//

#include "stdafx.h"
#include "MDITabs_Demo.h"
#include "FormB.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FormB

IMPLEMENT_DYNCREATE(FormB, CFormView)

FormB::FormB()
	: CFormView(FormB::IDD)
{
	//{{AFX_DATA_INIT(FormB)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

FormB::~FormB()
{
}

void FormB::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FormB)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FormB, CFormView)
	//{{AFX_MSG_MAP(FormB)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FormB diagnostics

#ifdef _DEBUG
void FormB::AssertValid() const
{
	CFormView::AssertValid();
}

void FormB::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// FormB message handlers
