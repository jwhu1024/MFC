// FormA.cpp : implementation file
//

#include "stdafx.h"
#include "MDITabs_Demo.h"
#include "FormA.h"
#include "MDITabs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// FormA

IMPLEMENT_DYNCREATE(FormA, CFormView)

FormA::FormA()
	: CFormView(FormA::IDD)
{
	//{{AFX_DATA_INIT(FormA)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

FormA::~FormA()
{
}

void FormA::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(FormA)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(FormA, CFormView)
	//{{AFX_MSG_MAP(FormA)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
  ON_MESSAGE(WM_GETTABTIPTEXT, OnGetTabTipText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// FormA diagnostics

#ifdef _DEBUG
void FormA::AssertValid() const
{
	CFormView::AssertValid();
}

void FormA::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// FormA message handlers

afx_msg LRESULT FormA::OnGetTabTipText(WPARAM, LPARAM)
{
  return LRESULT("My tiptext!");
}
