// MDITabs_DemoView.cpp : implementation of the CMDITabs_DemoView class
//

#include "stdafx.h"
#include "MDITabs_Demo.h"

#include "MDITabs_DemoDoc.h"
#include "MDITabs_DemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoView

IMPLEMENT_DYNCREATE(CMDITabs_DemoView, CView)

BEGIN_MESSAGE_MAP(CMDITabs_DemoView, CView)
	//{{AFX_MSG_MAP(CMDITabs_DemoView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoView construction/destruction

CMDITabs_DemoView::CMDITabs_DemoView()
{
}

CMDITabs_DemoView::~CMDITabs_DemoView()
{
}

BOOL CMDITabs_DemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoView drawing

void CMDITabs_DemoView::OnDraw(CDC* pDC)
{
	CMDITabs_DemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoView diagnostics

#ifdef _DEBUG
void CMDITabs_DemoView::AssertValid() const
{
	CView::AssertValid();
}

void CMDITabs_DemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMDITabs_DemoDoc* CMDITabs_DemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMDITabs_DemoDoc)));
	return (CMDITabs_DemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoView message handlers
