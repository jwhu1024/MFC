// MDITabs_DemoDoc.h : interface of the CMDITabs_DemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDITABS_DEMODOC_H__0CBC958C_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
#define AFX_MDITABS_DEMODOC_H__0CBC958C_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMDITabs_DemoDoc : public CDocument
{
protected: // create from serialization only
	CMDITabs_DemoDoc();
	DECLARE_DYNCREATE(CMDITabs_DemoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDITabs_DemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDITabs_DemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMDITabs_DemoDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDITABS_DEMODOC_H__0CBC958C_BA85_11D5_AF21_DF3E023ED24F__INCLUDED_)
