// MDITabs_DemoDoc.cpp : implementation of the CMDITabs_DemoDoc class
//

#include "stdafx.h"
#include "MDITabs_Demo.h"

#include "MDITabs_DemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoDoc

IMPLEMENT_DYNCREATE(CMDITabs_DemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CMDITabs_DemoDoc, CDocument)
	//{{AFX_MSG_MAP(CMDITabs_DemoDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoDoc construction/destruction

CMDITabs_DemoDoc::CMDITabs_DemoDoc()
{
}

CMDITabs_DemoDoc::~CMDITabs_DemoDoc()
{
}

BOOL CMDITabs_DemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoDoc serialization

void CMDITabs_DemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoDoc diagnostics

#ifdef _DEBUG
void CMDITabs_DemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMDITabs_DemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDITabs_DemoDoc commands
