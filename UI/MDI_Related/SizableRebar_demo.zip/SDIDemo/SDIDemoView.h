// SDIDemoView.h : interface of the CSDIDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SDIDEMOVIEW_H__0906AA80_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
#define AFX_SDIDEMOVIEW_H__0906AA80_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Preview.h"

class CSDIDemoView : public CPreviewableView< CRichEditView >
{
protected: // create from serialization only
	CSDIDemoView();
	DECLARE_DYNCREATE(CSDIDemoView)

// Attributes
public:
	CSDIDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIDemoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual HMENU GetContextMenu(WORD seltype, LPOLEOBJECT lpoleobj, CHARRANGE* lpchrg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSDIDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    CMenu m_menu;

// Generated message map functions
protected:
	//{{AFX_MSG(CSDIDemoView)
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SDIDemoView.cpp
inline CSDIDemoDoc* CSDIDemoView::GetDocument()
   { return (CSDIDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SDIDEMOVIEW_H__0906AA80_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
