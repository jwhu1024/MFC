//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDIDemo.rc
//
#define IDR_CNTR_IP                     6
#define IDD_ABOUTBOX                    1000
#define IDR_MAINFRAME                   1028
#define IDR_SDIDEMTYPE                  1029
#define IDB_COOLBARBG                   1030
#define IDR_MRU                         1031
#define IDR_TEXTOPTIONS                 1032
#define IDB_TBSMALL_COLD                1033
#define IDR_ICONOPTIONS                 1033
#define IDB_TBSMALL_HOT                 1034
#define IDB_TBLARGE_HOT                 1035
#define IDB_TBLARGE_COLD                1036
#define IDB_MENUS                       1038
#define IDR_EDIT                        1040
#define ID_BACKGROUND                   35771
#define ID_TEXTLABELS                   35772
#define ID_SHOW_TEXT_LABELS             35773
#define ID_TEXT_ON_RIGHT                35774
#define ID_NO_TEXT_LABELS               35775
#define ID_TEXTOPTIONS                  35777
#define ID_ICONOPTIONS                  35778
#define ID_SMALL_ICONS                  35780
#define ID_LARGE_ICONS                  35781
#define ID_TRANSPARENT                  35782
#define ID_OLE_VERB_POPUP               32811
#define ID_VIEW_DIALOGBAR               59397

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        1039
#define _APS_NEXT_COMMAND_VALUE         35782
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           1004
#endif
#endif
