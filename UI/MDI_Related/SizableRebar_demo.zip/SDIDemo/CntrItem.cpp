// CntrItem.cpp : implementation of the CSDIDemoCntrItem class
//

#include "stdafx.h"
#include "SDIDemo.h"

#include "SDIDemoDoc.h"
#include "SDIDemoView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoCntrItem implementation

IMPLEMENT_SERIAL(CSDIDemoCntrItem, CRichEditCntrItem, 0)

CSDIDemoCntrItem::CSDIDemoCntrItem(REOBJECT* preo, CSDIDemoDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CSDIDemoCntrItem::~CSDIDemoCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoCntrItem diagnostics

#ifdef _DEBUG
void CSDIDemoCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CSDIDemoCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
