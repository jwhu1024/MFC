// CntrItem.h : interface of the CSDIDemoCntrItem class
//

#if !defined(AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_)
#define AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSDIDemoDoc;
class CSDIDemoView;

class CSDIDemoCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CSDIDemoCntrItem)

// Constructors
public:
	CSDIDemoCntrItem(REOBJECT* preo = NULL, CSDIDemoDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CSDIDemoDoc* GetDocument()
		{ return (CSDIDemoDoc*)CRichEditCntrItem::GetDocument(); }
	CSDIDemoView* GetActiveView()
		{ return (CSDIDemoView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSDIDemoCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CSDIDemoCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_)
