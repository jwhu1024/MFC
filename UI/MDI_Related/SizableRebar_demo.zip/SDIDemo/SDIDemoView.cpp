// SDIDemoView.cpp : implementation of the CSDIDemoView class
//

#include "stdafx.h"
#include "SDIDemo.h"

#include "SDIDemoDoc.h"
#include "SDIDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoView

IMPLEMENT_DYNCREATE(CSDIDemoView, CRichEditView)

BEGIN_MESSAGE_MAP(CSDIDemoView, CRichEditView)
	//{{AFX_MSG_MAP(CSDIDemoView)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoView construction/destruction

CSDIDemoView::CSDIDemoView()
{
	// TODO: add construction code here

}

CSDIDemoView::~CSDIDemoView()
{
    m_menu.DestroyMenu();
}

BOOL CSDIDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CSDIDemoView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();


	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

HMENU CSDIDemoView::GetContextMenu( WORD, LPOLEOBJECT, CHARRANGE* )
{
    m_menu.DestroyMenu();

    if ( m_menu.LoadMenu( IDR_EDIT ) )
    {
        CMenu* pMenuPopup = m_menu.GetSubMenu( 0 );
        return pMenuPopup->Detach();
    }

    return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoView printing

BOOL CSDIDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CSDIDemoView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
   CRichEditView::OnDestroy();
}


/////////////////////////////////////////////////////////////////////////////
// CSDIDemoView diagnostics

#ifdef _DEBUG
void CSDIDemoView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CSDIDemoView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CSDIDemoDoc* CSDIDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSDIDemoDoc)));
	return (CSDIDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSDIDemoView message handlers
