// GuiLib.h : header file

#ifndef __GUILIB_H__
#define __GUILIB_H__

#include "resource.h"

#ifdef GUILIB_IMPL
    #define GUILIB_EXT_CLASS  _declspec( dllexport )
    #define GUILIB_EXT_API    _declspec( dllexport )
#else
    #define GUILIB_EXT_CLASS  _declspec( dllimport )
    #define GUILIB_EXT_API    _declspec( dllimport )
#endif

void GUILIB_EXT_API InitGuiLibDLL();

#endif // !__GUILIB_H__
