//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GuiLib.rc
//
#define IDB_PREVIEWSMALL_COLD           101
#define IDB_PREVIEWSMALL_HOT            102
#define IDC_BN_ACTIVATE                 103
#define IDC_BN_CASCADE                  104
#define IDC_BN_CLOSE_WIN                105
#define IDC_BN_MINIMIZE                 107
#define IDC_BN_SAVE                     111
#define IDC_BN_TILE_HORZ                113
#define IDC_BN_TILE_VERT                114
#define IDC_CB_ICONOPTIONS              115
#define IDC_CB_TEXTOPTIONS              116
#define IDC_LST_WINDOWS                 118
#define IDD_CUSTOMIZE                   120
#define IDD_WINDOW_LIST                 122
#define IDS_CUSTOMIZE                   142
#define IDS_IO_LARGEICONS               143
#define IDS_IO_SMALLICONS               144
#define IDS_LOCKTOOLBARS                145
#define IDS_SEPARATOR                   146
#define IDS_TO_NOTEXTLABELS             147
#define IDS_TO_TEXTLABELS               148
#define IDS_TO_TEXTONRIGHT              149
#define IDS_TOOLTIP_CLOSE               150
#define IDS_TOOLTIP_MAXIMIZE            151
#define IDS_TOOLTIP_MINIMIZE            152
#define IDS_TOOLTIP_RESTORE             153
#define IDS_WINDOW_LIST                 154
#define ID_CUSTOMIZE                    33001
#define ID_WINDOW_LIST                  33002
#define ID_LOCKTOOLBARS                 33003
#define IDW_MENUBAR                     0xE81A

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        59419
#define _APS_NEXT_COMMAND_VALUE         33004
#define _APS_NEXT_CONTROL_VALUE         155
#define _APS_NEXT_SYMED_VALUE           59519
#endif
#endif
