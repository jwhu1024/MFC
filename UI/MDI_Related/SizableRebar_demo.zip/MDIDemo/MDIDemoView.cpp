// MDIDemoView.cpp : implementation of the CMDIDemoView class
//

#include "stdafx.h"
#include "MDIDemo.h"

#include "MDIDemoDoc.h"
#include "MDIDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoView

IMPLEMENT_DYNCREATE(CMDIDemoView, CRichEditView)

BEGIN_MESSAGE_MAP(CMDIDemoView, CRichEditView)
	//{{AFX_MSG_MAP(CMDIDemoView)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoView construction/destruction

CMDIDemoView::CMDIDemoView()
{
	// TODO: add construction code here

}

CMDIDemoView::~CMDIDemoView()
{
    m_menu.DestroyMenu();
}

BOOL CMDIDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CMDIDemoView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();


	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

HMENU CMDIDemoView::GetContextMenu( WORD, LPOLEOBJECT, CHARRANGE* )
{
    m_menu.DestroyMenu();

    if ( m_menu.LoadMenu( IDR_EDIT ) )
    {
        CMenu* pMenuPopup = m_menu.GetSubMenu( 0 );
        return pMenuPopup->Detach();
    }

    return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoView printing

BOOL CMDIDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CMDIDemoView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
   CRichEditView::OnDestroy();
}


/////////////////////////////////////////////////////////////////////////////
// CMDIDemoView diagnostics

#ifdef _DEBUG
void CMDIDemoView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CMDIDemoView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CMDIDemoDoc* CMDIDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMDIDemoDoc)));
	return (CMDIDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoView message handlers
