// CntrItem.h : interface of the CMDIDemoCntrItem class
//

#if !defined(AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_)
#define AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMDIDemoDoc;
class CMDIDemoView;

class CMDIDemoCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CMDIDemoCntrItem)

// Constructors
public:
	CMDIDemoCntrItem(REOBJECT* preo = NULL, CMDIDemoDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CMDIDemoDoc* GetDocument()
		{ return (CMDIDemoDoc*)CRichEditCntrItem::GetDocument(); }
	CMDIDemoView* GetActiveView()
		{ return (CMDIDemoView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDIDemoCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CMDIDemoCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__B832DB65_5DB2_4C61_A463_4559C937AB00__INCLUDED_)
