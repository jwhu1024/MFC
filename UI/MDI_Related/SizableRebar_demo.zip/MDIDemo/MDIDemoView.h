// MDIDemoView.h : interface of the CMDIDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDIDEMOVIEW_H__0906AA6C_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
#define AFX_MDIDEMOVIEW_H__0906AA6C_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Preview.h"

class CMDIDemoView : public CPreviewableView< CRichEditView >
{
protected: // create from serialization only
	CMDIDemoView();
	DECLARE_DYNCREATE(CMDIDemoView)

// Attributes
public:
	CMDIDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDIDemoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual HMENU GetContextMenu(WORD seltype, LPOLEOBJECT lpoleobj, CHARRANGE* lpchrg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDIDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
    CMenu m_menu;

// Generated message map functions
protected:
	//{{AFX_MSG(CMDIDemoView)
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MDIDemoView.cpp
inline CMDIDemoDoc* CMDIDemoView::GetDocument()
   { return (CMDIDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDIDEMOVIEW_H__0906AA6C_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
