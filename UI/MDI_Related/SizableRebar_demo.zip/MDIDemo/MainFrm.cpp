// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "MDIDemo.h"

#include "MainFrm.h"

#include "GlobalData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTransparentDialogBar

IMPLEMENT_DYNAMIC( CTransparentDialogBar, CDialogBar )

CTransparentDialogBar::CTransparentDialogBar()
{
    m_bTransparent = true;
}

BEGIN_MESSAGE_MAP( CTransparentDialogBar, CDialogBar )
    ON_COMMAND( ID_TRANSPARENT, OnTransparent )
    ON_MESSAGE( WM_REBAR_CONTEXTMENU, OnReBarContextMenu )
    ON_WM_ERASEBKGND()
    ON_WM_MOVE()
    ON_WM_CTLCOLOR()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransparentDialogBar message handlers

void CTransparentDialogBar::OnTransparent() 
{
    m_bTransparent = !m_bTransparent;
    Invalidate();
}

LRESULT CTransparentDialogBar::OnReBarContextMenu( WPARAM wParam, LPARAM /*lParam*/ )
{
    CMenu* pMenu = ( CMenu* )wParam;
    ASSERT_VALID( pMenu );

    VERIFY( pMenu->AppendMenu( MF_STRING | ( m_bTransparent ? MF_CHECKED : MF_UNCHECKED ),
        ID_TRANSPARENT, _T("Transparent") ) );

    return 0L;
}

BOOL CTransparentDialogBar::OnEraseBkgnd( CDC* pDC )
{
    if ( m_bTransparent )
    {
        CWnd* pParent = GetParent();
        ASSERT_VALID( pParent );

        CPoint pt( 0, 0 );
        MapWindowPoints( pParent, &pt, 1 );
        pt = pDC->OffsetWindowOrg( pt.x, pt.y );
        LRESULT lResult = pParent->SendMessage( WM_ERASEBKGND, ( WPARAM )pDC->m_hDC, 0L );
        pDC->SetWindowOrg( pt.x, pt.y );
        return lResult;
    }

    return CDialogBar::OnEraseBkgnd( pDC );
}

void CTransparentDialogBar::OnMove( int x, int y )
{
    if ( m_bTransparent )
    {
        Invalidate();
    }
    else
    {
        CDialogBar::OnMove( x, y );
    }
}

HBRUSH CTransparentDialogBar::OnCtlColor( CDC* pDC, CWnd* pWnd, UINT nCtlColor )
{
    HBRUSH hbr = CDialogBar::OnCtlColor( pDC, pWnd, nCtlColor );

    if ( m_bTransparent && ( nCtlColor == CTLCOLOR_STATIC ) )
    {
        pDC->SetBkMode( TRANSPARENT );
        hbr = ( HBRUSH )::GetStockObject( NULL_BRUSH );
    }

    return hbr;
}

/////////////////////////////////////////////////////////////////////////////
// CMainToolBar

IMPLEMENT_DYNAMIC( CMainToolBar, CToolBarEx )

CMainToolBar::CMainToolBar()
{
}

void CMainToolBar::Init()
{
    static TBBUTTONEX tbButtons[] =
    {
        { {  0, ID_FILE_NEW,           TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  1, ID_FILE_OPEN,          TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_DROPDOWN, 0, 0 }, true },
        { {  2, ID_FILE_SAVE,          TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  0, 0,                     TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0 }, true },
        { {  6, ID_FILE_PRINT,         TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  7, ID_FILE_PRINT_PREVIEW, TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  0, 0,                     TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0 }, true },
        { {  3, ID_EDIT_CUT,           TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  4, ID_EDIT_COPY,          TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  5, ID_EDIT_PASTE,         TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  0, 0,                     TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0 }, true },
        { { 10, ID_TEXTOPTIONS,        TBSTATE_ENABLED, TBSTYLE_DROPDOWN | BTNS_WHOLEDROPDOWN, 0, 0 }, true },
        { { 11, ID_ICONOPTIONS,        TBSTATE_ENABLED, TBSTYLE_DROPDOWN | BTNS_WHOLEDROPDOWN, 0, 0 }, true },
        { {  9, ID_BACKGROUND,         TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, true },
        { {  0, 0,                     TBSTATE_ENABLED, TBSTYLE_SEP,    0, 0 }, false },
        { {  8, ID_APP_ABOUT,          TBSTATE_ENABLED, TBSTYLE_BUTTON, 0, 0 }, false }
    };

    SetBitmaps( IDB_TBSMALL_COLD, IDB_TBSMALL_HOT, ( UINT )-1,
        IDB_TBLARGE_COLD, IDB_TBLARGE_HOT, ( UINT )-1, ioLargeIcons );
    SetButtons( sizeof( tbButtons ) / sizeof( tbButtons[ 0 ] ), tbButtons, toTextOnRight );
}

bool CMainToolBar::HasButtonText( UINT nID )
{
    switch ( nID )
    {
        case ID_FILE_OPEN:
//        case ID_FILE_PRINT:
        case ID_EDIT_CUT:
        case ID_EDIT_COPY:
        case ID_EDIT_PASTE:
        case ID_BACKGROUND:
        case ID_TEXTOPTIONS:
        case ID_ICONOPTIONS:
        case ID_CUSTOMIZE:
            return true;

        default:
            return false;
    }
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWndEx)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_BACKGROUND, OnBackground)
	ON_UPDATE_COMMAND_UI(ID_BACKGROUND, OnUpdateBackground)
	ON_COMMAND(ID_TEXTOPTIONS, OnTextOptions)
	ON_COMMAND(ID_SHOW_TEXT_LABELS, OnShowTextLabels)
	ON_COMMAND(ID_TEXT_ON_RIGHT, OnTextOnRight)
	ON_COMMAND(ID_NO_TEXT_LABELS, OnNoTextLabels)
	ON_UPDATE_COMMAND_UI(ID_SHOW_TEXT_LABELS, OnUpdateShowTextLabels)
	ON_UPDATE_COMMAND_UI(ID_TEXT_ON_RIGHT, OnUpdateTextOnRight)
	ON_UPDATE_COMMAND_UI(ID_NO_TEXT_LABELS, OnUpdateNoTextLabels)
	ON_COMMAND(ID_ICONOPTIONS, OnIconOptions)
	ON_COMMAND(ID_SMALL_ICONS, OnSmallIcons)
	ON_COMMAND(ID_LARGE_ICONS, OnLargeIcons)
	ON_UPDATE_COMMAND_UI(ID_SMALL_ICONS, OnUpdateSmallIcons)
	ON_UPDATE_COMMAND_UI(ID_LARGE_ICONS, OnUpdateLargeIcons)
	ON_COMMAND(ID_LOCKTOOLBARS, OnLockToolbars)
	ON_UPDATE_COMMAND_UI(ID_LOCKTOOLBARS, OnUpdateLockToolbars)
	ON_COMMAND(ID_CUSTOMIZE, OnCustomize)
	ON_COMMAND(ID_VIEW_DIALOGBAR, OnViewDialogBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_DIALOGBAR, OnUpdateViewDialogBar)
	//}}AFX_MSG_MAP
    ON_NOTIFY(TBN_DROPDOWN, AFX_IDW_TOOLBAR, OnDropDown)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
    m_hbmBack     = 0;
	m_bBackground = false;
}

CMainFrame::~CMainFrame()
{
    if ( m_hbmBack != 0 )
    {
        VERIFY( ::DeleteObject( m_hbmBack ) );
    }
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    if ( !m_wndToolBar.Create( this,
            WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP | CBRS_FLYBY ) )
    {
        TRACE0("Failed to create toolbar(s)\n");
        return -1;      // fail to create
    }

    m_wndToolBar.ModifyStyle( 0, CCS_ADJUSTABLE );

    if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, CBRS_ALIGN_TOP | CBRS_HIDE_INPLACE, AFX_IDW_DIALOGBAR))
    {
        TRACE0("Failed to create dialogbar\n");
        return -1;      // fail to create
    }

    if ( !m_wndReBar.AddBar(&m_wndToolBar,
            0, 0, RBBS_FIXEDBMP | RBBS_BREAK, _T("&Toolbar"), false) ||
         !m_wndReBar.AddBar(&m_wndDlgBar,
            0, 0, RBBS_FIXEDBMP | RBBS_BREAK, _T("&Dialog Bar"), false))
    {
        TRACE0("Failed to create rebar\n");
        return -1;      // fail to create
    }

    m_wndToolBar.Init();

    LPCTSTR lpszResourceName = MAKEINTRESOURCE( IDB_COOLBARBG );
    HINSTANCE hInstImageWell = AfxFindResourceHandle( lpszResourceName, RT_BITMAP );
    HRSRC hRsrcImageWell = ::FindResource( hInstImageWell, lpszResourceName, RT_BITMAP );
    ASSERT( hRsrcImageWell != 0 );
    m_hbmBack = AfxLoadSysColorBitmap( hInstImageWell, hRsrcImageWell );
    VERIFY( m_wndReBar.SetBkImage( m_bBackground ? CBitmap::FromHandle( m_hbmBack ) : 0 ) );

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

    m_wndToolBar.LoadState( _T("MainToolbarState2") );
    m_wndReBar.LoadState( _T("RebarState") );

    CWinAppEx* pApp = CWinAppEx::GetInstance();
    CMapUIntToInt mapIDToImage;
    mapIDToImage[ ID_FILE_NEW           ] = 0;
    mapIDToImage[ ID_FILE_OPEN          ] = 1;
    mapIDToImage[ ID_FILE_SAVE          ] = 2;
    mapIDToImage[ ID_EDIT_CUT           ] = 3;
    mapIDToImage[ ID_EDIT_COPY          ] = 4;
    mapIDToImage[ ID_EDIT_PASTE         ] = 5;
    mapIDToImage[ ID_FILE_PRINT         ] = 6;
    mapIDToImage[ ID_FILE_PRINT_PREVIEW ] = 7;
    mapIDToImage[ ID_APP_ABOUT          ] = 8;
    pApp->AddMenuIcon( mapIDToImage, IDB_TBSMALL_HOT );
    mapIDToImage.RemoveAll();

    mapIDToImage[ ID_WINDOW_NEW       ] = 0;
    mapIDToImage[ ID_WINDOW_CASCADE   ] = 1;
    mapIDToImage[ ID_WINDOW_TILE_HORZ ] = 2;
    mapIDToImage[ ID_WINDOW_LIST      ] = 3;
    mapIDToImage[ ID_EDIT_UNDO        ] = 4;
    mapIDToImage[ ID_EDIT_REDO        ] = 5;
    mapIDToImage[ ID_EDIT_FIND        ] = 6;
    pApp->AddMenuIcon( mapIDToImage, IDB_MENUS );
    mapIDToImage.RemoveAll();

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

void CMainFrame::OnDestroy() 
{
    m_wndToolBar.SaveState( _T("MainToolbarState2") );
    m_wndReBar.SaveState( _T("RebarState") );

	CMDIFrameWndEx::OnDestroy();
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWndEx::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::OnDropDown( NMHDR* pNotifyStruct, LRESULT* pResult )
{
    NMTOOLBAR* pNMToolBar = ( NMTOOLBAR* )pNotifyStruct;

    CMenu menu;
    CMenu* pPopup = 0;

    switch ( pNMToolBar->iItem )
    {
        case ID_FILE_OPEN:
            VERIFY( menu.LoadMenu( IDR_MRU ) );
            pPopup = menu.GetSubMenu( 0 );
            break;

        case ID_TEXTOPTIONS:
            VERIFY( menu.LoadMenu( IDR_TEXTOPTIONS ) );
            pPopup = menu.GetSubMenu( 0 );
            break;

        case ID_ICONOPTIONS:
            VERIFY( menu.LoadMenu( IDR_ICONOPTIONS ) );
            pPopup = menu.GetSubMenu( 0 );
            break;

        default:
            ASSERT( false );
            break;
    }

    if ( pPopup != 0 )
    {
        CRect rc;
        ::SendMessage( pNMToolBar->hdr.hwndFrom, 
            TB_GETRECT, pNMToolBar->iItem, ( LPARAM )&rc );
        rc.top = rc.bottom;
        ::ClientToScreen( pNMToolBar->hdr.hwndFrom, &rc.TopLeft() );
        pPopup->TrackPopupMenu( TPM_LEFTALIGN | TPM_LEFTBUTTON, rc.left, rc.top, this );
    }

    *pResult = TBDDRET_DEFAULT;
}

void CMainFrame::OnBackground() 
{
    m_bBackground = !m_bBackground;
    VERIFY( m_wndReBar.SetBkImage( m_bBackground ? CBitmap::FromHandle( m_hbmBack ) : 0 ) );
    VERIFY( m_wndReBar.RedrawWindow( 0, 0, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE | RDW_ALLCHILDREN ) );
}

void CMainFrame::OnUpdateBackground(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_bBackground ? 1 : 0 );
}

void CMainFrame::OnTextOptions() 
{
    // Do nothing :-)
}

void CMainFrame::OnShowTextLabels() 
{
    m_wndToolBar.SetTextOptions( toTextLabels );
}

void CMainFrame::OnTextOnRight() 
{
    m_wndToolBar.SetTextOptions( toTextOnRight );
}

void CMainFrame::OnNoTextLabels() 
{
    m_wndToolBar.SetTextOptions( toNoTextLabels );
}

void CMainFrame::OnUpdateShowTextLabels(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndToolBar.GetTextOptions() == toTextLabels ? 1 : 0 );
}

void CMainFrame::OnUpdateTextOnRight(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndToolBar.GetTextOptions() == toTextOnRight ? 1 : 0 );
}

void CMainFrame::OnUpdateNoTextLabels(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndToolBar.GetTextOptions() == toNoTextLabels ? 1 : 0 );
}

void CMainFrame::OnIconOptions() 
{
    // Do nothing :-)
}

void CMainFrame::OnSmallIcons() 
{
    m_wndToolBar.SetIconOptions( ioSmallIcons );
}

void CMainFrame::OnLargeIcons() 
{
    m_wndToolBar.SetIconOptions( ioLargeIcons );
}

void CMainFrame::OnUpdateSmallIcons(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndToolBar.GetIconOptions() == ioSmallIcons ? 1 : 0 );
}

void CMainFrame::OnUpdateLargeIcons(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndToolBar.GetIconOptions() == ioLargeIcons ? 1 : 0 );
}

void CMainFrame::OnLockToolbars() 
{
    m_wndReBar.Lock( !m_wndReBar.IsLocked() );
}

void CMainFrame::OnUpdateLockToolbars(CCmdUI* pCmdUI)
{
    pCmdUI->SetCheck( m_wndReBar.IsLocked() ? 1 : 0 );
}

void CMainFrame::OnCustomize() 
{
    m_wndToolBar.GetToolBarCtrl().Customize();
}

void CMainFrame::OnViewDialogBar() 
{
    ShowControlBar( &m_wndDlgBar, !m_wndDlgBar.IsVisible(), FALSE );
}

void CMainFrame::OnUpdateViewDialogBar(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck( m_wndDlgBar.IsVisible() ? 1 : 0 );
}
