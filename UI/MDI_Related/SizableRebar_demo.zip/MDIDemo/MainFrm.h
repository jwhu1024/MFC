// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__0906AA66_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
#define AFX_MAINFRM_H__0906AA66_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FrameWndEx.h"
#include "ToolBarEx.h"

/////////////////////////////////////////////////////////////////////////////
// CTransparentDialogBar

class CTransparentDialogBar : public CDialogBar
{
    DECLARE_DYNAMIC( CTransparentDialogBar )
public:
	CTransparentDialogBar();

// Implementation data
protected:
    bool m_bTransparent;

// Message map functions
protected:
    afx_msg void OnTransparent();
    afx_msg LRESULT OnReBarContextMenu( WPARAM wParam, LPARAM lParam );
    afx_msg BOOL OnEraseBkgnd( CDC* pDC );
    afx_msg void OnMove( int x, int y );
    afx_msg HBRUSH OnCtlColor( CDC* pDC, CWnd* pWnd, UINT nCtlColor );
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CMainToolBar

class CMainToolBar : public CToolBarEx
{
    DECLARE_DYNAMIC( CMainToolBar )
public:
    CMainToolBar();

// Overrides
public:
    virtual void Init();

protected:
    virtual bool HasButtonText( UINT nID );
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

class CMainFrame : public CMDIFrameWndEx
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar              m_wndStatusBar;
	CMainToolBar            m_wndToolBar;
	CTransparentDialogBar   m_wndDlgBar;
	HBITMAP                 m_hbmBack;
	bool                    m_bBackground;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnBackground();
	afx_msg void OnUpdateBackground(CCmdUI* pCmdUI);
	afx_msg void OnTextOptions();
	afx_msg void OnShowTextLabels();
	afx_msg void OnTextOnRight();
	afx_msg void OnNoTextLabels();
	afx_msg void OnUpdateShowTextLabels(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTextOnRight(CCmdUI* pCmdUI);
	afx_msg void OnUpdateNoTextLabels(CCmdUI* pCmdUI);
	afx_msg void OnIconOptions();
	afx_msg void OnSmallIcons();
	afx_msg void OnLargeIcons();
	afx_msg void OnUpdateSmallIcons(CCmdUI* pCmdUI);
	afx_msg void OnUpdateLargeIcons(CCmdUI* pCmdUI);
	afx_msg void OnLockToolbars();
	afx_msg void OnUpdateLockToolbars(CCmdUI* pCmdUI);
	afx_msg void OnCustomize();
	afx_msg void OnViewDialogBar();
	afx_msg void OnUpdateViewDialogBar(CCmdUI* pCmdUI);
	//}}AFX_MSG
    afx_msg void OnDropDown( NMHDR* pNotifyStruct, LRESULT* pResult );
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__0906AA66_242D_11D5_8C3B_0060B0EEE47F__INCLUDED_)
