// CntrItem.cpp : implementation of the CMDIDemoCntrItem class
//

#include "stdafx.h"
#include "MDIDemo.h"

#include "MDIDemoDoc.h"
#include "MDIDemoView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoCntrItem implementation

IMPLEMENT_SERIAL(CMDIDemoCntrItem, CRichEditCntrItem, 0)

CMDIDemoCntrItem::CMDIDemoCntrItem(REOBJECT* preo, CMDIDemoDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CMDIDemoCntrItem::~CMDIDemoCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CMDIDemoCntrItem diagnostics

#ifdef _DEBUG
void CMDIDemoCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CMDIDemoCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
