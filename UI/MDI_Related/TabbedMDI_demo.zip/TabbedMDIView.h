// TabbedMDIView.h : interface of the CTabbedMDIView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TABBEDMDIVIEW_H__F2216B43_D628_11D2_A7DC_525400DAF3CE__INCLUDED_)
#define AFX_TABBEDMDIVIEW_H__F2216B43_D628_11D2_A7DC_525400DAF3CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTabbedMDIView : public CView
{
protected: // create from serialization only
	CTabbedMDIView();
	DECLARE_DYNCREATE(CTabbedMDIView)

// Attributes
public:
	CTabbedMDIDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabbedMDIView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTabbedMDIView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTabbedMDIView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TabbedMDIView.cpp
inline CTabbedMDIDoc* CTabbedMDIView::GetDocument()
   { return (CTabbedMDIDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABBEDMDIVIEW_H__F2216B43_D628_11D2_A7DC_525400DAF3CE__INCLUDED_)
