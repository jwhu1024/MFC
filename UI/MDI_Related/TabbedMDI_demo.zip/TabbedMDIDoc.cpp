// TabbedMDIDoc.cpp : implementation of the CTabbedMDIDoc class
//

#include "stdafx.h"
#include "TabbedMDI.h"

#include "TabbedMDIDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIDoc

IMPLEMENT_DYNCREATE(CTabbedMDIDoc, CDocument)

BEGIN_MESSAGE_MAP(CTabbedMDIDoc, CDocument)
	//{{AFX_MSG_MAP(CTabbedMDIDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIDoc construction/destruction

CTabbedMDIDoc::CTabbedMDIDoc()
{
	// TODO: add one-time construction code here

}

CTabbedMDIDoc::~CTabbedMDIDoc()
{
}

BOOL CTabbedMDIDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIDoc serialization

void CTabbedMDIDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIDoc diagnostics

#ifdef _DEBUG
void CTabbedMDIDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTabbedMDIDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIDoc commands
