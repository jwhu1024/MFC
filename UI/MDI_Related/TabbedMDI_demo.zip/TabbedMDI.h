// TabbedMDI.h : main header file for the TABBEDMDI application
//

#if !defined(AFX_TABBEDMDI_H__F2216B39_D628_11D2_A7DC_525400DAF3CE__INCLUDED_)
#define AFX_TABBEDMDI_H__F2216B39_D628_11D2_A7DC_525400DAF3CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIApp:
// See TabbedMDI.cpp for the implementation of this class
//

class CTabbedMDIApp : public CWinApp
{
public:
	CTabbedMDIApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabbedMDIApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTabbedMDIApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABBEDMDI_H__F2216B39_D628_11D2_A7DC_525400DAF3CE__INCLUDED_)
