// TabbedMDIView.cpp : implementation of the CTabbedMDIView class
//

#include "stdafx.h"
#include "TabbedMDI.h"

#include "TabbedMDIDoc.h"
#include "TabbedMDIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIView

IMPLEMENT_DYNCREATE(CTabbedMDIView, CView)

BEGIN_MESSAGE_MAP(CTabbedMDIView, CView)
	//{{AFX_MSG_MAP(CTabbedMDIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIView construction/destruction

CTabbedMDIView::CTabbedMDIView()
{
	// TODO: add construction code here

}

CTabbedMDIView::~CTabbedMDIView()
{
}

BOOL CTabbedMDIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIView drawing

void CTabbedMDIView::OnDraw(CDC* pDC)
{
	CTabbedMDIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIView diagnostics

#ifdef _DEBUG
void CTabbedMDIView::AssertValid() const
{
	CView::AssertValid();
}

void CTabbedMDIView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTabbedMDIDoc* CTabbedMDIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTabbedMDIDoc)));
	return (CTabbedMDIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabbedMDIView message handlers
