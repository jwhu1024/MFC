// ToolBarXP.cpp : implementation file
//

#include "stdafx.h"
#include "ToolBarXP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolBarXP

CToolBarXP::CToolBarXP()
{
}

CToolBarXP::~CToolBarXP()
{
}


BEGIN_MESSAGE_MAP(CToolBarXP, CToolBarCtrl)
	//{{AFX_MSG_MAP(CToolBarXP)
	//}}AFX_MSG_MAP
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolBarXP message handlers

void CToolBarXP::OnCustomDraw( NMHDR * pNotifyStruct, LRESULT* result )
{
	LPNMCUSTOMDRAW lpNmDraw = (LPNMCUSTOMDRAW)pNotifyStruct;

}

BOOL CToolBarXP::LoadToolBar(UINT nID)
{
	if(!m_hWnd)return FALSE;

	HRSRC hRsrc = ::FindResource(AfxGetInstance(), MAKEINTRESOURCE(nID), RT_TOOLBAR);
	if (hRsrc == NULL)
		return FALSE;

	HGLOBAL hGlobal = LoadResource(GetInstance(), hRsrc);
	if (hGlobal == NULL)
		return FALSE;

	TOOLBAR_DATA* pData = (TOOLBAR_DATA*)LockResource(hGlobal);
	if (pData == NULL)
		return FALSE;

	BOOL bResult;
	TBBUTTON tbb;
	memset(&tbb,0,sizeof(TBBUTTON));
	tbb.iString = -1;
	int iImage = 0;

	for (int i = 0; i < pData->wItemCount; i++)
	{
		tbb.fsState = TBSTATE_ENABLED;
		tbb.idCommand = pData->items()[i];
		if(tbb.idCommand == 0)
		{
			tbb.fsStyle = TBSTYLE_SEP;
			tbb.iBitmap = -1;
		}
		else
		{
			tbb.fsStyle = TBSTYLE_BUTTON;
			tbb.iBitmap = iImage++;
		}

		bResult = AddButtons(1,&tbb);

		if(!bResult)return FALSE;
	}

	if(bResult)
	{
		TBADDBITMAP tbab;

		tbab.hInst = GetInstance();
		tbab.nID = nID;
		SendMessage(m_hWnd,TB_ADDBITMAP,(WPARAM)pData->wItemCount,(LPARAM)&tbab);
	}

	UnlockResource(hGlobal);
	FreeResource(hGlobal);

	return bResult;
}