// MenuBarXPAppDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MenuBarXPApp.h"
#include "MenuBarXPAppDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuBarXPAppDlg dialog

CMenuBarXPAppDlg::CMenuBarXPAppDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMenuBarXPAppDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMenuBarXPAppDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMenuBarXPAppDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMenuBarXPAppDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMenuBarXPAppDlg, CDialog)
	//{{AFX_MSG_MAP(CMenuBarXPAppDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_MENUCHAR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMenuBarXPAppDlg message handlers

BOOL CMenuBarXPAppDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CRect	rect;
	GetClientRect(rect);
	rect.bottom = rect.top + 20;

	m_wndMenuBar.Create(WS_CHILD | WS_VISIBLE | TBSTYLE_FLAT | TBSTYLE_LIST | CCS_NODIVIDER | CCS_NORESIZE, 
		rect, this , 20);
	m_wndMenuBar.LoadMenu(CreateMenuXP());

	m_wndToolBar.Create(WS_CHILD | WS_VISIBLE | TBSTYLE_FLAT | CCS_NODIVIDER | CCS_NORESIZE,
		rect, this, 21);
	m_wndToolBar.LoadToolBar(IDR_MAINFRAME);
	
	//Create a rebar and add the menubar in it, if you want to keep it simple or don't
	//like a rebar, just remove the next block of code
	m_wndReBar.Create(WS_CHILD | WS_VISIBLE | RBS_BANDBORDERS | WS_BORDER | RBS_AUTOSIZE | RBS_VARHEIGHT, 
		CRect(0, 0, 0, 0), this, 10);
	REBARBANDINFO	rbi;
	memset(&rbi, 0, sizeof(rbi));
	rbi.cbSize= sizeof(REBARBANDINFO);
	rbi.fMask= RBBIM_CHILD | RBBIM_CHILDSIZE | RBBIM_STYLE;
	rbi.fStyle= RBBS_GRIPPERALWAYS;
	rbi.cxMinChild= 300;
	rbi.cyMinChild= 20;
	rbi.cx= 300;
	rbi.hwndChild= (HWND)m_wndMenuBar;
	m_wndReBar.InsertBand(0, &rbi);
	
	rbi.cyMinChild = 24;
	rbi.hwndChild = (HWND)m_wndToolBar;
	m_wndReBar.InsertBand(1, &rbi);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMenuBarXPAppDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMenuBarXPAppDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMenuBarXPAppDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

CMenuXP* CMenuBarXPAppDlg::CreateMenuXP(void)
{
	CMenuXP	*pMenu = new CMenuXP;

	//You can unrecomment the next two line to load a normal menu
	//pMenu->LoadMenu(IDR_MAINMENU);
	//return pMenu;

	pMenu->CreatePopupMenu();

	CMenuXP	*pPopup;

	pPopup = new CMenuXP;
	pPopup->CreatePopupMenu();
	pPopup->AddSideBar(new CMenuXPSideBar(24, "MenuBarXP"));
	pPopup->AppendODMenu(0, new CMenuXPText(100, "&New", AfxGetApp()->LoadIcon(IDI_ICON1)));
	pPopup->AppendODMenu(0, new CMenuXPText(101, "&Open...", AfxGetApp()->LoadIcon(IDI_ICON2)));
	pPopup->AppendODMenu(0, new CMenuXPText(102, "&Save", AfxGetApp()->LoadIcon(IDI_ICON3)));
	pPopup->AppendODMenu(0, new CMenuXPSeparator());
	pPopup->AppendODMenu(0, new CMenuXPText(ID_APP_EXIT, "E&xit"));

	pMenu->AppendODPopup(0, pPopup, new CMenuXPText(1, "&File"));

	pPopup = new CMenuXP;
	pPopup->CreatePopupMenu();
	pPopup->SetBackColor(RGB(0xf2, 0xf2, 0xf2));
	pPopup->SetSelectedBarColor(RGB(0x00, 0xcc, 0xcc));
	pPopup->SetIconAreaColor(RGB(0xff, 0x99, 0x00));
	pPopup->SetMenuStyle(CMenuXP::STYLE_XP);
	pPopup->AppendODMenu(0, new CMenuXPText(200, "&Cut", AfxGetApp()->LoadIcon(IDI_ICON4)));
	pPopup->AppendODMenu(0, new CMenuXPText(201, "&Copy", AfxGetApp()->LoadIcon(IDI_ICON5)));
	pPopup->AppendODMenu(0, new CMenuXPText(202, "&Paste", AfxGetApp()->LoadIcon(IDI_ICON6)));

	CMenuXP	*pButtons = new CMenuXP;
	pButtons->CreatePopupMenu();
	pButtons->SetBackColor(RGB(0xf2, 0xf2, 0xf2));
	pButtons->SetSelectedBarColor(RGB(0x00, 0xcc, 0xcc));
	pButtons->SetMenuStyle(CMenuXP::STYLE_XP);

	pButtons->AppendODMenu(0, new CMenuXPButton(301, AfxGetApp()->LoadIcon(IDI_ICON4)));
	pButtons->AppendODMenu(0, new CMenuXPButton(302, AfxGetApp()->LoadIcon(IDI_ICON5)));
	pButtons->AppendODMenu(0, new CMenuXPButton(303, AfxGetApp()->LoadIcon(IDI_ICON6)));
	pButtons->Break();
	pButtons->AppendODMenu(0, new CMenuXPButton(304, AfxGetApp()->LoadIcon(IDI_ICON7)));
	pButtons->AppendODMenu(0, new CMenuXPButton(305, AfxGetApp()->LoadIcon(IDI_ICON8)));
	pButtons->AppendODMenu(0, new CMenuXPButton(306, AfxGetApp()->LoadIcon(IDI_ICON9)));
	pButtons->Break();
	pButtons->AppendODMenu(0, new CMenuXPButton(307, AfxGetApp()->LoadIcon(IDI_ICON10)));
	pButtons->AppendODMenu(0, new CMenuXPButton(308, AfxGetApp()->LoadIcon(IDI_ICON11)));
	pButtons->AppendODMenu(0, new CMenuXPButton(309, AfxGetApp()->LoadIcon(IDI_ICON12)));

	pPopup->AppendODPopup(0, pButtons, new CMenuXPText(203, "Buttons"));

	pMenu->AppendODPopup(0, pPopup, new CMenuXPText(2, "&Edit"));

	return pMenu;
}

LRESULT CMenuBarXPAppDlg::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
	// TODO: Add your message handler code here and/or call default
	if (m_wndMenuBar.OpenMenu(nChar))
		return -1;
	
	return CDialog::OnMenuChar(nChar, nFlags, pMenu);
}
