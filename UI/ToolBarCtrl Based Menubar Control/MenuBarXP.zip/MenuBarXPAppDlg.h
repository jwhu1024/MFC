// MenuBarXPAppDlg.h : header file
//

#if !defined(AFX_MENUBARXPAPPDLG_H__4DD5805F_B928_4154_B644_A58D8AC4711D__INCLUDED_)
#define AFX_MENUBARXPAPPDLG_H__4DD5805F_B928_4154_B644_A58D8AC4711D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MenuXP.h"
#include "MenuBarXP.h"
#include "ToolBarXP.h"
/////////////////////////////////////////////////////////////////////////////
// CMenuBarXPAppDlg dialog

class CMenuBarXPAppDlg : public CDialog
{
// Construction
public:
	CMenuBarXPAppDlg(CWnd* pParent = NULL);	// standard constructor

	CMenuBarXP	m_wndMenuBar;
	CReBarCtrl	m_wndReBar;
	CToolBarXP	m_wndToolBar;

	CMenuXP		*CreateMenuXP(void);

// Dialog Data
	//{{AFX_DATA(CMenuBarXPAppDlg)
	enum { IDD = IDD_MENUBARXPAPP_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMenuBarXPAppDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMenuBarXPAppDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MENUBARXPAPPDLG_H__4DD5805F_B928_4154_B644_A58D8AC4711D__INCLUDED_)
