#if !defined(AFX_SIMPLEOBJECT_H__B42F445A_C2A4_45EA_8343_8A3D28490E41__INCLUDED_)
#define AFX_SIMPLEOBJECT_H__B42F445A_C2A4_45EA_8343_8A3D28490E41__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SimpleObject.h : header file
//

#include "CmdTargetPlus.h"

/////////////////////////////////////////////////////////////////////////////
// SimpleObject command target

class SimpleObject : public CCmdTargetPlus
{
	DECLARE_DYNCREATE(SimpleObject)

	SimpleObject();           // protected constructor used by dynamic creation
	virtual ~SimpleObject();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SimpleObject)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(SimpleObject)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(SimpleObject)
	afx_msg long GetValue();
	afx_msg void SetValue(long nNewValue);
	afx_msg void AddValue(long Ammount);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
	DECLARE_EVENT_MAP()

	DECLARE_OLETYPELIB(SimpleObject)
public:
	enum {
	//{{AFX_DISP_ID(SimpleObject)
	dispidValue = 1L,
	dispidAddValue = 2L,
	eventidValueChanged = 1L,
	//}}AFX_DISP_ID
	};

	// Event maps
	//{{AFX_EVENT(SimpleObject)
	void FireValueChanged(long NewValue)
		{FireEvent(eventidValueChanged,EVENT_PARAM(VTS_I4), NewValue);}
	//}}AFX_EVENT

public:
	HRESULT GetClassID(LPCLSID pclsid);
private:
	long m_val;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEOBJECT_H__B42F445A_C2A4_45EA_8343_8A3D28490E41__INCLUDED_)
