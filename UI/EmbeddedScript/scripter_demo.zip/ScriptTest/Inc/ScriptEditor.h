// ScriptEditor.h : main header file for the SCRIPTEDITOR DLL
//

#if !defined(AFX_SCRIPTEDITOR_H__3CA465FC_17A9_4572_8079_68B07C067316__INCLUDED_)
#define AFX_SCRIPTEDITOR_H__3CA465FC_17A9_4572_8079_68B07C067316__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CScriptEditorApp
// See ScriptEditor.cpp for the implementation of this class
//

class CScriptEditorApp : public CWinApp
{
public:
	CScriptEditorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptEditorApp)
		virtual BOOL InitInstance();
		virtual int ExitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CScriptEditorApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

// Ole-initialization class.
class OleInitClass {
public:
   OleInitClass() {
      OleInitialize(NULL);
   }
   ~OleInitClass() {
      OleUninitialize();
   }
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCRIPTEDITOR_H__3CA465FC_17A9_4572_8079_68B07C067316__INCLUDED_)
