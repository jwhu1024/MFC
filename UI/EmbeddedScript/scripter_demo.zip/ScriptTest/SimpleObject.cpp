// SimpleObject.cpp : implementation file
//

#include "stdafx.h"
#include "ScriptTest.h"
#include "SimpleObject.h"
#include "ScriptTestTypes_i.c"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SimpleObject

IMPLEMENT_DYNCREATE(SimpleObject, CCmdTargetPlus)

SimpleObject::SimpleObject()
{
	m_piidEvents = &DIID_ISimpleObjectEvents;
	m_piidPrimary = &DIID_ISimpleObject;
}

SimpleObject::~SimpleObject()
{
}


void SimpleObject::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTargetPlus::OnFinalRelease();
}
HRESULT SimpleObject::GetClassID(LPCLSID pclsid)
{
	*pclsid = CLSID_SimpleObject;
	return NOERROR;
}
// Note: we add support for IID_ISimpleObject to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {025DCA7E-4D47-4C8E-B977-3A632811128D}
static const IID IID_ISimpleObject =
{ 0x25dca7e, 0x4d47, 0x4c8e, { 0xb9, 0x77, 0x3a, 0x63, 0x28, 0x11, 0x12, 0x8d } };

const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;

IMPLEMENT_OLETYPELIB(SimpleObject, LIBID_ScriptTestLib, _wVerMajor, _wVerMinor)



BEGIN_INTERFACE_MAP(SimpleObject, CCmdTargetPlus)
	INTERFACE_PART(SimpleObject, DIID_ISimpleObject, Dispatch)
END_INTERFACE_MAP()



BEGIN_MESSAGE_MAP(SimpleObject, CCmdTargetPlus)
	//{{AFX_MSG_MAP(SimpleObject)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(SimpleObject, CCmdTargetPlus)
	//{{AFX_DISPATCH_MAP(SimpleObject)
	DISP_PROPERTY_EX(SimpleObject, "Value", GetValue, SetValue, VT_I4)
	DISP_FUNCTION(SimpleObject, "AddValue", AddValue, VT_EMPTY, VTS_I4)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()



BEGIN_EVENT_MAP(SimpleObject, CCmdTargetPlus)
	//{{AFX_EVENT_MAP(SimpleObject)
	EVENT_CUSTOM("ValueChanged", FireValueChanged, VTS_I4)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()
/////////////////////////////////////////////////////////////////////////////
// SimpleObject message handlers

long SimpleObject::GetValue() 
{
	// TODO: Add your property handler here

	return m_val;
}

void SimpleObject::SetValue(long nNewValue) 
{
	// TODO: Add your property handler here
	m_val = nNewValue;
	FireValueChanged(m_val);
}

void SimpleObject::AddValue(long Ammount) 
{
	// TODO: Add your dispatch handler code here
	m_val += Ammount;
	FireValueChanged(m_val);
}
