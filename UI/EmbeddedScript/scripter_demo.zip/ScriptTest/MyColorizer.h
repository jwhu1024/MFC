// MyColorizer.h: interface for the CMyColorizer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCOLORIZER_H__65247A38_61A7_4D40_8AE0_F52819D0522D__INCLUDED_)
#define AFX_MYCOLORIZER_H__65247A38_61A7_4D40_8AE0_F52819D0522D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMyColorizer : public CColorizer  
{
public:
	CMyColorizer();
	virtual ~CMyColorizer();

};

#endif // !defined(AFX_MYCOLORIZER_H__65247A38_61A7_4D40_8AE0_F52819D0522D__INCLUDED_)
