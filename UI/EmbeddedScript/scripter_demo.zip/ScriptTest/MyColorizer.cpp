// MyColorizer.cpp: implementation of the CMyColorizer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScriptTest.h"
#include "MyColorizer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyColorizer::CMyColorizer()
{

}

CMyColorizer::~CMyColorizer()
{

}
