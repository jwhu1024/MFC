// ScriptTestDlg.h : header file
//
//{{AFX_INCLUDES()
#include "mediaplayer.h"
#include "commandbutton.h"
#include "tabstrip.h"
//}}AFX_INCLUDES

#if !defined(AFX_SCRIPTTESTDLG_H__6E2482E5_EA44_43E4_B912_5C21C4A5470F__INCLUDED_)
#define AFX_SCRIPTTESTDLG_H__6E2482E5_EA44_43E4_B912_5C21C4A5470F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Inc\Scripter.h"
/////////////////////////////////////////////////////////////////////////////
// CScriptTestDlg dialog

#include "SimpleObject.h"	// Added by ClassView
class CScriptTestDlg : public CDialog
{
// Construction
public:
	CScriptTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CScriptTestDlg)
	enum { IDD = IDD_SCRIPTTEST_DIALOG };
	
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CScriptTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	SimpleObject m_simpleObject;
	CScripter scripter;
	CMediaPlayer	m_mediaPlayer;
	CCommandButton	m_commandButton;
	CTabStrip	m_tabStrip;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCRIPTTESTDLG_H__6E2482E5_EA44_43E4_B912_5C21C4A5470F__INCLUDED_)
