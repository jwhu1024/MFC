// Scripter.h: interface for the CScripter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCRIPTER_H__586C9D53_2A23_421F_8FAD_F23FB6A79C53__INCLUDED_)
#define AFX_SCRIPTER_H__586C9D53_2A23_421F_8FAD_F23FB6A79C53__INCLUDED_

#include <afxtempl.h>


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define DllExport   __declspec( dllexport )

class DllExport CScripter : public CCmdTarget
{
	DECLARE_DYNCREATE(CScripter)
public:
	BOOL GetObjectMembers(CString expression,CStringArray &properties,CStringArray &methods);
	int errLine;
	BOOL GetObjectFuncParams(CString objectDef,CString &methodName,CStringArray &params);
	BOOL GetLangFuncParams(CString fName, CStringArray &params);
	BOOL IsLangFunction(CString t);
	BOOL IsObject(CString &t);
	BOOL m_bScriptIsRunning;
	BOOL m_bCapitalizeScript;
	BOOL IsLangKeyWord(CString &t);
	BOOL GetEventParams(CString objName,CString evntName,CStringArray &params);
	void StartScript();
	void StopScript();
	void GetScriptFunctions(CStringArray &functions);
	void GetScriptObjects(CStringArray &objects);

	void GetObjectEvents(CString objName,CStringArray &events);
	CString scriptText;
	BOOL CreateEngine(CString lang);
	void AddObject(CString objName, IDispatch * Object);
	void ResetScript();
	void LaunchEditor();
	CScripter();
	virtual ~CScripter();
	DECLARE_OLETYPELIB(CScripter)

protected:
	DECLARE_INTERFACE_MAP()
	// ActiveScriptSite Implementation
	BEGIN_INTERFACE_PART(ActiveScriptSite, IActiveScriptSite)
		STDMETHOD(GetLCID)(LCID*);
		STDMETHOD(GetItemInfo)(LPCOLESTR, DWORD, LPUNKNOWN*, LPTYPEINFO*);
        STDMETHOD(GetDocVersionString)(BSTR*);
        STDMETHOD(OnScriptTerminate)(const VARIANT*, const EXCEPINFO*);
        STDMETHOD(OnStateChange)(SCRIPTSTATE);
        STDMETHOD(OnScriptError)(IActiveScriptError*);
        STDMETHOD(OnEnterScript)();
        STDMETHOD(OnLeaveScript)();
	END_INTERFACE_PART(ActiveScriptSite)

	BEGIN_INTERFACE_PART(ActiveScriptSiteWindow, IActiveScriptSiteWindow)
		STDMETHOD(EnableModeless)(BOOL);
		STDMETHOD(GetWindow)(HWND*);
	END_INTERFACE_PART(ActiveScriptSiteWindow)
private:
	CString m_langName;
	ITypeInfo *m_plangTypeInfo;
	ITypeLib *m_plangTypeLib;
	bool m_bEngineCreated;

	IActiveScriptParse* m_axParse;
	IActiveScript* m_axScript;
	CMapStringToPtr mapNamedItems;


};

#endif // !defined(AFX_SCRIPTER_H__586C9D53_2A23_421F_8FAD_F23FB6A79C53__INCLUDED_)
