#if !defined(AFX_SCRIPTEDITORWND_H__4791BA4F_CCBD_48FA_BEF1_938E9C427E62__INCLUDED_)
#define AFX_SCRIPTEDITORWND_H__4791BA4F_CCBD_48FA_BEF1_938E9C427E62__INCLUDED_

#include "ColorEditWnd.h"	// Added by ClassView
#include "Colorizer.h"	// Added by ClassView
#include "Scripter.h"
#include "ComboBoxBold.h"
#include "IntelliTip.h"	// Added by ClassView
#include "IntelliList.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScriptEditorWnd.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CScriptEditorWnd dialog

class CScriptEditorWnd : public CDialog
{
// Construction
public:
	
	CScripter* pScripter;
	CString GetScriptText();
	void SetScriptText(CString text);
	CScriptEditorWnd(CWnd* pParent = NULL);   // standard constructor

// Dialog Data 
	//{{AFX_DATA(CScriptEditorWnd)
	enum { IDD = IDD_SCRIPTEDITOR };
	CComboBoxBold	m_eventsCmb;
	CComboBoxBold	m_objectsCmb;
	CButton	m_scriptStopBtn;
	CButton	m_scriptStartBtn;
	int		m_scriptState;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScriptEditorWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScriptEditorWnd)
	virtual BOOL OnInitDialog();
	afx_msg void OnScriptstart();
	afx_msg void OnScriptstop();
	afx_msg void OnClose();
	afx_msg void OnSelchangeObjects();
	afx_msg void OnDropdownEvents();
	afx_msg void OnSelchangeEvents();
	afx_msg void OnDestroy();
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcRButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcMButtonDown(UINT nHitTest, CPoint point);
	//}}AFX_MSG
	afx_msg void OnDblclkList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCurPosChangeEditClr(NMHDR* pNotifyStruct, LRESULT* plResult);
	afx_msg void OnCharEditClr(NMHDR* pNotifyStruct, LRESULT* plResult);
	afx_msg void OnChangeEditClr();
	afx_msg void OnScrollEditClr(NMHDR* pNotifyStruct, LRESULT* plResult);
	afx_msg void OnKeyDownEditClr(NMHDR* pNotifyStruct, LRESULT* plResult);
	afx_msg void OnCaretEditClr(NMHDR* pNotifyStruct, LRESULT* plResult);
	DECLARE_MESSAGE_MAP()
public:
	void HideList();
	void HideTip();
	bool m_bList;
	bool m_bTip;
	CIntelliList m_iList;
	CIntelliTip m_iTip;
private:
	CToolTipCtrl m_tooltip;
	void UpdateIntelliToolsPosition();
	CString GetPrevWord(CString line, int &pos);
	CString GetNextWord(CString line, int &pos);
	HICON m_hIcon;

	CStringList functions;
	CString m_scriptText;
	CColorizer m_colorizer;
	ColorEditWnd * m_pColorWnd;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCRIPTEDITORWND_H__4791BA4F_CCBD_48FA_BEF1_938E9C427E62__INCLUDED_)
