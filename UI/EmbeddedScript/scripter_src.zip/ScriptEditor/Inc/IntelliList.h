////////////////////////////////////////////////////////////////////////////////////////////////
// Class to display pop-up list of object's members 
// Derived from dialog which in turn contains CListCtrl
////////////////////////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTELLILIST_H__22A43AC4_E919_4F14_96A0_40D6BE696882__INCLUDED_)
#define AFX_INTELLILIST_H__22A43AC4_E919_4F14_96A0_40D6BE696882__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// IntelliList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIntelliList dialog

class CIntelliList : public CDialog
{

public:
	// Construction
	CIntelliList(CWnd* pParent = NULL);   // standard constructor
	void Create(CWnd *pParent);

public:
	// Selection functions
	void SelectPgDn();
	void SelectPgUp();
	void SelectFirst();
	void SelectLast();
	void SelectPrev();
	void SelectNext();
	void SelectString(CString str);


	// Helper functions
	void SetCursorPoint(CPoint pt);		// Update position
	void Hide();						// Hide Me
	void Show();						// Show Me
	void Clear();						// Clear the list
	CString GetObject();				// Get the name of current object
	void SetObject(CString objectName); // Set the name of current object
	void AddItem(CString str, bool isprop);	// Add item to the list
	
	// Public data members
	int col;					// The position of the dot in color edit window
	int line;					// The line at which the list was activated
	CString SelectedString;		// Current selected string
	
	
	// Dialog Data
	//{{AFX_DATA(CIntelliList)
	enum { IDD = IDD_ILIST };
	CListCtrl	m_list;
	//}}AFX_DATA
	
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntelliList)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CIntelliList)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int GetSelectedItem();
	void UpdatePosition();

	// Private data members 
	CString m_szObjectName;	// Holds the current object's name
	CWnd* m_pParent;		// The pointer to parent window (the color edit window)
	CPoint m_ptPosition;			// Holds the Top-Left corner point
	CImageList m_ilList;		// Image list for CListCtrl
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTELLILIST_H__22A43AC4_E919_4F14_96A0_40D6BE696882__INCLUDED_)
