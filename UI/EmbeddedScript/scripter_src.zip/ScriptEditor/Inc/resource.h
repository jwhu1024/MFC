//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScriptEditor.rc
//
#define ID_EDIT_WND                     101
#define IDR_EDIT_ACCELS                 129
#define IDR_COLOREDITCTX                130
#define IDD_SCRIPTEDITOR                1000
#define IDC_EDIT_FRAME                  1000
#define IDC_OBJECTS                     1001
#define IDC_EVENTS                      1002
#define IDI_MAINFRAME                   1004
#define IDC_SCRIPTSTART                 1006
#define IDC_SCRIPTSTOP                  1007
#define IDR_SCRIPTEDITOR                1008
#define IDI_OBJECT                      1009
#define IDI_EVENT                       1010
#define IDC_LIST1                       1010
#define IDD_ITOOLTIP                    1011
#define IDD_ILIST                       1012
#define IDI_METHOD                      1017
#define IDI_PROP                        1018
#define IDI_START                       1022
#define IDI_STOP                        1023
#define IDR_VBKEYWORDS                  1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1025
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           1009
#endif
#endif
