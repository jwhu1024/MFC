////////////////////////////////////////////////////////////////////////////////////////////////////
// Class for Pop-Up smart tooltip
// Derived from simple dialog window
////////////////////////////////////////////////////////////////////////////////////////////////////


#if !defined(AFX_INTELLITIP_H__E4FC2226_82ED_4C26_9B88_A7016ED0BC87__INCLUDED_)
#define AFX_INTELLITIP_H__E4FC2226_82ED_4C26_9B88_A7016ED0BC87__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IntelliTip.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIntelliTip dialog

class CIntelliTip : public CDialog
{
public:
	// Construction
	CIntelliTip(CWnd* pParent = NULL);   // standard constructor
	BOOL Create(CWnd *pParent);

public:
	int GetCurParam();


	// Helper functons 
	int GetNumParams();				// Returns number of parameters for the function
	CString GetFunction();			// Returns function name
	void SetCursorPoint(CPoint pt);	// Update position
	void SetCurParam(int cp);		// Change the parameter that is current
	void SetFunction(CString fName,CStringArray& params); // Set the data for tooltip
	void Hide();	// Hide Me
	void Show();	// Show Me

	// Public data members
	int col;  // Column at which the tip was activated
	int line; // Line at which the tip was activated
	
	
	// Dialog Data
	//{{AFX_DATA(CIntelliTip)
	enum { IDD = IDD_ITOOLTIP };
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	
	
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntelliTip)
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	
	// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CIntelliTip)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CWnd* m_pParent;
	void UpdatePosition(); 
	CFont regFont,boldFont; // Normal and bold fonts for the tooltip
	CPoint m_pt;			// TopLeft corner
	int m_curParam;			// The current parameter
	CStringArray m_fParams;
	CString m_fName;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTELLITIP_H__E4FC2226_82ED_4C26_9B88_A7016ED0BC87__INCLUDED_)
