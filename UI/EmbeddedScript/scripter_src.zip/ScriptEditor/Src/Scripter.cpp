// Scripter.cpp: implementation of the CScripter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ScriptEditor.h"
#include "Scripter.h"
#include <initguid.h> // Realizes CLSID definitions
#include "msscript.h" // defines CLSIDs for VBScript and JScript


#include "ScriptEditorWnd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// {DE12FB13-D158-4995-AA1F-4BEFE9EB6AAF}
const GUID CDECL BASED_CODE _tlid =
{ 0xde12fb13, 0xd158, 0x4995, { 0xaa, 0x1f, 0x4b, 0xef, 0xe9, 0xeb, 0x6a, 0xaf } };
static const IID IID_IScripter =
{ 0xde12fb13, 0xd158, 0x4995, { 0xaa, 0x1f, 0x4b, 0xef, 0xe9, 0xeb, 0x6a, 0xaf } };
static const GUID CLSID_Scripter =
{ 0xde12fb13, 0xd158, 0x4995, { 0xaa, 0x1f, 0x4b, 0xef, 0xe9, 0xeb, 0x6a, 0xaf } };



const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_DYNCREATE(CScripter, CCmdTarget)

CScripter::CScripter()
{
	m_bScriptIsRunning = FALSE;
	m_bEngineCreated = false;
	m_axParse = NULL;
	m_axScript = NULL;
	m_bCapitalizeScript = TRUE;
	errLine = -1;

}

CScripter::~CScripter()
{
	if (m_axParse)
		m_axParse->Release();
	if (m_axScript)
	{
		m_axScript->Close();
		m_axScript->Release();
	}
}


BEGIN_INTERFACE_MAP(CScripter, CCmdTarget)
	INTERFACE_PART(CScripter, IID_IActiveScriptSite, ActiveScriptSite)
	INTERFACE_PART(CScripter, IID_IActiveScriptSiteWindow, ActiveScriptSiteWindow)
	INTERFACE_PART(CScripter, IID_IScripter, Dispatch)
END_INTERFACE_MAP()

IMPLEMENT_OLETYPELIB(CScripter, _tlid, _wVerMajor, _wVerMinor)

void CScripter::LaunchEditor()
{	
	if (!m_bEngineCreated)
		return;

	AFX_MANAGE_STATE(AfxGetStaticModuleState( ));
	CScriptEditorWnd scriptEdit;
	scriptEdit.pScripter = this;
	scriptEdit.SetScriptText(scriptText);
	scriptEdit.DoModal();
	scriptText = scriptEdit.GetScriptText();
}

void CScripter::ResetScript()
{
	if (m_axParse)
		m_axParse->Release();
	if (m_axScript)
	{
		m_axScript->Close();
		m_axScript->Release();
	}
	mapNamedItems.RemoveAll();
	CreateEngine(m_langName);
}

void CScripter::AddObject(CString objName, IDispatch * Object)
{
	if (!m_bEngineCreated)
		return;
	mapNamedItems.SetAt(objName,Object);
	USES_CONVERSION;
	m_axScript->AddNamedItem(T2COLE(objName),SCRIPTITEM_ISVISIBLE | SCRIPTITEM_ISSOURCE | SCRIPTITEM_ISPERSISTENT);
}

BOOL CScripter::CreateEngine(CString lang)
{
	CoInitialize(NULL);
	HRESULT hr;
	m_langName = lang;
	if (lang == "VBScript")
	{
		hr = CoCreateInstance(CLSID_VBScript, NULL, CLSCTX_INPROC_SERVER, IID_IActiveScript, (void **)&m_axScript);
		if (FAILED(hr))
			return FALSE;
		hr = LoadTypeLib(L"vbscript.dll",&m_plangTypeLib);
		if (FAILED(hr))
			return FALSE;
		hr = m_plangTypeLib->GetTypeInfo(0,&m_plangTypeInfo);
		if (FAILED(hr))
			return FALSE;
	}
	else if (lang == "JScript")
	{
		return FALSE; // curently not implemented
		hr = CoCreateInstance(CLSID_JScript, NULL, CLSCTX_INPROC_SERVER, IID_IActiveScript, (void **)&m_axScript);
	}
	else
		return FALSE;
	if (FAILED(hr))
		// If this happens, the scripting engine is probably not properly registered
		return FALSE;
	
	// Script Engine must support IActiveScriptParse for us to use it
	hr = m_axScript->QueryInterface(IID_IActiveScriptParse, (void **)&m_axParse);
	if (FAILED(hr))
		goto Failure;

	hr = m_axScript->SetScriptSite(&m_xActiveScriptSite); // Our MFC-OLE interface implementation
	if (FAILED(hr))
		goto Failure;

	// InitNew the object:
	hr = m_axParse->InitNew();
	if (FAILED(hr))
		goto Failure;

	m_bEngineCreated = true;
	return TRUE;

Failure:
	if (m_axScript)
		m_axScript->Release();
	if (m_axParse)
		m_axParse->Release();

	// XX ActiveX Scripting XX
	return FALSE;
}






void CScripter::GetScriptObjects(CStringArray &objects)
{
	if (!m_bEngineCreated)
		return;
	POSITION pos;
	CString key;
	void* pa;

	for( pos = mapNamedItems.GetStartPosition(); pos != NULL; )
	{
		mapNamedItems.GetNextAssoc( pos, key, pa);
		objects.Add(key);
	}
}

void CScripter::GetScriptFunctions(CStringArray &functions)
{
	if (!m_bEngineCreated)
		return;
	USES_CONVERSION;
	LPDISPATCH pDisp;
	m_axScript->GetScriptDispatch(NULL,&pDisp);
	LPTYPEINFO ppti;
	pDisp->GetTypeInfo(0,0,&ppti);
	TYPEATTR *pta;
	ppti->GetTypeAttr(&pta);
	for (int i=0; i<pta->cFuncs; i++)
	{
		FUNCDESC* pfd;
		BSTR bstrNames[1];
		ppti->GetFuncDesc(i, &pfd);
		UINT numNames;
		ppti->GetNames(pfd->memid,bstrNames,1,&numNames);
		functions.Add(bstrNames[0]);
		SysFreeString(bstrNames[0]);
		ppti->ReleaseFuncDesc(pfd);
	}
	ppti->ReleaseTypeAttr(pta);
}


void CScripter::GetObjectEvents(CString objName,CStringArray &events)
{
	if (!m_bEngineCreated)
		return;
	USES_CONVERSION;
	LPTYPEINFO ppti;
	HRESULT hr = m_xActiveScriptSite.GetItemInfo(T2COLE(objName),SCRIPTINFO_ITYPEINFO,NULL,&ppti);
	if (FAILED(hr))
		return;

	TYPEATTR *pta;
	ppti->GetTypeAttr(&pta);

	LPTYPEINFO pprti;
	if (pta->cImplTypes < 2)
		return;
	
	HREFTYPE rt;
	ppti->GetRefTypeOfImplType(1,&rt);
	ppti->GetRefTypeInfo(rt,&pprti);
	TYPEATTR *prta;
	pprti->GetTypeAttr(&prta);
	for (int j=0; j<prta->cFuncs; j++)
	{
		FUNCDESC* pfd;
		pprti->GetFuncDesc(j, &pfd);
		CComBSTR bstrName;
		pprti->GetDocumentation(pfd->memid, &bstrName, NULL, NULL, NULL);
		events.Add(OLE2T(bstrName));
		pprti->ReleaseFuncDesc(pfd);
	}
	pprti->ReleaseTypeAttr(prta);	
	ppti->ReleaseTypeAttr(pta);

}

void CScripter::StopScript()
{
	if (!m_bEngineCreated)
		return;
	if (!m_bScriptIsRunning)
		return;
	if (m_axScript)
	{
		m_axScript->SetScriptState(SCRIPTSTATE_INITIALIZED);
	}

	m_bScriptIsRunning = FALSE;
}

void CScripter::StartScript()
{
	if (!m_bEngineCreated)
		return;
	HRESULT hr;
	EXCEPINFO    ei;
	if (m_bScriptIsRunning)
		return;
	m_bScriptIsRunning = TRUE;
	errLine = -1;
	hr = m_axScript->SetScriptState(SCRIPTSTATE_CONNECTED);

	BSTR bstrParseMe = scriptText.AllocSysString();
	hr = m_axParse->ParseScriptText(bstrParseMe, NULL, NULL, NULL, 0, 0, 0L, NULL, &ei);
	if (FAILED(hr) || errLine != -1)
	{
		TRACE("Parse failed\n");
		m_bScriptIsRunning = FALSE;
		return;
	}
	// Start the script running...
	
	if (FAILED(hr) || errLine != -1)
	{
		TRACE("SetScriptState to CONNECTED failed\n");
		m_bScriptIsRunning = FALSE;
		return;
	}
	
}


/////////////////////////////////////////////////////////////////////////////
// IActiveScriptSiteWindow Implementation

STDMETHODIMP_(ULONG) CScripter::XActiveScriptSiteWindow::AddRef()
{
    METHOD_PROLOGUE_EX_(CScripter, ActiveScriptSiteWindow)
    return pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG) CScripter::XActiveScriptSiteWindow::Release()
{
    METHOD_PROLOGUE_EX_(CScripter, ActiveScriptSiteWindow)
    return pThis->ExternalRelease();
}

STDMETHODIMP CScripter::XActiveScriptSiteWindow::QueryInterface(REFIID iid, LPVOID* ppvObj)
{
    METHOD_PROLOGUE_EX_(CScripter, ActiveScriptSiteWindow)
    return pThis->ExternalQueryInterface(&iid, ppvObj);
}

STDMETHODIMP CScripter::XActiveScriptSiteWindow::EnableModeless(BOOL fEnable)
{
    METHOD_PROLOGUE_EX_(CScripter, ActiveScriptSiteWindow)
	
	CWinApp* pApp = AfxGetApp();
	if (!pApp)
		return E_FAIL;

	pApp->EnableModeless(fEnable);
	return S_OK;
}

STDMETHODIMP CScripter::XActiveScriptSiteWindow::GetWindow(HWND* phWnd)
{
    METHOD_PROLOGUE_EX_(CScripter, ActiveScriptSiteWindow)

	CWnd* pWnd = AfxGetMainWnd();
	if (!pWnd)
		return E_FAIL;

	*phWnd = pWnd->GetSafeHwnd();
	if (*phWnd)
		return S_OK;
	else
		return E_FAIL;
}

/////////////////////////////////////////////////////////////////////////////
// IActiveScriptSite Implementation

STDMETHODIMP_(ULONG)CScripter::XActiveScriptSite::AddRef()
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
    return pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG)CScripter::XActiveScriptSite::Release()
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
    return pThis->ExternalRelease();
}

STDMETHODIMP CScripter::XActiveScriptSite::QueryInterface(
    REFIID iid, void FAR* FAR* ppvObj)
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
    return (HRESULT)pThis->ExternalQueryInterface(&iid, ppvObj);
}

STDMETHODIMP CScripter::XActiveScriptSite::GetLCID(LCID* plcid)
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)

	return E_NOTIMPL;
}

STDMETHODIMP CScripter::XActiveScriptSite::GetItemInfo(
            /* [in] */ LPCOLESTR pstrName,
            /* [in] */ DWORD dwReturnMask,
            /* [out] */LPUNKNOWN* ppiunkItem,
            /* [out] */LPTYPEINFO* ppti)
{
	HRESULT hr = S_OK; 

    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
	USES_CONVERSION;

	if (dwReturnMask & SCRIPTINFO_ITYPEINFO)
	{
		if (!ppti)
			return E_INVALIDARG;
		*ppti = NULL;
	}

	if (dwReturnMask & SCRIPTINFO_IUNKNOWN)
	{
		if (!ppiunkItem)
			return E_INVALIDARG;
		*ppiunkItem = NULL;
	}

	IDispatch* pDisp;

	if (!(pThis->mapNamedItems.Lookup(OLE2CT(pstrName), (void*&) pDisp)))
	{
		return TYPE_E_ELEMENTNOTFOUND;
	}
	LPUNKNOWN pUnk = pDisp;
	if (dwReturnMask & SCRIPTINFO_ITYPEINFO)
	{
		// Use IProvideClassInfo to get ITypeInfo of coclass!
		IProvideClassInfo *pci = NULL;
		hr = pUnk->QueryInterface(IID_IProvideClassInfo, (void**)&pci);
		if (SUCCEEDED(hr) && pci)
			hr = pci->GetClassInfo(ppti);
		if (FAILED(hr))
		{
			hr = pDisp->GetTypeInfo(0,0,ppti);
			if (FAILED(hr))
				return E_FAIL;
		}
	}
	
	if (dwReturnMask & SCRIPTINFO_IUNKNOWN)
	{
		*ppiunkItem = pUnk;
		(*ppiunkItem)->AddRef();    // because returning
	}

	return S_OK;
}

STDMETHODIMP CScripter::XActiveScriptSite::GetDocVersionString(LPBSTR pbstrVersion)
{
	METHOD_PROLOGUE(CScripter, ActiveScriptSite)

	return E_NOTIMPL;

}

STDMETHODIMP CScripter::XActiveScriptSite::OnScriptTerminate( 
            /* [in] */ const VARIANT* pvarResult,
            /* [in] */ const EXCEPINFO* pexcepinfo)
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)

	return S_OK;

}

STDMETHODIMP CScripter::XActiveScriptSite::OnStateChange( 
            /* [in] */ SCRIPTSTATE ssScriptState)
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
	CString state = "";
	switch (ssScriptState)
	{
	case 0:
		state = "SCRIPTSTATE_UNINITIALIZED";
		break;
	case 1:
		state = "SCRIPTSTATE_STARTED";
		break;
	case 2:
		state = "SCRIPTSTATE_CONNECTED";
		break;
	case 3:
		state = "SCRIPTSTATE_DISCONNECTED";
		break;
	case 4:
		state = "SCRIPTSTATE_CLOSED";
		break;
	case 5:
		state = "SCRIPTSTATE_INITIALIZED";
		break;

	}
	TRACE("New Script State %s\n",state);
	return S_OK;
}

STDMETHODIMP CScripter::XActiveScriptSite::OnScriptError( 
            /* [in] */ IActiveScriptError* pse)
{
	METHOD_PROLOGUE_EX(CScripter, ActiveScriptSite)

	EXCEPINFO ei;
	DWORD     dwSrcContext;
	ULONG     ulLine;
	LONG      ichError;
	BSTR      bstrLine = NULL;
	CString strError;

	pse->GetExceptionInfo(&ei);
	pse->GetSourcePosition(&dwSrcContext, &ulLine, &ichError);
	pse->GetSourceLineText(&bstrLine);
	
	CString desc;
	CString src;
	CString srcLine;

	desc = (LPCWSTR)ei.bstrDescription;
	src = (LPCWSTR)ei.bstrSource;
	srcLine = (LPCWSTR)bstrLine;
	
	

	
	strError.Format("%s\nError: %s\nIn line %d At column %d Error Code:%d\nSource line: %s", 
		src, desc, ulLine+1,ichError, (int)ei.wCode,srcLine);
	if (pThis->m_bScriptIsRunning)
		AfxMessageBox(strError);

	TRACE(strError);
	TRACE("\n");
	pThis->errLine = ulLine;
	return S_OK;
}

STDMETHODIMP CScripter::XActiveScriptSite::OnEnterScript()
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
	TRACE("OnEnterScript\n");

	return S_OK;
}

STDMETHODIMP CScripter::XActiveScriptSite::OnLeaveScript()
{
    METHOD_PROLOGUE(CScripter, ActiveScriptSite)
	TRACE("OnLeaveScript\n");

	return S_OK;
}

BOOL CScripter::GetEventParams(CString objName, CString evntName, CStringArray &params)
{
	if (!m_bEngineCreated)
		return FALSE;
	USES_CONVERSION;

	BSTR bstrNames[1];
	MEMBERID memId[1];

	BSTR bstrParams[20];
	UINT numParams;

	LPTYPEINFO ppti;
	m_xActiveScriptSite.GetItemInfo(T2COLE(objName),SCRIPTINFO_ITYPEINFO,NULL,&ppti);

	TYPEATTR *pta;
	ppti->GetTypeAttr(&pta);

	LPTYPEINFO pprti;
	if (pta->cImplTypes < 2)
		return FALSE;
	
	HREFTYPE rt;
	ppti->GetRefTypeOfImplType(1,&rt);
	ppti->GetRefTypeInfo(rt,&pprti);

	
	bstrNames[0] =T2OLE(evntName); 
	pprti->GetIDsOfNames(bstrNames,1,memId);
	
	pprti->GetNames(memId[0],bstrParams,20,&numParams);
	for (UINT i = 1; i < numParams; i++)
	{
		params.Add(bstrParams[i]);
		SysFreeString(bstrParams[i]);
	}
	ppti->ReleaseTypeAttr(pta);
	return TRUE;
}

BOOL CScripter::IsLangKeyWord(CString &t)
{
	USES_CONVERSION;
	BOOL found;
	CComBSTR name(t);
	m_plangTypeLib->IsName(name,0,&found);
	if (found)
	{
		t=name;
		return TRUE;
	}
	return FALSE;
}

BOOL CScripter::IsObject(CString &t)
{
	CStringArray objects;
	GetScriptObjects(objects);
	t.MakeUpper();
	for (int i = 0; i < objects.GetSize(); i++)
	{
		CString test = objects[i];
		test.MakeUpper();
		if (t == test)
		{
			t = objects[i];
			return TRUE;
		}
	}
	return FALSE;
}

BOOL CScripter::IsLangFunction(CString t)
{
	USES_CONVERSION;
	TYPEATTR *pta;
	m_plangTypeInfo->GetTypeAttr(&pta);
	
	for (int i = 0; i < pta->cFuncs; i++)
	{
		FUNCDESC* pfd;
		m_plangTypeInfo->GetFuncDesc(i, &pfd);
		CComBSTR bstrName,bstrTest(t);
		m_plangTypeInfo->GetDocumentation(pfd->memid, &bstrName, NULL, NULL, NULL);
		if (bstrTest == bstrName)
		{
			m_plangTypeInfo->ReleaseTypeAttr(pta);
			m_plangTypeInfo->ReleaseFuncDesc(pfd);
			return i;
		}
		m_plangTypeInfo->ReleaseFuncDesc(pfd);
	}
	m_plangTypeInfo->ReleaseTypeAttr(pta);
	return -1;
}

BOOL CScripter::GetLangFuncParams(CString fName,CStringArray &params)
{
	USES_CONVERSION;
	int index = IsLangFunction(fName);
	if (index <0)
		return FALSE;
	
	FUNCDESC* pfd;
	m_plangTypeInfo->GetFuncDesc(index, &pfd);
	
	BSTR bstrParams[20];
	UINT numParams;
	BOOL result = FALSE;
	m_plangTypeInfo->GetNames(pfd->memid,bstrParams,20,&numParams);
	for (UINT i = 1; i < numParams; i++)
	{
		CString str = bstrParams[i];
		if (i > pfd->cParams - pfd->cParamsOpt)
			str = "[" + str + "]";
		params.Add(str);
		SysFreeString(bstrParams[i]);
		result = TRUE;
	}
	m_plangTypeInfo->ReleaseFuncDesc(pfd);
	return result;
}

BOOL CScripter::GetObjectFuncParams(CString objectDef,CString &methodName, CStringArray &params)
{
	if (!m_bEngineCreated)
		return FALSE;
	USES_CONVERSION;
	VARIANT pVarRes;
	HRESULT hr;
	hr = m_axParse->ParseScriptText(T2OLE(objectDef),NULL,NULL,NULL,0,0,
		SCRIPTTEXT_ISEXPRESSION,&pVarRes,NULL);
	if (FAILED(hr))
		return FALSE;
	if (pVarRes.vt != VT_DISPATCH)
		return FALSE;
	IDispatch *pDisp = pVarRes.pdispVal;
	LPTYPEINFO ppti;
	pDisp->GetTypeInfo(0,0,&ppti);
	BSTR bstrNames[1];
	MEMBERID memId[1];

	BSTR bstrParams[20];
	UINT numParams;
	bstrNames[0] =T2OLE(methodName); 
	hr = ppti->GetIDsOfNames(bstrNames,1,memId);
	if (FAILED(hr))
		return FALSE;
	hr = ppti->GetNames(memId[0],bstrParams,20,&numParams);
	if (FAILED(hr))
		return FALSE;
	BOOL result = FALSE;
	for (UINT i = 1; i < numParams; i++)
	{
		params.Add(bstrParams[i]);
		SysFreeString(bstrParams[i]);
		result = TRUE;
	}
	return result;
}

BOOL CScripter::GetObjectMembers(CString expression, CStringArray &properties, CStringArray &methods)
{
	if (!m_bEngineCreated)
		return FALSE;
	USES_CONVERSION;
	VARIANT pVarRes;
	HRESULT hr;
	hr = m_axParse->ParseScriptText(T2OLE(expression),NULL,NULL,NULL,0,0,
		SCRIPTTEXT_ISEXPRESSION,&pVarRes,NULL);
	if (FAILED(hr))
		return FALSE;
	if (pVarRes.vt != VT_DISPATCH)
		return FALSE;
	IDispatch *pDisp = pVarRes.pdispVal;
	LPTYPEINFO ppti;
	pDisp->GetTypeInfo(0,0,&ppti);
	TYPEATTR *pta;
	ppti->GetTypeAttr(&pta);
	BOOL result = FALSE;
	int i;
	for (i=0; i<pta->cFuncs; i++)
	{
		FUNCDESC* pfd;
		ppti->GetFuncDesc(i, &pfd);
		if ((pfd->wFuncFlags & (FUNCFLAG_FRESTRICTED | 
			FUNCFLAG_FHIDDEN | FUNCFLAG_FNONBROWSABLE)) == 0)
		{
			CComBSTR bstrName;
			ppti->GetDocumentation(pfd->memid, &bstrName, NULL, NULL, NULL);
			CString str = OLE2T(bstrName);
			if (str[0] != '_')
			{
				if (pfd->invkind == INVOKE_FUNC)
				{
					methods.Add(OLE2T(bstrName));
					result = TRUE;
				}
				else if (pfd->invkind == INVOKE_PROPERTYGET)
				{
					properties.Add(str);
					result = TRUE;
				}
			}
		}
		ppti->ReleaseFuncDesc(pfd);
	}
	for (i = 0; i < pta->cVars; i++)
	{
		VARDESC* pvd;
		ppti->GetVarDesc(i, &pvd);
		if (pvd->varkind == VAR_DISPATCH && (pvd->wVarFlags & (VARFLAG_FHIDDEN | 
			VARFLAG_FRESTRICTED | VARFLAG_FNONBROWSABLE)) == 0   )
		{
			CComBSTR bstrName;
			ppti->GetDocumentation(pvd->memid, &bstrName, NULL, NULL, NULL);
			CString str = OLE2T(bstrName);
			if (str[0] != '_')
			{
				properties.Add(str);
				result = TRUE;
			}
		}
		ppti->ReleaseVarDesc(pvd);
	}
	ppti->ReleaseTypeAttr(pta);
	return result;
}
