/*********************************************************************

   Copyright (C) 2001 Smaller Animals Software, Inc.

   This software is provided 'as-is', without any express or implied
   warranty.  In no event will the authors be held liable for any damages
   arising from the use of this software.

   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute it
   freely, subject to the following restrictions:

   1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.

   2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.

   3. This notice may not be removed or altered from any source distribution.

   http://www.smalleranimals.com
   smallest@smalleranimals.com

   --------

   This code is based, in part, on:

      "Syntax Coloring Text Edit Window Class " - Randy More (9, May 1998)
      http://www.codeguru.com/editctrl/syntax_coloring.shtml

   Though probably only 5% of the original code remains.

**********************************************************************/

// Colorizer.cpp : implementation of the CColorizer class
//

#include "stdafx.h"
#include "Colorizer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////

CColorizer::CColorizer()
{
   m_bCompareCase = TRUE ;
}

/////////////////////////////////////////////////////////////////////////////

CColorizer::~CColorizer()
{
}

void CColorizer::SetLineColors(int lineNum, CString &csString, vector<COLORREF>& colors) 
{
	// nothing to do
	if (csString.GetLength() ==0) 
	{
		colors.clear();
		return;
	}
	
	// one COLORREF per input char
	colors.resize(csString.GetLength());
	
	// look for keywords
	
	CString word;
	word = csString;
	word.TrimLeft();
	word.TrimRight();
	word = word.Left(3);
	
	//set the line to all black
	int k = 0;
	int j = csString.GetLength();
	COLORREF color = NORMAL_COLOR;
	for(int i=0; i<j; i++)
	{
		if (csString[i] == '\'')
			color = COMMENT_COLOR;
		if (lineNum == pScripter->errLine)
			color = ERROR_COLOR;
		colors.at(i) = color;
	}
	
	// do keyword coloring and auto-case correction
	while(k<j)
	{
		// find "words" (sequences of alpha-numeric characters)
		word.Empty();
		while((k<j) && (!__iscsym(csString.GetAt(k))))
		{
			k++;
		}
		
		int s = k;
		while((k < j) && (__iscsym(csString.GetAt(k))))
		{
			word = word + csString.GetAt(k);
			k++;
		}
		
		int e = k;
		
		word.TrimLeft();
		word.TrimRight();
		
		if(IsKeyWord(word))
		{
			int l = 0;
			for(i=s; i<e; i++)
			{
				l++;
				if (colors.at(i) == NORMAL_COLOR)
					colors.at(i) = KEYWORD_COLOR;
			}
			if (pScripter->m_bCapitalizeScript)
			{
				FindWord(word);
				csString.Delete(s,e-s);
				csString.Insert(s,word);
			}
		}
		else if(pScripter->IsLangKeyWord(word))
		{
			int l = 0;
			for(i=s; i<e; i++)
			{
				l++;
				if (colors.at(i) == NORMAL_COLOR)
					colors.at(i) = FUNCTION_COLOR;
			}
			if (pScripter->m_bCapitalizeScript)
			{
				csString.Delete(s,e-s);
				csString.Insert(s,word);
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

BOOL CColorizer::IsKeyWord(CString & test)
{
   POSITION pos;
   if (m_bCompareCase)
   {
      CString t(test); t.MakeUpper();

      pos = m_szKeywords.Find(t);
   }
   else
   {
      pos = m_szKeywords.Find(test);
   }

   return (pos != NULL);
}

/////////////////////////////////////////////////////////////////////////////

void CColorizer::LoadKeywords(int resId)
{
	
	
	HRSRC hSource = FindResource(AfxGetResourceHandle(),MAKEINTRESOURCE(resId),"TEXTFILE");
	if (!hSource)
		return;
	DWORD dwSize = SizeofResource(AfxGetResourceHandle(), hSource);
	
	HGLOBAL hGlobal = LoadResource(AfxGetResourceHandle(), hSource);
	
	if (!hGlobal)
		return;
	
	char* pFile = (char*)LockResource(hGlobal);
	
	CString strTemp(pFile);
	CString t = "";
	for (int i = 0; i < strTemp.GetLength(); i++)
	{
		if (strTemp[i] == '\n')
		{
			m_szStrings.Add(t);
			if (m_bCompareCase)
				t.MakeUpper();
			m_szKeywords.AddTail(t);
			t = "";
		}	
		else if (strTemp[i] == '\r')
			continue;
		else
			t += strTemp[i];
	}
	
	
	FreeResource(hGlobal);
	
}


void CColorizer::FindWord(CString &t)
{
	for (int i = 0; i < m_szStrings.GetSize(); i++)
	{
		CString str = m_szStrings[i];
		str.MakeUpper();
		CString test = t;
		test.MakeUpper();
		if (test == str)
			t = m_szStrings[i];
	}
	
}
