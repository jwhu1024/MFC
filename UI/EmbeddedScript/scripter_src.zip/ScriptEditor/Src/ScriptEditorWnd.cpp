// ScriptEditorWnd.cpp : implementation file
//

#include "stdafx.h"
#include "ScriptEditor.h"
#include "ScriptEditorWnd.h"

#include "TokenEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define SCRIPT_START 0
#define SCRIPT_STOP 1
/////////////////////////////////////////////////////////////////////////////
// CScriptEditorWnd dialog


CScriptEditorWnd::CScriptEditorWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CScriptEditorWnd::IDD, pParent)
{
	//{{AFX_DATA_INIT(CScriptEditorWnd)
	m_scriptState = SCRIPT_STOP;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAINFRAME);
	pScripter = NULL;
	m_pColorWnd = NULL;
	m_bList = false;
	m_bTip = false;
}


void CScriptEditorWnd::DoDataExchange(CDataExchange* pDX)
{
	
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScriptEditorWnd)
	DDX_Control(pDX, IDC_EVENTS, m_eventsCmb);
	DDX_Control(pDX, IDC_OBJECTS, m_objectsCmb);
	DDX_Control(pDX, IDC_SCRIPTSTOP, m_scriptStopBtn);
	DDX_Control(pDX, IDC_SCRIPTSTART, m_scriptStartBtn);
	DDX_Radio(pDX, IDC_SCRIPTSTART, m_scriptState);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScriptEditorWnd, CDialog)
	//{{AFX_MSG_MAP(CScriptEditorWnd)
	ON_BN_CLICKED(IDC_SCRIPTSTART, OnScriptstart)
	ON_BN_CLICKED(IDC_SCRIPTSTOP, OnScriptstop)
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(IDC_OBJECTS, OnSelchangeObjects)
	ON_CBN_DROPDOWN(IDC_EVENTS, OnDropdownEvents)
	ON_CBN_SELCHANGE(IDC_EVENTS, OnSelchangeEvents)
	ON_WM_DESTROY()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCRBUTTONDOWN()
	ON_WM_NCMBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_NOTIFY(EN_CURPOSCHANGE,ID_EDIT_WND, OnCurPosChangeEditClr)
	ON_NOTIFY(EN_CHAR,ID_EDIT_WND, OnCharEditClr)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList)
	ON_EN_CHANGE(ID_EDIT_WND, OnChangeEditClr)
	ON_NOTIFY(EN_SCROLL, ID_EDIT_WND, OnScrollEditClr)
	ON_NOTIFY(WM_KEYDOWN, ID_EDIT_WND, OnKeyDownEditClr)
	ON_NOTIFY(EN_CARET, ID_EDIT_WND, OnCaretEditClr)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScriptEditorWnd message handlers

BOOL CScriptEditorWnd::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_scriptStartBtn.SetIcon((HICON)::LoadImage(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDI_START),IMAGE_ICON,16,16,0));
	m_scriptStopBtn.SetIcon((HICON)::LoadImage(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDI_STOP),IMAGE_ICON,16,16,0));
	if (!pScripter)
		return FALSE;
	CRect frameRect;
	GetDlgItem(IDC_EDIT_FRAME)->GetWindowRect(frameRect);
	ScreenToClient(frameRect);
	frameRect.InflateRect(-2,-2);
	long iTabSize = 4;   // number of spaces in a tab. tabs are always spaces.
	int iFontSize = 100; //font size * 10 (I.E. 100 = 10pt)
	CString csFontName = "Courier New";
	
	m_pColorWnd = new ColorEditWnd(this,			      // parent window
		frameRect,			   // initial size and position
		ID_EDIT_WND,	      // id value
		iTabSize,		
		iFontSize,		
		csFontName);
	m_iTip.Create(m_pColorWnd);
	m_iList.Create(m_pColorWnd);
	
	m_pColorWnd->SetColorizer(&m_colorizer);
	m_colorizer.LoadKeywords(IDR_VBKEYWORDS);
	m_colorizer.pScripter = pScripter;
	// put a little space between the chars
	m_pColorWnd->SetCharXSpacing(1);
	m_pColorWnd->SetHighlightColor(RGB(0,0,0));
	
	m_pColorWnd->SetReadOnly(false);
	m_pColorWnd->SetFocus();
	m_pColorWnd->LoadText(m_scriptText);
	CStringArray objNames;
	pScripter->GetScriptObjects(objNames);

	m_eventsCmb.SetIcon(IDI_EVENT);
	m_objectsCmb.SetIcon(IDI_OBJECT);

	for (int i = 0; i < objNames.GetSize(); i++)
		m_objectsCmb.AddString(objNames[i]);
	m_objectsCmb.SetCurSel(0);
	OnSelchangeObjects();
	if (pScripter->m_bScriptIsRunning)
	{
		GetDlgItem(IDC_SCRIPTSTOP)->EnableWindow(TRUE);
		GetDlgItem(IDC_SCRIPTSTART)->EnableWindow(FALSE);
	}
	m_tooltip.Create(this);
	m_tooltip.AddTool(GetDlgItem(IDC_SCRIPTSTOP),"Stop running script");
	m_tooltip.AddTool(GetDlgItem(IDC_SCRIPTSTART),"Run script");
	m_tooltip.AddTool(GetDlgItem(IDC_OBJECTS),"Known Objects");
	m_tooltip.AddTool(GetDlgItem(IDC_EVENTS),"Object Events");

	return FALSE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CScriptEditorWnd::OnScriptstart() 
{
	// TODO: Add your control notification handler code here
	pScripter->scriptText = GetScriptText();
	pScripter->StartScript();
	if (pScripter->m_bScriptIsRunning)
	{
		GetDlgItem(IDC_SCRIPTSTOP)->EnableWindow(TRUE);
		GetDlgItem(IDC_SCRIPTSTART)->EnableWindow(FALSE);
	}
	else
		m_pColorWnd->Recolorize();
}

void CScriptEditorWnd::OnScriptstop() 
{
	// TODO: Add your control notification handler code here
	pScripter->StopScript();
	if (!pScripter->m_bScriptIsRunning)
	{
		GetDlgItem(IDC_SCRIPTSTOP)->EnableWindow(FALSE);
		GetDlgItem(IDC_SCRIPTSTART)->EnableWindow(TRUE);
	}
}

void CScriptEditorWnd::SetScriptText(CString text)
{
	m_scriptText = text;
}

CString CScriptEditorWnd::GetScriptText()
{
	if (m_pColorWnd)
		m_pColorWnd->UnloadText(m_scriptText);
	return m_scriptText;
}

void CScriptEditorWnd::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_pColorWnd->UnloadText(m_scriptText);
	CDialog::OnClose();
}

void CScriptEditorWnd::OnSelchangeObjects() 
{
	// TODO: Add your control notification handler code here
	m_eventsCmb.ResetContent();
	CString objName = "";
	if (m_objectsCmb.GetCurSel() != -1)
		m_objectsCmb.GetLBText(m_objectsCmb.GetCurSel(),objName);
	CStringArray objEvents;
	pScripter->GetObjectEvents(objName,objEvents);

	for (int i = 0; i < objEvents.GetSize(); i++)
		m_eventsCmb.AddString(objEvents[i]);
	m_eventsCmb.SetCurSel(0);
	OnDropdownEvents();
}

void CScriptEditorWnd::OnDropdownEvents() 
{
	// TODO: Add your control notification handler code here
	if (m_eventsCmb.GetCount() == 0)
		return;
	for (int i = 0; i < m_eventsCmb.GetCount(); i++)
		m_eventsCmb.SetItemBold(i,false);
	
	CString objName;
	m_objectsCmb.GetLBText(m_objectsCmb.GetCurSel(),objName);
	CString evntStr;
	for (i = 0; i < m_eventsCmb.GetCount(); i++)
	{
		m_eventsCmb.GetLBText(i,evntStr);
		evntStr = objName + "_" + evntStr;
		evntStr.MakeLower();
		for (int j = 0; j < m_pColorWnd->GetLineCount(); j++)
		{
			CString line = m_pColorWnd->GetLine(j);
			line.MakeLower();
			int sbF = line.Find("sub ",0);
			int evF = line.Find(evntStr,0);
			if (sbF != -1 && evF != -1 && sbF+4 && evF)
				m_eventsCmb.SetItemBold(i,true);
		}
	}
}

void CScriptEditorWnd::OnSelchangeEvents() 
{
	// TODO: Add your control notification handler code here
	CString objName;
	m_objectsCmb.GetLBText(m_objectsCmb.GetCurSel(),objName);
	if (!m_eventsCmb.GetItemData(m_eventsCmb.GetCurSel()))
	{
		CString evntStr;
		m_eventsCmb.GetLBText(m_eventsCmb.GetCurSel(),evntStr);

		CStringArray evntParams;
		pScripter->GetEventParams(objName,evntStr,evntParams);

		CString str = "\nSub ";
		str += objName + "_";
		str += evntStr + "(";
		for (int i = 0; i < evntParams.GetSize(); i++)
		{
			str += evntParams[i];
			if (i < evntParams.GetSize()-1)
				str += ", ";
		}
		str += ")";
		str += "\n\nEnd Sub";
		CString text;
		m_pColorWnd->UnloadText(text);
		text += str;
		m_pColorWnd->LoadText(text);
		m_pColorWnd->SetCursorPos(CPoint(0,m_pColorWnd->GetLineCount()-3));
		m_pColorWnd->SetAnchorPos(CPoint(0,m_pColorWnd->GetLineCount()-3));
		m_pColorWnd->ScrollToCursor();
		m_eventsCmb.SetItemBold(m_eventsCmb.GetCurSel(),true);
		m_pColorWnd->SetFocus();
	}
	else
	{
		CString evntStr;
		m_eventsCmb.GetLBText(m_eventsCmb.GetCurSel(),evntStr);
		evntStr = objName + "_" + evntStr;
		evntStr.MakeLower();
		for (int i = 0; i < m_pColorWnd->GetLineCount(); i++)
		{
			CString line = m_pColorWnd->GetLine(i);
			line.MakeLower();
			
			if (line.Find(evntStr,0) != -1)
			{
				m_pColorWnd->SetCursorPos(CPoint(0,i+1));
				m_pColorWnd->SetAnchorPos(CPoint(0,i+1));
				if (i > m_pColorWnd->LastVisibleLine() || i < m_pColorWnd->FirstVisibleLine())
					m_pColorWnd->ScrollToLine(i);
				m_pColorWnd->SetFocus();
				break;
			}
		}
	}
}


void CScriptEditorWnd::OnCurPosChangeEditClr(NMHDR* pNotifyStruct, LRESULT* plResult) 
{
	if (!m_pColorWnd)
		return;
	LPNMCLRWND pnmmp = (LPNMCLRWND)pNotifyStruct;
	int line = pnmmp->code2;
	int col = pnmmp->code1;
	CString str = m_pColorWnd->GetLine(line);
	str.MakeLower();
	if (m_bTip) // tip is displayed so check for remove conditions
	{
		CString fName = m_iTip.GetFunction();
		fName.MakeLower();

		// if the line is different from the line on wich the tip was invoked, hide tip
		if (line != m_iTip.line)
		{
			HideTip();
			return;
		}
		// if the cursor on left of the original position on which the tip was invoked , hide
		if (col <= m_iTip.col)
		{
			HideTip();
			return;
		}
		// if the line does not contain oir function anymore, hide
		int tCol = m_iTip.col;
		CString test = GetNextWord(str,tCol);
		test.MakeLower();
		if (fName != test)
		{
			HideTip();
			return;
		}
		// if inside the function name 
		if (col > m_iTip.col && col <= m_iTip.col+fName.GetLength())
			m_iTip.SetCurParam(0);
		else
		{
			int curParam = 1;
			int numParams = m_iTip.GetNumParams();

			for (int i = m_iTip.col + fName.GetLength(); i < col && i < str.GetLength(); i++)
			{
				if (str[i] == ',')
					curParam++;
			}
			m_iTip.SetCurParam(curParam);
		}
	}
	if (m_bList) // list is displayed so check for remove conditions
	{
		// if the line is different from the line on wich the list was invoked, hide list
		if (line != m_iList.line)
		{
			HideList();
			return;
		}
		// if the cursor on left of the original position on which the list was invoked , hide
		if (col+1 <= m_iList.col)
		{
			HideList();
			return;
		}

	}
}
void CScriptEditorWnd::OnCharEditClr(NMHDR* pNotifyStruct, LRESULT* plResult) 
{
	LPNMCLRWND pnmmp = (LPNMCLRWND)pNotifyStruct;
	char nChar = pnmmp->code1;
	CPoint cPos = m_pColorWnd->GetCursorPos();
	CString line = m_pColorWnd->GetLine(cPos.y);
	CString word;
	CStringArray params,properties,methods;
	int column = cPos.x;

	if (m_bTip && nChar == ')') // valid chars to release the tip
	{
		HideTip();
		return;
	}
	if (m_bList && !__iscsym(nChar))
	{
		CString str = m_iList.SelectedString;
		if (str != "")
		{
			int pos = m_iList.col;
			GetNextWord(line,pos);
			m_pColorWnd->SetSelection(m_iList.col,m_iList.line,pos,m_iList.line);
			m_pColorWnd->ReplaceSelText(str);
			m_pColorWnd->SetCursorPos(CPoint(m_pColorWnd->GetCursorPos().x+1,m_pColorWnd->GetCursorPos().y));
			m_pColorWnd->SetAnchorPos(CPoint(m_pColorWnd->GetCursorPos().x+1,m_pColorWnd->GetCursorPos().y));
			cPos = m_pColorWnd->GetCursorPos();
			line = m_pColorWnd->GetLine(cPos.y);
			column = cPos.x;
		}
		HideList();
	}

	if (m_bTip)
		return;

	switch (nChar)
	{
	case ' ':        // Condition to pop Tip
	case '\t':
	case '(':
		{
			word = GetPrevWord(line,column);
			int l = word.GetLength();
			word.TrimLeft("()"); // trim any leading braskets
			column += l - word.GetLength();
			CString funcName;
			if (word.Find('.',0) != -1)  // could be an object function
			{
				column = word.ReverseFind('.');
				CString objectDef = word.Left(column);
				column++;
				funcName = word.Mid(column);
				if (!pScripter->GetObjectFuncParams(objectDef,funcName,params))
					return;
			}
			else
			{
				funcName = word;
				if (!pScripter->GetLangFuncParams(funcName,params))
					return;
			}
			m_iTip.SetFunction(funcName,params);			
			m_iTip.SetCurParam(1);
			m_iTip.line = cPos.y;
			m_iTip.col = column;
			m_bTip = true;
			UpdateIntelliToolsPosition();
			m_iTip.Show();	
			return;
		}
		break;
	case '.':  // Conditions to pop list
		{
			word = GetPrevWord(line,column);
			int l = word.GetLength();
			word.TrimLeft("()"); // trim any leading braskets
			column += l - word.GetLength();
			if (!pScripter->GetObjectMembers(word,properties,methods))
				return;
			m_iList.Clear();
			// Show List
			for (int i = 0; i < methods.GetSize(); i++)
			{
				m_iList.AddItem(methods[i],0);
			}
			for (i = 0; i < properties.GetSize(); i++)
			{
				m_iList.AddItem(properties[i],1);
			}
			m_iList.line = cPos.y;
			m_iList.col = cPos.x+1;
			m_iList.SetObject(word);
			m_bList = true;	
			UpdateIntelliToolsPosition();
			m_iList.Show();
		}
		break;
	}
}


CString CScriptEditorWnd::GetPrevWord(CString line, int &pos)
{
	
	int e = pos;
	//scroll back the spaces
	while (e > 0 && isspace(line[e-1]))
		e--;
	//got the word end
	int s = e;
	while (s > 0 && (__iscsym(line[s-1]) || strchr(".()",line[s-1]) != NULL))
		s--;
	//got the word start (including points if it's an part of object)
	CString word = line.Mid(s,e-s);
	pos = s;
	return word;
}
CString CScriptEditorWnd::GetNextWord(CString line, int &pos)
{
	
	int s = pos;
	while (s < line.GetLength() && __iscsym(line[s]))
		s++;
	//got the word end
	CString word = line.Mid(pos,s-pos);
	pos = s;
	return word;
}

void CScriptEditorWnd::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	if (m_pColorWnd)
	{
		delete m_pColorWnd;
		m_pColorWnd = NULL;
	}
}

void CScriptEditorWnd::OnDblclkList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) pNMHDR;
	CString str = m_iList.SelectedString;
	if (str == "")
		return;
	HideList();
	CString line = m_pColorWnd->GetLine(m_iList.line);
	CString word;
	int pos = m_iList.col;
	GetNextWord(line,pos);
	m_pColorWnd->SetSelection(m_iList.col,m_iList.line,pos,m_iList.line);
	m_pColorWnd->ReplaceSelText(str);
	*pResult = 0;
}

void CScriptEditorWnd::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	HideTip();
	HideList();
	CDialog::OnNcLButtonDown(nHitTest, point);
}

void CScriptEditorWnd::OnNcRButtonDown(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	HideTip();
	HideList();
	CDialog::OnNcRButtonDown(nHitTest, point);
}

void CScriptEditorWnd::OnNcMButtonDown(UINT nHitTest, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	HideTip();
	HideList();
	CDialog::OnNcMButtonDown(nHitTest, point);
}

void CScriptEditorWnd::OnChangeEditClr() 
{	
	if (!m_pColorWnd)
		return;
	if (m_pColorWnd->GetCursorPos().y == pScripter->errLine)
	{
		pScripter->errLine = -1;
		m_pColorWnd->Recolorize();
	}
	CPoint cPos = m_pColorWnd->GetCursorPos();
	CString line = m_pColorWnd->GetLine(cPos.y);
	if (m_bList)
	{
		int wdEnd = m_iList.col;
		CString word = GetNextWord(line,wdEnd);
		m_iList.SelectString(word);
	}
	OnDropdownEvents();
}

void CScriptEditorWnd::OnScrollEditClr(NMHDR* pNotifyStruct, LRESULT* plResult)
{
	UpdateIntelliToolsPosition();
}

void CScriptEditorWnd::UpdateIntelliToolsPosition()
{
	if (!m_pColorWnd)
		return;
	CPoint ptCaret = m_pColorWnd->GetCaretPos();
	CPoint ptCursor = m_pColorWnd->GetCursorPos();
	CRect rt = m_pColorWnd->GetLineRect(ptCursor.y);
	ptCaret.y += rt.Height();
	if (m_bList)
		m_iList.SetCursorPoint(ptCaret);
	if (m_bTip)
		m_iTip.SetCursorPoint(ptCaret);
}

void CScriptEditorWnd::HideTip()
{
	if (m_bTip)
	{
		m_bTip = false;
		m_iTip.Hide();
	}
}

void CScriptEditorWnd::HideList()
{
	if (m_bList)
	{
		m_bList = false;
		m_iList.Hide();
	}
}
void CScriptEditorWnd::OnKeyDownEditClr(NMHDR* pNotifyStruct, LRESULT* plResult) 
{
	LPNMCLRWND pnmmp = (LPNMCLRWND)pNotifyStruct;
	*plResult = 0;
	if (m_bList)
	{
		switch (pnmmp->code1)
		{
			case VK_UP: //up arrow
				m_iList.SelectPrev();
				break;
			case VK_DOWN: //down arrow
				m_iList.SelectNext();
				break;
			case VK_PRIOR: // pg up
				m_iList.SelectPgUp();
				break;
			case VK_NEXT: // pg down
				m_iList.SelectPgDn();
				break;
			case VK_ESCAPE:
				HideList();
				*plResult = 1;
			default:
				*plResult = 1;
				break;
		}
		return;
	}
	if (m_bTip && pnmmp->code1 == VK_ESCAPE)
		HideTip();
	*plResult = 1;
}
void CScriptEditorWnd::OnCaretEditClr(NMHDR* pNotifyStruct, LRESULT* plResult) 
{
	UpdateIntelliToolsPosition();
}


BOOL CScriptEditorWnd::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (pMsg->message == WM_MOUSEMOVE) // For tool tips
		m_tooltip.RelayEvent(pMsg);
	return CDialog::PreTranslateMessage(pMsg);
}
