// IntelliList.cpp : implementation file
//

#include "stdafx.h"
#include "ScriptEditor.h"
#include "IntelliList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntelliList dialog


CIntelliList::CIntelliList(CWnd* pParent /*=NULL*/)
	: CDialog(CIntelliList::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIntelliList)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CIntelliList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntelliList)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIntelliList, CDialog)
	//{{AFX_MSG_MAP(CIntelliList)
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, OnItemchangedList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIntelliList message handlers

BOOL CIntelliList::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ilList.Create(16,16,ILC_MASK,2,1);
	m_ilList.Add((HICON)::LoadImage(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDI_METHOD),IMAGE_ICON,16,16,0));
	m_ilList.Add((HICON)::LoadImage(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDI_PROP),IMAGE_ICON,16,16,0));

	m_list.SetImageList(&m_ilList,LVSIL_SMALL);

	m_list.SetExtendedStyle(m_list.GetExtendedStyle()|
		LVS_EX_FULLROWSELECT|LVS_EX_FLATSB);
	m_list.InsertColumn (0,"Col1",LVCFMT_LEFT,175);

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CIntelliList::Show()
{
	SelectedString = "";
	ShowWindow(SW_SHOW);
	m_pParent->SetFocus();
}

void CIntelliList::Hide()
{
	ShowWindow(SW_HIDE);
}

void CIntelliList::UpdatePosition()
{
	MoveWindow(m_ptPosition.x,m_ptPosition.y,200,100);
	Invalidate();
}

void CIntelliList::SetCursorPoint(CPoint pt)
{
	m_pParent->ClientToScreen(&pt);
	m_ptPosition = pt;
	UpdatePosition();
}

void CIntelliList::Create(CWnd *pParent)
{
	m_pParent = pParent;
	CDialog::Create(IDD_ILIST,pParent);
}

void CIntelliList::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (IsWindow(m_list.m_hWnd))
		m_list.MoveWindow(0,0,cx,cy);
}

void CIntelliList::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE) pNMHDR;
	Hide();
	NMHDR nm;
	nm.hwndFrom = m_list.m_hWnd;
	nm.idFrom = IDC_LIST1;
	nm.code = NM_DBLCLK;
	GetParent()->SendMessage(WM_NOTIFY,IDC_LIST1,(long)&nm);
	*pResult = 0;
}

void CIntelliList::AddItem(CString str, bool isprop)
{
	m_list.InsertItem(0,str,isprop);
}

void CIntelliList::SetObject(CString objectName)
{
	m_szObjectName = objectName;
}

CString CIntelliList::GetObject()
{
	return m_szObjectName;
}

void CIntelliList::Clear()
{
	m_list.DeleteAllItems();
}

void CIntelliList::OnOK() 
{
	// TODO: Add extra validation here
	Hide();
	NMHDR nm;
	nm.hwndFrom = m_list.m_hWnd;
	nm.idFrom = IDC_LIST1;
	nm.code = NM_DBLCLK;
	GetParent()->SendMessage(WM_NOTIFY,IDC_LIST1,(long)&nm);
}

void CIntelliList::SelectString(CString str)
{
	for (int i = 0; i < m_list.GetItemCount(); i++)
	{
		CString itemText = m_list.GetItemText(i,0);
		itemText.MakeUpper();
		str.MakeUpper();
		if (itemText.Find(str,0) == 0 && str != "")
		{
			m_list.SetItemState(i,LVIS_SELECTED,LVIS_SELECTED);
			m_list.EnsureVisible(i,FALSE);
			return;
		}
	}
	int iItem = GetSelectedItem();
	m_list.SetItemState(iItem,0,LVIS_SELECTED);
	SelectedString = "";
}

void CIntelliList::SelectNext()
{
	int selItem = GetSelectedItem();
	m_list.SetItemState( selItem+1,LVIS_SELECTED,LVIS_SELECTED);
	m_list.EnsureVisible(selItem+1,FALSE);
}

void CIntelliList::SelectPrev()
{
	int selItem = GetSelectedItem();
	m_list.SetItemState( selItem-1,LVIS_SELECTED,LVIS_SELECTED);
	m_list.EnsureVisible(selItem-1,FALSE);
}

void CIntelliList::SelectLast()
{
	m_list.SetItemState( m_list.GetItemCount()-1,LVIS_SELECTED,LVIS_SELECTED);
	m_list.EnsureVisible(m_list.GetItemCount()-1,FALSE);
}

void CIntelliList::SelectFirst()
{
	m_list.SetItemState( 0,LVIS_SELECTED,LVIS_SELECTED);
	m_list.EnsureVisible(0,FALSE);
}

int CIntelliList::GetSelectedItem()
{
	POSITION pos = m_list.GetFirstSelectedItemPosition();
	if (pos == NULL)
		return -1;
	return m_list.GetNextSelectedItem(pos);
}

void CIntelliList::SelectPgUp()
{
	int selItem = GetSelectedItem();
	if (selItem < 10)
		SelectFirst();
	else
	{
		m_list.SetItemState( selItem-10,LVIS_SELECTED,LVIS_SELECTED);
		m_list.EnsureVisible(selItem-10,FALSE);
	}
}

void CIntelliList::SelectPgDn()
{
	int selItem = GetSelectedItem();
	if (selItem + 10 > m_list.GetItemCount())
		SelectLast();
	else
	{
		m_list.SetItemState( selItem+10,LVIS_SELECTED,LVIS_SELECTED);
		m_list.EnsureVisible(selItem+10,FALSE);
	}
}

void CIntelliList::OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	if (pNMListView->uNewState & LVIS_SELECTED)
		SelectedString = m_list.GetItemText(pNMListView->iItem,0);
	*pResult = 0;
}
