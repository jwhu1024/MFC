// IntelliTip.cpp : implementation file
//

#include "stdafx.h"
#include "ScriptEditor.h"
#include "IntelliTip.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntelliTip dialog


CIntelliTip::CIntelliTip(CWnd* pParent /*=NULL*/)
	: CDialog(CIntelliTip::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIntelliTip)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CIntelliTip::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIntelliTip)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CIntelliTip, CDialog)
	//{{AFX_MSG_MAP(CIntelliTip)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIntelliTip message handlers

void CIntelliTip::Show()
{
	ShowWindow(SW_SHOW);
}

void CIntelliTip::Hide()
{
	ShowWindow(SW_HIDE);
}

void CIntelliTip::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rect;
	GetClientRect(&rect);
	dc.SetBkMode(TRANSPARENT);

	dc.FillRect(&rect,&CBrush(RGB(255,255,200)));

	CRect textRect(rect);
	textRect.DeflateRect(2,0);

	int curText = 0;

	if (curText == m_curParam)
		dc.SelectObject(boldFont);
	else
		dc.SelectObject(regFont);
	CString str = m_fName;
	dc.TextOut(textRect.left,textRect.top,str);
	CSize sz = dc.GetTextExtent(str);
	textRect.left += sz.cx;
	curText++;

	dc.SelectObject(regFont);

	dc.TextOut(textRect.left,textRect.top,"(");
	sz = dc.GetTextExtent("(");
	textRect.left += sz.cx;

	CSize spsz = dc.GetTextExtent(", ");

	for (int i = 0; i < m_fParams.GetSize(); i++)
	{
		str = m_fParams[i];
		if (curText == m_curParam)
			dc.SelectObject(boldFont);
		else
			dc.SelectObject(regFont);
		dc.TextOut(textRect.left,textRect.top,str);
		sz = dc.GetTextExtent(str);
		textRect.left += sz.cx;
		dc.SelectObject(regFont);
		if (i < m_fParams.GetSize()-1)
		{
			dc.TextOut(textRect.left,textRect.top,", ");
			textRect.left += spsz.cx;
		}
		curText++;
	}
	dc.TextOut(textRect.left,textRect.top,")");

	dc.FrameRect(&rect,&CBrush(RGB(0,0,0)));
	// Do not call CDialog::OnPaint() for painting messages
}

void CIntelliTip::SetFunction(CString fName,CStringArray &params)
{
	m_fName = fName;
	m_fParams.RemoveAll();
	for (int i = 0 ; i < params.GetSize(); i++)
		m_fParams.Add(params[i]);
	UpdatePosition();
}

void CIntelliTip::SetCurParam(int cp)
{
	m_curParam = cp;
	Invalidate();
}

void CIntelliTip::SetCursorPoint(CPoint pt)
{
	m_pParent->ClientToScreen(&pt);
	m_pt = pt;
	UpdatePosition();
}

BOOL CIntelliTip::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));       // zero out structure
	lf.lfHeight = 15;                      // request a 12-pixel-height font
	strcpy(lf.lfFaceName, "Arial");        // request a face name "Arial"
	VERIFY(regFont.CreateFontIndirect(&lf));  // create the font
	lf.lfWeight = FW_BOLD;
	VERIFY(boldFont.CreateFontIndirect(&lf));  // create the font
	GetDC()->SelectObject(regFont);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CIntelliTip::OnSetFocus(CWnd* pOldWnd) 
{
	//CDialog::OnSetFocus(pOldWnd);
	pOldWnd->SetFocus();
	// TODO: Add your message handler code here
	
}

void CIntelliTip::UpdatePosition()
{
	CString str = m_fName;
	str += "(";
	for (int i = 0 ; i < m_fParams.GetSize(); i++)
	{
		str += m_fParams[i];
		if (i < m_fParams.GetSize()-1)
			str += ", ";
	}
	str += ")";

	CDC *pDc = GetDC();
	pDc->SelectObject(regFont);
	CSize sz = pDc->GetTextExtent(str);
	MoveWindow(m_pt.x,m_pt.y,sz.cx+10,sz.cy+2);
	Invalidate();
}

BOOL CIntelliTip::Create(CWnd *pParent)
{
	m_pParent = pParent;
	return CDialog::Create(IDD_ITOOLTIP,pParent);
}

CString CIntelliTip::GetFunction()
{
	return m_fName;
}

int CIntelliTip::GetNumParams()
{	
	return m_fParams.GetSize();
}

int CIntelliTip::GetCurParam()
{
	return m_curParam;
}
