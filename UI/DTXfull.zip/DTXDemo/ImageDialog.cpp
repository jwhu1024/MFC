// ImageDialog.cpp : implementation file
//

#include "stdafx.h"
#include "DTXDemo.h"
#include "ImageDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageDialog dialog

CImageDialog::CImageDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CImageDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImageDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CImageDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImageDialog)
	DDX_Control(pDX, IDC_IMAGE, m_Image);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CImageDialog, CDialog)
	//{{AFX_MSG_MAP(CImageDialog)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageDialog message handlers

BOOL CImageDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_Image.SetShadowSize(9);
	m_Image.LoadBitmap(IDB_BITMAP1);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CImageDialog::OnButton2() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty()) 
		m_Image.LoadBitmap(m_FName);
}

void CImageDialog::OnButton1() 
{
	m_Image.LoadBitmap(IDB_BITMAP1);	
}
