// DTXDemoView.cpp : implementation of the CDTXDemoView class
//

#include "stdafx.h"
#include "DTXDemo.h"

#include "LabelDialog.h"
#include "EditDialog.h"
#include "ImageDialog.h"
#include "ComboDlg.h"
#include "BackgroundDlg.h"
#include "EmployeeDlg.h"
#include "myfriends.h"
#include "MyPrograms.h"
#include "NewCtrls.h"

#include "DTXDemoDoc.h"
#include "DTXDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int rw = 370, rh = 120;

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView

IMPLEMENT_DYNCREATE(CDTXDemoView, CView)

BEGIN_MESSAGE_MAP(CDTXDemoView, CView)
	//{{AFX_MSG_MAP(CDTXDemoView)
	ON_COMMAND(ID_LABELDEMO, OnLabeldemo)
	ON_COMMAND(ID_EDITDEMO, OnEditdemo)
	ON_COMMAND(ID_IMAGEDEMO, OnImagedemo)
	ON_COMMAND(ID_COMBOBOXES, OnComboboxes)
	ON_COMMAND(ID_BACKGROUND, OnBackground)
	ON_COMMAND(ID_EMPLOYEES, OnEmployees)
	ON_COMMAND(ID_MYFRIENDS, OnMyfriends)
	ON_COMMAND(ID_MYPROG, OnMyprog)
	ON_COMMAND(IDC_NEWCTLS, OnNewctls)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView construction/destruction

CDTXDemoView::CDTXDemoView()
{
	// TODO: add construction code here

}

CDTXDemoView::~CDTXDemoView()
{
}

BOOL CDTXDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView drawing

void CDTXDemoView::OnDraw(CDC* pDC)
{
	CDTXDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
	CRect rect, rect2;
	GetClientRect(&rect);
	
	rect2 = CRect((rect.Width() - rw) / 2, (rect.Height() - rh) / 2, 
				  (rect.Width() - rw) / 2 + rw, (rect.Height() - rh) / 2 + rh);

	pDC->Rectangle(&rect2);
	rect2.DeflateRect(1, 1);
	CBrush br(RGB(255, 255, 192));
	pDC->FillRect(&rect2, &br);
	
	rect2.DeflateRect(5, 5);
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(RGB(64, 0, 128));
	pDC->DrawText(_T("Database Toolbox Demo\nCopyright � 2001 C�neyt EL�BOL\n") \
		_T("http://server33.hypermart.net/celibol\nmail: celibol@alibaba.com\nor\ncelibol@hotmail.com"), 
		&rect2, DT_CENTER|DT_VCENTER);
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView printing

BOOL CDTXDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDTXDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDTXDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView diagnostics

#ifdef _DEBUG
void CDTXDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CDTXDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDTXDemoDoc* CDTXDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDTXDemoDoc)));
	return (CDTXDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoView message handlers

void CDTXDemoView::OnLabeldemo() 
{
	CWaitCursor w;
	CLabelDialog dlg;
	
	dlg.DoModal();
}

void CDTXDemoView::OnEditdemo() 
{
	CWaitCursor w;
	CEditDialog dlg;

	dlg.DoModal();
}

void CDTXDemoView::OnImagedemo() 
{
	CWaitCursor w;
	CImageDialog dlg;

	dlg.DoModal();	
}

void CDTXDemoView::OnComboboxes() 
{
	CWaitCursor w;
	CComboDlg dlg;

	dlg.DoModal();	
}

void CDTXDemoView::OnBackground() 
{
	CWaitCursor w;
	CBackgroundDlg dlg;	

	dlg.DoModal();
}

void CDTXDemoView::OnEmployees() 
{
	CWaitCursor w;
	CEmployeeDlg dlg;

	dlg.DoModal();	
}

void CDTXDemoView::OnMyfriends() 
{
	CWaitCursor w;
	CMyFriends dlg;

	dlg.DoModal();	
}

void CDTXDemoView::OnMyprog() 
{
	CWaitCursor w;
	CMyPrograms dlg;

	dlg.DoModal();	
}

void CDTXDemoView::OnNewctls() 
{
	CWaitCursor w;
	CNewCtrls	dlg;

	dlg.DoModal();
}
