#if !defined(AFX_COMBODLG_H__B470E050_8A05_4648_9DB7_7CE4DE62BF8C__INCLUDED_)
#define AFX_COMBODLG_H__B470E050_8A05_4648_9DB7_7CE4DE62BF8C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// combodlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComboDlg dialog

class CComboDlg : public CDialog
{
// Construction
public:
	CComboDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CComboDlg)
	enum { IDD = IDD_COMBODIALOG };
	CDTXSACComboBox		m_DTXSACComboBox;
	CDTXFlatACComboBox	m_FlatACCombo;
	CDTXACComboBox		m_ACCombo;
	CDTXComboBox		m_DTXCombo;
	CFlatComboBox		m_FlatCombo;
	CDTXLabel			m_CBXCaption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CComboDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void AddACEntry(CDTXACBase& nEntry);
	void AddComboStr(CComboBox& nCombo);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBODLG_H__B470E050_8A05_4648_9DB7_7CE4DE62BF8C__INCLUDED_)
