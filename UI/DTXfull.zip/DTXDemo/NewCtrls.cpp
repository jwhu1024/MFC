// NewCtrls.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdemo.h"
#include "NewCtrls.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNewCtrls dialog


CNewCtrls::CNewCtrls(CWnd* pParent /*=NULL*/)
	: CDialog(CNewCtrls::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNewCtrls)
	//}}AFX_DATA_INIT
}


void CNewCtrls::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewCtrls)
	DDX_Control(pDX, IDC_LISTCTRL, m_List);
	DDX_Control(pDX, IDC_DATECOMBO, m_DateCombo);
	DDX_Control(pDX, IDC_CALCCOMBO, m_CalcCombo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNewCtrls, CDialog)
	//{{AFX_MSG_MAP(CNewCtrls)
	ON_BN_CLICKED(IDC_CALCDLG, OnCalcdlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewCtrls message handlers

BOOL CNewCtrls::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_DateCtrl.SubclassDlgItem(IDC_DATECTRL, this);

	m_CalcCombo.SetShadowSize(4);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNewCtrls::OnCalcdlg() 
{
	CCalculatorDlg dlg;
	
	dlg.DoModal();
}
