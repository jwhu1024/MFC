//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DTXDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_NEWCONTROLS_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_DTXDEMTYPE                  129
#define IDD_EDITDIALOG                  131
#define IDB_BITMAP1                     132
#define IDD_BITMAPDIALOG                133
#define IDD_COMBODIALOG                 134
#define IDD_BGDIALOG                    135
#define IDD_EMPLOYEEDLG                 136
#define IDD_MYFRIENDS                   138
#define IDB_BITMAP2                     139
#define IDB_BITMAP3                     140
#define IDD_MYPROGRAMS                  141
#define IDD_LABELDIALOG                 230
#define IDC_DTXLABEL1                   1000
#define IDC_CALCCOMBO                   1000
#define IDC_DTXLABEL3                   1001
#define IDC_DTXLABEL2                   1002
#define IDC_LABEL                       1002
#define IDC_DTXLABEL4                   1003
#define IDC_EDIT1                       1003
#define IDC_LISTCTRL                    1003
#define IDC_DTXEDIT                     1004
#define IDC_BIRTHDAY                    1004
#define IDC_DTXEDIT2                    1005
#define IDC_WEBSITE                     1005
#define IDC_DATECOMBO                   1005
#define IDC_DTXEDIT3                    1006
#define IDC_COMBO3                      1006
#define IDC_EMAIL                       1006
#define IDC_DATECTRL                    1006
#define IDC_DTXEDIT6                    1007
#define IDC_COMBO4                      1007
#define IDC_ICQ                         1007
#define IDC_DTXEDIT4                    1008
#define IDC_COMBO5                      1008
#define IDC_REMARKS                     1008
#define IDC_DTXEDIT5                    1009
#define IDC_COMBO6                      1009
#define IDC_COMBO1                      1010
#define IDC_COMBO2                      1010
#define IDC_LIST1                       1011
#define IDC_CAPTIONSTATIC               1011
#define IDC_LIST2                       1012
#define IDC_IMAGE                       1013
#define IDC_BUTTON1                     1014
#define IDC_BUTTON2                     1015
#define IDC_LOADBTN                     1016
#define IDC_SAVEBTN                     1017
#define IDC_PICTUREWND                  1018
#define IDC_VIEWBTN                     1018
#define IDC_NAVIGATOR                   1019
#define IDC_DETAILSTATIC                1020
#define IDC_OCCUPATIONEDIT              1021
#define IDC_BIRTHDAYEDIT                1022
#define IDC_OPENDAYEDIT                 1023
#define IDC_NAMEEDIT                    1024
#define IDC_LOCATIONSTATIC              1025
#define IDC_ADDREDIT                    1026
#define IDC_CITYEDIT                    1027
#define IDC_STATEEDIT                   1028
#define IDC_ZIPEDIT                     1029
#define IDC_INTERESTSTATIC              1030
#define IDC_INTERESTSEDIT               1031
#define IDC_COMMUNICATIONSTATIC         1032
#define IDC_TELEPHONEEDIT               1033
#define IDC_EMAILEDIT                   1034
#define IDC_NAVIGATORSTATIC             1035
#define IDC_PICSTATIC                   1036
#define IDC_GENDERCOMBO                 1038
#define IDC_ALARMONBIRTHDAY             1039
#define IDC_NAME                        1040
#define IDC_PICTURESTATIC               1041
#define IDC_LOADBUTTON                  1042
#define IDC_SAVEBUTTON                  1043
#define IDC_GOWEB                       1044
#define IDC_SENDMAIL                    1045
#define IDC_SENDICQMESSAGE              1046
#define IDC_LANGCOMBO                   1050
#define IDC_USERCOMBO                   1051
#define IDC_CALCDLG                     1052
#define ID_EDITDEMO                     32771
#define ID_MYFRIENDS                    32772
#define ID_BACKGROUND                   32773
#define ID_BULLETS                      32774
#define ID_CARTOON                      32775
#define ID_LABELS                       32776
#define ID_IMAGEDEMO                    32777
#define ID_LABELDEMO                    32778
#define ID_COMBOBOXES                   32779
#define ID_EMPLOYEES                    32780
#define ID_MYPROG                       32781
#define IDC_NEWCTLS                     32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
