#if !defined(AFX_IMAGEDIALOG_H__83FFBEA6_9EF1_4B93_B60C_16E4F71476BE__INCLUDED_)
#define AFX_IMAGEDIALOG_H__83FFBEA6_9EF1_4B93_B60C_16E4F71476BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImageDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CImageDialog dialog

class CImageDialog : public CDialog
{
// Construction
public:
	CImageDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CImageDialog)
	enum { IDD = IDD_BITMAPDIALOG };
	CDTXImage	m_Image;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImageDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CImageDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton2();
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGEDIALOG_H__83FFBEA6_9EF1_4B93_B60C_16E4F71476BE__INCLUDED_)
