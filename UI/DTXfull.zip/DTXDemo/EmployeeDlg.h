#if !defined(AFX_EMPLOYEEDLG_H__9E22E262_622D_4B94_808F_75B041F983CF__INCLUDED_)
#define AFX_EMPLOYEEDLG_H__9E22E262_622D_4B94_808F_75B041F983CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EmployeeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEmployeeDlg dialog

class CEmployeeDlg : public CDialog
{
	CDTXDAOTable m_Table;
// Construction
public:
	CEmployeeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEmployeeDlg)
	enum { IDD = IDD_EMPLOYEEDLG };
	CDTXDBComboBox	m_Gender;
	CDTXDBEdit	m_Zip;
	CDTXDBEdit	m_Telephone;
	CDTXDBEdit	m_State;
	CDTXDBImage	m_Picture;
	CDTXDBEdit	m_Occupation;
	CDBNavigator m_Navigator;
	CDTXDBEdit	m_Name;
	CDTXLabel	m_Location;
	CDTXLabel	m_InterestLabel;
	CDTXDBEdit	m_Interest;
	CDTXDBEdit	m_Email;
	CDTXLabel	m_DetailLabel;
	CDTXLabel	m_CommLabel;
	CDTXDBEdit	m_City;
	CDTXDBMaskedEdit	m_OpenDay;
	CDTXDBMaskedEdit	m_BirthDay;
	CDTXDBEdit	m_Addr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmployeeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEmployeeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnLoadbtn();
	afx_msg void OnSavebtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void SetEditAttr(CDTXDBEdit& nEdit, CString nFldName);
	void SetLabelAttr(CDTXLabel& nLabel);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMPLOYEEDLG_H__9E22E262_622D_4B94_808F_75B041F983CF__INCLUDED_)
