// myfriends.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdemo.h"
#include "myfriends.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyFriends dialog


CMyFriends::CMyFriends(CWnd* pParent /*=NULL*/)
	: CDialog(CMyFriends::IDD, pParent),
	m_Table(NULL, _T("DTX.mdb"),  _T("MyFriends"))
{
	//{{AFX_DATA_INIT(CMyFriends)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_ImageList.Create(IDB_BITMAP3, 45, 1, RGB(255,0,255));
}


void CMyFriends::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyFriends)
	DDX_Control(pDX, IDC_SENDMAIL, m_SendMail);
	DDX_Control(pDX, IDC_SENDICQMESSAGE, m_SendICQ);
	DDX_Control(pDX, IDC_SAVEBUTTON, m_Save);
	DDX_Control(pDX, IDC_LOADBUTTON, m_Load);
	DDX_Control(pDX, IDC_GOWEB, m_GoWEB);
	DDX_Control(pDX, IDC_PICTURESTATIC, m_Picture);
	DDX_Control(pDX, IDC_NAVIGATORSTATIC, m_Navigator);
	DDX_Control(pDX, IDC_WEBSITE, m_WEBSite);
	DDX_Control(pDX, IDC_REMARKS, m_Remarks);
	DDX_Control(pDX, IDC_NAME, m_Name);
	DDX_Control(pDX, IDC_ICQ, m_ICQ);
	DDX_Control(pDX, IDC_EMAIL, m_Email);
	DDX_Control(pDX, IDC_BIRTHDAY, m_BirthDay);
	DDX_Control(pDX, IDC_ALARMONBIRTHDAY, m_Alarm);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyFriends, CDialog)
	//{{AFX_MSG_MAP(CMyFriends)
	ON_BN_CLICKED(IDC_LOADBUTTON, OnLoadbutton)
	ON_BN_CLICKED(IDC_SAVEBUTTON, OnSavebutton)
	ON_BN_CLICKED(IDC_GOWEB, OnGoweb)
	ON_BN_CLICKED(IDC_SENDMAIL, OnSendmail)
	ON_BN_CLICKED(IDC_SENDICQMESSAGE, OnSendicqmessage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyFriends message handlers

void CMyFriends::SetEditAttr(CDTXDBEdit &nEdit, CString nFldName)
{
	nEdit.SetUseControlColors(true);
	nEdit.SetEditField(nFldName);
	nEdit.SetTable(&m_Table);
}

BOOL CMyFriends::OnInitDialog() 
{
	CDialog::OnInitDialog();
/*
	CDAOTableCreator m_TestCreator;
	m_TestCreator.CreateDatabase(GetAppPath() + _T("DTX.mdb"), dbLangTurkish);

	m_TestCreator.AddField(_T("Name"), dbText, 32);
	m_TestCreator.AddField(_T("WEBSite"), dbText, 64);
	m_TestCreator.AddField(_T("EMail"), dbText, 64);
	m_TestCreator.AddField(_T("ICQ"), dbLong, 1);
	m_TestCreator.AddField(_T("Remarks"), dbMemo, 1);
	m_TestCreator.AddField(_T("AlarmOnBirthDay"), dbBoolean, 1);
	m_TestCreator.AddField(_T("BirthDay"), dbDate, 1);
	m_TestCreator.AddField(_T("Picture"), dbLongBinary, 0);
	m_TestCreator.CreateTable(_T("MyFriends"));
*/
	m_Table.SetTableName(GetAppPath() + _T("DTX.MDB"));
	m_Table.SetOwner(this);

	m_Name.SetEditField(_T("Name"));
	m_Name.SetTable(&m_Table);
	m_Name.SetControlColor(RGB(0, 160, 192));
	m_Name.SetBorderColor(RGB(0, 160, 192));
	m_Name.SetFocusColor(RGB(0, 160, 192));
	m_Name.SetFocusTextColor(RGB(0xFF, 0xFF, 0x00));
	m_Name.SetTextColor(RGB(255, 255, 255));
	m_Name.SetUseControlColors(true);
	m_Name.SetShadowSize(5);

	m_BirthDay.SetUseControlColors(true);
	m_BirthDay.SetEditField(_T("BirthDay"));
	m_BirthDay.SetTable(&m_Table);
	m_BirthDay.SetMask(_T("##/##/####"));

	m_ICQ.SetUseControlColors(true);
	m_ICQ.SetEditField(_T("ICQ"));
	m_ICQ.SetAttributes(0, false);
	m_ICQ.SetTable(&m_Table);

	SetEditAttr(m_WEBSite, _T("WEBSite"));
	SetEditAttr(m_Email, _T("EMail"));
	SetEditAttr(m_Remarks, _T("Remarks"));

	m_Alarm.SetEditField(_T("AlarmOnBirthDay"));
	m_Alarm.SetTable(&m_Table);

	m_Picture.SetEditField(_T("Picture"));
	m_Picture.SetTable(&m_Table);
	m_Picture.SetShadowSize(10);

	m_Navigator.SetTable(&m_Table);

	m_Table.OpenTable();

	m_Load.SetIcon(m_ImageList.ExtractIcon(0), CSize(45, 16));
	m_Save.SetIcon(m_ImageList.ExtractIcon(1), CSize(45, 16));
	m_SendMail.SetIcon(m_ImageList.ExtractIcon(2), CSize(45, 16));
	m_SendICQ.SetIcon(m_ImageList.ExtractIcon(3), CSize(45, 16));
	m_GoWEB.SetIcon(m_ImageList.ExtractIcon(4), CSize(45, 16));
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyFriends::OnLoadbutton() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty()) 
		m_Picture.LoadBitmap(m_FName);
}

void CMyFriends::OnSavebutton() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty() && !FileExist(m_FName)) 
	{
		WriteBlobToFile(m_FName, m_Table[_T("Picture")]);
	}
}

void CMyFriends::OnGoweb() 
{
	CString nFriendName = *m_Table[_T("Name")]->strVal,
			   nWebAddr = *m_Table[_T("WEBSite")]->strVal;

	AfxMessageBox(_T("I Will goto\n") + nFriendName + 
		_T("'s Web Page(") + nWebAddr + _T(")"));
	ShellExecute(GetSafeHwnd(), _T("open"), nWebAddr, NULL, NULL, SW_SHOWNORMAL);
}

void CMyFriends::OnSendmail() 
{
	CString nFriendName = *m_Table[_T("Name")]->strVal,
			   nMailAddr = *m_Table[_T("EMail")]->strVal;

	AfxMessageBox(_T("I Will send mail to\n") + nFriendName + 
		_T("(") + nMailAddr);
	ShellExecute(GetSafeHwnd(), _T("open"), _T("mailto:") + nMailAddr, NULL, NULL, SW_SHOWNORMAL);
}

void CMyFriends::OnSendicqmessage() 
{
	CString nFriendName = *m_Table[_T("Name")]->strVal;
	long UIN = m_Table[_T("ICQ")]->longVal;

	CString nMessage;
	nMessage.Format(_T("I Will send ICQ Message to %s(%d)\nBut this function not implemented yet"), nFriendName, UIN);
	AfxMessageBox(nMessage);
}