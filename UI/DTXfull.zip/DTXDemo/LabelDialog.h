#if !defined(AFX_LABELDIALOG_H__EBC2E86D_ECB6_4EC9_8759_EE2DCCA267E5__INCLUDED_)
#define AFX_LABELDIALOG_H__EBC2E86D_ECB6_4EC9_8759_EE2DCCA267E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LabelDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLabelDialog dialog

class CLabelDialog : public CDialog
{
// Construction
public:
	CLabelDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLabelDialog)
	enum { IDD = IDD_LABELDIALOG };
	CDTXLabel	m_Label4;
	CDTXLabel	m_Label3;
	CDTXLabel	m_Label2;
	CDTXLabel	m_Label1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLabelDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLabelDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LABELDIALOG_H__EBC2E86D_ECB6_4EC9_8759_EE2DCCA267E5__INCLUDED_)
