// EditDialog.cpp : implementation file
//

#include "stdafx.h"
#include "DTXDemo.h"
#include "EditDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditDialog dialog


CEditDialog::CEditDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CEditDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CEditDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditDialog)
	DDX_Control(pDX, IDC_LIST2, m_ListBox);
	DDX_Control(pDX, IDC_LIST1, m_ShadowList);
	DDX_Control(pDX, IDC_COMBO1, m_comboMasks);
	DDX_Control(pDX, IDC_DTXEDIT6, m_Edit6); // Numeric Edit
	DDX_Control(pDX, IDC_DTXEDIT5, m_Edit5); // Masked Edit
	DDX_Control(pDX, IDC_DTXEDIT4, m_Edit4); // History Edit
	DDX_Control(pDX, IDC_DTXEDIT3, m_Edit3); // Focused
	DDX_Control(pDX, IDC_DTXEDIT2, m_Edit2); // Without shadow
	DDX_Control(pDX, IDC_DTXEDIT, m_Edit1);
	DDX_Control(pDX, IDC_LABEL, m_Label);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditDialog, CDialog)
	//{{AFX_MSG_MAP(CEditDialog)
	ON_CBN_SELENDOK(IDC_COMBO1, OnSelendokCombo1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditDialog message handlers

BOOL CEditDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_Label.SetBorderColor(RGB(0, 0, 0));
	m_Label.SetShape(stRectangle);
	m_Label.SetControlColor(RGB(255, 255, 192));
	m_Label.SetTextColor(RGB(0, 0, 255));
	m_Label.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	m_Label.SetShadowSize(5);

	m_Edit1.SetControlColor(RGB(0, 160, 192));
	m_Edit1.SetBorderColor(RGB(0, 160, 192));
	m_Edit1.SetFocusColor(RGB(0, 160, 192));
	m_Edit1.SetFocusTextColor(RGB(0xFF, 0xFF, 0x00));
	m_Edit1.SetTextColor(RGB(255, 255, 255));
	m_Edit1.SetUseControlColors(true);
	m_Edit1.SetShadowSize(5);

	m_Edit2.SetDrawShadow(false);
	m_Edit3.SetUseControlColors(true);

	m_Edit4.AddACEntry( _T( "MSFT" ) );	
	m_Edit4.AddACEntry( _T( "RHAT" ) );	
	m_Edit4.AddACEntry( _T( "LNUX" ) );	
	m_Edit4.AddACEntry( _T( "AMD" ) );	
	m_Edit4.AddACEntry( _T( "FATAX" ) );	
	m_Edit4.AddACEntry( _T( "DELL" ) );	
	m_Edit4.AddACEntry( _T( "TDFX" ) );	
	m_Edit4.AddACEntry( _T( "NVDA" ) );	
	m_Edit4.AddACEntry( _T( "SANM" ) );	
	m_Edit4.AddACEntry( _T( "CSCO" ) );	
	m_Edit4.AddACEntry( _T( "This is a test" ) );
	m_Edit4.SetIgnoreChase(true);
	
    m_comboMasks.AddString ( _T("Decimal Test: ###.###.###.###") ) ;
    m_comboMasks.AddString ( _T("Thousands Test: ##,###.##") ) ;
    m_comboMasks.AddString ( _T("Time Test: ##:##") ) ;
    m_comboMasks.AddString ( _T("Date Test: ##/##/####") ) ;
    m_comboMasks.AddString ( _T("\\Alphanumeric Test: AAAAAAAAAA\\, AAAAAAAA") ) ;
    m_comboMasks.AddString ( _T("\\Alphabetic Test: ????????????????") ) ;
    m_comboMasks.AddString ( _T("Uppercase Test: >>>>>>> ????????") ) ;
    m_comboMasks.AddString ( _T("Lowercase Test: <<<<<<< ????????") ) ;
    m_comboMasks.AddString ( _T("Phone:(###)###-#### Ext:####") ) ;
    m_comboMasks.AddString ( _T("AAA-#######")                  ) ;
    m_comboMasks.AddString ( _T("&####-##-## ##\\:##\\:##")     ) ;
    m_comboMasks.SetCurSel ( 0 ) ;
	OnSelendokCombo1();

	m_ShadowList.SetBorderColor(RGB(0, 192, 255));
	m_ShadowList.SetUseControlColors(true);
	m_ShadowList.SetFocusColor(RGB(0xFF, 0xFF, 0x00));
	m_ShadowList.SetFocusTextColor(RGB(0, 0, 255));
	m_ShadowList.SetShadowSize(9);

	m_ListBox.SetBorderColor(RGB(0, 192, 255));
	m_ListBox.SetControlColor(RGB(0, 160, 192));
	m_ListBox.SetFocusColor(RGB(0, 160, 192));
	m_ListBox.SetFocusTextColor(RGB(0xFF, 0xFF, 0x00));
	m_ListBox.SetUseControlColors(true);
	m_ListBox.SetDrawShadow(false);

	AddListBoxItems(m_ListBox);
	AddListBoxItems(m_ShadowList);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEditDialog::OnSelendokCombo1() 
{
	int nSelected = m_comboMasks.GetCurSel() ;
    if ( nSelected >= 0 )
    {
        CString csNewMask ;
        m_comboMasks.GetLBText(nSelected, csNewMask) ;
        m_Edit5.SetMask(csNewMask) ;
    }
}

void CEditDialog::AddListBoxItems(CListBox& nBox)
{
	nBox.AddString( _T("DTX - Database Toolbox Ver. 1.0"));
	nBox.AddString( _T("Demo program"));
	nBox.AddString( _T("Copyright � 2001"));
	nBox.AddString( _T("by C�neyt EL�BOL"));
	nBox.AddString( _T("WEB: http://server33.hypermart.net/celibol"));
	nBox.AddString( _T("EMail: celibol@hotmail.com"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 2.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 3.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 4.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 5.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 6.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 7.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 8.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 9.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 10.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 11.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 12.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 13.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 14.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 15.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 16.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 17.0"));
	nBox.AddString( _T("DTX - Database Toolbox Ver. 18.0"));
}
