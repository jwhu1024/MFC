#if !defined(AFX_MYFRIENDS_H__A8F06476_BC93_4C3B_9810_140D1DE8859C__INCLUDED_)
#define AFX_MYFRIENDS_H__A8F06476_BC93_4C3B_9810_140D1DE8859C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// myfriends.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyFriends dialog

class CMyFriends : public CDialog
{
	CImageList m_ImageList;
	CDTXDAOTable m_Table;
// Construction
public:
	CMyFriends(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMyFriends)
	enum { IDD = IDD_MYFRIENDS };
	CCJFlatButton		m_SendMail;
	CCJFlatButton		m_SendICQ;
	CCJFlatButton		m_Save;
	CCJFlatButton		m_Load;
	CCJFlatButton		m_GoWEB;
	CDTXDBImage			m_Picture;
	CDBNavigator		m_Navigator;
	CDTXDBEdit			m_WEBSite;
	CDTXDBEdit			m_Remarks;
	CDTXDBEdit			m_Name;
	CDTXDBNumericEdit	m_ICQ;
	CDTXDBEdit			m_Email;
	CDTXDBMaskedEdit	m_BirthDay;
	CDBCheckBox			m_Alarm;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyFriends)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyFriends)
	virtual BOOL OnInitDialog();
	afx_msg void OnLoadbutton();
	afx_msg void OnSavebutton();
	afx_msg void OnGoweb();
	afx_msg void OnSendmail();
	afx_msg void OnSendicqmessage();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void SetEditAttr(CDTXDBEdit& nEdit, CString nFldName);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFRIENDS_H__A8F06476_BC93_4C3B_9810_140D1DE8859C__INCLUDED_)
