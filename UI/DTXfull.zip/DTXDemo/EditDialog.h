#if !defined(AFX_EDITDIALOG_H__5DFA6BB2_9106_4BC7_92A4_AE5BD392BFA5__INCLUDED_)
#define AFX_EDITDIALOG_H__5DFA6BB2_9106_4BC7_92A4_AE5BD392BFA5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditDialog dialog

class CEditDialog : public CDialog
{
// Construction
public:
	CEditDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEditDialog)
	enum { IDD = IDD_EDITDIALOG };
	CDTXListBox		m_ListBox;
	CDTXListBox		m_ShadowList;
	CDTXComboBox	m_comboMasks;
	CNumericEdit	m_Edit6;
	CDTXMaskedEdit	m_Edit5;
	CACEditCtrl		m_Edit4;
	CDTXEdit		m_Edit3;
	CDTXEdit		m_Edit2;
	CDTXEdit		m_Edit1;
	CDTXLabel		m_Label;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelendokCombo1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void AddListBoxItems(CListBox& nBox);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITDIALOG_H__5DFA6BB2_9106_4BC7_92A4_AE5BD392BFA5__INCLUDED_)
