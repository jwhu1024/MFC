// LabelDialog.cpp : implementation file
//

#include "stdafx.h"
#include "DTXDemo.h"
#include "LabelDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLabelDialog dialog


CLabelDialog::CLabelDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CLabelDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLabelDialog)
	//}}AFX_DATA_INIT
}


void CLabelDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLabelDialog)
	DDX_Control(pDX, IDC_DTXLABEL4, m_Label4);
	DDX_Control(pDX, IDC_DTXLABEL3, m_Label3);
	DDX_Control(pDX, IDC_DTXLABEL2, m_Label2);
	DDX_Control(pDX, IDC_DTXLABEL1, m_Label1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLabelDialog, CDialog)
	//{{AFX_MSG_MAP(CLabelDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLabelDialog message handlers

BOOL CLabelDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_Label1.SetBorderColor(RGB(0, 192, 255));
	m_Label1.SetShape(stRectangle);
	m_Label1.SetControlColor(RGB(0, 192, 255));
	m_Label1.SetTextColor(RGB(0, 0, 255));
	m_Label1.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	m_Label1.SetShadowSize(5);
	
	m_Label2.SetBorderColor(RGB(0, 192, 255));
	m_Label2.SetShape(stRoundRect);
	m_Label2.SetControlColor(RGB(0xFF, 0xFF, 0xFF));
	m_Label2.SetTextColor(0);
	m_Label2.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);

	m_Label3.SetBorderColor(RGB(0, 0, 0));
	m_Label3.SetShape(stEllipse);
	m_Label3.SetControlColor(RGB(255, 255, 192));
	m_Label3.SetTextColor(RGB(0, 0, 255));
	m_Label3.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	m_Label3.SetDrawShadow(false);


	m_Label4.SetBorderColor(RGB(255, 255, 255));
	m_Label4.SetShape(stRectangle);
	m_Label4.SetControlColor(RGB(192, 0, 0));
	m_Label4.SetTextColor(RGB(255, 255, 255));
	m_Label4.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	m_Label4.SetShadowSize(10);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
