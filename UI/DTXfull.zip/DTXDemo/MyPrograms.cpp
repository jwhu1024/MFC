// MyPrograms.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdemo.h"
#include "MyPrograms.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPrograms dialog


CMyPrograms::CMyPrograms(CWnd* pParent /*=NULL*/)
	: CDialog(CMyPrograms::IDD, pParent),
	m_Table(NULL, _T("DTX.mdb"),  _T("MyPrograms"))
{
	//{{AFX_DATA_INIT(CMyPrograms)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyPrograms::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPrograms)
	DDX_Control(pDX, IDC_USERCOMBO, m_User);
	DDX_Control(pDX, IDC_REMARKS, m_Remarks);
	DDX_Control(pDX, IDC_PICTURESTATIC, m_ScreenShot);
	DDX_Control(pDX, IDC_NAVIGATORSTATIC, m_Navigator);
	DDX_Control(pDX, IDC_NAMEEDIT, m_Name);
	DDX_Control(pDX, IDC_LANGCOMBO, m_Lang);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPrograms, CDialog)
	//{{AFX_MSG_MAP(CMyPrograms)
	ON_BN_CLICKED(IDC_LOADBTN, OnLoadbtn)
	ON_BN_CLICKED(IDC_SAVEBTN, OnSavebtn)
	ON_BN_CLICKED(IDC_VIEWBTN, OnViewbtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyPrograms message handlers

BOOL CMyPrograms::OnInitDialog() 
{
	CDialog::OnInitDialog();
/*
	CDAOTableCreator m_TestCreator;
	m_TestCreator.CreateDatabase(GetAppPath() + _T("DTX.mdb"), dbLangTurkish);

	m_TestCreator.AddField(_T("Name"), dbText, 32);
	m_TestCreator.AddField(_T("User"), dbInteger, 0);
	m_TestCreator.AddField(_T("Language"), dbInteger, 0);
	m_TestCreator.AddField(_T("Remarks"), dbMemo, 1);
	m_TestCreator.AddField(_T("Picture"), dbLongBinary, 0);
	
	m_TestCreator.CreateTable(_T("MyPrograms"));
*/
	m_Table.SetTableName(GetAppPath() + _T("DTX.MDB"));
	m_Table.SetOwner(this);

	m_Name.SetEditField(_T("Name"));
	m_Name.SetTable(&m_Table);

	m_User.SetEditField(_T("User"));
	m_User.SetTable(&m_Table);

	m_Lang.SetEditField(_T("Language"));
	m_Lang.SetTable(&m_Table);

	m_Remarks.SetEditField(_T("Remarks"));
	m_Remarks.SetTable(&m_Table);

	m_ScreenShot.SetEditField(_T("Picture"));
	m_ScreenShot.SetTable(&m_Table);
	m_ScreenShot.SetShadowSize(10);

	m_Navigator.SetTable(&m_Table);
	m_Table.OpenTable();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMyPrograms::OnLoadbtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty()) 
		m_ScreenShot.LoadBitmap(m_FName);
}

void CMyPrograms::OnSavebtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty() && !FileExist(m_FName)) 
	{
		WriteBlobToFile(m_FName, m_Table[_T("Picture")]);
	}
}

void CMyPrograms::OnViewbtn() 
{
	char nTmpDir[256];
	GetTempPath(256, nTmpDir);

	CString nFileName;
	nFileName.Format(_T("%sDTX.JPG"), nTmpDir);
	WriteBlobToFile(nFileName, m_Table[_T("Picture")]);
	ShellExecute(GetSafeHwnd(), _T("open"), nFileName, NULL, NULL, SW_SHOWNORMAL);
}
