#if !defined(AFX_NEWCTRLS_H__21945282_9485_4F02_9320_7156D84AC18C__INCLUDED_)
#define AFX_NEWCTRLS_H__21945282_9485_4F02_9320_7156D84AC18C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewCtrls.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNewCtrls dialog

class CNewCtrls : public CDialog
{
// Construction
public:
	CNewCtrls(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewCtrls)
	enum { IDD = IDD_NEWCONTROLS_DIALOG };
	CDTXListCtrl	m_List;
	CListboxDate	m_DateCtrl;
	CComboDate		m_DateCombo;
	CDTXCalculatorCombo	m_CalcCombo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewCtrls)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewCtrls)
	virtual BOOL OnInitDialog();
	afx_msg void OnCalcdlg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWCTRLS_H__21945282_9485_4F02_9320_7156D84AC18C__INCLUDED_)
