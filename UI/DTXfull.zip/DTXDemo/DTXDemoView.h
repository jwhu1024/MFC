// DTXDemoView.h : interface of the CDTXDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DTXDEMOVIEW_H__2874B501_4DA5_4A7A_B603_C71E1534DD75__INCLUDED_)
#define AFX_DTXDEMOVIEW_H__2874B501_4DA5_4A7A_B603_C71E1534DD75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDTXDemoView : public CView
{
protected: // create from serialization only
	CDTXDemoView();
	DECLARE_DYNCREATE(CDTXDemoView)

// Attributes
public:
	CDTXDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDemoView)
	afx_msg void OnLabeldemo();
	afx_msg void OnEditdemo();
	afx_msg void OnImagedemo();
	afx_msg void OnComboboxes();
	afx_msg void OnBackground();
	afx_msg void OnEmployees();
	afx_msg void OnMyfriends();
	afx_msg void OnMyprog();
	afx_msg void OnNewctls();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DTXDemoView.cpp
inline CDTXDemoDoc* CDTXDemoView::GetDocument()
   { return (CDTXDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDEMOVIEW_H__2874B501_4DA5_4A7A_B603_C71E1534DD75__INCLUDED_)
