// EmployeeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DTXDemo.h"
#include "EmployeeDlg.h"
#include "AutoFont.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CAutoFont m_LabelFont;

/////////////////////////////////////////////////////////////////////////////
// CEmployeeDlg dialog


CEmployeeDlg::CEmployeeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEmployeeDlg::IDD, pParent),
	m_Table(NULL, _T("DTX.mdb"),  _T("Employee"))
{
	//{{AFX_DATA_INIT(CEmployeeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CEmployeeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEmployeeDlg)
	DDX_Control(pDX, IDC_GENDERCOMBO, m_Gender);
	DDX_Control(pDX, IDC_ZIPEDIT, m_Zip);
	DDX_Control(pDX, IDC_TELEPHONEEDIT, m_Telephone);
	DDX_Control(pDX, IDC_STATEEDIT, m_State);
	DDX_Control(pDX, IDC_PICSTATIC, m_Picture);
	DDX_Control(pDX, IDC_OCCUPATIONEDIT, m_Occupation);
	DDX_Control(pDX, IDC_NAVIGATORSTATIC, m_Navigator);
	DDX_Control(pDX, IDC_NAMEEDIT, m_Name);
	DDX_Control(pDX, IDC_LOCATIONSTATIC, m_Location);
	DDX_Control(pDX, IDC_INTERESTSTATIC, m_InterestLabel);
	DDX_Control(pDX, IDC_INTERESTSEDIT, m_Interest);
	DDX_Control(pDX, IDC_EMAILEDIT, m_Email);
	DDX_Control(pDX, IDC_DETAILSTATIC, m_DetailLabel);
	DDX_Control(pDX, IDC_COMMUNICATIONSTATIC, m_CommLabel);
	DDX_Control(pDX, IDC_CITYEDIT, m_City);
	DDX_Control(pDX, IDC_OPENDAYEDIT, m_OpenDay);
	DDX_Control(pDX, IDC_BIRTHDAYEDIT, m_BirthDay);
	DDX_Control(pDX, IDC_ADDREDIT, m_Addr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEmployeeDlg, CDialog)
	//{{AFX_MSG_MAP(CEmployeeDlg)
	ON_BN_CLICKED(IDC_LOADBTN, OnLoadbtn)
	ON_BN_CLICKED(IDC_SAVEBTN, OnSavebtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEmployeeDlg message handlers

BOOL CEmployeeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_LabelFont.SetFaceName(_T("Tahoma"));
	m_LabelFont.SetBold(true);
/*	
	CDAOTableCreator m_TestCreator;
	m_TestCreator.CreateDatabase(GetAppPath() + _T("DTX.mdb"), dbLangTurkish);

	m_TestCreator.AddField(_T("Name"), dbText, 32);
	m_TestCreator.AddField(_T("Gender"), dbInteger, 0);
	m_TestCreator.AddField(_T("Occupation"), dbText, 32);
	m_TestCreator.AddField(_T("BirthDay"), dbDate, 1);
	m_TestCreator.AddField(_T("OpenDay"), dbDate, 1);
	m_TestCreator.AddField(_T("Addr"), dbText, 32);
	m_TestCreator.AddField(_T("City"), dbText, 16);
	m_TestCreator.AddField(_T("State"), dbText, 16);
	m_TestCreator.AddField(_T("Zip"), dbText, 8);
	m_TestCreator.AddField(_T("Interest"), dbText, 128);
	m_TestCreator.AddField(_T("Telephone"), dbText, 20);
	m_TestCreator.AddField(_T("email"), dbText, 64);
	m_TestCreator.AddField(_T("Picture"), dbLongBinary, 0);

	m_TestCreator.CreateTable(_T("Employee"));
*/
	m_Table.SetTableName(GetAppPath() + _T("DTX.MDB"));
	m_Table.SetOwner(this);

	SetLabelAttr(m_DetailLabel);
	SetLabelAttr(m_CommLabel);
	SetLabelAttr(m_InterestLabel);
	SetLabelAttr(m_Location);
	
	m_Name.SetEditField(_T("Name"));
	m_Name.SetTable(&m_Table);

	m_Gender.SetEditField(_T("Gender"));
	m_Gender.SetTable(&m_Table);

	m_Name.SetControlColor(RGB(0, 160, 192));
	m_Name.SetBorderColor(RGB(0, 160, 192));
	m_Name.SetFocusColor(RGB(0, 160, 192));
	m_Name.SetFocusTextColor(RGB(0xFF, 0xFF, 0x00));
	m_Name.SetTextColor(RGB(255, 255, 255));
	m_Name.SetUseControlColors(true);
	m_Name.SetShadowSize(5);

	SetEditAttr(m_Occupation, _T("Occupation"));
	SetEditAttr(m_Addr, _T("Addr"));
	SetEditAttr(m_City, _T("City"));
	SetEditAttr(m_State, _T("State"));
	SetEditAttr(m_Zip, _T("Zip"));
	SetEditAttr(m_Interest, _T("Interest"));
	SetEditAttr(m_Telephone, _T("Telephone"));
	SetEditAttr(m_Email, _T("email"));

	m_BirthDay.SetUseControlColors(true);
	m_BirthDay.SetEditField(_T("BirthDay"));
	m_BirthDay.SetTable(&m_Table);
	m_BirthDay.SetMask(_T("##/##/####"));

	m_OpenDay.SetUseControlColors(true);
	m_OpenDay.SetEditField(_T("OpenDay"));
	m_OpenDay.SetTable(&m_Table);
	m_OpenDay.SetMask(_T("##/##/####"));

	m_Picture.SetEditField(_T("Picture"));
//	m_Picture.m_AutoSize = true;
	m_Picture.SetTable(&m_Table);
	m_Picture.SetShadowSize(10);

	m_Navigator.SetTable(&m_Table);

	m_Table.OpenTable();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CEmployeeDlg::SetLabelAttr(CDTXLabel& nLabel)
{
	nLabel.SetControlColor(RGB(48, 159, 214));
	nLabel.SetBorderColor(0);
	nLabel.SetUseControlColors(true);
	nLabel.SetShape(stRoundRect);
	nLabel.SetDrawShadow(false);
	nLabel.SetTextColor(0); //RGB(255, 255, 128));
	nLabel.SetTextFont((CFont*) &m_LabelFont);
}

void CEmployeeDlg::SetEditAttr(CDTXDBEdit &nEdit, CString nFldName)
{
	nEdit.SetUseControlColors(true);
	nEdit.SetEditField(nFldName);
	nEdit.SetTable(&m_Table);
}

void CEmployeeDlg::OnLoadbtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty()) 
		m_Picture.LoadBitmap(m_FName);
}

void CEmployeeDlg::OnSavebtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty() && !FileExist(m_FName)) 
	{
		WriteBlobToFile(m_FName, m_Table[_T("Picture")]);
	}
}
