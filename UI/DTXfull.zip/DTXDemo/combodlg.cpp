// combodlg.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdemo.h"
#include "combodlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComboDlg dialog


CComboDlg::CComboDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CComboDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComboDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CComboDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComboDlg)
	DDX_Control(pDX, IDC_COMBO3, m_DTXSACComboBox);
	DDX_Control(pDX, IDC_COMBO6, m_FlatACCombo);
	DDX_Control(pDX, IDC_COMBO5, m_ACCombo);
	DDX_Control(pDX, IDC_COMBO2, m_DTXCombo);
	DDX_Control(pDX, IDC_COMBO4, m_FlatCombo);
	DDX_Control(pDX, IDC_CAPTIONSTATIC, m_CBXCaption);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComboDlg, CDialog)
	//{{AFX_MSG_MAP(CComboDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboDlg message handlers

BOOL CComboDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_CBXCaption.SetBorderColor(RGB(192, 0, 0));
	m_CBXCaption.SetShape(stRectangle);
	m_CBXCaption.SetControlColor(RGB(255, 255, 255));
	m_CBXCaption.SetTextColor(RGB(192, 0, 255));
	m_CBXCaption.SetTextAlignment(DT_CENTER | DT_VCENTER | DT_SINGLELINE);


	AddComboStr(m_DTXCombo);
	AddComboStr(*((CComboBox*)GetDlgItem(IDC_COMBO1)));
	AddComboStr(m_ACCombo);
	AddComboStr(m_FlatCombo);

	AddComboStr(m_DTXCombo);
	m_DTXCombo.SetDrawShadow(false);
	
	AddACEntry(m_ACCombo);
	m_ACCombo.SetIgnoreChase(true);

	AddComboStr(m_DTXSACComboBox);
	m_DTXSACComboBox.SetBorderColor(RGB(0, 192, 255));
	m_DTXSACComboBox.SetUseControlColors(true);
	m_DTXSACComboBox.SetFocusColor(RGB(0xFF, 0xFF, 0x00));
	m_DTXSACComboBox.SetFocusTextColor(RGB(0, 0, 255));
	AddACEntry(m_DTXSACComboBox);	
	m_DTXSACComboBox.SetIgnoreChase(true);

	AddComboStr(m_FlatACCombo);
	AddACEntry(m_FlatACCombo);	
	m_FlatACCombo.SetIgnoreChase(true);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CComboDlg::AddComboStr(CComboBox& nCombo)
{
	nCombo.AddString(_T("This is 1. Line"));
	nCombo.AddString(_T("This is 2. Line"));
	nCombo.AddString(_T("This is 3. Line"));
	nCombo.AddString(_T("This is 4. Line"));
	nCombo.AddString(_T("This is 5. Line"));
	nCombo.AddString(_T("This is 6. Line"));
	nCombo.AddString(_T("This is 7. Line"));
	nCombo.AddString(_T("This is 8. Line"));
	nCombo.AddString(_T("This is 9. Line"));
	nCombo.AddString(_T("This is 10. Line"));
	nCombo.AddString(_T("This is 11. Line"));
	nCombo.AddString(_T("This is 12. Line"));
	nCombo.AddString(_T("This is 13. Line"));
	nCombo.AddString(_T("This is 14. Line"));
	nCombo.AddString(_T("This is 15. Line"));
}

void CComboDlg::AddACEntry(CDTXACBase& nEntry)
{
	nEntry.AddACEntry( _T( "MSFT" ) );	
	nEntry.AddACEntry( _T( "RHAT" ) );	
	nEntry.AddACEntry( _T( "LNUX" ) );	
	nEntry.AddACEntry( _T( "AMD" ) );	
	nEntry.AddACEntry( _T( "FATAX" ) );	
	nEntry.AddACEntry( _T( "DELL" ) );	
	nEntry.AddACEntry( _T( "TDFX" ) );	
	nEntry.AddACEntry( _T( "NVDA" ) );	
	nEntry.AddACEntry( _T( "SANM" ) );	
	nEntry.AddACEntry( _T( "CSCO" ) );	
	nEntry.AddACEntry( _T( "This is a test" ) );
}
