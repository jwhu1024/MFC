// BackgroundDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DTXDemo.h"
#include "BackgroundDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBackgroundDlg dialog


CBackgroundDlg::CBackgroundDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBackgroundDlg::IDD, pParent),
	m_Table(NULL, _T("C:/d/DTX.mdb"),  _T("Background"))
{
	//{{AFX_DATA_INIT(CBackgroundDlg)
	//}}AFX_DATA_INIT
}


void CBackgroundDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBackgroundDlg)
	DDX_Control(pDX, IDC_NAVIGATOR, m_DBNavigator);
	DDX_Control(pDX, IDC_EDIT1, m_PicName);
	DDX_Control(pDX, IDC_PICTUREWND, m_Picture);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBackgroundDlg, CDialog)
	//{{AFX_MSG_MAP(CBackgroundDlg)
	ON_BN_CLICKED(IDC_LOADBTN, OnLoadbtn)
	ON_BN_CLICKED(IDC_SAVEBTN, OnSavebtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBackgroundDlg message handlers

void CBackgroundDlg::OnLoadbtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty() && FileExist(m_FName)) 
		m_Picture.LoadBitmap(m_FName);
}

void CBackgroundDlg::OnSavebtn() 
{
	CString m_FName = GetFileName(GetSafeHwnd(), "Resim Dosyalar�\0*.JPG;*.JPEG;*.BMP;*.GIF\0\0");
	if(!m_FName.IsEmpty() && !FileExist(m_FName)) 
	{
		WriteBlobToFile(m_FName, m_Table[_T("Picture")]);
	}
}

BOOL CBackgroundDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
/*
	CDAOTableCreator m_TestCreator;
	m_TestCreator.CreateDatabase(GetAppPath() + _T("DTX.mdb"), dbLangTurkish);

	m_TestCreator.AddField(_T("PicName"), dbText, 64);
	m_TestCreator.AddField(_T("Picture"), dbLongBinary, 0);
	m_TestCreator.CreateTable(_T("Background"));
*/
	m_Table.SetTableName(GetAppPath() + _T("DTX.MDB"));
	m_Table.SetOwner(this);

	m_PicName.SetEditField(_T("PicName"));
	m_PicName.SetTable(&m_Table);

	m_PicName.SetControlColor(RGB(0, 160, 192));
	m_PicName.SetBorderColor(RGB(0, 160, 192));
	m_PicName.SetFocusColor(RGB(0, 160, 192));
	m_PicName.SetFocusTextColor(RGB(0xFF, 0xFF, 0x00));
	m_PicName.SetTextColor(RGB(255, 255, 255));
	m_PicName.SetUseControlColors(true);
	m_PicName.SetShadowSize(5);

	m_Picture.SetShadowSize(10);

	m_Picture.SetEditField(_T("Picture"));
	m_Picture.m_AutoSize = true;
	m_Picture.SetTable(&m_Table);

	m_DBNavigator.SetTable(&m_Table);

	m_Table.OpenTable();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
