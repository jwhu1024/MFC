// DTXDemoDoc.cpp : implementation of the CDTXDemoDoc class
//

#include "stdafx.h"
#include "DTXDemo.h"

#include "DTXDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoDoc

IMPLEMENT_DYNCREATE(CDTXDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CDTXDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CDTXDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoDoc construction/destruction

CDTXDemoDoc::CDTXDemoDoc()
{
	// TODO: add one-time construction code here

}

CDTXDemoDoc::~CDTXDemoDoc()
{
}

BOOL CDTXDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDTXDemoDoc serialization

void CDTXDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoDoc diagnostics

#ifdef _DEBUG
void CDTXDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDTXDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDTXDemoDoc commands
