// dtxlabel.cpp : implementation file
//

#include "stdafx.h"
#include "dtxlabel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXLabel

IMPLEMENT_DYNAMIC(CDTXLabel, CStatic)

CDTXLabel::CDTXLabel()
{
	m_UseControlColors = m_GotFocus =  m_TimerSet = false;
	m_DrawShadow = true;
	m_ShadowSize = 3;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor = m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = m_TextColor  = RGB(0, 0, 0);
	m_ShapeType  = stNone;
	m_TextAlignment = DT_CENTER | DT_VCENTER;
}

CDTXLabel::~CDTXLabel()
{
	m_TextFont.DeleteObject();
}


BEGIN_MESSAGE_MAP(CDTXLabel, CStatic)
	//{{AFX_MSG_MAP(CDTXLabel)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXLabel message handlers

void CDTXLabel::OnPaint() 
{
	DrawShape();
	CString m_Text;
	GetWindowText(m_Text);
	CRect rect;
	GetClientRect(&rect);
	
	CPaintDC dc(this);

	CFont* pFont = dc.SelectObject(&m_TextFont);
	dc.SetTextColor(m_TextColor);
	dc.SetBkColor(m_ControlColor);
	dc.SetBkMode(TRANSPARENT);
	dc.DrawText(m_Text, &rect, m_TextAlignment);
	dc.SelectObject(pFont);
}

void CDTXLabel::DrawShape()
{
	CRect rect;
	GetWindowRect(&rect);
	ScreenToClient(&rect);

	CDC* pDC = GetDC();
	
	CPen m_Pen(PS_SOLID, 1, m_borderColor);
	CBrush m_Brush(m_ControlColor);

	CPen* pOldPen = pDC->SelectObject(&m_Pen);
	CBrush *pOldBrush = pDC->SelectObject(&m_Brush);
	rect.DeflateRect(1, 1);
	switch(m_ShapeType)
	{
		case stRectangle: pDC->Rectangle(rect); break;
		case stRoundRect: pDC->RoundRect(rect, CPoint(11, 11 )); break;
		case stEllipse  : pDC->Ellipse(rect); break;
	}

	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldBrush);
	rect.InflateRect(1, 1);
	if(m_DrawShadow)
	{
		CRect rectRight (rect.right, rect.top + m_ShadowSize, rect.right + m_ShadowSize, rect.Height() + m_ShadowSize);
		CRect rectBottom(rect.left + m_ShadowSize, rect.bottom, rect.right + m_ShadowSize, rect.Height() + m_ShadowSize);
	
		CBrush br(m_ShadowColor);
		pDC->FillRect (rectRight, &br);
		pDC->FillRect (rectBottom, &br);
	}
	ReleaseDC(pDC);
}

void CDTXLabel::SetTextFont(CFont* pFont)
{
	LOGFONT lf;
	pFont->GetLogFont(&lf);
	m_TextFont.Detach();
	m_TextFont.CreateFontIndirect(&lf);
}

void CDTXLabel::PreSubclassWindow() 
{
	CStatic::PreSubclassWindow();
	LOGFONT lf;
	GetFont()->GetLogFont(&lf);
	m_TextFont.CreateFontIndirect(&lf);
}
