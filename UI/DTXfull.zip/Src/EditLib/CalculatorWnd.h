#if !defined(AFX_CALCULATORWND_H__7E99F8A5_CFED_4C90_8384_FB148537DB31__INCLUDED_)
#define AFX_CALCULATORWND_H__7E99F8A5_CFED_4C90_8384_FB148537DB31__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalculatorWnd.h : header file
//
#include "PopupCombo.h"

#define BTNCOUNT   28

/////////////////////////////////////////////////////////////////////////////
// CCalculatorWnd window

class CCalculatorWnd : public CPopupWnd
{
	CString m_ScreenText;
// Construction
public:
	CCalculatorWnd(CComboBox* pWnd);

// Attributes
public:

// Operations
public:
	int GetDecimalPlaces()
	{ return m_DecimalPlaces; }

	void SetDecimalPlaces(int nPlaces)
	{ m_DecimalPlaces = nPlaces; }

	BOOL HaveMemory()
	{ return m_Memory != 0.0; }

	double GetMemoryValue()
	{ return m_Memory; }
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalculatorWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCalculatorWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCalculatorWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_DecimalPlaces;
	double m_Memory;
	enum {MaxDigits = 15, BaseID = 8000};
	TCHAR m_szInput[MaxDigits + 2];
	TCHAR m_szHold[MaxDigits + 2];
	TCHAR m_chOperator;

	CButton* m_Buttons[BTNCOUNT];
	CFont m_BtnFont;

	CString InsertComma(CString nText);
	afx_msg void DrawMemory();
	afx_msg void SetText(CString nText);
	afx_msg void OnDigit(UINT nID);
	afx_msg void OnButton(UINT nID);
	afx_msg void OnDecimalPoint();
	afx_msg void OnEquals();
	afx_msg void OnPlus();
	afx_msg void OnMinus();
	afx_msg void OnMultiply();
	afx_msg void OnDivide();
	afx_msg void OnClear();
	afx_msg void OnClearEntry();
	afx_msg void OnSign();
	afx_msg void OnPi();
	afx_msg void OnSin();
	afx_msg void OnCos();
	afx_msg void OnTan();
	afx_msg void OnX2();
	afx_msg void OnSQR();
	afx_msg void On1DivX();
	afx_msg void OnMC();
	afx_msg void OnMP();
	afx_msg void OnMM();
	afx_msg void OnMR();
	afx_msg void AddDigit(LPTSTR string, LPCTSTR lpszDigit);
	void DoCalculate();
};

class CCalculatorCombo : public CPopupCombo 
{
	CCalculatorWnd* m_CalcWnd;
public:
	CCalculatorCombo();	
protected:
	afx_msg virtual void OnPopup();
	virtual void InitFont();
};

class CDTXCalculatorCombo : public CDTXPopupCombo 
{
	CCalculatorWnd* m_CalcWnd;
public:
	CDTXCalculatorCombo();	
protected:
	afx_msg virtual void OnPopup();
	virtual void InitFont();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALCULATORWND_H__7E99F8A5_CFED_4C90_8384_FB148537DB31__INCLUDED_)
