#if !defined(AFX_DTXFLATACCOMBOBOX_H__8E5B736B_3866_4849_958D_2DAF2B1D7A5A__INCLUDED_)
#define AFX_DTXFLATACCOMBOBOX_H__8E5B736B_3866_4849_958D_2DAF2B1D7A5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxflataccombobox.h : header file
//
#include "FlatComboBox.h"
#include "dtxacbase.h"
/////////////////////////////////////////////////////////////////////////////
// CDTXFlatACComboBox window

class CDTXFlatACComboBox : public CFlatComboBox, public CDTXACBase
{
// Construction
public:
	CDTXFlatACComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXFlatACComboBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXFlatACComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXFlatACComboBox)
	afx_msg void OnEditupdate();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXFLATACCOMBOBOX_H__8E5B736B_3866_4849_958D_2DAF2B1D7A5A__INCLUDED_)
