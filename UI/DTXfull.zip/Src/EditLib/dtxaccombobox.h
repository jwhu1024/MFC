#if !defined(AFX_DTXACCOMBOBOX_H__1FF7A1D2_DCBB_4A41_A186_FC74BAB20133__INCLUDED_)
#define AFX_DTXACCOMBOBOX_H__1FF7A1D2_DCBB_4A41_A186_FC74BAB20133__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxaccombobox.h : header file
//
#include "dtxacbase.h"
/////////////////////////////////////////////////////////////////////////////
// CDTXACComboBox window

class CDTXACComboBox : public CComboBox, public CDTXACBase
{
// Construction
public:
	CDTXACComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXACComboBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXACComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXACComboBox)
	afx_msg void OnEditupdate();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXACCOMBOBOX_H__1FF7A1D2_DCBB_4A41_A186_FC74BAB20133__INCLUDED_)
