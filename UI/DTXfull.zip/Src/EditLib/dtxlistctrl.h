#if !defined(AFX_DTXLISTCTRL_H__48052CB3_FD43_44CC_B887_D0D14F43311F__INCLUDED_)
#define AFX_DTXLISTCTRL_H__48052CB3_FD43_44CC_B887_D0D14F43311F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxlistctrl.h : header file
//

#include <DTXBase.h>
#include "ReportCtrl.h"

class CDTXReportCtrl : public CReportCtrl
{
public:
	void SetBackColor(COLORREF nColor)
	{ m_crBackground = nColor; }

	void SetBkSelectedColor(COLORREF nColor)
	{ m_crBkSelected = nColor; }

	void SetBkSelectedNoFocusColor(COLORREF nColor)
	{ m_crBkSelectedNoFocus = nColor; }

	void SetTextColor(COLORREF nColor)
	{ m_crText = nColor; }

	void SetTextSelectedColor(COLORREF nColor)
	{ m_crTextSelected = nColor; }

	void SetTextSelectedNoFocusColor(COLORREF nColor)
	{ m_crTextSelectedNoFocus = nColor; }
};

/////////////////////////////////////////////////////////////////////////////
// CDTXListCtrl window

class CDTXListCtrl : public CWnd, public CDTXWndBase
{
// Construction
public:
	CDTXListCtrl();

// Attributes
public:
	CDTXReportCtrl m_Ctrl;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXListCtrl)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXListCtrl)
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	
private:
	void DrawBorder(bool fHot = TRUE);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXLISTCTRL_H__48052CB3_FD43_44CC_B887_D0D14F43311F__INCLUDED_)
