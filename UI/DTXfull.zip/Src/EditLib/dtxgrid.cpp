// dtxgrid.cpp : implementation file
//

#include "stdafx.h"
#include "dtxgrid.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXGrid

CDTXGrid::CDTXGrid()
{
}

CDTXGrid::~CDTXGrid()
{
}


BEGIN_MESSAGE_MAP(CDTXGrid, CWnd)
	//{{AFX_MSG_MAP(CDTXGrid)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDTXGrid message handlers

BOOL CDTXGrid::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL nRes = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if(nRes)
	{
		CRect r(rect);
		r.DeflateRect(1, 1);
		//Create(DWORD dwExStyle, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);
		
		if(nRes = m_Grid.Create(CWnd::GetExStyle(), dwStyle | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL| AGS_FLAT| WS_TABSTOP , r, this, 1))
		{
			m_Grid.SetFont(GetFont()); 
		}
	}
	return nRes;
}

void CDTXGrid::PreSubclassWindow() 
{
	CWnd::PreSubclassWindow();
	CRect r;
	GetClientRect(&r);

	r.DeflateRect(1, 1);
	m_Grid.Create(CWnd::GetExStyle(), CWnd::GetStyle() | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL| AGS_FLAT| WS_TABSTOP , r, this, 1);
	m_Grid.SetFont(GetFont()); 
}

void CDTXGrid::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}


void CDTXGrid::OnPaint() 
{
	if(IsWindow(m_Grid.GetSafeHwnd()))
		m_Grid.UpdateWindow();

	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

BOOL CDTXGrid::OnEraseBkgnd(CDC* pDC) 
{
	BOOL nRes = CWnd::OnEraseBkgnd(pDC);
	if(IsWindow(m_Grid.GetSafeHwnd()))
		m_Grid.PostMessage(WM_ERASEBKGND);
	return nRes;
}
