// CalculatorWnd.cpp : implementation file
//

#include "stdafx.h"
#include "CalculatorWnd.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BTNWIDTH   28
#define BTNHEIGHT  25

CCalculatorCombo::CCalculatorCombo() : m_CalcWnd(NULL)
{
	SetControlSize(CSize(235, 155));
	SetPopupWnd(m_CalcWnd);
}

void CCalculatorCombo::OnPopup()
{
	m_CalcWnd = new CCalculatorWnd(this);
	m_CalcWnd->SetPopupCombo(this);
	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = m_CalcWnd->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	m_CalcWnd->SetFocus();
}

void CCalculatorCombo::InitFont()
{

}

CDTXCalculatorCombo::CDTXCalculatorCombo() : m_CalcWnd(NULL)
{
	SetControlSize(CSize(235, 155));
	SetPopupWnd(m_CalcWnd);
}

void CDTXCalculatorCombo::OnPopup()
{
	m_CalcWnd = new CCalculatorWnd((CComboBox*) this);
	m_CalcWnd->SetPopupCombo(this);
	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = m_CalcWnd->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	m_CalcWnd->SetFocus();
}

void CDTXCalculatorCombo::InitFont()
{

}
/////////////////////////////////////////////////////////////////////////////
// CCalculatorWnd

CCalculatorWnd::CCalculatorWnd(CComboBox* pWnd) :
	CPopupWnd(pWnd)
{
	m_szInput[0] = _T('0');
	m_szInput[1] = _T('\0');
	m_szHold[0] = _T('\0');
	m_chOperator = _T('\0');
	m_DecimalPlaces = 5;
	m_Memory = 0.0;
	m_ScreenText = _T("0");
}

CCalculatorWnd::~CCalculatorWnd()
{
	for (int i = 0; i <= BTNCOUNT; ++i)
	{
		if(m_Buttons[i])
			delete m_Buttons[i];
	}
	m_BtnFont.DeleteObject();
}

BEGIN_MESSAGE_MAP(CCalculatorWnd, CPopupWnd)
	//{{AFX_MSG_MAP(CCalculatorWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_CHAR()
	ON_COMMAND_RANGE(BaseID, BaseID + BTNCOUNT, OnButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalculatorWnd message handlers

int CCalculatorWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CPopupWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rect(0, 0, 0, 0);
	static const TCHAR DigitLabels[BTNCOUNT][4] = {_T("7"), _T("8"), _T("9"), _T("/"), _T("MC"), _T("sin"), _T("pi"),
                                            _T("4"), _T("5"), _T("6"), _T("*"),  _T("M+"), _T("cos"), _T("C"),
                                            _T("1"), _T("2"), _T("3"), _T("-"), _T("M-"), _T("tan"), _T("sqr"), 
											_T("0"), _T("+/-"), _T(","), _T("+"), _T("MR"), _T("x^2"),_T("1/x")
											};

	static const DWORD dwStyle = BS_PUSHBUTTON | WS_VISIBLE;
	for (int i = 0; i <= BTNCOUNT; ++i)
	{
		m_Buttons[i] = new CButton;
		m_Buttons[i]->Create(DigitLabels[i], dwStyle, rect, this, BaseID + i);
	}

	m_BtnFont.CreateFont(13,0,0,0,FW_NORMAL,
		0,0,0,ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH || FF_DONTCARE,
		_T("Tahoma"));	
	for (i = 0; i <= BTNCOUNT; ++i)
		m_Buttons[i]->SetFont(&m_BtnFont);
	ModifyStyle(0, WS_BORDER);
	return 0;
}

void CCalculatorWnd::OnSize(UINT nType, int cx, int cy) 
{
	CPopupWnd::OnSize(nType, cx, cy);
	int yPos = 35;
	for(int y = 0;  y < 4; y++)
	{
		int xPos = 7;
		for(int x = 0; x  < 7; x++)
		{
			CRect btnRect(xPos, yPos, xPos + BTNWIDTH, yPos + BTNHEIGHT);
			m_Buttons[y * 7 + x]->MoveWindow(btnRect);
			xPos += BTNWIDTH + 3;
		}
		yPos += BTNHEIGHT + 3;
	}
}

BOOL CCalculatorWnd::OnEraseBkgnd(CDC* pDC) 
{
	COLORREF clrBack = GetSysColor(COLOR_BTNFACE);
	
	CRect rect;
	GetClientRect(&rect);
    
	pDC->Rectangle(&rect);
	rect.DeflateRect(CSize(1, 1));
	
	CBrush NewBrush(clrBack); 
	pDC->SetBrushOrg(0, 0);
	CBrush* pOldBrush = (CBrush*)pDC->SelectObject(&NewBrush);   
	pDC->PatBlt(rect.left, rect.top, rect.Width(), rect.Height(), PATCOPY);
	pDC->SelectObject(pOldBrush);                                           
	

	CRect edtRect = CRect(27, 11, 220, 29);
	pDC->Rectangle(&edtRect);
	edtRect.DeflateRect(CSize(1, 1));
	CBrush br(RGB(255, 255, 255)); 
	pDC->SetBrushOrg(0, 0);
	pOldBrush = (CBrush*)pDC->SelectObject(&br);   

	pDC->PatBlt(edtRect.left, edtRect.top, edtRect.Width(), edtRect.Height(), PATCOPY);
	pDC->SelectObject(pOldBrush);                                           

	SetText(m_ScreenText);
	return TRUE;
}

BOOL CCalculatorWnd::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_CHAR)
	{
		OnChar(pMsg->wParam, 0, 0);
		pMsg->wParam = 0;

	}
	return CPopupWnd::PreTranslateMessage(pMsg);
}

void CCalculatorWnd::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
   switch (nChar)
   {
   case 8: {
				int l = lstrlen(m_szInput);
				if(l > 0)
				{
					m_szInput[l - 1] = _T('\0');
					SetText(m_szInput);
				}
		   }
	   break;

   case 27: PostMessage(WM_CLOSE); break;
   case '0': case '1': case '2': case '3': case '4':
   case '5': case '6': case '7': case '8': case '9':
      OnDigit(BaseID + (nChar - '0'));
      break;
   case '.':
      OnDecimalPoint();
      break;
   case '+':
      OnPlus();
      break;
   case '-':
      OnMinus();
      break;
   case '*':
      OnMultiply();
      break;
   case '=': case 13:   // Pressing "Enter" works too!
      OnEquals();
      break;
   case '/':
      OnDivide();
      break;
   case 'C': case 'c':
      OnClear();
      break;
   case 'E': case 'e':
      OnClearEntry();
      break;
   }
   CPopupWnd::OnChar(nChar, nRepCnt, nFlags);
}

void CCalculatorWnd::DrawMemory()
{
	CRect edtRect = CRect(15, 13, 26, 28);
	CDC* pDC = GetDC();
	
	if(m_Memory != 0)
	{
		CFont* pFont = (CFont*) pDC->SelectObject(&m_BtnFont);
		pDC->SetBkMode(TRANSPARENT);
		pDC->DrawText(_T("M"), &edtRect, DT_CENTER);
		pDC->SelectObject(pFont);
	}
	else
	{
		CBrush br(GetSysColor(COLOR_BTNFACE)); 
		pDC->SetBrushOrg(0, 0);
		CBrush* pOldBrush = (CBrush*)pDC->SelectObject(&br);   

		pDC->PatBlt(edtRect.left, edtRect.top, edtRect.Width(), edtRect.Height(), PATCOPY);
		pDC->SelectObject(pOldBrush);
	}
}

void CCalculatorWnd::SetText(CString nText)
{
	m_ScreenText = nText;
//	nText = InsertComma(nText);
	CRect edtRect = CRect(28, 12, 219, 28);
	CDC* pDC = GetDC();

	pDC->SetBkMode(TRANSPARENT);
	CBrush br(RGB(255, 255, 255)); 
	pDC->SetBrushOrg(0, 0);
	CBrush* pOldBrush = (CBrush*)pDC->SelectObject(&br);   

	pDC->PatBlt(edtRect.left, edtRect.top, edtRect.Width(), edtRect.Height(), PATCOPY);
	pDC->SelectObject(pOldBrush);                                           

	CFont* pFont = (CFont*) pDC->SelectObject(&m_BtnFont);
	pDC->DrawText(nText, &edtRect, DT_RIGHT);
	pDC->SelectObject(pFont);
}

void CCalculatorWnd::OnDigit(UINT nID)
{
   if (lstrlen(m_szInput) < MaxDigits)
   {
		TCHAR szDigit[20] = {0} ;
		_itot(nID - BaseID, szDigit, MaxDigits);
		if(lstrlen(m_szInput) == 1 && m_szInput[0] == _T('0'))
			m_szInput[0] = _T('\0');
		AddDigit(m_szInput, szDigit);
		SetText(m_szInput);
		SetFocus();
   }
}

void CCalculatorWnd::OnDecimalPoint()
{
   if (lstrlen(m_szInput) < MaxDigits && !_tcschr(m_szInput, _T('.')))
   {
      AddDigit(m_szInput, _T("."));
      SetText(m_szInput);
      SetFocus();
   }
}

void CCalculatorWnd::OnEquals()
{
   DoCalculate();
   if(pWndCombo)
   {
		pWndCombo->SetWindowText(m_szHold);
		PostMessage(WM_CLOSE);
   }
}

void CCalculatorWnd::OnPlus()
{
   DoCalculate();
   m_chOperator = _T('+');
   SetFocus();
}

void CCalculatorWnd::OnMinus()
{
   DoCalculate();
   m_chOperator = _T('-');
   SetFocus();
}
   
void CCalculatorWnd::OnMultiply()
{
   DoCalculate();
   m_chOperator = _T('*');
   SetFocus();
}

void CCalculatorWnd::OnDivide()
{
   DoCalculate();
   m_chOperator = _T('/');
   SetFocus();
}

void CCalculatorWnd::OnClear()
{
   m_szHold[0] = _T('\0');
   m_szInput[0] = _T('\0');
   m_chOperator = _T('\0');
   m_ScreenText = _T("0");
   SetText(m_ScreenText);
   SetFocus();
}

void CCalculatorWnd::OnClearEntry()
{
   m_szInput[0] = _T('\0');
   SetText(m_szInput);
   SetFocus();
}

void CCalculatorWnd::AddDigit(LPTSTR string, LPCTSTR lpszDigit)
{
   _tcscat(string, lpszDigit);
}   

void CCalculatorWnd::DoCalculate()
{
   if (!lstrlen(m_szHold))
   {
      lstrcpy(m_szHold, m_szInput);
      m_szInput[0] = _T('\0');
      return;
   }
   
   // Yes.  Get the value of the hold string and the current string
   double v1 = atof(m_szHold);
   double v2 = atof(m_szInput);
   double value = 0.0;

   // Do the calculation
   switch (m_chOperator)
   {
      case _T('+'):
         value = v1 + v2;
         break;
      case _T('-'):
         value = v1 - v2;
         break;
      case _T('*'):
         value = v1 * v2;
         break;
      case _T('/'):
         if (v2)
            value = v1 / v2;
         else
         {
            MessageBeep(MB_ICONEXCLAMATION);
            return;
         }
         break;
   }
   
   _stprintf(m_szInput, _T("%lf"), value );
   SetText(m_szInput);
   
   // Save old into m_szHold
   lstrcpy(m_szHold, m_szInput);
   
   // Clear the operator
   m_chOperator = _T('\0');
   
   // Clear the current input string
   m_szInput[0] = _T('\0');
}

void CCalculatorWnd::OnButton(UINT nID)
{
	switch(nID)
	{
		case BaseID	+ 21: OnDigit(BaseID); break;
		case BaseID + 14: OnDigit(BaseID + 1); break;
		case BaseID + 15: OnDigit(BaseID + 2); break;
		case BaseID	+ 16: OnDigit(BaseID + 3); break;
		case BaseID +  7: OnDigit(BaseID + 4); break;
		case BaseID +  8: OnDigit(BaseID + 5); break;
		case BaseID	+  9: OnDigit(BaseID + 6); break;
		case BaseID		: OnDigit(BaseID + 7); break;
		case BaseID +  1: OnDigit(BaseID + 8); break;
		case BaseID	+  2: OnDigit(BaseID + 9); break;
		case BaseID + 23: OnDecimalPoint(); break;
		case BaseID + 24: OnPlus(); break;
		case BaseID + 17: OnMinus(); break;
		case BaseID +  3: OnDivide(); break;
		case BaseID + 10: OnMultiply(); break;
		case BaseID + 22: OnSign(); break; //+/-
		case BaseID +  4: OnMC(); break;	// MC
		case BaseID + 11: OnMP(); break;	// M+
		case BaseID + 18: OnMM(); break;	// M-
		case BaseID + 25: OnMR(); break;	// MR
		case BaseID +  5: OnSin(); break;	// sin
		case BaseID + 12: OnCos(); break;	// cos
		case BaseID + 19: OnTan(); break;	// tan
		case BaseID + 26: OnX2(); break;	// x^2
		case BaseID + 13: OnClear(); break;	// C
		case BaseID + 20: OnSQR(); break;	// sqr
		case BaseID + 27: On1DivX(); break;	// 1/x
		case BaseID +  6: OnPi(); break;	// pi
	}
}

CString CCalculatorWnd::InsertComma(CString nText)
{
	CString nRes, nRes2;
	double nVal = atof(nText);
	int  decimal, sign;

	nRes2 = fcvt(nVal, m_DecimalPlaces, &decimal, &sign );
	if(nRes2.IsEmpty())
		return InsertComma(_T("0"));
	if(sign == 0)
		nRes = _T("");
	else
		nRes = _T("-");

   int  string_length = nRes2.GetLength(), wholenum_place,
		num_whole_nums = string_length - m_DecimalPlaces;

	for(int loop = 0; loop < string_length; loop++)
	{
		wholenum_place = num_whole_nums - loop;
		if(wholenum_place > 2)
		{
		    if((wholenum_place % 3) == 0 && loop > 0)
			{
				nRes = nRes + _T(",");
			}
		}
		if(decimal == loop)
		{
			if(nRes.GetLength() == 0)
				nRes = _T("0");
			else if(nRes == _T("-"))
				nRes = _T("-0");
			nRes = nRes + _T(".");
		}
		nRes = nRes + nRes2[loop];
	}
	return nRes;
}

void CCalculatorWnd::OnSign()
{
	CString nRes(m_ScreenText);
	if(nRes[0] == _T('-'))
		nRes.Delete(0);
	else
		nRes = _T('-') + nRes;
	_stprintf(m_szInput, _T("%s"), nRes);
	SetText(m_szInput);
	SetFocus();
}

void CCalculatorWnd::OnPi()
{
   double d = (double) 22/7;
	_stprintf(m_szInput, _T("%lf"), d);
	SetText(m_szInput);
   SetFocus();
}

void CCalculatorWnd::OnSin()
{
	double nVal = atof(m_ScreenText);
	nVal = sin(nVal);
	_stprintf(m_szInput, _T("%lf"), nVal);
	SetText(m_szInput);
   SetFocus();
}

void CCalculatorWnd::OnCos()
{
	double nVal = atof(m_ScreenText);
	nVal = cos(nVal);
	_stprintf(m_szInput, _T("%lf"), nVal);
	SetText(m_szInput);
	SetFocus();
}

void CCalculatorWnd::OnTan()
{
	double nVal = atof(m_ScreenText);
	nVal = tan(nVal);
	_stprintf(m_szInput, _T("%lf"), nVal);
	SetText(m_szInput);
	SetFocus();
}

void CCalculatorWnd::OnX2()
{
	double nVal;
	nVal = atof(m_ScreenText);
	_stprintf(m_szInput, _T("%lf"), nVal * nVal);
	SetText(m_szInput);

	SetFocus();
}

void CCalculatorWnd::OnSQR()
{
	double nVal = atof(m_ScreenText);
	nVal = sqrt(nVal);
	_stprintf(m_szInput, _T("%lf"), nVal);
	SetText(m_szInput);
	SetFocus();
}

void CCalculatorWnd::On1DivX()
{
	double nVal = (double) 1 / atof(m_ScreenText);
	_stprintf(m_szInput, _T("%lf"), nVal);
	SetText(m_szInput);
	SetFocus();
}

void CCalculatorWnd::OnMC()
{
	m_Memory = 0.0;
	DrawMemory();
	SetFocus();
}

void CCalculatorWnd::OnMP()
{
	m_Memory += atof(m_ScreenText);
	DrawMemory();
	SetFocus();
}

void CCalculatorWnd::OnMM()
{
	m_Memory -= atof(m_ScreenText);
	DrawMemory();
	SetFocus();
}

void CCalculatorWnd::OnMR()
{
	_stprintf(m_szInput, _T("%lf"), m_Memory);
	SetText(m_szInput);
	SetFocus();
}
