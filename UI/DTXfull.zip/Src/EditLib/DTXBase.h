#if !defined(AFX_DTXBASE_H__604B4CE4_3386_4FCE_AA72_7DACE6284470__INCLUDED_)
#define AFX_DTXBASE_H__604B4CE4_3386_4FCE_AA72_7DACE6284470__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DTXBase.h : header file
//

extern COLORREF m_clr3DFace;
extern COLORREF m_clr3DLight;
extern COLORREF m_clr3DHilight;
extern COLORREF m_clr3DShadow;
extern COLORREF m_clr3DDkShadow;

/////////////////////////////////////////////////////////////////////////////
// CDTXWndBase window

class CDTXWndBase
{
// Construction
public:
	CDTXWndBase();

// Attributes
public:
	bool GetDrawShadow() { return m_DrawShadow; }
	void SetDrawShadow(bool nValue) { m_DrawShadow = nValue; }

	bool GetUseControlColors() { return m_UseControlColors; }
	void SetUseControlColors(bool nValue) { m_UseControlColors = nValue; }

	COLORREF GetControlColor() { return m_ControlColor; }
	void SetControlColor(COLORREF nColor) { m_ControlColor = nColor; }

	COLORREF GetFocusColor() { return m_FocusColor; }
	void SetFocusColor(COLORREF nColor) { m_FocusColor = nColor; }

	COLORREF GetTextColor() { return m_TextColor; }
	void SetTextColor(COLORREF nColor) { m_TextColor = nColor; }

	COLORREF GetFocusTextColor() { return m_FocusTextColor; }
	void SetFocusTextColor(COLORREF nColor) { m_FocusTextColor = nColor; }

	COLORREF GetBorderColor() { return m_borderColor; }
	void SetBorderColor(COLORREF nColor) { m_borderColor = nColor; }

	COLORREF GetShadowColor() { return m_ShadowColor; }
	void SetShadowColor(COLORREF nColor) { m_ShadowColor = nColor; }

	int GetShadowSize() { return m_ShadowSize; }
	void SetShadowSize(int nSize) { m_ShadowSize = nSize; }
// Operations
public:

// Implementation
public:
	virtual ~CDTXWndBase();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot, CWnd* fThisWnd, bool m_Inc);
	virtual void DrawBorder(bool fHot, CWnd* fThisWnd)
	{ DrawBorder(fHot, fThisWnd, false); }
	bool m_GotFocus;
	bool m_TimerSet;
	bool m_DrawShadow;
	bool m_UseControlColors;
	
	int m_ShadowSize;
	
	COLORREF m_ShadowColor;
	COLORREF m_borderColor;
	COLORREF m_ControlColor;
	COLORREF m_FocusColor;
	COLORREF m_TextColor;
	COLORREF m_FocusTextColor;

	CBrush	m_BackBrush;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXBASE_H__604B4CE4_3386_4FCE_AA72_7DACE6284470__INCLUDED_)
