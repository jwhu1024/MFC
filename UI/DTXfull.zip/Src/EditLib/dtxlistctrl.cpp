// dtxlistctrl.cpp : implementation file
//

#include "stdafx.h"
#include "dtxlistctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXListCtrl

CDTXListCtrl::CDTXListCtrl()
{
	m_UseControlColors = m_GotFocus =  m_TimerSet = false;
	m_DrawShadow = true;
	m_ShadowSize = 5;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor = m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = m_TextColor  = RGB(0, 0, 0);
}

CDTXListCtrl::~CDTXListCtrl()
{
}


BEGIN_MESSAGE_MAP(CDTXListCtrl, CWnd)
	//{{AFX_MSG_MAP(CDTXListCtrl)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXListCtrl message handlers

void CDTXListCtrl::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}

void CDTXListCtrl::OnPaint() 
{
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
	if(IsWindow(m_Ctrl.GetSafeHwnd()))
		m_Ctrl.UpdateWindow();
}

BOOL CDTXListCtrl::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL nRes = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if(nRes)
		if(nRes = m_Ctrl.Create(dwStyle, rect, this, 1))
		{
			m_Ctrl.SetFont(GetFont()); 
			m_Ctrl.SetBackColor(m_ControlColor);
			m_Ctrl.SetBkSelectedColor(m_FocusColor);
			m_Ctrl.SetBkSelectedNoFocusColor(m_FocusColor);
			m_Ctrl.SetTextColor(m_TextColor);
			m_Ctrl.SetTextSelectedColor(m_FocusTextColor);
			m_Ctrl.SetTextSelectedNoFocusColor(m_FocusTextColor);
		}
	return nRes;
}

void CDTXListCtrl::PreSubclassWindow() 
{
	CWnd::PreSubclassWindow();

	CRect r;
	GetClientRect(&r);

	r.DeflateRect(1, 1);
	m_Ctrl.Create(GetStyle() | WS_CHILD, r, this, 1); 
	m_Ctrl.SetFont(GetFont()); 
	m_Ctrl.SetFont(GetFont()); 
	m_Ctrl.SetBackColor(m_ControlColor);
	m_Ctrl.SetBkSelectedColor(m_FocusColor);
	m_Ctrl.SetBkSelectedNoFocusColor(m_FocusColor);
	m_Ctrl.SetTextColor(m_TextColor);
	m_Ctrl.SetTextSelectedColor(m_FocusTextColor);
	m_Ctrl.SetTextSelectedNoFocusColor(m_FocusTextColor);
}

void CDTXListCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CWnd::OnSetFocus(pOldWnd);
	m_Ctrl.SetFocus();
}

BOOL CDTXListCtrl::OnEraseBkgnd(CDC* pDC) 
{
	BOOL nRes = CWnd::OnEraseBkgnd(pDC);
	if(IsWindow(m_Ctrl.GetSafeHwnd()))
		m_Ctrl.PostMessage(WM_ERASEBKGND);
	return nRes;
}

HBRUSH CDTXListCtrl::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	DWORD	dwStyle = GetStyle();

	if(pWnd->GetDlgCtrlID() == 1 &&
		m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		pDC->SetTextColor(m_FocusTextColor);
		pDC->SetBkColor(m_FocusColor);
		m_BackBrush.CreateSolidBrush(m_FocusColor);
		pDC->SelectObject(GetFont());
		return((HBRUSH) m_BackBrush);
	}
	return(CWnd::OnCtlColor(pDC, pWnd, nCtlColor));
}
