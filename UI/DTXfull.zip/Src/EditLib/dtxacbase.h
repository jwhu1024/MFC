#if !defined(AFX_DTXACBASE_H__A86BABAE_3A07_49C9_B64D_AAB395645572__INCLUDED_)
#define AFX_DTXACBASE_H__A86BABAE_3A07_49C9_B64D_AAB395645572__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxacbase.h : header file
//
#pragma warning (disable : 4018)	// '<':  signed/unsigned mismatch
#pragma warning (disable : 4100)	// unreferenced formal parameter
#pragma warning (disable : 4127)	// conditional expression is constant
#pragma warning (disable : 4244)	// conv from X to Y, possible loss of data
#pragma warning (disable : 4310)	// cast truncates constant value
#pragma warning (disable : 4505)	// X: unreference local function removed
#pragma warning (disable : 4510)	// X: default ctor could not be generated
#pragma warning (disable : 4511)	// X: copy constructor could not be generated
#pragma warning (disable : 4512)	// assignment operator could not be generated
#pragma warning (disable : 4514)	// debug symbol exceeds 255 chars
#pragma warning (disable : 4610)	// union X can never be instantiated
#pragma warning (disable : 4663)	// to explicitly spec class template X use ...
#pragma warning (disable : 4710)	// function 'XXX' not expanded
#pragma	warning	(disable : 4786)	// X: identifier truncated to '255' chars
#pragma warning( disable : 4706)

#include	<vector>
#include	<string>

#define LO_BYTE(w)    ((unsigned char)(((unsigned short)(w)) & 0xFF))
#define HI_BYTE(w)    ((unsigned char)(((unsigned short)(w) >> 8) & 0xff))

typedef		std::basic_string< TCHAR >	SString;			// String Type
typedef		std::vector< SString* >		SSVect;				// String Vector Type
typedef		SSVect::iterator			SSVectIter;			// String Vector Iterator

/////////////////////////////////////////////////////////////////////////////
// CDTXACBase window

class CDTXACBase
{
// Construction
public:
	CDTXACBase();

// Attributes
public:
	void	AddACEntry( LPCTSTR cpEntry );					// Add An AutoCompletion Entry
	void	DisableAC( bool bDisable = true );				// Disable AutoCompletion
	void	SetIgnoreChase(BOOL nValue) { m_IgnoreChase = nValue; }
	BOOL	GetIgnoreChase()			{ return m_IgnoreChase; }
// Operations
public:

// Overrides

// Implementation
public:
	virtual ~CDTXACBase();

	// Generated message map functions
protected:
	BOOL UpdateAC(CWnd* nUser);
	BOOL m_IgnoreChase;
	CString	m_sTarget;										// Target String To Check
	SSVect	m_vecACStrings;									// Vector Of AutoCompletion Strings
	bool	m_bDisableAC;									// Flag To Disable AutoCompletion
	bool	m_bDisabledInternally;							// Flag For Internal Disabling Of AC
	bool	m_bInUpdate;									// Recursion Flag
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXACBASE_H__A86BABAE_3A07_49C9_B64D_AAB395645572__INCLUDED_)
