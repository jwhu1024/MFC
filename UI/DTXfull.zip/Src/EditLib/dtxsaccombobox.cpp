// dtxsaCDTXComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "DTXSACComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXSACComboBox

CDTXSACComboBox::CDTXSACComboBox()
{
}

CDTXSACComboBox::~CDTXSACComboBox()
{
}


BEGIN_MESSAGE_MAP(CDTXSACComboBox, CDTXComboBox)
	//{{AFX_MSG_MAP(CDTXSACComboBox)
	ON_CONTROL_REFLECT(CBN_EDITUPDATE, OnEditupdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXSACComboBox message handlers

void CDTXSACComboBox::OnEditupdate() 
{
	DWORD nCursel = GetEditSel();
	int		iStart = LO_BYTE(nCursel);
	int		iEnd   = HI_BYTE(nCursel);

	if (UpdateAC(this))
	{
		SetEditSel(iStart, -1);
		UpdateWindow();
	}
}

BOOL CDTXSACComboBox::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		if(pMsg->wParam == VK_DELETE || pMsg->wParam == VK_BACK)
		{
			m_bDisableAC = true;								// Disable AutoComplete
			m_bDisabledInternally = true;
		}
		else if( ( m_bDisableAC ) && ( m_bDisabledInternally ) )// Else If Some Other Key, And Disabled Internally
		{
			m_bDisableAC = false;								// Enable AC
			m_bDisabledInternally = false;						// Unset Internal Flag
			UpdateWindow();										// Trigger Update
		}
	}
	return CDTXComboBox::PreTranslateMessage(pMsg);	return CDTXComboBox::PreTranslateMessage(pMsg);
}
