#if !defined(AFX_DTXRICHEDIT_H__A654C626_5F5F_463E_B0A9_CEADF9EEB452__INCLUDED_)
#define AFX_DTXRICHEDIT_H__A654C626_5F5F_463E_B0A9_CEADF9EEB452__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxrichedit.h : header file
//

#include "AutoRichEditCtrl.h"
#include <DTXBase.h>

/////////////////////////////////////////////////////////////////////////////
// CDTXRichEdit window

class CDTXRichEdit : public CAutoRichEditCtrl, public CDTXWndBase
{
// Construction
public:
	CDTXRichEdit();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXRichEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXRichEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXRichEdit)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void DrawBorder(bool fHot = TRUE);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXRICHEDIT_H__A654C626_5F5F_463E_B0A9_CEADF9EEB452__INCLUDED_)
