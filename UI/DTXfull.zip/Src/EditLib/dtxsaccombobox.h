#if !defined(AFX_DTXSACCOMBOBOX_H__0501CA24_802E_4855_BD79_A529A7425E76__INCLUDED_)
#define AFX_DTXSACCOMBOBOX_H__0501CA24_802E_4855_BD79_A529A7425E76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxsaccombobox.h : header file
//
#include "dtxacbase.h"
#include "DTXComboBox.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXSACComboBox window

class CDTXSACComboBox : public CDTXComboBox, public CDTXACBase
{
// Construction
public:
	CDTXSACComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXSACComboBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXSACComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXSACComboBox)
	afx_msg void OnEditupdate();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXSACCOMBOBOX_H__0501CA24_802E_4855_BD79_A529A7425E76__INCLUDED_)
