#if !defined(AFX_DTXLABEL_H__2E773A0C_0134_4C0C_AF5A_152768EEE0AA__INCLUDED_)
#define AFX_DTXLABEL_H__2E773A0C_0134_4C0C_AF5A_152768EEE0AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxlabel.h : header file
//
#include "DTXBase.h"

typedef enum {stNone, stRectangle, stRoundRect, stEllipse} ShapeType;

/////////////////////////////////////////////////////////////////////////////
// CDTXLabel window

class CDTXLabel : public CStatic, public CDTXWndBase
{
	DECLARE_DYNAMIC(CDTXLabel)
	
	ShapeType m_ShapeType;
	UINT	  m_TextAlignment;
// Construction
public:
	CDTXLabel();

// Attributes
public:
	void SetShape(ShapeType nType) { m_ShapeType = nType; }
	ShapeType GetShapeTYpe()       { return m_ShapeType;  }

	void SetTextAlignment(UINT nValue) { m_TextAlignment = nValue; }
	UINT GetTextAlignment()			   { return m_TextAlignment;   }
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXLabel)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetTextFont(CFont* pFont);
	virtual ~CDTXLabel();

	// Generated message map functions
protected:
	CFont m_TextFont;
	//{{AFX_MSG(CDTXLabel)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void DrawShape();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXLABEL_H__2E773A0C_0134_4C0C_AF5A_152768EEE0AA__INCLUDED_)
