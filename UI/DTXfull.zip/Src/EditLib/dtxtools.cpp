#include "stdafx.h"
#include "DTXTools.h"
#include <OLECTL.H>
#include <ocidl.h>

CString GetAppPath()
{
	TCHAR szExePath[MAX_PATH];
	GetModuleFileName( AfxGetInstanceHandle(), szExePath, MAX_PATH );

	//remove app name from path
	CString m_AppPath = szExePath;
	m_AppPath = m_AppPath.Left( m_AppPath.ReverseFind('\\') );
	m_AppPath += _T("\\");
	return m_AppPath;
}

bool FileExist(LPCTSTR lpszPath)
{
  CFileStatus status;
  return CFile::GetStatus(lpszPath, status) != 0;
}

void LoadPictureFile(LPCTSTR szFile, CBitmap* pBitmap)
{
	// open file
	HANDLE hFile = CreateFile(szFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	_ASSERTE(INVALID_HANDLE_VALUE != hFile);

	// get file size
	DWORD dwFileSize = GetFileSize(hFile, NULL);
	_ASSERTE(-1 != dwFileSize);

	LPVOID pvData = NULL;
	// alloc memory based on file size
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, dwFileSize);
	_ASSERTE(NULL != hGlobal);

	pvData = GlobalLock(hGlobal);
	_ASSERTE(NULL != pvData);

	DWORD dwBytesRead = 0;
	// read file and store in global memory
	BOOL bRead = ReadFile(hFile, pvData, dwFileSize, &dwBytesRead, NULL);
	_ASSERTE(FALSE != bRead);
	GlobalUnlock(hGlobal);
	CloseHandle(hFile);

	LPSTREAM pstm = NULL;
	// create IStream* from global memory
	HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &pstm);
	_ASSERTE(SUCCEEDED(hr) && pstm);

	// Create IPicture from image file
	LPPICTURE gpPicture;

	hr = ::OleLoadPicture(pstm, dwFileSize, FALSE, IID_IPicture, (LPVOID *)&gpPicture);
	_ASSERTE(SUCCEEDED(hr) && gpPicture);	
	pstm->Release();

	OLE_HANDLE m_picHandle;
	gpPicture->get_Handle(&m_picHandle);
	pBitmap->DeleteObject();
	pBitmap->Attach((HGDIOBJ) m_picHandle);
}


float ScaleFactor(BOOL bAllowZoom, CSize sizeSrc, CSize sizeTgt)
{
  float fScale = 1;

  // If the image is smaller than the target don't scale zoom

  if ((sizeSrc.cx < sizeTgt.cx)&& (sizeSrc.cy < sizeTgt.cy))
  {
    if (bAllowZoom)
    {
      float fScaleW = (float) sizeSrc.cx / (float) sizeTgt.cx;
      float fScaleH = (float)  sizeSrc.cy / (float) sizeTgt.cy;

      if (fScaleH < fScaleW)
      {
        fScale = fScaleH;
      }
      else
      {
        fScale = fScaleW;
      }
    }
    else
    {
      fScale = 1;
    }
  }

  // If the image is equal to the target don't scale

  if ((sizeSrc.cx == sizeTgt.cx) && (sizeSrc.cy == sizeTgt.cy))
  {
    fScale = 1;
  }

  // If the current image is wider than the target image,
  // reduce the size of the image whilst preserving the aspect
  // ratio of the original image.

  if ((sizeSrc.cx > sizeTgt.cx) && (sizeSrc.cy <= sizeTgt.cy))
  {
    fScale = (float) sizeTgt.cx / (float) sizeSrc.cx;
  }

  // If the current image is taller than the target image,
  // reduce the size of the image whilst preserving the aspect
  // ratio of the original image.

  if (((int)sizeSrc.cx <= sizeTgt.cx) && ((int)sizeSrc.cy > sizeTgt.cy))
    {
      fScale = (float) sizeTgt.cy / (float) sizeSrc.cy;
    }

  // If the Jpeg image is wider and taller than the client rectangle,
  // reduce the size of the image whilst preserving the aspect
  // ratio of the original image.

  if (((int)sizeSrc.cx > sizeTgt.cx) && ((int)sizeSrc.cy > sizeTgt.cy))
  {
    float fScaleW = (float) sizeTgt.cx / (float) sizeSrc.cx;
    float fScaleH = (float) sizeTgt.cy / (float) sizeSrc.cy;

    if (fScaleH < fScaleW)
      {
        fScale = fScaleH;
      }
    else
      {
        fScale = fScaleW;
      }
  }
  return fScale;
}

CSize Scale(CSize sizeSrc, CSize sizeTgt)
{
	CSize size;

	// Obtain the scaling factor
	float fScale = ScaleFactor(FALSE,sizeSrc,sizeTgt);

	// Calculate the size of the sized rectangle
	size.cx = (int) (((float) sizeSrc.cx * fScale) + 0.5);
	size.cy = (int) (((float) sizeSrc.cy * fScale) + 0.5);

	// Ensure roundings errors don't make scaled rectangle too large
	if (size.cx > sizeTgt.cx)
	{
		size.cx = sizeTgt.cx;
	}

	if (size.cy > sizeTgt.cy)
	{
		size.cy = sizeTgt.cy;
	}

	// Return dimensions of the rectangle
	return size;
}
