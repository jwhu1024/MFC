// dtxacbase.cpp : implementation file
//

#include "stdafx.h"
#include "dtxacbase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXACBase

CDTXACBase::CDTXACBase() :
	m_bDisableAC( false ),									// Default To AC Enabled
	m_bDisabledInternally( false ),							// Not Disabled Internally
	m_IgnoreChase(false), 									// Ignore Chase
	m_bInUpdate( false )									// Not In The Update Handler
{
}

CDTXACBase::~CDTXACBase()
{
	SSVectIter	iterString = m_vecACStrings.begin();
	SSVectIter	iterEnd = m_vecACStrings.end();
	SString		*pString = NULL;

	while( iterString != iterEnd )							// For All Available String Objects
	{
		pString = *iterString;								// Get String Pointer
		iterString++;										// Increment Iterator
		if( pString )										// If Not NULL
		{
			delete pString;									// Dealocate String
		}
	}
	return;													// Done!
}

/////////////////////////////////////////////////////////////////////////////
// CDTXACBase message handlers

void CDTXACBase::AddACEntry( LPCTSTR cpEntry )
{
	_ASSERTE( ( !cpEntry ) || ( !::IsBadStringPtr( cpEntry, // If Not NULL, Then...
			1 ) ) );										// Assert Valid For At Least One Character
	
	if( ( cpEntry ) && ( _tcslen( cpEntry ) >= 2 ) )		// If A String Is There
	{
		//
		//	NOTE: No Duplicate Checking Is Done Here, It Is 
		//	Supposed To Be Handled By The Data Provider!!!!
		//
		m_vecACStrings.push_back( new SString( cpEntry ) );	// Add String To Vector
	}
	return;													// Done!
}

void CDTXACBase::DisableAC( bool bDisable )
{
	m_bDisableAC = bDisable;								// Set Flag As Requested
	m_bDisabledInternally = false;							// Unset Internal Flag
}

BOOL CDTXACBase::UpdateAC(CWnd *nUser)
{
	if( m_bInUpdate )										// If Already Here
	{
		return( FALSE );									// Just Stop Here
	}
	int		iTLength = 0;
	
	m_bInUpdate = true;										// Set Recursion Flag
	
	if( ( m_vecACStrings.size() ) && ( iTLength =			// If Text There And Strings To Check Aganist
		nUser->GetWindowTextLength() ) && ( !m_bDisableAC ) )	// And Matching Not Disabled
	{
		SSVectIter	iterString = m_vecACStrings.begin();
		SSVectIter	iterEnd = m_vecACStrings.end();

		nUser->GetWindowText( m_sTarget );							// Get Target Text
		if(m_IgnoreChase)
			m_sTarget.MakeUpper();

		//
		//	Is The The Fastest Way?  No.  Is It Good Enough
		//	For The Current Specifications?  Yes.
		//	Comments/Suggestions Are Encouraged.
		//
		while( iterString != iterEnd )						// While Strings Available To Check
		{
			CString	cpTest = (*iterString) -> c_str();	// Get Text To Test Aganist
			CString tmp = cpTest;
			if(m_IgnoreChase)
				cpTest.MakeUpper();
			
			++iterString;									// Increment Iterator
			
			if( ( cpTest ) && ( !_tcsncmp( m_sTarget, 		// If String Pointer Not NULL
					cpTest, iTLength ) ) )					// If Match On Substring Found
			{
				nUser->SetWindowText( tmp );					// Set New Window Text
				nUser->UpdateWindow();								// Force Update
				break;										// Stop Here
			}
		}
	}
	m_bInUpdate = false;									// Unset Recursion Flag
	return( TRUE );											// Done!
}
