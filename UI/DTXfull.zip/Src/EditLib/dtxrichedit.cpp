// dtxrichedit.cpp : implementation file
//

#include "stdafx.h"
#include "dtxrichedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXRichEdit

CDTXRichEdit::CDTXRichEdit()
{
}

CDTXRichEdit::~CDTXRichEdit()
{
}
 

BEGIN_MESSAGE_MAP(CDTXRichEdit, CAutoRichEditCtrl)
	//{{AFX_MSG_MAP(CDTXRichEdit)
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_CTLCOLOR()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXRichEdit message handlers

void CDTXRichEdit::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}

void CDTXRichEdit::OnKillFocus(CWnd* pNewWnd) 
{
	m_GotFocus = false;
	Invalidate();
	CAutoRichEditCtrl::OnKillFocus(pNewWnd);
}

void CDTXRichEdit::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_GotFocus) 
	{
		if (!m_TimerSet) 
		{
			DrawBorder();
			SetTimer(1, 10, NULL);
			m_TimerSet = true;
		}
	}
	CAutoRichEditCtrl::OnMouseMove(nFlags, point);
}

void CDTXRichEdit::OnPaint() 
{
	Default();
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

void CDTXRichEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CAutoRichEditCtrl::OnSetFocus(pOldWnd);
	m_GotFocus = true;
	Invalidate();
}

HBRUSH CDTXRichEdit::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	DWORD	dwStyle = GetStyle();

	if(m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		if(m_GotFocus)
		{
			pDC->SetBkColor(m_FocusColor);
			m_BackBrush.CreateSolidBrush(m_FocusColor);
		}
		else
		{
			pDC->SetBkColor(m_ControlColor);
			m_BackBrush.CreateSolidBrush(m_ControlColor);
		}
		return((HBRUSH) m_BackBrush);
	}
	return(NULL);
}

void CDTXRichEdit::OnTimer(UINT nIDEvent) 
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) 
	{
		KillTimer(1);
		m_TimerSet = false;
		if (!m_GotFocus) 
			DrawBorder(false);
		else
			DrawBorder();
		return;
	}
	CAutoRichEditCtrl::OnTimer(nIDEvent);
}