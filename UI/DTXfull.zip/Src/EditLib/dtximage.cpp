// dtximage.cpp : implementation file
//

#include "stdafx.h"
#include "dtximage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXImage

CDTXImage::CDTXImage()
{
	m_AutoSize = false;
	m_UseControlColors = m_GotFocus =  m_TimerSet = false;
	m_GotFocus = m_DrawShadow = true;
	m_ShadowSize = 3;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor = m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = m_TextColor  = RGB(0, 0, 0);
	m_MenuID = 0;
}

CDTXImage::~CDTXImage()
{
	m_Image.DeleteObject();
}


BEGIN_MESSAGE_MAP(CDTXImage, CWnd)
	//{{AFX_MSG_MAP(CDTXImage)
	ON_WM_PAINT()
	ON_WM_RBUTTONDOWN()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDTXImage message handlers

BOOL CDTXImage::LoadBitmap(UINT nResID)
{
	m_Image.DeleteObject();
	BOOL nRes = m_Image.LoadBitmap(nResID);
	InternalGetSizes();
	Invalidate();
	return nRes;
}

void CDTXImage::InternalGetSizes()
{
	BITMAP bm;
	GetObject(m_Image.m_hObject, sizeof(bm), &bm);
	m_ImageSize.cx = bm.bmWidth; //nWidth;
	m_ImageSize.cy = bm.bmHeight; //nHeight;
}
	

BOOL CDTXImage::LoadBitmap(CString nFile)
{
	TRY
	{
		LoadPictureFile(nFile, &m_Image);
		InternalGetSizes();
		if(IsWindowEnabled()) Invalidate();

	}
	CATCH(CException, e)
	{
		return false;
	}
	END_CATCH
	return true;
}

void CDTXImage::OnPaint() 
{
	CRect r;
	GetClientRect(&r);
	
	CPaintDC dc(this);
	int w = m_ImageSize.cx, h = m_ImageSize.cy;
	if(w > 0 && h > 0)
	{
		r.DeflateRect(5, 5);
		int x = 5, y = 5;
		if(!m_AutoSize)
		{
			CSize sizeScaled = Scale(CSize(m_ImageSize.cx, m_ImageSize.cy), r.Size());
			w = sizeScaled.cx;
			h = sizeScaled.cy;
		}
		else
		{
			w -= 2; //r.Width()  - 2;
			h -= 2; //r.Height() - 2;
		}

		CPoint pt = r.TopLeft();
		x = ((r.Width() - w) / 2) + pt.x ;
	    y = ((r.Height() - h) / 2) + pt.y;
		if(x < 2) x = 2;
		if(y < 2) y = 2;
		if(h > r.Height() - 2) h = r.Height() - 2;
		if(w > r.Width() - 2) w = r.Width() - 2;

		CDC memdc;
		memdc.CreateCompatibleDC(&dc);
		memdc.SelectObject(m_Image);

		if(m_AutoSize)
			dc.BitBlt(x, y, w, h, &memdc, 0, 0, SRCCOPY);
		else
		dc.StretchBlt(x, y, w, h, &memdc, 
			0, 0, m_ImageSize.cx, m_ImageSize.cy, SRCCOPY); 
	}
}

void CDTXImage::SetMenuID(UINT mMenuID)
{
	m_MenuID = mMenuID;
}

void CDTXImage::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (m_MenuID > 0)
	{
		CMenu popMenu;

		popMenu.LoadMenu(m_MenuID);
	
		CPoint posMouse;
		GetCursorPos(&posMouse);

		popMenu.GetSubMenu(0)->TrackPopupMenu(0, posMouse.x, posMouse.y, GetParent());
	} 
	CWnd::OnRButtonDown(nFlags, point);
}

BOOL CDTXImage::OnEraseBkgnd(CDC* pDC) 
{
	ASSERT_VALID(pDC);
	CBrush backBrush(m_ControlColor);
	CRect rect;
	GetClientRect(&rect);

	pDC->FillRect(&rect, &backBrush);
	DrawBorder(true, this, true);	
	ReleaseDC(pDC);
	return false;
}

void CDTXImage::Empty()
{
	CRect r;
	GetClientRect(&r);
	m_Image.CreateBitmap(r.Width() - 5, r.Height() - 5, 1, 16, NULL);
	CDC* pDC = GetDC();
	pDC->SelectObject(&m_Image);
	pDC->FillRect(&r, NULL);
	ReleaseDC(pDC);
	InternalGetSizes();
	DrawBorder(true, this);
}
