#ifndef __DTX_TOOS_H__
#define __DTX_TOOS_H__

void LoadPictureFile(LPCTSTR szFile, CBitmap* pBitmap);
float ScaleFactor(BOOL bAllowZoom, CSize sizeSrc, CSize sizeTgt);
CSize Scale(CSize sizeSrc, CSize sizeTgt);
bool FileExist(LPCTSTR lpszPath);
CString GetAppPath();

#endif
