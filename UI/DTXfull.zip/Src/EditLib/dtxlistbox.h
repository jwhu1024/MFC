#if !defined(AFX_DTXLISTBOX_H__B2DD2D9B_0FC5_4F92_83D2_A94156701A7D__INCLUDED_)
#define AFX_DTXLISTBOX_H__B2DD2D9B_0FC5_4F92_83D2_A94156701A7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxlistbox.h : header file
//
#include "DTXBase.h"
/////////////////////////////////////////////////////////////////////////////
// CDTXListBox window

class CDTXListBox : public CListBox, public CDTXWndBase
{
	DECLARE_DYNAMIC(CDTXListBox)
// Construction
public:
	CDTXListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXListBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXListBox();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot = true);
	//{{AFX_MSG(CDTXListBox)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXLISTBOX_H__B2DD2D9B_0FC5_4F92_83D2_A94156701A7D__INCLUDED_)
