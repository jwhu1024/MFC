#if !defined(AFX_DTXGRID_H__C8D30E31_CA01_46D2_86CE_C87471C5B5DB__INCLUDED_)
#define AFX_DTXGRID_H__C8D30E31_CA01_46D2_86CE_C87471C5B5DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxgrid.h : header file
//

#include <DTXBase.h>
#include <ALXGridCtrl.h>

/////////////////////////////////////////////////////////////////////////////
// CDTXGrid window

class CDTXGrid : public CWnd, public CDTXWndBase
{
// Construction
public:
	CDTXGrid();

// Attributes
public:
	CALXGridCtrl m_Grid;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXGrid)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXGrid();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXGrid)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DrawBorder(bool fHot = TRUE);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXGRID_H__C8D30E31_CA01_46D2_86CE_C87471C5B5DB__INCLUDED_)
