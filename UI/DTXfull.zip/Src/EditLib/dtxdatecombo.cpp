// dtxdatecombo.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdatecombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPopupDate

BEGIN_MESSAGE_MAP(CPopupDate, CListboxDate)
	//{{AFX_MSG_MAP(CPopupDate)
	ON_WM_LBUTTONDOWN()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPopupDate::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if((nChar == VK_ESCAPE))
	{
		GetParent()->PostMessage(WM_CLOSE);
	}
	CListboxDate::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CPopupDate::OnLButtonDown(UINT nFlags, CPoint point)
{
	CListboxDate::OnLButtonDown(nFlags, point);
	if(m_arrSelection.GetSize() >  0)
	{
		CDate dt = m_arrSelection.GetAt(0);
		GetParent()->SetWindowText(dt.Format(DATE_SHORTDATE));
	}
	GetParent()->PostMessage(WM_CLOSE);
}

void CPopupDate::SetDate(CDate& dt)
{
	m_arrSelection.RemoveAll();
	m_arrSelection.Add(dt);
	m_dtPreview.SetDate(dt.GetYear(), dt.GetMonth(), 1);
}

/////////////////////////////////////////////////////////////////////////////
// CDateWnd

CDateWnd::CDateWnd(CComboBox* pWnd)
: CPopupWnd(pWnd)
{
}

BEGIN_MESSAGE_MAP(CDateWnd, CPopupWnd)
	//{{AFX_MSG_MAP(CDateWnd)
	ON_WM_CREATE()
	ON_WM_PAINT()
	ON_MESSAGE(WM_SETTEXT, OnSetText)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CDateWnd::SetDate(CDate& dt)
{
	if(pWnd && pWnd->GetSafeHwnd())
		pWnd->SetDate(dt);
}

LRESULT CDateWnd::OnSetText(WPARAM wParam, LPARAM lParam)
{
	CString str((LPCTSTR)lParam);
	if(pWndCombo && pWndCombo->GetSafeHwnd())
		pWndCombo->SetWindowText(str);
	return DefWindowProc(WM_SETTEXT, wParam, lParam);
}

int CDateWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CPopupWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	pWnd = new CPopupDate;
	if(pWnd)
	{
		pWnd->Create(WS_BORDER|WS_CHILD|WS_VISIBLE, CRect(1, 1, lpCreateStruct->cx - 1, lpCreateStruct->cy - 1), this, 1);
		pWnd->SetFont(GetFont());
		return 0;
	}
	return -1;
}

CDateWnd::~CDateWnd()
{
}

void CDateWnd::InitFont(CFont *pFont)
{
 	if(pWnd && pWnd->GetSafeHwnd())
 		pWnd->SetFont(pFont);
}

void CDateWnd::OnPaint() 
{
	CRect r;
	
	GetClientRect(&r);
	r.bottom -= 17;
	CPaintDC dc(this);
	dc.Rectangle(&r);
}

/////////////////////////////////////////////////////////////////////////////
// CDateComboBox

CDateComboBox::CDateComboBox() : pWnd(NULL)
{
	SetControlSize(CSize(138, 138));
	SetPopupWnd(pWnd);
}

CDateComboBox::~CDateComboBox()
{
}

void CDateComboBox::OnPopup()
{
	pWnd = new CDateWnd(this);
	pWnd->SetPopupCombo(this);
	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = pWnd->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	if(bSuccess)
	{
		CString str;
		GetWindowText(str);
		if(!str.IsEmpty())
		{
			CDate dt;
			dt.ParseDate(str);
			pWnd->SetDate(dt);
		}
		pWnd->ModifyStyle(0, WS_BORDER);
		pWnd->InitFont(GetFont());
		pWnd->SetFocus();
	}
}

void CDateComboBox::SetDate(CDate &dt)
{
	SetWindowText(dt.Format(DATE_SHORTDATE));
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDateComboBox

CDTXDateComboBox::CDTXDateComboBox() : pWnd(NULL)
{
	SetControlSize(CSize(138, 138));
	SetPopupWnd(pWnd);
}

CDTXDateComboBox::~CDTXDateComboBox()
{
}

void CDTXDateComboBox::OnPopup()
{
	pWnd = new CDateWnd(this);
	pWnd->SetPopupCombo(this);
	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = pWnd->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	if(bSuccess)
	{
		pWnd->SetDlgCtrlID(2);
		CString str;
		GetWindowText(str);
		if(!str.IsEmpty())
		{
			CDate dt;
			dt.ParseDate(str);
			pWnd->SetDate(dt);
		}
		pWnd->ModifyStyle(0, WS_BORDER);
		pWnd->InitFont(GetFont());
		pWnd->SetFocus();
	}
}

void CDTXDateComboBox::SetDate(CDate &dt)
{
	SetWindowText(dt.Format(DATE_SHORTDATE));
}
