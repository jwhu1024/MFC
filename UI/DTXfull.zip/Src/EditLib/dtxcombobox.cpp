// dtxcombobox.cpp : implementation file
//

#include "stdafx.h"
#include "dtxcombobox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXComboBox

IMPLEMENT_DYNAMIC(CDTXComboBox, CFlatComboBox)

CDTXComboBox::CDTXComboBox()
{
	m_UseControlColors = false;
}

CDTXComboBox::~CDTXComboBox()
{
}


BEGIN_MESSAGE_MAP(CDTXComboBox, CFlatComboBox)
	//{{AFX_MSG_MAP(CDTXComboBox)
	ON_WM_TIMER()
	ON_WM_PAINT()
	ON_WM_MOUSEMOVE()
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	ON_CONTROL_REFLECT(CBN_SETFOCUS, OnSetfocus)
	ON_WM_CTLCOLOR()
	ON_WM_KILLFOCUS()
	ON_CONTROL_REFLECT(CBN_CLOSEUP, OnCloseUp)
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXComboBox message handlers

void CDTXComboBox::OnTimer(UINT nIDEvent) 
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) 
	{
		KillTimer(1);
		m_TimerSet = false;
		if (!m_GotFocus) 
			DrawBorder(false);
		else
			DrawBorder();
	}
}

void CDTXComboBox::OnPaint() 
{
	Default();
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

void CDTXComboBox::OnKillfocus() 
{
	CFlatComboBox::OnKillfocus();
	m_GotFocus = false;
//	Invalidate();
}

void CDTXComboBox::OnSetfocus() 
{
	CFlatComboBox::OnSetfocus();
	m_GotFocus = true;
//	Invalidate();
}

void CDTXComboBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	CFlatComboBox::OnMouseMove(nFlags, point);
	if (!m_GotFocus) 
	{
		if (!m_TimerSet) 
		{
			DrawBorder();
			SetTimer(1, 10, NULL);
			m_TimerSet = true;
		}
	}
}

void CDTXComboBox::DrawBorder(bool fHot)
{
	if (m_bFocused)
		DrawCombo (FC_DRAWPRESSD,	::GetSysColor(COLOR_BTNHIGHLIGHT),
									::GetSysColor(COLOR_BTNSHADOW));
	else
		DrawCombo (FC_DRAWNORMAL,	::GetSysColor(COLOR_BTNFACE),
									::GetSysColor(COLOR_BTNFACE));
	CDTXWndBase::DrawBorder(fHot, this, true);
}

HBRUSH CDTXComboBox::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	DWORD	dwStyle = GetStyle();

	if(m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		if(m_GotFocus)
		{
			pDC->SetTextColor(m_FocusTextColor);
			pDC->SetBkColor(m_FocusColor);
			m_BackBrush.CreateSolidBrush(m_FocusColor);
		}
		else
		{
			pDC->SetTextColor(m_TextColor);
			pDC->SetBkColor(m_ControlColor);
			m_BackBrush.CreateSolidBrush(m_ControlColor);
		}
		return((HBRUSH) m_BackBrush);
	}
	return(NULL);
}

void CDTXComboBox::OnKillFocus(CWnd* pNewWnd) 
{
	CFlatComboBox::OnKillFocus(pNewWnd);
	m_GotFocus = false;
	Invalidate();
}

void CDTXComboBox::OnCloseUp()
{
	Invalidate();
}

void CDTXComboBox::OnSetFocus(CWnd* pOldWnd) 
{
	CFlatComboBox::OnSetFocus(pOldWnd);
	m_GotFocus = true;
	Invalidate();
}
