#if !defined(AFX_DTXIMAGE_H__E5DA7B76_3033_4FF4_B497_9AAA9CE2C146__INCLUDED_)
#define AFX_DTXIMAGE_H__E5DA7B76_3033_4FF4_B497_9AAA9CE2C146__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtximage.h : header file
//

#include "DTXBase.h"
#include "DTXTools.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXImage window

class CDTXImage : public CWnd, public CDTXWndBase
{
// Construction
public:
	CDTXImage();

// Attributes
public:
	BOOL m_AutoSize;
	void GetImageSizes(CSize& nSize) { nSize = m_ImageSize; }
	CString GetFileName()            { return m_ImageFileName; }
	CBitmap& GetBitmap()			 { return m_Image; }
	void SetMenuID(UINT mMenuID);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXImage)
	//}}AFX_VIRTUAL

// Implementation
public:
	void Empty();
	BOOL LoadBitmap(CString nFile);
	BOOL LoadBitmap(UINT nResID);
	virtual ~CDTXImage();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXImage)
	afx_msg void OnPaint();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	UINT m_MenuID;
	CBitmap m_Image;
	CSize	m_ImageSize;
	CString m_ImageFileName;
	void InternalGetSizes();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXIMAGE_H__E5DA7B76_3033_4FF4_B497_9AAA9CE2C146__INCLUDED_)
