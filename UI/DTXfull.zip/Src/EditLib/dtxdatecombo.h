#if !defined(AFX_DTXDATECOMBO_H__AE62B4E9_3FE2_4FFA_BA93_6FE42B90277D__INCLUDED_)
#define AFX_DTXDATECOMBO_H__AE62B4E9_3FE2_4FFA_BA93_6FE42B90277D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdatecombo.h : header file
//
#include <DTXBase.h>
#include "DateCtrl.h"
#include "PopupCombo.h"

/////////////////////////////////////////////////////////////////////////////
// CPopupDate

class CPopupDate : public CListboxDate
{
public:
	void SetDate(CDate& dt);
protected:
	//{{AFX_MSG(CDateWnd)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CDateWnd

class CDateWnd: public CPopupWnd
{
	CPopupDate* pWnd;
public:
	void InitFont(CFont* pFont);
	CDateWnd(CComboBox* pWnd);
	void SetDate(CDate& dt);
	~CDateWnd();
protected:
	//{{AFX_MSG(CDateWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnPaint();
	afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CDateComboBox window

class CDateComboBox : public CPopupCombo 
{
	CDateWnd* pWnd;
// Construction
public:
	CDateComboBox();

// Attributes
public:

// Operations
public:

// Overrides
// Implementation
public:
	void SetDate(CDate& dt);
	virtual ~CDateComboBox();
	// Generated message map functions
protected:
	afx_msg virtual void OnPopup();
};

/////////////////////////////////////////////////////////////////////////////
// CDTXDateComboBox window

class CDTXDateComboBox : public CDTXPopupCombo 
{
	CDateWnd* pWnd;
// Construction
public:
	CDTXDateComboBox();

// Attributes
public:

// Operations
public:

// Overrides
// Implementation
public:
	void SetDate(CDate& dt);
	virtual ~CDTXDateComboBox();
	// Generated message map functions
protected:
	afx_msg virtual void OnPopup();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDATECOMBO_H__AE62B4E9_3FE2_4FFA_BA93_6FE42B90277D__INCLUDED_)
