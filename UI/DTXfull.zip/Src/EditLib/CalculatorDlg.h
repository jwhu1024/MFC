#if !defined(AFX_CALCULATORDLG_H__03222BF1_852A_4EC2_9E07_7B79F35A9B49__INCLUDED_)
#define AFX_CALCULATORDLG_H__03222BF1_852A_4EC2_9E07_7B79F35A9B49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CalculatorDlg.h : header file
//
#include "CalculatorWnd.h"
#include "dtxlibrc.h"

/////////////////////////////////////////////////////////////////////////////
// CCalculatorDlg dialog

class CCalculatorDlg : public CDialog
{
	CCalculatorWnd* m_CalcWnd;	
	DECLARE_DYNCREATE(CCalculatorDlg )
// Construction
public:
	CCalculatorDlg(CWnd* pParent = NULL);   // standard constructor
	~CCalculatorDlg();

// Dialog Data
	//{{AFX_DATA(CCalculatorDlg)
	enum { IDD = IDD_CALCULATORDIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCalculatorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCalculatorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnMove(int x, int y);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CALCULATORDLG_H__03222BF1_852A_4EC2_9E07_7B79F35A9B49__INCLUDED_)
