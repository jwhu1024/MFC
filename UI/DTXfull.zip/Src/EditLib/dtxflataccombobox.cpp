// dtxflataccombobox.cpp : implementation file
//

#include "stdafx.h"
#include "dtxflataccombobox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXFlatACComboBox

CDTXFlatACComboBox::CDTXFlatACComboBox()
{
}

CDTXFlatACComboBox::~CDTXFlatACComboBox()
{
}


BEGIN_MESSAGE_MAP(CDTXFlatACComboBox, CFlatComboBox)
	//{{AFX_MSG_MAP(CDTXFlatACComboBox)
	ON_CONTROL_REFLECT(CBN_EDITUPDATE, OnEditupdate)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXFlatACComboBox message handlers

BOOL CDTXFlatACComboBox::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		if(pMsg->wParam == VK_DELETE || pMsg->wParam == VK_BACK)
		{
			m_bDisableAC = true;								// Disable AutoComplete
			m_bDisabledInternally = true;
		}
		else if( ( m_bDisableAC ) && ( m_bDisabledInternally ) )// Else If Some Other Key, And Disabled Internally
		{
			m_bDisableAC = false;								// Enable AC
			m_bDisabledInternally = false;						// Unset Internal Flag
			UpdateWindow();										// Trigger Update
		}
	}
	return CFlatComboBox::PreTranslateMessage(pMsg);
}

void CDTXFlatACComboBox::OnEditupdate() 
{
	DWORD nCursel = GetEditSel();
	int		iStart = LO_BYTE(nCursel);
	int		iEnd   = HI_BYTE(nCursel);

	if (UpdateAC(this))
	{
		SetEditSel(iStart, -1);
		UpdateWindow();
	}
}
