// CalculatorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CalculatorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCalculatorDlg dialog

IMPLEMENT_DYNCREATE(CCalculatorDlg, CDialog)

CCalculatorDlg::CCalculatorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalculatorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCalculatorDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_CalcWnd = NULL;
}

CCalculatorDlg::~CCalculatorDlg()
{
	if(m_CalcWnd)
		delete m_CalcWnd;
}

void CCalculatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCalculatorDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCalculatorDlg, CDialog)
	//{{AFX_MSG_MAP(CCalculatorDlg)
	ON_WM_MOVE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalculatorDlg message handlers

BOOL CCalculatorDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_CalcWnd = new CCalculatorWnd(NULL);

	BOOL bSuccess = 
		m_CalcWnd->Create(-1, -1, 235, 155, 0, WS_VISIBLE|WS_CHILD, GetSafeHwnd());
	m_CalcWnd->SetParent(this);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CCalculatorDlg::OnMove(int x, int y) 
{
	CDialog::OnMove(x, y);
	CRect r;
	GetClientRect(&r);
	ClientToScreen(&r);
	if(m_CalcWnd && m_CalcWnd->GetSafeHwnd())
	{
		m_CalcWnd->MoveWindow(-1, -1, 235, 155);
	}
}

void CCalculatorDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// Do not call CDialog::OnPaint() for painting messages
}
