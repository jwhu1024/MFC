#if !defined(AFX_DTXCOMBOBOX_H__A07F9B3D_31D4_49D8_8F79_07DB76EB5735__INCLUDED_)
#define AFX_DTXCOMBOBOX_H__A07F9B3D_31D4_49D8_8F79_07DB76EB5735__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxcombobox.h : header file
//

#include "DTXBase.h"
#include "FlatComboBox.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXComboBox window

class CDTXComboBox : public CFlatComboBox, public CDTXWndBase
{
	DECLARE_DYNAMIC(CDTXComboBox)
// Construction
public:
	CDTXComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXComboBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXComboBox();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot = true);
	//{{AFX_MSG(CDTXComboBox)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPaint();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKillfocus();
	afx_msg void OnSetfocus();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnCloseUp();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXCOMBOBOX_H__A07F9B3D_31D4_49D8_8F79_07DB76EB5735__INCLUDED_)
