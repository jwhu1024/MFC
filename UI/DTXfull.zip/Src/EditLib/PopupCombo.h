#if !defined(AFX_POPUPCOMBO_H__DAB9CE4E_DE72_477E_BA03_EF83C8D0B6D4__INCLUDED_)
#define AFX_POPUPCOMBO_H__DAB9CE4E_DE72_477E_BA03_EF83C8D0B6D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PopupCombo.h : header file
//

#include <DTXComboBox.h>

class CPopupCombo;

class CPopupWnd : public CWnd
{
public:
	CPopupWnd(CComboBox* pWnd);
	void SetPopupCombo(CComboBox* pCombo)
	{ pWndCombo = pCombo; }

	virtual BOOL Create(int x, int y, int w, int h, 
		DWORD dwStyleEX = WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
		DWORD dwStyle = WS_POPUP | WS_VISIBLE,
		HWND pParent = NULL);
protected:
	//{{AFX_MSG(CCalcWnd)
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
   	DECLARE_MESSAGE_MAP()
	CComboBox* pWndCombo;
	virtual void InitFont()
	{};
};

/////////////////////////////////////////////////////////////////////////////
// CPopupCombo window

class CPopupCombo : public CComboBox
{
// Construction
public:
	CPopupCombo();

// Attributes
public:

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPopupCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetPopupWnd(CPopupWnd* pWnd);
	virtual ~CPopupCombo();
	void SetControlSize(CSize nSize)
	{ m_CtrlSize = nSize; }

	// Generated message map functions
protected:
	//{{AFX_MSG(CPopupCombo)
	afx_msg void OnDropdown();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
	afx_msg virtual void OnPopup();
	DECLARE_MESSAGE_MAP()
	CPopupWnd* pPopupWnd;
	CSize m_CtrlSize;
};

class CDTXPopupCombo : public CDTXComboBox
{
// Construction
public:
	CDTXPopupCombo();

// Attributes
public:

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXPopupCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetPopupWnd(CPopupWnd* pWnd);
	virtual ~CDTXPopupCombo();
	void SetControlSize(CSize nSize)
	{ m_CtrlSize = nSize; }

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXPopupCombo)
	afx_msg void OnDropdown();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//}}AFX_MSG
	afx_msg virtual void OnPopup();
	DECLARE_MESSAGE_MAP()
	CPopupWnd* pPopupWnd;
	CSize m_CtrlSize;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POPUPCOMBO_H__DAB9CE4E_DE72_477E_BA03_EF83C8D0B6D4__INCLUDED_)
