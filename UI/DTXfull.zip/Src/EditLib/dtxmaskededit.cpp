// dtxmaskededit.cpp : implementation file
//

#include "stdafx.h"
#include "dtxmaskededit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXMaskedEdit

CDTXMaskedEdit::CDTXMaskedEdit()
{
}

CDTXMaskedEdit::~CDTXMaskedEdit()
{
}


BEGIN_MESSAGE_MAP(CDTXMaskedEdit, COXMaskedEdit)
	//{{AFX_MSG_MAP(CDTXMaskedEdit)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXMaskedEdit message handlers
void CDTXMaskedEdit::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}

void CDTXMaskedEdit::OnPaint() 
{
	Default();
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

void CDTXMaskedEdit::OnSetFocus(CWnd* pOldWnd) 
{
	COXMaskedEdit::OnSetFocus(pOldWnd);
	m_GotFocus = true;
	Invalidate();
}

void CDTXMaskedEdit::OnKillFocus(CWnd* pNewWnd) 
{
	COXMaskedEdit::OnKillFocus(pNewWnd);
	m_GotFocus = false;
	Invalidate();
}

void CDTXMaskedEdit::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_GotFocus) 
	{
		if (!m_TimerSet) 
		{
			DrawBorder();
			SetTimer(1, 10, NULL);
			m_TimerSet = true;
		}
	}

	COXMaskedEdit::OnMouseMove(nFlags, point);
}

void CDTXMaskedEdit::OnTimer(UINT nIDEvent) 
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) 
	{
		KillTimer(1);
		m_TimerSet = false;
		if (!m_GotFocus) 
			DrawBorder(false);
		else
			DrawBorder();
		return;
	}
	COXMaskedEdit::OnTimer(nIDEvent);
}

HBRUSH CDTXMaskedEdit::CtlColor(CDC* pDC, UINT nCtlColor)
{
	DWORD	dwStyle = GetStyle();

	if(m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		if(m_GotFocus)
		{
			pDC->SetTextColor(m_FocusTextColor);
			pDC->SetBkColor(m_FocusColor);
			m_BackBrush.CreateSolidBrush(m_FocusColor);
		}
		else
		{
			pDC->SetTextColor(m_TextColor);
			pDC->SetBkColor(m_ControlColor);
			m_BackBrush.CreateSolidBrush(m_ControlColor);
		}
		return((HBRUSH) m_BackBrush);
	}
	return(NULL);
}
