// DTXBase.cpp : implementation file
//

#include "stdafx.h"
#include "DTXBase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef WS_EX_LAYOUTRTL
#define WS_EX_LAYOUTRTL                    0x00400000L
#endif

COLORREF m_clr3DFace     = GetSysColor(COLOR_3DFACE);
COLORREF m_clr3DLight    = GetSysColor(COLOR_3DLIGHT);
COLORREF m_clr3DHilight  = GetSysColor(COLOR_3DHILIGHT);
COLORREF m_clr3DShadow   = GetSysColor(COLOR_3DSHADOW);
COLORREF m_clr3DDkShadow = GetSysColor(COLOR_3DDKSHADOW);

/////////////////////////////////////////////////////////////////////////////
// CDTXWndBase

CDTXWndBase::CDTXWndBase()
{
#ifdef DTX_DEMO_
	static BOOL nMessageBox = FALSE;
	if(!nMessageBox)
	{
		AfxMessageBox(_T("DTX - Database Toolbox For MFC Ver 1.8\n") \
					  _T("Freeware version\n\nCopyright 2001 by C�neyt EL�BOL\n\n") \
					  _T("http://server33.hypermart.net/celibol\n\n") \
					  _T("celibol@alibaba.com or celibol@hotmail.com\n\n") \
					  _T("Thanks for using DTX"));
		nMessageBox = TRUE;
	}
#endif

	m_UseControlColors = m_GotFocus =  m_TimerSet = false;
	m_DrawShadow = true;
	m_ShadowSize = 5;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor  = RGB(0xFF, 0xFF, 0x00);
	m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = RGB(0, 0, 255);
	m_TextColor  = RGB(0, 0, 0);
}

CDTXWndBase::~CDTXWndBase()
{
}

/////////////////////////////////////////////////////////////////////////////
// CDTXWndBase message handlers

void CDTXWndBase::DrawBorder(bool fHot, CWnd *fThisWnd, bool m_Inc)
{
	CRect rcItem;
	DWORD dwExStyle = fThisWnd->GetExStyle();
	CDC* pDC = fThisWnd->GetDC();
	COLORREF clrBlack;
	int nBorderWidth = 0;
	int nLoop;

	fThisWnd->GetWindowRect(&rcItem);
	::ScreenToClient(fThisWnd->GetSafeHwnd(), (LPPOINT)&rcItem);
	::ScreenToClient(fThisWnd->GetSafeHwnd(), ((LPPOINT)&rcItem)+1);
	if (dwExStyle & WS_EX_LAYOUTRTL)
		CRect::SwapLeftRight(&rcItem);

	clrBlack = RGB(0, 0, 0);

	if (!fThisWnd->IsWindowEnabled()) 
		fHot = true;

	if (dwExStyle & WS_EX_DLGMODALFRAME) 
		nBorderWidth += 3;

	if (dwExStyle & WS_EX_CLIENTEDGE) 
		nBorderWidth += 2;

	if (dwExStyle & WS_EX_STATICEDGE && !(dwExStyle & WS_EX_DLGMODALFRAME)) 
		nBorderWidth ++;

	// blank the border
	for (nLoop = 0; nLoop < nBorderWidth; nLoop++) 
	{
		pDC->Draw3dRect(rcItem, m_clr3DFace, m_clr3DFace);
		rcItem.DeflateRect(1, 1);
	}
	rcItem.InflateRect(1, 1);

	WINDOWPLACEMENT wp;
	fThisWnd->GetWindowPlacement(&wp);

	if(m_DrawShadow)
	{
		CRect rectRight(wp.rcNormalPosition.right - 1, wp.rcNormalPosition.top + m_ShadowSize,
			wp.rcNormalPosition.right + m_ShadowSize - 1, wp.rcNormalPosition.bottom + m_ShadowSize - 1);
		
		CRect rectBottom(wp.rcNormalPosition.left + m_ShadowSize, wp.rcNormalPosition.bottom - 1,
			wp.rcNormalPosition.right + m_ShadowSize - 1, wp.rcNormalPosition.bottom + m_ShadowSize - 1);

		if(m_Inc)
		{
			rectRight.left += 2;
			rectBottom.top += 2;
		}

		CDC* ppDC = fThisWnd->GetParent()->GetDC();

		CBrush br(m_ShadowColor);
		CBrush* pOldBrush = ppDC->SelectObject(&br);
		ppDC->PatBlt(rectRight.left, rectRight.top, rectRight.Width(), 
			rectRight.Height(), PATCOPY);
		ppDC->PatBlt(rectBottom.left, rectBottom.top, rectBottom.Width(), 
			rectBottom.Height(), PATCOPY);
		ppDC->SelectObject(pOldBrush);
	}

	pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);

	if (fHot) 
	{
		if (dwExStyle & WS_EX_CLIENTEDGE) 
		{
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
			rcItem.InflateRect(1, 1);
		}

		if (dwExStyle & WS_EX_STATICEDGE && !(dwExStyle & WS_EX_DLGMODALFRAME)) 
		{
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
			rcItem.InflateRect(1, 1);
		}

		if (dwExStyle & WS_EX_DLGMODALFRAME) 
		{
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
			rcItem.InflateRect(1, 1);
			pDC->Draw3dRect(rcItem, m_borderColor, m_borderColor);
		}
	}
	fThisWnd->ReleaseDC(pDC);
}
