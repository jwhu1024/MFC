#ifndef NUMEDITC_H
#define NUMEDITC_H

// Created by Corey Spagnoli  1/14/98
// How to use:
// 1. Create an edit control on your dialog.
// 2. Declare a variable in your dialog class, like this:
//       CNumericEdit m_NumeriCDTXEdit;
// 3. In OnInitDialog, call SubclassDlgItem, like this:
//       m_NumeriCDTXEdit.SubclassDlgItem(IDC_NUMERIC_EDIT, this); // Use your edit control ID here
// 4. Set the prefix, suffix, # decimals, and whether commas should be displayed using the following member functions:
//       void SetAttributes(short NumDecimalPlaces, BOOL DisplayCommas = TRUE);
//       void SetPrefix(CString Prefix);
//       void SetSuffix(CString Suffix);
// 5. Set (optional) and retrieve the numeric value within your dialog as needed using the following member functions:
//       double GetNumericValue(); 
//       void SetNumericValue(double NumericValue);


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// NumEditC.h : header file
//
#include "DTXEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CNumericEdit window

class CNumericEdit : public CDTXEdit
{
// Construction
public:
	CNumericEdit();

// Attributes
public:

// Operations
public:
   double GetNumericValue() {return m_NumericValue;}
   void SetNumericValue(double NumericValue);
   void SetAttributes(short NumDecimalPlaces, BOOL DisplayCommas = TRUE);
   void SetPrefix(CString Prefix);
   void SetSuffix(CString Suffix);
   

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNumericEdit)
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNumericEdit();
	void SetMinMax(double nmin, double nmax);
	// Generated message map functions
protected:
    BOOL m_DecimalAlreadyUsed;   
	BOOL m_UseMinMax;
    short m_NumDecimalPlaces;   
	BOOL m_InsertCommas; 
	double m_NumericValue;
	double m_MinValue;
	double m_MaxValue;
	BOOL m_HasValue;
	CString m_Prefix;
	CString m_Suffix;

   void SetNumericText(BOOL InsertFormatting);
   double RoundToDecimal(double Value, short DecimalPlaces);
   BOOL DoesCharacterPass(UINT nChar, int CharacterPosition);

	//{{AFX_MSG(CNumericEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChange();
	afx_msg void OnSetfocus();
	afx_msg void OnKillfocus();
	//}}AFX_MSG
   afx_msg LRESULT OnPaste(WPARAM Wparam, LPARAM LParam);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(NUMEDITC_H)
