// PopupCombo.cpp : implementation file
//

#include "stdafx.h"
#include "PopupCombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int WM_DISPLAYPOPUPWND = WM_USER + 1;

BEGIN_MESSAGE_MAP(CPopupWnd, CWnd)
	//{{AFX_MSG_MAP(CPopupWnd)
		ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CPopupWnd::CPopupWnd(CComboBox* pWnd)
{
	pWndCombo = pWnd;
}

BOOL CPopupWnd::Create(int x, int y, int w, int h, 
		DWORD dwStyleEX, DWORD dwStyle, HWND pParent)
{
   static LPCTSTR lpszName = NULL;
   
   if (!lpszName)
   {
      lpszName = AfxRegisterWndClass(CS_DBLCLKS);
   }
   return CreateEx(dwStyleEX, lpszName, _T(""), dwStyle, x, y, w, h, pParent, NULL);
}

void CPopupWnd::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CWnd::OnActivate(nState, pWndOther, bMinimized);
	
	if ((pWndOther != NULL) && (pWndOther->GetParent() == this))
		return;
   
	if (m_hWnd && nState == WA_INACTIVE)
	{
		PostMessage(WM_CLOSE);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPopupCombo

CPopupCombo::CPopupCombo()
{
	pPopupWnd = NULL;
	m_CtrlSize = CSize(0, 0);
}

CPopupCombo::~CPopupCombo()
{
	if(pPopupWnd)
		delete pPopupWnd;
}


BEGIN_MESSAGE_MAP(CPopupCombo, CComboBox)
	//{{AFX_MSG_MAP(CPopupCombo)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropdown)
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
	ON_COMMAND(WM_DISPLAYPOPUPWND, OnPopup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPopupCombo message handlers

void CPopupCombo::OnDropdown() 
{
	ShowDropDown(FALSE);
	PostMessage(WM_COMMAND, WM_DISPLAYPOPUPWND);	
}

void CPopupCombo::OnPopup()
{
	pPopupWnd = new CPopupWnd(this);

	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = pPopupWnd ->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	pPopupWnd ->SetFocus();
}

void CPopupCombo::SetPopupWnd(CPopupWnd* pWnd)
{
	pPopupWnd = pWnd;
}

void CPopupCombo::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CComboBox::OnActivate(nState, pWndOther, bMinimized);
}


/////////////////////////////////////////////////////////////////////////////
// CPopupCombo

CDTXPopupCombo::CDTXPopupCombo()
{
	pPopupWnd = NULL;
	m_CtrlSize = CSize(0, 0);
}

CDTXPopupCombo::~CDTXPopupCombo()
{
	if(pPopupWnd)
		delete pPopupWnd;
}


BEGIN_MESSAGE_MAP(CDTXPopupCombo, CDTXComboBox)
	//{{AFX_MSG_MAP(CDTXPopupCombo)
	ON_CONTROL_REFLECT(CBN_DROPDOWN, OnDropdown)
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
	ON_COMMAND(WM_DISPLAYPOPUPWND, OnPopup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXPopupCombo message handlers

void CDTXPopupCombo::OnDropdown() 
{
	ShowDropDown(FALSE);
	PostMessage(WM_COMMAND, WM_DISPLAYPOPUPWND);	
}

void CDTXPopupCombo::OnPopup()
{
	pPopupWnd = new CPopupWnd(this);

	CRect rect;    
	GetWindowRect(&rect);

	BOOL bSuccess = pPopupWnd ->Create(rect.left, rect.bottom, m_CtrlSize.cx, m_CtrlSize.cy);
	pPopupWnd ->SetFocus();
}

void CDTXPopupCombo::SetPopupWnd(CPopupWnd* pWnd)
{
	pPopupWnd = pWnd;
}

void CDTXPopupCombo::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDTXComboBox::OnActivate(nState, pWndOther, bMinimized);
}
