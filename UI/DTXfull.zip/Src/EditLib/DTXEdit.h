#if !defined(AFX_DTXEDIT_H__DE18EB4E_AA25_45E2_8987_7A7A594FB66B__INCLUDED_)
#define AFX_DTXEDIT_H__DE18EB4E_AA25_45E2_8987_7A7A594FB66B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DTXEdit.h : header file
//

#include "DTXBase.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXEdit window

class CDTXEdit : public CEdit, public CDTXWndBase
{
	DECLARE_DYNAMIC(CDTXEdit)
// Construction
public:
	CDTXEdit();

// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXEdit();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot = true);
	//{{AFX_MSG(CDTXEdit)
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXEDIT_H__DE18EB4E_AA25_45E2_8987_7A7A594FB66B__INCLUDED_)
