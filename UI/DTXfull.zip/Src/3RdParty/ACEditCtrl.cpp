#include	"stdafx.h"
#include	"ACEditCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CACEditCtrl

CACEditCtrl::CACEditCtrl()
{
}


CACEditCtrl::~CACEditCtrl()
{
}

BEGIN_MESSAGE_MAP(CACEditCtrl,CDTXEdit)
	//{{AFX_MSG_MAP(CACEditCtrl)
	ON_CONTROL_REFLECT_EX(EN_UPDATE, OnUpdate)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CACEditCtrl message handlers

void CACEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if( ( nChar == VK_DELETE ) || ( nChar == VK_BACK ) )	// If <DELETE> or <BACKSPACE>
	{
		m_bDisableAC = true;								// Disable AutoComplete
		m_bDisabledInternally = true;
	}
	else if( ( m_bDisableAC ) && ( m_bDisabledInternally ) )// Else If Some Other Key, And Disabled Internally
	{
		m_bDisableAC = false;								// Enable AC
		m_bDisabledInternally = false;						// Unset Internal Flag
		UpdateWindow();										// Trigger Update
	}
	CDTXEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CACEditCtrl::OnUpdate() 
{
	int		iStart = 0;
	int		iEnd = 0;
				
	GetSel(iStart, iEnd);
	if (UpdateAC(this))
	{
		SetSel( iStart, -1 );
		UpdateWindow();
		return( TRUE );
	}
	return FALSE;
}
