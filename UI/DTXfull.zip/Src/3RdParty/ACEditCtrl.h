#if !defined( __TW_ACEDITCTRL_H_ )
#define		__TW_ACEDITCTRL_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ACEditCtrl.h : header file
//
#include "DTXEdit.h"
#include "dtxacbase.h"
/////////////////////////////////////////////////////////////////////////////
// CACEditCtrl window

class	CACEditCtrl : public CDTXEdit, public CDTXACBase
{
// Construction
public:
	/**/	CACEditCtrl();									// Constructor
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CACEditCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual	~CACEditCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CACEditCtrl)
	afx_msg BOOL OnUpdate();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	/**/			CACEditCtrl( const CACEditCtrl &rSrc );	// Prevent Copy-Construction
	CACEditCtrl&	operator=( const CACEditCtrl &rSrc );	// Prevent Assignment
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif		// __TW_ACEDITCTRL_H_
