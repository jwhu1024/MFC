/*************************************************************
 * Copyright (C) 1996,1997, by MORIN Jean-Marc (mjm)
 *
 * Permission is given by the author to freely redistribute,
 * modify, enhance and include this code in any program as long
 * as this credit is given where due.
 *
 * This source code is distributed as is, and author cannot be taken
 * responsible for any mis-function of any kind, due the usage of this one.
 */
// DateCtrl.h : header file

#if !defined(AFX_DATECTRL_H__F8B76550_DE7A_11D1_A719_0000C09D590F__INCLUDED_)
#define AFX_DATECTRL_H__F8B76550_DE7A_11D1_A719_0000C09D590F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

///////////////////////////////////////////////////////////
//       modification log
//       ----------------
//       mjm   Jun-1998     - CListboxDate full rewrite
//       mjm   May-1998     - Pre-wire for date predecessor/successor
//       mjm   Apr-1998     - Notification support + Enhanced operators
//       mjm   Mar-1998     - CComboDate full rewrite
//       mjm   Feb-1998     - Enhancement + locale support
//       mjm   Apr-1996     - Creation (EDIT+BUTTON)/(WINDOW) not really OO
//

///////////////
// class CDate
///////////////
// This class maintain information for representing date.
// It can be in duplicate with the new COleDateTime, but
// this one is strictly date support, and is independant 
// from Automation. It is fully Year2000 complaint, and 
// fully functional since the 15th October, 1582 AD to
// the 31 December 5874777 AD (limited only because long
// are 4bytes long). ((+2,147,483,647 / 365.25) - 4712)
// This class use now locale information for input/output
// operation. Every instance of this class created before 
// you change the locale will still use the locale of the
// thread at the instant of it creation.
// Because this class represent only the date, there is no
// TIMEZONE support. There is no check made for date validity
// neither on construction nor for other affecting operation.
// IMPORTANT:
//   This is the responsability to the user to call the IsRelevant()
//   member to check date validity. The only function that implicitly
//   call the IsRelevant member is ParseDate().

typedef DWORD JULIANDATE;

class CDate
{
public:
   // Constructors
   CDate( );
   CDate( time_t time );
   CDate( const CDate& dtSrc );
   CDate( struct tm* ptm );
   CDate( SYSTEMTIME* pst );
   CDate( const CTime& timeSrc );
   CDate( JULIANDATE julians );
   CDate( int nYear, int nMonth, int nDay );
   // Constructor like (as static)
   static CDate PASCAL Today();

   // A static CDate constant
   static const CDate nullDate;

   enum weekDays { Sunday = 0, Monday, Tuesday, Wednesday, Thrusday, Friday, Saturday };
   // Members information
   inline int  GetYear() const    { return m_nYear; }
   inline int  GetMonth() const   { return m_nMonth; }
   inline int  GetDay() const     { return m_nDay; }
   inline LCID GetLCID() const    { return m_lcid; }
   // Extra informations
   BOOL IsLeapYear() const;
   BOOL IsRelevant() const;   // Check validity
   // Usefull calculations
   int  GetMonthLastDay() const;
   int  GetCentury()   const;
   weekDays  GetWeekDay()   const;  // 0 = Sunday
   int  GetYearWeek()  const;  // Started 1.1, based on Sunday first day of week
   int  GetYearDay()   const;
   double GetMoonPhase( double julianTimeUT = 0.0 ) const;
   JULIANDATE GetJulianDay() const;  // Usefull for date elapsed time calculation
   // Affectations
   const CDate& operator=(const CDate& timeSrc);
   BOOL SetDate( int nYear, int nMonth, int nDay );
   BOOL SetLCID( LCID lcid );
   BOOL ParseDate(LPCTSTR lpszString );    // --
   // Output                                     > Read note above
   CString Format(LPCTSTR pFormat );       // --
   CString Format(DWORD dwLocaleID);
   CString Format(CWnd* pWnd, const RECT& rc = CRect(0,0,0,0), CDC* pDC = NULL);
   // Cast operators
   operator struct tm*() const;
   operator SYSTEMTIME *() const;
   // Comparison operators
   BOOL operator ==(const CDate& dtSrc) const;
   BOOL operator  <(const CDate& dtSrc) const;
   BOOL operator  >(const CDate& dtSrc) const;
   BOOL operator <=(const CDate& dtSrc) const;
   BOOL operator >=(const CDate& dtSrc) const;
   BOOL operator !=(const CDate& dtSrc) const;
   // Arithmetic operators ( add or sub a certain number of days )
   const CDate& operator +=(long inc);
   const CDate& operator -=(long dec);
   const CDate& operator --();      // prefix operator
   const CDate& operator ++();      // prefix operator
   const CDate& operator --( int ); // postfix operator
   const CDate& operator ++( int ); // postfix operator
#ifdef _DEBUG
   friend CDumpContext& AFXAPI operator<<(CDumpContext& dc, const CDate& date);
#endif
   friend CArchive& AFXAPI operator<<(CArchive& ar, CDate date);
   friend CArchive& AFXAPI operator>>(CArchive& ar, CDate& date);

   // Destructor
   ~CDate();

protected:
   void CommonConstruct();
   void NlsBlockInit();

private:
protected:
   LCID          m_lcid;
   int           m_nYear;
   unsigned char m_nMonth;
   unsigned char m_nDay;
   struct LOCALE_INFO_BLOCK
          {
            BOOL      bIsFilled;
            CString   strLWD[7];  // Long  WeekDay names
            CString   strSWD[7];  // Short WeekDay names
            CString   strLMN[12]; // Long  Month   names
            CString   strSMN[12]; // Short Month   names
            struct {
                      unsigned char day;
                      unsigned char month;
                      unsigned char year;
                   }  shortPos;
            struct {
                      unsigned char day;
                      unsigned char year;
                   }  fullPos;
          } NLSBLK;
public:
};

#ifdef _DEBUG
CDumpContext& AFXAPI operator<<(CDumpContext& dc, const CDate& date);
#endif
CArchive& AFXAPI operator<<(CArchive& ar, CDate date);
CArchive& AFXAPI operator>>(CArchive& ar, CDate& date);

/////////////////////////////////////////////////////////////////////////////
// CListboxDate window
#include <afxtempl.h>
class CListboxDate : public CListBox
{
// Construction
public:
	CListboxDate();

	CDate GetShiftAnchor()
	{ return m_dtShiftAnchor; }
// Attributes
private:
    CDate      m_dtShiftAnchor;
protected:
    CFont      m_fontCaption;
    CRect      m_rcNonClient;
    CArray<CDate,CDate&> m_arrSelection;
public:
    CDate     m_dtPreview;

// Operations
public:
    void OnNavigatorClick( UINT nID );
    operator const CDate& () const;
    const CDate& operator =(const CDate& dtSrc);
    operator const CArray<CDate,CDate&>& () const;
    const CArray<CDate,CDate&>& operator =(const CArray<CDate,CDate&>& arrSrc);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListboxDate)
    //}}AFX_VIRTUAL
    virtual BOOL SubclassDlgItem( UINT nID, CWnd* pParent );
    virtual void PickDate( UINT nFlags, CPoint point);
    virtual void CaptionPainter(CDC& dc);
    virtual void BorderPainter(CDC& dc);
    virtual void DrawCalendar( CDC& dc);
    virtual void DrawHeader( CDC& dc );
    virtual CSize GetBorderMetrics();

// Implementation
public:
	virtual ~CListboxDate();

	// Generated message map functions
protected:
	//{{AFX_MSG(CListboxDate)
	afx_msg void OnNcPaint();
	afx_msg void OnPaint();
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg UINT OnNcHitTest(CPoint point);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
    afx_msg LRESULT OnSetText(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetAnchorIndex(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetCaretIndex(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetLocale(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBSetLocale(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetSelCount(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetCurSel(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBInsertString(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBAddString(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBSelectString(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBResetContent(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetTextLen(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetText(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetSel(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnLBGetSelItems(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

// DDX for single selection CListboxDate
void AFXAPI DDX_LBDate(CDataExchange* pDX, int nIDC, CDate& value);
// DDX for multiple/extended selection CListboxDate
void AFXAPI DDX_LBDate(CDataExchange* pDX, int nIDC, CArray<CDate,CDate&>& array);

/////////////////////////////////////////////////////////////////////////////
// CComboDate window

class CComboDate : public CWnd
{
// Sub-class
public:
    class SCalendarWnd : public CListboxDate
    {
    // Construction
    public:
	    SCalendarWnd( CComboDate* container );

    // Attributes
    private:
        CComboDate*   m_pParent;
        CDate*        m_pdtValue;
        static CRect  m_rcDropDown;
    protected:
        CFont         m_fontSmall;
    public:
      
    // Operations
    public:
        virtual BOOL Create( CWnd* pWndParent, LPCTSTR lpszTitle = NULL);

    // Overrides
	    // ClassWizard generated virtual function overrides
	    //{{AFX_VIRTUAL(CComboDate::SCalendarWnd)
        //}}AFX_VIRTUAL
        virtual BOOL SubclassDlgItem( UINT nID, CWnd* pParent );
        virtual void PickDate( UINT nFlags, CPoint point);
        virtual void BorderPainter( CDC& dc );
        virtual CSize GetBorderMetrics();

    // Implementation
    public:
	    virtual ~SCalendarWnd();

	    // Generated message map functions
    protected:
	    //{{AFX_MSG(CComboDate::SCalendarWnd)
	    afx_msg void OnPaint();
	    afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	    afx_msg void OnCaptureChanged(CWnd *pWnd);
	    afx_msg UINT OnNcHitTest(CPoint point);
        afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
        afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
        afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
        afx_msg void OnKeyDown( UINT nChar, UINT nRepCnt, UINT nFlags );
	    //}}AFX_MSG

	    DECLARE_MESSAGE_MAP()
    };

    class SCalendarEdit : public CEdit
    {
    // Construction
    public:
	    SCalendarEdit( CComboDate* container );

    // Attributes
    private:
        CComboDate*   m_pParent;
        CDate*        m_pdtValue;

    // Operations
    protected:
        BOOL CheckChainedCtrl();
    public:

    // Overrides
	    // ClassWizard generated virtual function overrides
	    //{{AFX_VIRTUAL(CComboDate::SCalendarEdit)
	    public:
	        virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

    // Implementation
    public:
	    virtual ~SCalendarEdit();

	    // Generated message map functions
    protected:
	    //{{AFX_MSG(CComboDate::SCalendarEdit)
	    afx_msg void OnKillFocus(CWnd* pNewWnd);
	    //}}AFX_MSG
        afx_msg LRESULT OnSetText(WPARAM wParam,LPARAM lParam);
	    DECLARE_MESSAGE_MAP()
    };

    friend class SCalendarWnd;
    friend class SCalendarEdit;
// Construction
public:
	CComboDate();

// Attributes
public:
protected:
   CRect         m_rcButton;
   SCalendarWnd  m_wndCal;
   SCalendarEdit m_wndEdt;
   CDate         m_dtValue;
   CComboDate*   m_ctrlPredecessor;
   CComboDate*   m_ctrlSuccessor;

// Operations
protected:
   void DrawButton(CDC* pDc, BOOL bPressed = FALSE);
   void DropdownButton( BOOL bPressed );
   void PostNotifyMessage( UINT nonWM );

public:
    operator const CDate& () const;
    const CDate& operator =(const CDate& dtSrc);
    void    ConsiderAsPredecessor( CComboDate* pPred );
    void    ConsiderAsSuccessor  ( CComboDate* pSucc );
    void ShowDropDown(BOOL bShowIt = TRUE );
    LCID GetLocale( ) const;
    LCID SetLocale( LCID nNewLocale );
    BOOL GetDroppedState( ) const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboDate)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CComboDate();


	// Generated message map functions
protected:
	//{{AFX_MSG(CComboDate)
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg LRESULT OnGetTextLength(WPARAM wParam,LPARAM lParam);
    afx_msg LRESULT OnGetText(WPARAM wParam,LPARAM lParam);
    afx_msg LRESULT OnSetText(WPARAM wParam,LPARAM lParam);
	//}}AFX_MSG
    afx_msg LRESULT OnCBShowDropDown(WPARAM wParam,LPARAM lParam);
    afx_msg LRESULT OnCBGetDroppedState(WPARAM wParam,LPARAM lParam);
    afx_msg LRESULT OnCBGetLocale(WPARAM wParam,LPARAM lParam);
    afx_msg LRESULT OnCBSetLocale(WPARAM wParam,LPARAM lParam);
    DECLARE_MESSAGE_MAP()
};

void AFXAPI DDX_CBDate(CDataExchange* pDX, int nIDC, CDate& value);
void AFXAPI DDV_DateFrame(CDataExchange* pDX, CDate& value, CDate& minVal, CDate& maxVal = CDate(9999,31,12));

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATECTRL_H__F8B76550_DE7A_11D1_A719_0000C09D590F__INCLUDED_)
