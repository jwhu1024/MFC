// DateCtrl.cpp : implementation file
//
/*************************************************************
 * Copyright (C) 1996,1997, by MORIN Jean-Marc (mjm)
 *
 * Permission is given by the author to freely redistribute,
 * modify, enhance and include this code in any program as long
 * as this credit is given where due.
 *
 * This source code is distributed as is, and author cannot be taken
 * responsible for any mis-function of any kind, due the usage of this one.
 */

/*
 * This source code of 3000 lines approx. represent a big part
 * of job. Using it will represent for you benfits and time 
 * saving, so it would be really kind of you to send me an
 * e-mail or post-card, and to sendback any enhancement, or
 * improvement.
 * E-mail:  mjm@mygale.org
 * WWW:     http:://www.mygale.org/~mjm
 * Address: 1 Av. Aristide BRIAND
 *          21000 DIJON - FRANCE
 */

// This file contain usefull Control class to handle date with
// such a powerfull user interface.
// When I first start those class, I have plan to use the CTime class thus
// the COleDateTime was no yet present. But, due to CTime limitations
// ( 1900AD to 2038AD) I decide to implement my own CDate class.
// I decide then to don't split the CDate class into a separated file,
// because I suppose that if you need a one of the control that handle
// date you also need the CDate class, and if you need the CDate class you
// have to provide some GUI to represent those date, and so you need the 
// controls associated.
// When I rewrite the part to support such recent NLS functionalities,
// I look on the benefits of the COleDateTime, and ask my-self about to 
// use it to replace my CDate class ( one of the Keep It Simple (KIS) rule ).
// But (again), COleDateTime don't seems to be such powerfull, and I got the
// feeling that it is much more like some gas-factory. And finaly the
// COleDateTime class is really some specific Microsoft stuff. So keeping
// the CDate class will increase the possibility to port this code (or part)
// on other plateforms.

#include "stdafx.h"
#include <locale.h>
#include "DateCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static long January1AD = 1721426; // Julian days between January 4713 BC and January 1 AD

///////////////////////////////////////////////////////////////////////////////////////////
// content of this file
//     global functions
//     CDate members
//     CListboxDate  members
//     CComboDate members
//        SCalendarWnd  members
//        SCalendarEdit members


/////////////////////////////////////////////////////////////////////////////
// Global helpers for this code file

// Compare 2 string no case sensitive, no accent sensitive
static int  CmpStrNoCaseNoAccent(LCID lcid, LPCTSTR lpszStr1, LPCTSTR lpszStr2, int nLen = -1)
{
   CString sortStr1, sortStr2;
   int len1 = _tcslen(lpszStr1)*2 +1;
   int len2 = _tcslen(lpszStr2)*2 +1;

   LCMapString( lcid, LCMAP_SORTKEY|NORM_IGNORECASE|NORM_IGNOREWIDTH|SORT_STRINGSORT,lpszStr1, -1, sortStr1.GetBuffer(len1), len1 );
   LCMapString( lcid, LCMAP_SORTKEY|NORM_IGNORECASE|NORM_IGNOREWIDTH|SORT_STRINGSORT,lpszStr2, -1, sortStr2.GetBuffer(len2), len2 );
   sortStr1.ReleaseBuffer();
   sortStr2.ReleaseBuffer();

   return memcmp(sortStr1,sortStr2,(nLen==-1)?max(--len1,--len2):nLen*2);
}

/////////////////////////////////////////////////////////////////////////////
// DATEFORMAT_BLOCK class
/////////////////////////
// Special global info block. And it's 
// associated populating function.
// See CDate::Format( CWnd* ...) for usage
static struct DATEFORMAT_BLOCK
              {
                DATEFORMAT_BLOCK() { ::InitializeCriticalSection(&lock); }
                CRITICAL_SECTION lock;
                CStringArray     arrFormats;
              } DTF;

static BOOL CALLBACK EnumDateFormatsProc( LPTSTR lpDateFormatString )
{
  DTF.arrFormats.Add(lpDateFormatString);
  return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CDate class
const CDate CDate::nullDate;

CDate PASCAL CDate::Today()
{
   return CDate(::time(NULL)); 
}

void CDate::CommonConstruct()
{
   NLSBLK.bIsFilled = FALSE;
//   NLSBLK.parrFormat = NULL;
   m_lcid = GetThreadLocale();
}

void CDate::NlsBlockInit()
{
   NLSBLK.bIsFilled = TRUE;
   // Recover name for week days
   {
     for (int i=0; i < 7; i++)
         {
           GetLocaleInfo(
                          m_lcid, LOCALE_SDAYNAME1+i,
                          NLSBLK.strLWD[i].GetBuffer(256),256
                        );
           NLSBLK.strLWD[i].ReleaseBuffer();
           GetLocaleInfo(
                          m_lcid, LOCALE_SABBREVDAYNAME1+i,
                          NLSBLK.strSWD[i].GetBuffer(256),256
                        );
           NLSBLK.strSWD[i].ReleaseBuffer();
         }
   }

   // Recover name for months
   {
     for (int i=0; i < 12; i++)
         {
           GetLocaleInfo(
                          m_lcid, LOCALE_SMONTHNAME1+i,
                          NLSBLK.strLMN[i].GetBuffer(256),256
                        );
           NLSBLK.strLMN[i].ReleaseBuffer();
           GetLocaleInfo(
                          m_lcid, LOCALE_SABBREVMONTHNAME1+i,
                          NLSBLK.strSMN[i].GetBuffer(256),256
                        );
           NLSBLK.strSMN[i].ReleaseBuffer();
         }
   }

   // Recover locale representation
   {
     TCHAR strInt[2]; // LOCALE_I... constant need 2 chars
     int     num;

     // In short format
     GetLocaleInfo( m_lcid, LOCALE_IDATE, strInt, 2 );
     num = atoi(strInt);
     // 0 Month - Day - Year
     // 1 Day - Month - Year
     // 2 Year - Month - Day 
     switch (num)
        {
          case 0: NLSBLK.shortPos.day = 1; NLSBLK.shortPos.month = 0; NLSBLK.shortPos.year = 2; break;
          case 1: NLSBLK.shortPos.day = 0; NLSBLK.shortPos.month = 1; NLSBLK.shortPos.year = 2; break;
          case 2: NLSBLK.shortPos.day = 2; NLSBLK.shortPos.month = 1; NLSBLK.shortPos.year = 0; break;
        }

     // In wide format
     GetLocaleInfo( m_lcid, LOCALE_ILDATE, strInt, 2 );
     num = atoi(strInt);
     // 0 Month - Day - Year
     // 1 Day - Month - Year
     // 2 Year - Month - Day 
     switch (num)
        {
          case 0:
          case 1: NLSBLK.fullPos.day = 0; NLSBLK.fullPos.year = 1; break;
          case 2: NLSBLK.fullPos.day = 1; NLSBLK.fullPos.year = 0; break;
        }
   }
}

CDate::CDate()
{
  m_nYear = m_nMonth = m_nDay = 0;
  CommonConstruct();
}

CDate::CDate( int nYear, int nMonth, int nDay)
{
  m_nYear = nYear;
  m_nMonth = nMonth;
  m_nDay = nDay;
  CommonConstruct(  );
}

CDate::CDate( time_t time )
{
  struct tm* ptm = localtime(&time);
  m_nYear =  ptm->tm_year + 1900;
  m_nMonth = ptm->tm_mon  + 1;
  m_nDay   = ptm->tm_mday;
  CommonConstruct(  );
}

CDate::CDate( struct tm* ptm )
{
  m_nYear =  ptm->tm_year + 1900;
  m_nMonth = ptm->tm_mon  + 1;
  m_nDay   = ptm->tm_mday;
  CommonConstruct(  );
}

CDate::CDate( SYSTEMTIME* pst )
{
  m_nDay   = (unsigned char)pst->wDay;
  m_nMonth = (unsigned char)pst->wMonth;
  m_nYear  = pst->wYear;
  CommonConstruct(  );
}

CDate::CDate( const CTime& timeSrc )
{
  m_nYear = timeSrc.GetYear();
  m_nMonth = timeSrc.GetMonth();
  m_nDay = timeSrc.GetDay();
  CommonConstruct(  );
}

CDate::CDate( const CDate& dtSrc )
{
  m_nYear = dtSrc.GetYear();
  m_nMonth = dtSrc.GetMonth();
  m_nDay = dtSrc.GetDay();
  CommonConstruct(  );
}

CDate::CDate( DWORD julians )
{
  CDate dt;
  long delta;

  m_nYear = (int)((julians - January1AD) / 365.2425) + 1;
  dt.SetDate(m_nYear,1,1);
  delta = julians - dt.GetJulianDay();
  if (delta < 0) m_nYear--;
  if (delta > 364 + IsLeapYear()?1:0) m_nYear++;
  dt.SetDate(m_nYear,1,1);
  delta = julians - dt.GetJulianDay();

  m_nMonth = (unsigned char)(((julians - dt.GetJulianDay()) / 30.6001) + 1);
  dt.SetDate(m_nYear,m_nMonth,1);
  delta = julians - dt.GetJulianDay();
  if (delta < 0) m_nMonth--;
  if (delta > (GetMonthLastDay()-1)) m_nMonth++;
  dt.SetDate(m_nYear,m_nMonth,1);
  delta = julians - dt.GetJulianDay();

  m_nDay = (unsigned char)(julians - dt.GetJulianDay()) + 1;
  CommonConstruct();
}

CDate::~CDate()
{
}

BOOL CDate::SetLCID( LCID lcid )
{
  TCHAR buf[16];

  if (GetLocaleInfo(lcid, LOCALE_SABBREVLANGNAME,buf,16) == 0)
     { // This LCID is either not implemented into this
       // machine or an invalid one.
       return FALSE;
     }
  m_lcid = lcid;
  NLSBLK.bIsFilled = FALSE;
  return TRUE;
}

BOOL CDate::SetDate( int nYear, int nMonth, int nDay )
{
  m_nYear = nYear;
  m_nMonth = nMonth;
  m_nDay = nDay;
  return TRUE;
}

BOOL CDate::IsLeapYear() const
{
  return (!(m_nYear%4) - !(m_nYear%100) + !(m_nYear%400));
}

int CDate::GetYearDay() const
{
  return ((m_nMonth-1)*30)
           -((m_nMonth>2)?(IsLeapYear()?1:2):0)
           +(m_nMonth/2)
           +((m_nMonth>8)?(m_nMonth%2):0)
           +(m_nDay);
}

int CDate::GetYearWeek() const
{
  CDate Jan1st(m_nYear,1,1);
  int wd1 = Jan1st.GetWeekDay();
  int yd = GetYearDay();

  return (wd1?1:0) + (yd / 7) + ((yd%7)?1:0);
}

// This is an experimental implementation of the 
// moon phase calendar ...
// Just remember that Solar Year period is 365.242190 days,
// and Moon "month" period is 29.530589 days.
// The julian time represent in hundredth the time in the day
// expressed in UT. (e.g: 0h00 => 0.0, 12h00 => 0.5, 18h00 => 0.75)
// To convert 24h time to julian time:
//      hour*(1/24)+minute*(1/1440)+seconds*(1/86400)
double CDate::GetMoonPhase( double julianTimeUT /* = 0.0 */) const
{
  static double moonPeriod = 29.530589;
  double cycle = ((GetJulianDay()+julianTimeUT) / moonPeriod);
  long   omega = (long)cycle;
  double phy   = cycle - (omega*moonPeriod);

  return phy;
}

JULIANDATE CDate::GetJulianDay() const
{
  // Julian day starting date is 1.1.4713 BC at 0h00 UT
  // Remember after the 31st December 1 BC, we got 1st January 1 AD,
  // so the year 1 BC is stored as 0 in computer notation. 
  // The year 1582 AD is shorter of 10 days. After Thursday, October 4,
  // we got Friday, October 15. This is only true for Roman Church and
  // can vary depending with the country. In that case the number of
  // removed days can vary. This is because leap year appear each 4 years before
  // this date and calendar has shift from the real solar year. When Cesear Julius
  // officialise the calendar in 46 BC, this year contain 445 days to align 
  // calendar with solar year. There is a misunderstood at this time, which provide leap
  // years each 3 years until Cesear Augustus who decide to ignore the next 4 leap
  // years in 9 BC for shifting reason again. Every thing ( near ) as usual since 12 AD.

  // This function don't take care of any of thoses exceptions. So if you want to use
  // date that are before October 15, 1582 AD or you want to reflect you own country 
  // commitment for this calendar, you need to rewrite this part.

  register long y = m_nYear - 1;
  return (JULIANDATE)((long)(y*365.25)) - (y/100) + (y/400) + January1AD + GetYearDay() - 1;
}

CDate::weekDays CDate::GetWeekDay() const
{
  // 1st January, 1 BC, would have to be a Monday
  return static_cast<CDate::weekDays>(((GetJulianDay()%7)+Monday)%7);
}

int CDate::GetMonthLastDay() const
{
  return 30
           -((m_nMonth==2)?(IsLeapYear()?1:2):0)
           +((m_nMonth>7)?((m_nMonth+1)%2):(m_nMonth%2));
}

int CDate::GetCentury() const
{
  return GetYear()/100;
}

CDate::operator struct tm*() const
{
  static struct tm atm;

  atm.tm_mday = m_nDay;
  atm.tm_mon =  m_nMonth - 1;
  atm.tm_year = m_nYear - 1900;
  atm.tm_wday = GetWeekDay();
  atm.tm_yday = GetYearDay();
  atm.tm_sec = atm.tm_min = atm.tm_hour = 0;

  return &atm;
}

CDate::operator SYSTEMTIME*() const
{
  static SYSTEMTIME ast;

  ast.wDay       = m_nDay;
  ast.wMonth     = m_nMonth;
  ast.wYear      = m_nYear;
  ast.wDayOfWeek = GetWeekDay();
  ast.wMilliseconds = ast.wSecond = ast.wMinute = ast.wHour = 0;

  return &ast;
}

const CDate& CDate::operator=(const CDate& dtSrc)
{
     m_nYear  = dtSrc.m_nYear;
     m_nMonth = dtSrc.m_nMonth;
     m_nDay   = dtSrc.m_nDay;
     return *this;
}

BOOL CDate::operator ==(const CDate& dtSrc) const
{
  return (GetJulianDay() == dtSrc.GetJulianDay())?TRUE:FALSE;
}

BOOL CDate::operator  <(const CDate& dtSrc) const
{
  return GetJulianDay() < dtSrc.GetJulianDay();//?TRUE:FALSE;
}

BOOL CDate::operator  >(const CDate& dtSrc) const
{
  return (GetJulianDay() > dtSrc.GetJulianDay())?TRUE:FALSE;
}

BOOL CDate::operator <=(const CDate& dtSrc) const
{
  return (GetJulianDay() <= dtSrc.GetJulianDay())?TRUE:FALSE;
}

BOOL CDate::operator >=(const CDate& dtSrc) const
{
  return (GetJulianDay() >= dtSrc.GetJulianDay())?TRUE:FALSE;
}

BOOL CDate::operator !=(const CDate& dtSrc) const
{
  return (GetJulianDay() != dtSrc.GetJulianDay())?TRUE:FALSE;
}

const CDate& CDate::operator --( int )
{
  return --(*this);
}

const CDate& CDate::operator --()
{
  m_nDay--;
  if (!m_nDay)
     {
       m_nMonth--;
       if (!m_nMonth)
          {
            m_nYear--;
            m_nMonth = 12;
          }
       m_nDay = GetMonthLastDay();
     }
  return *this;
}

const CDate& CDate::operator ++( int )
{
  return ++(*this);
}

const CDate& CDate::operator ++()
{
  m_nDay++;
  if (m_nDay > GetMonthLastDay())
     {
       m_nMonth++;
       if (m_nMonth > 12)
          {
            m_nYear++;
            m_nMonth = 1;
          }
       m_nDay = 1;
     }
  return *this;
}

// The next 2 operators are not really efficient,
// but at this time I couldn't figure out how to
// perform this without using conversion to julian
// day and back to date... Conversion will be less
// efficient.
const CDate& CDate::operator -=(long dec)
{
  if (dec)
     {
       if (dec < 0) *this += (-dec);
       else
          {
            while(dec--)
              {
                (*this)--;
              }
          }
     }
  return *this;
}

const CDate& CDate::operator +=(long inc)
{
  if (inc)
     {
       if (inc < 0) *this -= (-inc);
       else
          {
            while(inc--)
              {
                (*this)++;
              }
          }
     }
  return *this;
}

CString CDate::Format(LPCTSTR pFormat)
{
    CString one;
    CString strOK;  // Bug fix
    CString strKO;  // Bug fix

    if (!NLSBLK.bIsFilled) NlsBlockInit();

    // Huh! The guy that write the GetDateFormat decide to return
    // failure for any date prior to 1.1.1601 AD. I suppose that it
    // is because he want to check the day of the week. Anyway I found
    // this non-appropriate... So a little gymastic now to work arround
    // this limitation. The idea is there to add a multiple of 4 centuries
    // in order to be complaint with the valid range. (400*365.25 - 3)/7 = 20871 weeks
    if (*this < CDate(1601,1,1))
       {
         strKO.Format(_T("%04d"),m_nYear);
         m_nYear += ((((17 - (m_nYear/100))/4)+1)*400);
         strOK.Format(_T("%d"),m_nYear);
       }

    ::GetDateFormat(m_lcid, 0, *this, pFormat, one.GetBuffer(256), 256);

    // The second step of the bug fix explained above
    if (!strKO.IsEmpty())
       {
         int pos = one.Find(strOK);
         m_nYear = atoi(strKO);
         if (pos != -1)
            {
              LPTSTR p = (LPTSTR)((int)one.GetBuffer(256) + pos);
              for(int i=0; i<strKO.GetLength(); i++)
                 {
                   *p++ = strKO[i];
                 }
            }
       }
    one.ReleaseBuffer();

    return one;
}

#ifndef DATE_YEARMONTH
    // Here is another (current?) designer's head-ache generator by Microsoft,
    // functionality exist only in the twilight-zone.
    #define DATE_YEARMONTH _T("MMMM yyyy")
    // This pragma mislead DevStudio for safe reason
    #if _DEBUG
        #pragma message( __FILE__ "(555) : warning MSC4999: 'DATE_YEARMONTH' : this documented parameter is not implemented!")
    #endif
#endif

CString CDate::Format(DWORD dwLocaleID)
{
    CString one;
    CString strOK;  // Bug fix
    CString strKO;  // Bug fix

    if (!NLSBLK.bIsFilled) NlsBlockInit();

    // Huh! The guy that write the GetDateFormat decide to return
    // failure for any date prior to 1.1.1601 AD. I suppose that it
    // is because he want to check the day of the week. Anyway I found
    // this non-appropriate... So a little gymastic now to work arround
    // this limitation. The idea is there to add a multiple of 4 centuries
    // in order to be complaint with the valid range. (400*365.25 - 3)/7 = 20871 weeks
    if (*this < CDate(1601,1,1))
       {
         strKO.Format(_T("%04d"),m_nYear);
         m_nYear += ((((17 - (m_nYear/100))/4)+1)*400);
         strOK.Format(_T("%d"),m_nYear);
       }

    ::GetDateFormat(m_lcid, dwLocaleID, *this, NULL, one.GetBuffer(256), 256);

    // The second step of the bug fix explained above
    if (!strKO.IsEmpty())
       {
         int pos = one.Find(strOK);
         m_nYear = atoi(strKO);
         if (pos != -1)
            {
              LPTSTR p = (LPTSTR)((int)one.GetBuffer(256) + pos);
              for(int i=0; i<strKO.GetLength(); i++)
                 {
                   *p++ = strKO[i];
                 }
            }
       }
    one.ReleaseBuffer();

    return one;
}

CString CDate::Format(CWnd* pWnd, const RECT& rc /* = CRect(0,0,0,0)*/, CDC* pDC /* = NULL */ )
{
  // The CWnd parameter for this function, represent
  // the window on which we will TextOut the resultant string.
  // So this function try to be clever enough to select by it-self
  // the format that fit on the CRect area, or if passed CRect equal
  // to the NULL rect, to the client size...It use the CDC* argument
  // for text extent calculation if any, otherwise it get the client DC.
  //
  // The use of the EnumDateFormats and EnumDateFormatsProc, is a little
  // bit boring thus it can't be attached to an object like other sort of
  // CALLBACK. eg.:
  // EnumBlabla(params, (LPVOID)this);
  // EnumBlablaProc( value, LPVOID extra ) { (MyObject*)extra->var = value; }
  // Just consider that a callback need to be static. So what's append
  // if the designer decide to change the locale, because his GUI provide
  // such choice to his users... ? Use the OnLocaleChange handler... ?
  // The solution is to create a global block of information to save
  // the results. And to free it at the end of the function... Yes, each
  // time... Yes, it's time consuming... but I can't figure out any other
  // solution.
  // Now the other problem, his that this block of information is shared 
  // with all instance of this class. So we need to protect this part from
  // re-entrant situations...Why? You,me, then every body ... can use multi
  // threading... So be pessimistic!

  CString strReturn;
  CStringArray arrFormated;

  {
    ::EnterCriticalSection( &DTF.lock );
    ::EnumDateFormats(&EnumDateFormatsProc, m_lcid, DATE_LONGDATE);
    ::EnumDateFormats(&EnumDateFormatsProc, m_lcid, DATE_SHORTDATE);
    for(int i=0; i < DTF.arrFormats.GetSize(); i++)
       {
         if (*this < CDate(1582,10,15))
            { // Before this date, it is unrealistic to display 
              // day of the week...  "ddd" & "dddd" implies WeekDay
              if (_tcsstr(DTF.arrFormats[i],_T("ddd"))) continue;
            }
         arrFormated.Add(Format(DTF.arrFormats[i]));
       }
    DTF.arrFormats.RemoveAll();
    ::LeaveCriticalSection( &DTF.lock );
  }

  // Choose the best-fit format in width.
  {
    CDC* pdc = pDC?pDC:pWnd->GetDC();
    CSize area;
    CRect rect;
    CSize szLast(0,0);

    {
      CRect rect = rc;
      if (rect.IsRectNull())
       {
         pWnd->GetClientRect(&rect);
       }
      area = rect.Size();
    }

    for(int i = 0; i < arrFormated.GetSize(); i++)
       {
         CSize sz = pdc->GetTextExtent(arrFormated[i]);
         // At least one if nothing fit.
         if (i==0) strReturn = arrFormated[i];

         if ( (sz - szLast).cx > 0 && (area - sz).cx > 0)
            {
              strReturn = arrFormated[i];
              szLast = sz;
            }
       }
    if (!pDC) pWnd->ReleaseDC(pdc);
  }

  return strReturn;
}

BOOL CDate::IsRelevant() const
{
    if (m_nMonth < 1 || m_nMonth > 12) return FALSE;
    if (m_nDay < 1 || m_nDay > GetMonthLastDay()) return FALSE;
    if (m_nYear < 1) return FALSE;
    return TRUE;
}


#define _AssignVal(x) (values[x]<0)?(-values[x]):(values[x])
#define _AssignValAsYear(x)  (values[x]>0)?(values[x]+(now.GetCentury()*100)):(-values[x])
// Such a function (parsing date) is not a simple process
// especialy because we want it to be clever enough to support
// and correct mis-ordering.

BOOL CDate::ParseDate( LPCTSTR lpszString )
{
  CString strCopy(lpszString);
  int nYear = 0;
  unsigned char nMonth=0;
  unsigned char nDay=0;
  int values[] = {0,0,0};

  if (!NLSBLK.bIsFilled) NlsBlockInit();

  {
    LPTSTR tok;
    int pos;
    for( 
         pos=0,tok=_tcstok(strCopy.GetBuffer(strCopy.GetLength()+sizeof(TCHAR)),_T(" \t,.-/"));
         tok;
         tok = _tcstok(NULL,_T(" \t,.-/"))
       )
       {
          // Step 1: We check for month names
          {
            for(int loop = 0; loop < 12; loop++)
               {
                 if (
                      !CmpStrNoCaseNoAccent( m_lcid, NLSBLK.strLMN[loop], tok)
                     ||
                      !CmpStrNoCaseNoAccent( m_lcid, NLSBLK.strSMN[loop], tok, max(_tcslen(tok),3))
                    )
                    { // This is the month information
                      nMonth = loop +1;
                      goto parse_next;
                    }
               }
          }

          // Step 2: We check for weekday names
          {
            for(int loop = 0; loop < 7; loop++)
               {
                 if (
                      !CmpStrNoCaseNoAccent( m_lcid, NLSBLK.strLWD[loop], tok)
                     ||
                      !CmpStrNoCaseNoAccent( m_lcid, NLSBLK.strSWD[loop], tok, max(_tcslen(tok),3))
                    )
                    { // and just ignore them.
                      goto parse_next;
                    }
               }
          }

          // Step 3: We guess this is numeric value
          {
            int val = atoi(tok);
            if (val || tok[0] == _T('0'))
               {
                 if (pos == (sizeof(values)/sizeof(values[0])))
                    { // Too many arguments
                      return FALSE;
                    }
                 // We mark user entry > to 4 characters
                 // so we can use this to decide for century.
                 if (_tcslen(tok) > 2) val = -val;
                 values[pos++] = val;
               }
          }

parse_next:
       // parse the next token
       continue;
       }
  }
  strCopy.ReleaseBuffer();

  // Dispatch numeric values
  {
    CDate now = CDate::Today();
    int   nr = 0;          // Number of relevant date
    CDate* areRelevant[6]; // Maximum number of combination
    if (nMonth)
       {
         if (values[2])
            { // Too many arguments
              return FALSE;
            }
         for(int c = 0; c < 2; c++)
            {
              int yr = _AssignValAsYear(c);
              int dy = _AssignVal((c+1)%2);

              if (!yr) yr=now.GetYear();

              areRelevant[nr] = new CDate(yr,nMonth,dy);
              if (areRelevant[nr]->IsRelevant())
                 {
                   nr++;
                   for(int u = 0; u < (nr-1); u++)
                      {
                        // Eliminate duplicated proposition (e.g. 1.1.99)
                        if (areRelevant[u]->GetJulianDay() == areRelevant[nr-1]->GetJulianDay())
                           {
                             nr--;
                             delete areRelevant[nr];
                             break;
                           }
                      }
                 }
              else
                 {
                   delete areRelevant[nr];
                 }
            }

         switch(nr)
            {
              case 0:   return FALSE; break;
              case 1:   *this = *areRelevant[0]; break;
              case 2:   {
                          BOOL first = (NLSBLK.fullPos.day==0 && areRelevant[0]->GetDay()==values[0]);
                          *this = *areRelevant[(first)?0:1];
                        }
            }
       }
    else
       {
         for(int c = 0; c < 6; c++)
            {
              int y,d,m;

              switch(c)
                {
                  case 0: y = 0; m = 1; d = 2; break;
                  case 1: y = 0; m = 2; d = 1; break;
                  case 2: y = 1; m = 0; d = 2; break;
                  case 3: y = 1; m = 2; d = 0; break;
                  case 4: y = 2; m = 0; d = 1; break;
                  case 5: y = 2; m = 1; d = 0; break;
                }

              int yr = _AssignValAsYear(y);
              int mn = _AssignVal(m);
              int dy = _AssignVal(d);

              if (!yr) yr=now.GetYear();

              areRelevant[nr] = new CDate(yr,mn,dy);
              if (areRelevant[nr]->IsRelevant())
                 {
                   nr++;
                   for(int u = 0; u < (nr-1); u++)
                      {
                        if (areRelevant[u]->GetJulianDay() == areRelevant[nr-1]->GetJulianDay())
                           {
                             nr--;
                             delete areRelevant[nr];
                             break;
                           }
                      }
                 }
              else
                 {
                   delete areRelevant[nr];
                 }
            }

         switch(nr)
            {
              case 0:   return FALSE; break;
              case 1:   *this = *areRelevant[0]; break;
              case 2:   {
                          BOOL first = (NLSBLK.fullPos.day==0 && areRelevant[0]->GetDay()==values[0]);
                          *this = *areRelevant[(first)?0:1];
                        }
                        break;
              case 3:   // With 1/1/12 for example
              case 4:   // With 1/3/25 for example
              case 5:   // Never appear
              case 6:   {
                          int yr = _AssignValAsYear(NLSBLK.shortPos.year);
                          int mn = _AssignVal(NLSBLK.shortPos.month);
                          int dy = _AssignVal(NLSBLK.shortPos.day);

                          if (!yr) yr=now.GetYear();

                          CDate dt( yr, mn, dy );
                          if (dt.IsRelevant())
                             {
                               *this = dt;
                             }
                          else
                             {
                               for(;nr;nr--)
                                  {
                                    delete areRelevant[nr-1];
                                  }
                               return FALSE;
                             }
                        }
                        break;
            }
       }

    for(;nr;nr--)
       {
         delete areRelevant[nr-1];
       }
  }

  return TRUE;
}

#undef _AssignVal
#undef _AssignValAsYear

//////////////////////////////////////////////////////////////////////////////
// Diagnostic support

#ifdef _DEBUG
CDumpContext& AFXAPI operator<<(CDumpContext& dc, const CDate& date)
{
    // Dump is in US date coding
	dc << date.m_nMonth << "-" << date.m_nDay << "-" << date.m_nYear;
	return dc;
}
#endif //_DEBUG

//////////////////////////////////////////////////////////////////////////////
// Archiving

CArchive& AFXAPI operator <<(CArchive& ar, CDate date)
{
    if (!date.IsRelevant()) date = CDate::nullDate;
	return ar << (unsigned char) date.m_nMonth << (unsigned char) date.m_nDay << (DWORD) date.m_nYear;
}

CArchive& AFXAPI operator >>(CArchive& ar, CDate& date)
{
	ar >> (DWORD&) date.m_nMonth >> (unsigned char&) date.m_nDay >> (unsigned char&) date.m_nYear;
    if (!date.IsRelevant()) date = CDate::nullDate;
    return ar;
}


/////////////////////////////////////////////////////////////////////////////
// CListboxDate

CListboxDate::CListboxDate()
{
  HDC hdc = ::GetDC(NULL);

  {
    LOGFONT lf; memset(&lf, 0, sizeof(LOGFONT));
    lf.lfHeight = -MulDiv(8, ::GetDeviceCaps(hdc, LOGPIXELSY), 72);

    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfWeight = FW_NORMAL;
    lf.lfPitchAndFamily = DEFAULT_PITCH | FF_SWISS;

    m_fontCaption.CreateFontIndirect( &lf );
	m_fontCaption.GetLogFont(&lf);
  }

  m_dtPreview = CDate::Today();
  m_dtPreview.SetDate(m_dtPreview.GetYear(),m_dtPreview.GetMonth(),1);
  ::ReleaseDC(NULL,hdc);
}

CListboxDate::~CListboxDate()
{
}

CListboxDate::operator const CDate&() const
{
  if (m_arrSelection.GetSize())
     {
       return m_arrSelection.GetAt(m_arrSelection.GetSize()-1);
     }
  return CDate::nullDate;
}

const CDate& CListboxDate::operator =(const CDate& dtSrc)
{
  m_arrSelection.RemoveAll();
  if (dtSrc != CDate::nullDate)
     {
       m_arrSelection.Add(CDate(dtSrc));
       if (dtSrc.GetYear() != m_dtPreview.GetYear() || dtSrc.GetMonth() != m_dtPreview.GetMonth())
          {
            m_dtPreview.SetDate(dtSrc.GetYear(),dtSrc.GetMonth(),1);
            if (GetSafeHwnd())
               {
                 SendMessage(WM_NCPAINT);
               }
          }
     }

  if (GetSafeHwnd())
     {
       Invalidate();
     }
  return dtSrc;
}

CListboxDate::operator const CArray<CDate,CDate&>&() const
{
  return m_arrSelection;
}

const CArray<CDate,CDate&>& CListboxDate::operator =(const CArray<CDate,CDate&>& arrSrc)
{
  m_arrSelection.RemoveAll();
  m_arrSelection.Append(arrSrc);

  if (m_arrSelection.GetSize())
     {
       CDate dtLast = m_arrSelection.GetAt(m_arrSelection.GetSize()-1);
       if (dtLast.GetYear() != m_dtPreview.GetYear() || dtLast.GetMonth() != m_dtPreview.GetMonth())
          {
            m_dtPreview.SetDate(dtLast.GetYear(),dtLast.GetMonth(),1);
            if (GetSafeHwnd())
               {
                 SendMessage(WM_NCPAINT);
               }
          }
     }

  if (GetSafeHwnd())
     {
       Invalidate();
     }
  return arrSrc;
}


BEGIN_MESSAGE_MAP(CListboxDate, CListBox)
	//{{AFX_MSG_MAP(CListboxDate)
	ON_WM_NCPAINT()
	ON_WM_PAINT()
	ON_WM_NCCALCSIZE()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCHITTEST()
	ON_WM_MOUSEMOVE()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_NCLBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
    ON_MESSAGE(LB_GETANCHORINDEX,OnLBGetAnchorIndex)
    ON_MESSAGE(LB_GETCARETINDEX,OnLBGetCaretIndex)
    ON_MESSAGE(LB_GETLOCALE,OnLBGetLocale)
    ON_MESSAGE(LB_SETLOCALE,OnLBSetLocale)
    ON_MESSAGE(LB_GETSELCOUNT,OnLBGetSelCount)
    ON_MESSAGE(LB_GETCURSEL,OnLBGetCurSel)
    ON_MESSAGE(LB_INSERTSTRING,OnLBInsertString)
    ON_MESSAGE(LB_ADDSTRING,OnLBAddString)
    ON_MESSAGE(LB_SELECTSTRING,OnLBSelectString)
    ON_MESSAGE(LB_RESETCONTENT,OnLBResetContent)
    ON_MESSAGE(LB_GETTEXTLEN,OnLBGetTextLen)
    ON_MESSAGE(LB_GETTEXT,OnLBGetText)
    ON_MESSAGE(LB_GETSEL,OnLBGetSel)
    ON_MESSAGE(LB_GETSELITEMS,OnLBGetSelItems)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListboxDate message handlers

void CListboxDate::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
    DrawHeader( dc );
    DrawCalendar( dc );

	// Do not call CListBox::OnPaint() for painting messages
}

void CListboxDate::DrawHeader( CDC& dc )
{
  static TCHAR lpszWeekDays[] = {_T("\0\0\0\0\0\0\0\0")};
  static LCID  lcid;
  
  CRect rc;  GetClientRect(&rc); rc.bottom--;
  CSize sz = rc.Size(); sz.cx /= 7; sz.cy /= 1 + 6;
  TEXTMETRIC tm;

  // Initialize Week Day list
  if (!lpszWeekDays[0] || lcid != m_dtPreview.GetLCID())
     { // Create list of days of the week into appropriate language
       for(int i = 0; i < 7; i++)
          {
            GetLocaleInfo( m_dtPreview.GetLCID(), LOCALE_SDAYNAME1+(i?i-1:6), &lpszWeekDays[i], 1);
            lpszWeekDays[i] = toupper(lpszWeekDays[i]);
          }
     }

  // Paint top portion of the window like tooltips
  {
     CBrush brushTips( ::GetSysColor( COLOR_INFOBK ));
     CRect rcTips = rc;

     rcTips.bottom = rcTips.top+sz.cy;
     rcTips.left++; rcTips.right--;
     dc.FillRect( rcTips, &brushTips );
  }

  // Configure the DC
  {
    dc.SetBkMode( TRANSPARENT );
    dc.SetTextAlign( TA_CENTER );
  }

  // Recover text metrics informations
  {
    memset(&tm,0,sizeof(tm));
    dc.GetTextMetrics(&tm);
  }

  // Output the week days title rows
  {
    dc.SetTextColor( ::GetSysColor( COLOR_BTNTEXT ) );
    for( int i = 0; i < 7; i++)
       {
         dc.TextOut( ((i%7)*sz.cx)+sz.cx/2, (sz.cy-1)-(tm.tmHeight+tm.tmExternalLeading), &lpszWeekDays[i], 1);
       }

    dc.SelectObject(::GetStockObject(BLACK_PEN));
    dc.MoveTo(rc.left + 4,sz.cy - 1);
    dc.LineTo(rc.right - 4, sz.cy -1);
  }
}

void CListboxDate::DrawCalendar(CDC& dc)
{
  CRect rc;  GetClientRect(&rc); rc.bottom--;
  CSize sz = rc.Size(); sz.cx /= 7; sz.cy /= 1 + 6;

  // Configure the DC
  {
    dc.SetBkMode( TRANSPARENT );
    dc.SetTextAlign( TA_CENTER );
  }

  ASSERT(m_dtPreview.GetDay() == 1);
  CDate dtToday = CDate::Today();
  CDate dtMonthCurrent = m_dtPreview;
  CDate dtMonthPrevious, dtMonthNext;

  // Calculate next & previous month 1st date
  {
    int nMonth = dtMonthCurrent.GetMonth();
    int nYear  = dtMonthCurrent.GetYear();

    switch(nMonth)
      {
        case 1:   dtMonthPrevious.SetDate( nYear-1, 12,       1);
                  dtMonthNext.SetDate    ( nYear,   nMonth+1, 1);
                  break;
        case 12:  dtMonthPrevious.SetDate( nYear,   nMonth-1, 1);
                  dtMonthNext.SetDate    ( nYear+1, 1,        1);
                  break;
        default:  dtMonthPrevious.SetDate( nYear,   nMonth-1, 1);
                  dtMonthNext.SetDate    ( nYear,   nMonth+1, 1);
                  break;
      }
  }

  int nIndex;
  int nIndexFirstDay = dtMonthCurrent.GetWeekDay() + 1;
  int nNumberOfDays = dtMonthCurrent.GetMonthLastDay();

  // Output the days of the current month 
  {
    dc.SetTextColor( ::GetSysColor( COLOR_HIGHLIGHT ) );
    for( nIndex = nIndexFirstDay - 1; nIndex < nIndexFirstDay + nNumberOfDays - 1; nIndex++)
       {
         CString str;
         CDate   now(dtMonthCurrent.GetYear(), dtMonthCurrent.GetMonth(), nIndex - ( nIndexFirstDay - 2));
         str.Format("%d",now.GetDay());

         // Check for current selected dates
         {
           int nSel = 0;

           for(nSel = m_arrSelection.GetSize(); nSel; nSel--)
              {
                if (now == m_arrSelection.GetAt(nSel-1))
                   {
                     CRect hilight(
                                    CPoint((nIndex%7)*sz.cx, ((nIndex/7)+1)*sz.cy),
                                    CSize(sz.cx+1, sz.cy+1)
                                  );
                     hilight.OffsetRect(-1,1);
                     hilight.DeflateRect(1,1);
                     dc.FillRect(hilight,&CBrush(::GetSysColor(COLOR_HIGHLIGHT)));
                     dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
                     dc.TextOut( ((nIndex%7)*sz.cx)+sz.cx/2, (((nIndex/7)+1)*sz.cy) + (sz.cy/4), str);
                     dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHT));
                     break;
                   }
              }
           if (!nSel)
              {
                dc.TextOut( ((nIndex%7)*sz.cx)+sz.cx/2, (((nIndex/7)+1)*sz.cy) + (sz.cy/4), str);
              }
         }


         // If the current displaying day is today
         if ( now == dtToday )
            {
              CPen  penLight(PS_SOLID,0,::GetSysColor(COLOR_BTNHIGHLIGHT));
              CPen  penDark (PS_SOLID,0,::GetSysColor(COLOR_BTNSHADOW));
              CPen* oldPen = (CPen*)dc.SelectObject( &penDark );
              CRect hilight(
                             CPoint((nIndex%7)*sz.cx, ((nIndex/7)+1)*sz.cy),
                             CSize(sz.cx+1, sz.cy+1)
                           );
              hilight.OffsetRect(-1,1);
              dc.MoveTo( hilight.left,  hilight.bottom);
              dc.LineTo( hilight.left,  hilight.top );
              dc.LineTo( hilight.right, hilight.top );
              dc.SelectObject( &penLight );
              dc.LineTo( hilight.right, hilight.bottom );
              dc.LineTo( hilight.left,  hilight.bottom );
              dc.SelectObject( oldPen );
            }
       }
  }

  {
      // Output the days of the next month 
      {
        dc.SetTextColor( ::GetSysColor( COLOR_BTNSHADOW ) );
        for( int i = nIndex; i < 42; i++)
           {
             CString str;
             CDate   now(dtMonthNext.GetYear(), dtMonthNext.GetMonth(), i - (nIndex - 1));
             str.Format("%d",now.GetDay());

             // Check for current selected dates
             {
               int nSel = 0;
  
               for(nSel = m_arrSelection.GetSize(); nSel; nSel--)
                  {
                    if (now == m_arrSelection.GetAt(nSel-1))
                       {
                         CRect hilight(
                                        CPoint((i%7)*sz.cx, ((i/7)+1)*sz.cy),
                                        CSize(sz.cx+1, sz.cy+1)
                                      );
                         hilight.OffsetRect(-1,1);
                         hilight.DeflateRect(1,1);
                         dc.FillRect(hilight,&CBrush(::GetSysColor(COLOR_HIGHLIGHT)));
                         {
                           COLORREF color = dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
                           CBrush* oldBrush = (CBrush*)dc.SelectObject(CDC::GetHalftoneBrush());
                           dc.PatBlt(hilight.left,hilight.top,hilight.Width(),hilight.Height(),PATINVERT);
                           dc.SelectObject(oldBrush);
                           dc.SetBkColor(color);
                         }
                         dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
                         dc.TextOut( ((i%7)*sz.cx)+sz.cx/2, (((i/7)+1)*sz.cy) + (sz.cy/4), str);
                         dc.SetTextColor(::GetSysColor(COLOR_BTNSHADOW));
                         break;
                       }
                  }
               if (!nSel)
                  {
                    dc.TextOut( ((i%7)*sz.cx)+sz.cx/2, (((i/7)+1)*sz.cy) + (sz.cy/4), str);
                  }
             }
           }
      }

      nNumberOfDays = dtMonthPrevious.GetMonthLastDay();

      // Output the days of the previous month 
      {
        dc.SetTextColor( ::GetSysColor( COLOR_BTNSHADOW ) );
        for( int i = 0; i < nIndexFirstDay - 1; i++)
           {
             CString str;
             CDate   now(dtMonthPrevious.GetYear(), dtMonthPrevious.GetMonth(), nNumberOfDays - ((nIndexFirstDay-2) - i));
             str.Format("%d",now.GetDay());

             // Check for current selected dates
             {
               int nSel = 0;
  
               for(nSel = m_arrSelection.GetSize(); nSel; nSel--)
                  {
                    if (now == m_arrSelection.GetAt(nSel-1))
                       {
                         CRect hilight(
                                        CPoint((i%7)*sz.cx, ((i/7)+1)*sz.cy),
                                        CSize(sz.cx+1, sz.cy+1)
                                      );
                         hilight.OffsetRect(-1,1);
                         hilight.DeflateRect(1,1);
                         dc.FillRect(hilight,&CBrush(::GetSysColor(COLOR_HIGHLIGHT)));
                         {
                           COLORREF color = dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
                           CBrush* oldBrush = (CBrush*)dc.SelectObject(CDC::GetHalftoneBrush());
                           dc.PatBlt(hilight.left,hilight.top,hilight.Width(),hilight.Height(),PATINVERT);
                           dc.SelectObject(oldBrush);
                           dc.SetBkColor(color);
                         }
                         dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
                         dc.TextOut( ((i%7)*sz.cx)+sz.cx/2, (((i/7)+1)*sz.cy) + (sz.cy/4), str);
                         dc.SetTextColor(::GetSysColor(COLOR_BTNSHADOW));
                         break;
                       }
                  }
               if (!nSel)
                  {
                    dc.TextOut( ((i%7)*sz.cx)+sz.cx/2, (((i/7)+1)*sz.cy) + (sz.cy/4), str);
                  }
             }
           }
      }
  }
}

void CListboxDate::OnNcPaint() 
{
   CWindowDC dc(this);

   BorderPainter(dc);
   CaptionPainter(dc);

	// Do not call CListBox::OnNcPaint(); // for painting messages
}

#ifndef STILL_SOME_CARPET
    // Here is another strange reaction ( certainly some kind of
    // new Microsoft thinking method). The DevStudio don't add the
    // WS_BORDER to the resource script, but even if it does, the 
    // RC compiler or control creation seems to discard this value,
    // but the control always got the border (?!?), and a test
    // like [if (GetStyle & WS_BORDER)] always fail!
    // Now consider that WS_EX_CLIENTEDGE works the same, and that
    // when you choose WS_EX_MODALFRAME it automaticaly consider
    // WS_EX_WINDOWEDGE (that we cannot set with DevStudio).
    // The logical table we use is:
    //      3 - Sunken FX
    //      2 - Double FX
    //      1 - Static FX
    //      0 - no border
    #define AVOID_BUG4998(x) (x & (WS_EX_DLGMODALFRAME|WS_EX_STATICEDGE))
    #if _DEBUG
        #pragma message( __FILE__ "(1331) : warning MSC4998: Microsoft designer have (again) smoked the carpet!")
    #endif
#endif

void CListboxDate::BorderPainter(CDC& dc)
{
   CRect rc; GetWindowRect(&rc);
   rc.OffsetRect(-rc.left, -rc.top);

   CSize edge(::GetSystemMetrics(SM_CXEDGE),::GetSystemMetrics(SM_CYEDGE));

   // Draw borders (if any)
   {
     DWORD exStyle = GetExStyle();
     CRect rcBorder = rc;

     switch(AVOID_BUG4998(exStyle))
        {
          case 0:
               break;
          case WS_EX_STATICEDGE:
               dc.DrawEdge(rcBorder,EDGE_ETCHED,BF_RECT); break;
          case WS_EX_DLGMODALFRAME:
               dc.DrawEdge(rcBorder,EDGE_RAISED,BF_RECT);
               rcBorder.DeflateRect(edge.cx*2,edge.cy*2);
               dc.DrawEdge(rcBorder,EDGE_SUNKEN,BF_RECT);
               break;
          default:
               dc.DrawEdge(rcBorder,EDGE_SUNKEN,BF_RECT); break;
        }
   }   	
}

CSize CListboxDate::GetBorderMetrics()
{
   CSize edge(::GetSystemMetrics(SM_CXEDGE),::GetSystemMetrics(SM_CYEDGE));
   CSize border(0,0);

   DWORD exStyle = GetExStyle();

   switch(AVOID_BUG4998(exStyle))
      {
        case 0:
             break;
        case WS_EX_STATICEDGE:
             border = CSize(edge.cx,edge.cy); break;
        case WS_EX_DLGMODALFRAME:
             border = CSize(edge.cx*2,edge.cy*2); break;
        default:
             border = CSize(edge.cx,edge.cy); break;
      }
   return border;
}

void CListboxDate::CaptionPainter(CDC& dc) 
{
    // The NC area will reflets Month & Year, plus controls button
    // to allow the user to change current calendar month date.
    //          +------------------------+
    //          | [<] September 1998 [>] |
    //          +------------------------+

	// Prepare for drawing the non-client area
	CRect     rc; GetWindowRect(&rc); rc.OffsetRect(-rc.left, -rc.top);
    CSize     border( ::GetSystemMetrics( SM_CXBORDER ), ::GetSystemMetrics( SM_CYBORDER ));
    CSize     bttn( ::GetSystemMetrics( SM_CXHSCROLL ), ::GetSystemMetrics( SM_CYHSCROLL ));
    CFont*    oldFont = (CFont*)dc.SelectObject(&m_fontCaption);

    // Draw the background of the caption
    {
      CBrush brushFace( ::GetSysColor( COLOR_BTNFACE ));
      TEXTMETRIC tm; memset(&tm, 0, sizeof(TEXTMETRIC));

      dc.GetTextMetrics(&tm);
      rc.bottom = rc.top + max(tm.tmHeight,bttn.cy) + border.cy * 4;
      rc.InflateRect(-border.cx, -border.cy);
      dc.FillRect(rc,&brushFace);
    }

    // Draw the caption border as 3dButton
    {
      CBrush brushLight( ::GetSysColor( COLOR_BTNHIGHLIGHT ));
      CBrush brushDark( ::GetSysColor( COLOR_BTNSHADOW ));

      rc.InflateRect(-border.cx, -border.cy);
      dc.FillRect( CRect(rc.left, rc.top, rc.right, rc.top + border.cx), &brushLight );
      dc.FillRect( CRect(rc.right - border.cy, rc.top, rc.right, rc.bottom), &brushDark );
      dc.FillRect( CRect(rc.left, rc.top, rc.left + border.cx, rc.bottom), &brushLight );
      dc.FillRect( CRect(rc.left, rc.bottom - border.cy, rc.right, rc.bottom), &brushDark);
    }

	// Draw the text of the caption.
    {
      CString strTitle = m_dtPreview.Format(DATE_YEARMONTH);

      dc.SetTextAlign( TA_CENTER );
      dc.SetTextColor( ::GetSysColor(COLOR_BTNTEXT));
      dc.SetBkMode( TRANSPARENT );
      dc.TextOut(rc.left + (rc.Width()/2), rc.top, strTitle, strTitle.GetLength());
    }

    // Draw navigation buttons
    for( int i = -1; i < 2; i+=2)
       {
         CRect rcButton(0,0,bttn.cx,bttn.cy);
         rcButton.InflateRect( -border.cx, -border.cy );
         switch(i)
           {
             case -1: rcButton.OffsetRect( border.cx,border.cy );
                     break;
             default:rcButton.OffsetRect( rc.right - ( bttn.cx + border.cx ), border.cy );
                     break;
           }

           // Draw the arrow
           {
             CPoint center, allPts[3];

             center = rcButton.TopLeft();
             center.x += rcButton.Width() / 2;
             center.y += rcButton.Height() / 2;
      
             allPts[0].x = center.x - i;     allPts[0].y = center.y - (i*3);
             allPts[1].x = center.x - i;     allPts[1].y = center.y + (i*3);
             allPts[2].x = center.x + (i*2); allPts[2].y = center.y;

             dc.SelectObject(::GetStockObject(BLACK_BRUSH));

             dc.SetPolyFillMode(ALTERNATE);
             dc.Polygon(allPts, sizeof(allPts)/sizeof(CPoint));
           }
       }

    dc.SelectObject(oldFont);
	// Do not call CWnd::OnNcPaint() for painting messages
}

// This is the default layout. It could be overided throught an
// handler in the parent of this control ...
HBRUSH CListboxDate::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	HBRUSH hbr = (HBRUSH)::GetStockObject(LTGRAY_BRUSH);
	
    CFont* font = GetFont();
    pDC->SelectObject(font);

	return hbr;
}

// This overide of standard CWnd -and- derived class is to
// allow such kind of PostSubclass operation...
BOOL CListboxDate::SubclassDlgItem( UINT nID, CWnd* pParent )
{
   BOOL ret = CListBox::SubclassDlgItem( nID, pParent );

   CRect rc; GetWindowRect(&rc);
   SetWindowPos(NULL,0,0,0,0,SWP_NOMOVE|
                             SWP_NOSIZE|
                             SWP_NOACTIVATE|
                             SWP_NOZORDER|
                             SWP_FRAMECHANGED); // Force WM_NCCALCSIZE
   return ret;
}

// During the creation with a Create or CreateEx, lpncsp->rgrc[0] reflect
// the real position of the window. It do exactly what GetWindowRect does.
// The problem arrive when this creation was initiated through a Dialog
// creation. In that case the dialog is created, including children control
// and then moved to the appropriate screen coordonate. For same reason, 
// during WM_NCHITTEST, we need to recalculate the appropriate area to
// avoid due problem of Dialog movements. Another approach would be to
// interpret NonClient coordonate in Client coordonate, but because the
// Client area didn't exists at this time, ScreenToClient return
// unappropriate values.
void CListboxDate::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
    CSize bttn( ::GetSystemMetrics( SM_CXHSCROLL ), ::GetSystemMetrics( SM_CYHSCROLL ));
    CSize border = GetBorderMetrics();
    CRect winRect(lpncsp->rgrc);

    ::InflateRect(lpncsp->rgrc,-border.cx*2, -border.cy*2);

    {
      CWindowDC  dc(this);
      CFont* oldFont = (CFont*)dc.SelectObject(&m_fontCaption);

      TEXTMETRIC tm; memset(&tm, 0, sizeof(TEXTMETRIC));
      dc.GetTextMetrics(&tm);

      m_rcNonClient.CopyRect(lpncsp->rgrc);
      lpncsp->rgrc[0].top += max(tm.tmHeight,bttn.cy) + (::GetSystemMetrics( SM_CYBORDER)*3) - (border.cy*2);
      dc.SelectObject(oldFont);
    }
    m_rcNonClient.bottom = lpncsp->rgrc[0].top;
    m_rcNonClient.OffsetRect(-winRect.left, -winRect.top);
}

UINT CListboxDate::OnNcHitTest(CPoint point) 
{
	UINT nHit = CWnd::OnNcHitTest(point);
    CRect area;
    
    {
      GetWindowRect(&area);
      area.OffsetRect(m_rcNonClient.left,m_rcNonClient.top);
      area.left  += m_rcNonClient.left;
      area.top   += m_rcNonClient.top;
      area.right  = area.left + m_rcNonClient.Width();
      area.bottom = area.top + m_rcNonClient.Height();
    }

    if (area.PtInRect(point))
       {
         static CRect rcButton(0,0,::GetSystemMetrics(SM_CXHSCROLL),::GetSystemMetrics(SM_CXHSCROLL));
         static CSize border(::GetSystemMetrics(SM_CXBORDER)*2,::GetSystemMetrics(SM_CYBORDER)*2);
         CRect rcWnd; GetWindowRect(&rcWnd);

         nHit =  HTCAPTION;

         for( int i = 0; i < 2; i++)
            {
              UINT nHitCheck;
              CRect  rc = rcButton;
              CPoint pt = point;
              switch(i)
                {
                  case  0: rc.OffsetRect( rcWnd.left+border.cx,rcWnd.top+border.cy );
                           nHitCheck = HTMINBUTTON;
                           break;
                  default: rc.OffsetRect( rcWnd.right - (rcButton.Width() + border.cx), rcWnd.top+border.cy );
                           nHitCheck = HTMAXBUTTON;
                           break;
                }
      
              if ( rc.PtInRect(point))
                 {
                   nHit = nHitCheck;
                   break;
                 }
            }

       }

    if (nHit == HTNOWHERE)
       {
         CRect rc; GetClientRect(&rc); ClientToScreen( &rc );
         if (rc.PtInRect(point)) nHit = HTCLIENT;
       }

    return nHit;
}

void CListboxDate::OnNavigatorClick( UINT nID )
{
  int nMonth = m_dtPreview.GetMonth() + nID;
  int nYear  = m_dtPreview.GetYear();
  if (nMonth < 1) { nMonth = 12; nYear--; }
  if (nMonth > 12) { nMonth = 1; nYear++; }

  m_dtPreview.SetDate(nYear,nMonth,1);
  SendMessage(WM_NCPAINT);
  Invalidate();
}

LRESULT CListboxDate::OnSetText( WPARAM wParam, LPARAM lParam )
{
    CString str((LPCTSTR)lParam);
    str = _T("1,")+str;

    if (!m_dtPreview.ParseDate(str))
       {
         GetWindowText(str);
         if (str.IsEmpty())
            {
              m_dtPreview.SetDate(CDate::Today().GetYear(), CDate::Today().GetMonth(), 1);
            }

       }
    str = m_dtPreview.Format(DATE_YEARMONTH);

    LRESULT lRet = DefWindowProc(WM_SETTEXT, wParam, (LPARAM)(LPCTSTR)str );
    SendMessage(WM_NCPAINT);
    return lRet;
}

void CListboxDate::OnMouseMove(UINT nFlags, CPoint point) 
{
    static CPoint oldRowCol(0,0);

    CRect rc; GetClientRect(&rc); rc.bottom--;
    CSize sz = rc.Size(); sz.cx /= 7; sz.cy /= 1 + 6;

    {
      CPoint RowCol(point.x / sz.cx, point.y / sz.cy);
      if (RowCol != oldRowCol)
         {
           CClientDC* dc = (CClientDC*)GetDC();
           CPen       penR( PS_SOLID, 0, RGB(255,0,0));
           CPen*      oldPen = (CPen*)dc->SelectObject( &penR );

           if (oldRowCol.x + oldRowCol.y != 0)
              { // Erase previous tracker
                CRect tracker(CPoint(sz.cx*oldRowCol.x,sz.cy*oldRowCol.y),sz);
                tracker.OffsetRect(0,2);

                InvalidateRect(tracker);
              }
           if ( RowCol.x < 0 || RowCol.x > 6 || RowCol.y < 1 || RowCol.y > 6 )
              {
                RowCol.x = RowCol.y = 0;
              }
           oldRowCol = RowCol;
           if (oldRowCol.x + oldRowCol.y != 0)
              { // Paint a tracker
                CRect tracker(CPoint(sz.cx*oldRowCol.x,sz.cy*oldRowCol.y),sz);
                tracker.OffsetRect(0,2);
 
                dc->MoveTo( tracker.left,      tracker.top       );
                dc->LineTo( tracker.right - 1, tracker.top       );
                dc->LineTo( tracker.right - 1, tracker.bottom - 1);
                dc->LineTo( tracker.left,      tracker.bottom - 1);
                dc->LineTo( tracker.left,      tracker.top       );
              }

           dc->SelectObject( oldPen );
           ReleaseDC( dc );
         }
    }
    
    if ((nFlags & MK_LBUTTON) == MK_LBUTTON)
       {
         PickDate(MK_SHIFT|nFlags,point);
       }

    CWnd::OnMouseMove(nFlags, point);
}

void CListboxDate::OnLButtonDown(UINT nFlags, CPoint point) 
{
    PickDate(nFlags,point);
}

void CListboxDate::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// React as a click
	OnLButtonDown(nFlags, point);
}

void CListboxDate::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
    if (nHitTest == HTMINBUTTON) { OnNavigatorClick( -1 ); return; }
    if (nHitTest == HTMAXBUTTON) { OnNavigatorClick(  1 ); return; }
}

void CListboxDate::OnNcLButtonDblClk(UINT nHitTest, CPoint point) 
{
    // A double-click react as a click
    OnNcLButtonDown( nHitTest, point );
}

void CListboxDate::PickDate( UINT nFlags, CPoint point)
{
  static CPoint oldRowCol(0,0);
  CDate theDate;
  DWORD style = GetStyle() & (LBS_EXTENDEDSEL|LBS_MULTIPLESEL|LBS_NOSEL);

  nFlags &= MK_SHIFT|MK_CONTROL;

  switch(style)
     {
       case 0:
            nFlags = 0; break;
       case LBS_NOSEL:
            return; break;
       case LBS_MULTIPLESEL:
            nFlags = MK_CONTROL; break;
     }

  if (!nFlags || (nFlags==MK_SHIFT && m_dtShiftAnchor==CDate::nullDate))
     {
       // If not, the user as make a simple selection
       m_arrSelection.RemoveAll();
     }

  // Calculation of row/col clicked from the client area
  {
    CRect rc; GetClientRect(&rc); rc.bottom--;
    CSize sz = rc.Size(); sz.cx /= 7; sz.cy /= 1 + 6;
    CPoint RowCol(point.x / sz.cx, point.y / sz.cy);
    CRect  cells(0,1,7,7);

    if (RowCol != oldRowCol)
       {
         oldRowCol = RowCol;
       }
    else
       {
         // No cell change ignored.
         return;
       }

    if (cells.PtInRect(RowCol))
       { // Yes! Calculate the day...

         int nMonth = m_dtPreview.GetMonth();
         int nYear  = m_dtPreview.GetYear();
         int day = (RowCol.x+1) + ((RowCol.y-1)*7);
         day -= m_dtPreview.GetWeekDay();
         if (day < 1)
            { // The previous month has been selected
              nYear -= (nMonth==1)?1:0;
              nMonth -= (nMonth==1)?-11:1;
              m_dtPreview.SetDate(nYear,nMonth,1);
              day = m_dtPreview.GetMonthLastDay() + day;
              SendMessage(WM_NCPAINT);
            }
         else if (day > m_dtPreview.GetMonthLastDay())
            { // The next month has been selected
              nYear += (nMonth==12)?1:0;
              nMonth += (nMonth==12)?-11:1;
              day = day - m_dtPreview.GetMonthLastDay();
              m_dtPreview.SetDate(nYear,nMonth,1);
              SendMessage(WM_NCPAINT);
            }

         theDate.SetDate(m_dtPreview.GetYear(), m_dtPreview.GetMonth(), day);
       }
    else
       {
         // Not a valid cell ignored.
         return;
       }
  }

  if (nFlags != MK_SHIFT)
     {
       m_dtShiftAnchor = CDate::nullDate;
     }
  else
     {
       if (m_dtShiftAnchor == CDate::nullDate)
          {
            nFlags = 0;
          }
     }

  switch(nFlags)
     {
       case MK_CONTROL|MK_SHIFT:
       case MK_CONTROL:
            {
              int i;
              for(i=m_arrSelection.GetSize(); i; i--)
                 {
                   if ( m_arrSelection.GetAt(i-1) == theDate )
                      {
                        m_arrSelection.RemoveAt(i-1);
                        break;
                      }
                 }
              if (i) break;
            } // Fall through
       case 0:
            {
              m_arrSelection.Add(theDate);
              m_dtShiftAnchor = theDate;
            }
            break;
       case MK_SHIFT:
            {
              CDate dtLast = m_dtShiftAnchor;
              int nSense = 0;

              if (m_dtShiftAnchor == theDate)
                 {
                   m_arrSelection.RemoveAll();
                 }

              // Purge any unnecessary date
              if (m_dtShiftAnchor > theDate)
                 {
                   nSense = -1;
                   for(int i=m_arrSelection.GetSize(); i; i--)
                      {
                        if (m_arrSelection.GetAt(i-1) <= theDate)
                           {
                             m_arrSelection.RemoveAt(i-1);
                           }
                        else
                           {
                             dtLast = min(dtLast,m_arrSelection.GetAt(i-1));
                           }
                      }
                 }
              if (m_dtShiftAnchor < theDate)
                 {
                   nSense = 1;
                   for(int i=m_arrSelection.GetSize(); i; i--)
                      {
                        if (m_arrSelection.GetAt(i-1) >= theDate)
                           {
                             m_arrSelection.RemoveAt(i-1);
                           }
                        else
                           {
                             dtLast = max(dtLast,m_arrSelection.GetAt(i-1));
                           }
                      }
                 }

              if (nSense)
                 {
                   for (dtLast+=nSense; dtLast!=theDate; dtLast+=nSense)
                       {
                         m_arrSelection.Add(dtLast);
                       }
                 }
              {
                 m_arrSelection.Add(theDate);
              }
            }
            break;
     }
  Invalidate();
  PostMessage(WM_KILLFOCUS);	
  return;
}

LRESULT CListboxDate::OnLBGetAnchorIndex(WPARAM, LPARAM)
{
  int i=0;
  if (m_dtShiftAnchor != CDate::nullDate)
     {
       for(i=m_arrSelection.GetSize(); i; i--)
          {
            if (m_arrSelection.GetAt(i-1) == m_dtShiftAnchor) break;
          }
     }
  return (LRESULT)(i?(i-1):LB_ERR);
}

LRESULT CListboxDate::OnLBGetCaretIndex(WPARAM, LPARAM)
{
  int i=m_arrSelection.GetSize();
  return (LRESULT)(i?(i-1):LB_ERR);
}

LRESULT CListboxDate::OnLBGetLocale(WPARAM, LPARAM)
{
  return (LRESULT)m_dtPreview.GetLCID();
}

LRESULT CListboxDate::OnLBSetLocale( WPARAM wParam, LPARAM )
{
  if (!m_dtPreview.SetLCID((LCID)(WORD)wParam))
     {
       return FALSE;
     }
  if (GetSafeHwnd())
     {
       SendMessage(WM_NCPAINT);
     }
  return TRUE;
}

LRESULT CListboxDate::OnLBGetSelCount(WPARAM, LPARAM)
{
  if (GetStyle() & (LBS_EXTENDEDSEL|LBS_MULTIPLESEL))
     {
       return (LRESULT)(m_arrSelection.GetSize());
     }
  else
     {
       return (LRESULT)LB_ERR;
     }
}

LRESULT CListboxDate::OnLBGetCurSel(WPARAM, LPARAM)
{
  return (LRESULT)(m_arrSelection.GetSize()-1);
}

LRESULT CListboxDate::OnLBInsertString(WPARAM, LPARAM)
{
  return (LRESULT)LB_ERR;
}

LRESULT CListboxDate::OnLBAddString(WPARAM, LPARAM)
{
  return (LRESULT)LB_ERR;
}

LRESULT CListboxDate::OnLBResetContent(WPARAM, LPARAM)
{
  m_arrSelection.RemoveAll();
  return NULL;
}

LRESULT CListboxDate::OnLBGetTextLen(WPARAM wParam, LPARAM)
{
  int nSel = (int)wParam;

  if (nSel >= 0 && nSel < m_arrSelection.GetSize())
     {
       CDate dt; dt.SetLCID( m_dtPreview.GetLCID());
       dt = m_arrSelection.GetAt(nSel);
       return (LRESULT)dt.Format(DATE_LONGDATE).GetLength();
     }
  return (LRESULT)LB_ERR;
}

LRESULT CListboxDate::OnLBGetText(WPARAM wParam, LPARAM lParam)
{
  LPTSTR lpsz = (LPTSTR)lParam;
  int nSel = (int)wParam;

  if (nSel >= 0 && nSel < m_arrSelection.GetSize() && lpsz)
     {
       CDate dt; dt.SetLCID( m_dtPreview.GetLCID());
       dt = m_arrSelection.GetAt(nSel);
       _tcscpy(lpsz,dt.Format(DATE_LONGDATE));
       return (LRESULT)_tcslen(lpsz);
     }
  return (LRESULT)LB_ERR;
}

LRESULT CListboxDate::OnLBSelectString(WPARAM, LPARAM lParam)
{
  CString str = (LPCTSTR)lParam;
  CDate dt;  dt.SetLCID(m_dtPreview.GetLCID());
  DWORD style = GetStyle();

  if (style & LBS_NOSEL) return (LRESULT)LB_ERR;

  if (!str.IsEmpty() && dt.ParseDate(str))
     {
       if (style & (LBS_EXTENDEDSEL|LBS_MULTIPLESEL))
          {
            for(int i=m_arrSelection.GetSize(); i; i--)
               {
                 if (m_arrSelection.GetAt(i-1) == dt)
                    {
                      return (LRESULT)(i-1);
                    }
               }
          }
       else
          {
            m_arrSelection.RemoveAll();
          }

       m_arrSelection.Add(dt);
       if (dt.GetMonth() != m_dtPreview.GetMonth() || dt.GetYear() != m_dtPreview.GetYear())
          {
            m_dtPreview.SetDate(dt.GetYear(),dt.GetMonth(),1);
            SendMessage(WM_NCPAINT);
          }
       Invalidate();
       return (LRESULT)(m_arrSelection.GetSize()-1);
     }
  return (LRESULT)LB_ERR;
}

LRESULT CListboxDate::OnLBGetSel(WPARAM wParam, LPARAM)
{
  int nSel = (int)wParam;
  if (nSel > 0 && nSel < m_arrSelection.GetSize())
     {
       return TRUE;
     }
  return FALSE;
}

LRESULT CListboxDate::OnLBGetSelItems(WPARAM wParam, LPARAM lParam)
{
  int nCount = min((int)wParam, m_arrSelection.GetSize());
  LPINT pBuf = (LPINT)lParam;

  if (nCount > 0 && pBuf && !(GetStyle() && (LBS_EXTENDEDSEL|LBS_MULTIPLESEL)))
     {
       for(int i=0; i < nCount; i++)
          {
            *pBuf++=i;
          }
       return (LRESULT)nCount;
     }
  return LB_ERR;
}

/////////////////////////////////////////////////////////////////////////////
// Those DDX for CListboxDate

// DDX for single selection CListboxDate
void AFXAPI DDX_LBDate(CDataExchange* pDX, int nIDC, CDate& value)
{
	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
    CListboxDate* pCtl = (CListboxDate*)CWnd::FromHandle( hWndCtrl );

	if (pDX->m_bSaveAndValidate)
	{
		value = *pCtl;
	}
	else
	{
        *pCtl = value;
	}
}

// DDX for multiple/extended selection CListboxDate
void AFXAPI DDX_LBDate(CDataExchange* pDX, int nIDC, CArray<CDate,CDate&>& array)
{
	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
    CListboxDate* pCtl = (CListboxDate*)CWnd::FromHandle( hWndCtrl );

	if (pDX->m_bSaveAndValidate)
	{
        array.RemoveAll();
		array.Append(*pCtl);
	}
	else
	{
        *pCtl = array;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CComboDate

#pragma warning(disable:4355)
CComboDate::CComboDate()
           : m_rcButton(0,0,0,0),
             m_wndCal(this),
             m_wndEdt(this)
{
  m_ctrlPredecessor = NULL;
  m_ctrlSuccessor = NULL;
}
#pragma warning(default:4355)


CComboDate::~CComboDate()
{
}

CComboDate::operator const CDate&() const
{
  return m_dtValue;
}

const CDate& CComboDate::operator =(const CDate& dtSrc)
{
  m_dtValue = dtSrc;
  if (m_wndEdt.GetSafeHwnd())
     {
       m_wndEdt.SetWindowText(NULL);
     }
  return m_dtValue;
}

BEGIN_MESSAGE_MAP(CComboDate, CWnd)
	//{{AFX_MSG_MAP(CComboDate)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
    ON_MESSAGE(WM_GETTEXTLENGTH, OnGetTextLength)
    ON_MESSAGE(WM_GETTEXTLENGTH, OnGetText)
    ON_MESSAGE(WM_SETTEXT, OnSetText)
    ON_MESSAGE(CB_SHOWDROPDOWN, OnCBShowDropDown)
    ON_MESSAGE(CB_GETDROPPEDSTATE, OnCBGetDroppedState)
    ON_MESSAGE(CB_SETLOCALE, OnCBSetLocale)
    ON_MESSAGE(CB_GETLOCALE, OnCBGetLocale)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// This is to replace the normal SendNotifyMessage API,
// because we want to Post those message in during 
// other message processing...
void CComboDate::PostNotifyMessage( UINT nonWM )
{
  CWnd* pWnd = GetParentOwner();
  UINT nID  = GetDlgCtrlID();
  HWND hWnd = GetSafeHwnd();

  pWnd->PostMessage(WM_COMMAND, (WPARAM)MAKELONG(nID,nonWM),(LPARAM)hWnd);
}

void CComboDate::ShowDropDown(BOOL bShowIt /*= TRUE*/)
{
  if (bShowIt)
     {
       if (GetCapture() != this)
          {
            SetCapture();
          }
       if (!m_wndCal.GetSafeHwnd())
          {
            m_wndCal.Create( this, m_dtValue.Format(DATE_YEARMONTH));
            PostNotifyMessage(CBN_DROPDOWN);
          }
     }
  else
     {
       if (m_wndCal.GetSafeHwnd())
          {
            m_wndCal.DestroyWindow();
            PostNotifyMessage(CBN_CLOSEUP);
          }
     }
}

LRESULT CComboDate::OnCBShowDropDown( WPARAM wParam, LPARAM )
{
  ShowDropDown((BOOL)wParam);
  return (LRESULT)TRUE;
  // Don't call DefWindowProc(CB_SHOWDROPDOWN, wParam, lParam)
  // to be sure that we intercept to combo open...
}

BOOL CComboDate::GetDroppedState( ) const
{
  return (m_wndCal.GetSafeHwnd() != 0);
}

LRESULT CComboDate::OnCBGetDroppedState( WPARAM wParam, LPARAM )
{
  return (LRESULT)GetDroppedState();
}

LCID CComboDate::GetLocale( ) const
{
  return m_dtValue.GetLCID();
}

LRESULT CComboDate::OnCBGetLocale( WPARAM, LPARAM )
{
  return (LRESULT)GetLocale();
}

LCID CComboDate::SetLocale( LCID nNewLocale )
{
  if (!m_dtValue.SetLCID( nNewLocale ))
     {
       return GetLocale();
     }
  if (GetSafeHwnd()) m_wndEdt.SetWindowText(NULL);
  return nNewLocale;
}

LRESULT CComboDate::OnCBSetLocale( WPARAM wParam, LPARAM )
{
  if (SetLocale((LCID)(WORD)wParam) != (LCID)(WORD)wParam)
     {
       return FALSE;
     }
  return TRUE;
}

LRESULT CComboDate::OnGetTextLength(WPARAM wParam,LPARAM lParam)
{
  return DefWindowProc(WM_GETTEXTLENGTH, wParam, lParam);
}

LRESULT CComboDate::OnGetText(WPARAM wParam,LPARAM lParam)
{
  return DefWindowProc(WM_GETTEXT, wParam, lParam);
}

LRESULT CComboDate::OnSetText(WPARAM wParam,LPARAM lParam)
{
  CString str((LPCTSTR)lParam);
  if (!str.IsEmpty())
     {
       if (m_dtValue.ParseDate((LPCTSTR)str))
          {
            m_wndEdt.SetWindowText(NULL);
            return TRUE;
          }
     }
  else
     {
       m_dtValue = CDate::nullDate;
       m_wndEdt.SetWindowText(NULL);
       return TRUE;
     }

  {
    LRESULT ret = DefWindowProc(WM_SETTEXT, wParam, lParam);
    MessageBeep(MB_ICONEXCLAMATION);
    m_wndEdt.SetSel(0,-1,TRUE);
    m_wndEdt.SetFocus();
    return ret;
  }
}

void CComboDate::DrawButton( CDC* pDc, BOOL bPressed /* =FALSE */ )
{
    // Create some usefull pen & brush that
    // we use in the following code
    CPen    penFace (PS_SOLID,0,::GetSysColor(COLOR_BTNFACE));
    CPen    penLight(PS_SOLID,0,::GetSysColor(COLOR_BTNHIGHLIGHT));
    CPen    penDark (PS_SOLID,0,::GetSysColor(COLOR_BTNSHADOW));
    CPen    penBlack(PS_SOLID,0,::GetSysColor(COLOR_BTNTEXT));
    CBrush  brushFace(::GetSysColor(COLOR_BTNFACE));

    // Save pen & brush so forget them during
    // this function processing
    CPen*   oldPen   =   (CPen*)pDc->SelectObject( penFace );
    CBrush* oldBrush = (CBrush*)pDc->SelectObject( brushFace );

    // Calculate once the usefull rect of the button
    // tile as a square on right side of the client rect.
    if (!m_rcButton.bottom || !m_rcButton.right)
       {
         CSize sizeBorder(
                           GetSystemMetrics(SM_CXEDGE),
                           GetSystemMetrics(SM_CYEDGE)
                         );

         CRect rcEdit; GetTopWindow()->GetWindowRect(&rcEdit); ScreenToClient(&rcEdit);
         CRect rcCombo; GetClientRect(&rcCombo);

         m_rcButton = CRect(
                             rcEdit.right+1,sizeBorder.cy,
                             rcCombo.right-sizeBorder.cx,rcCombo.bottom-sizeBorder.cy
                           );
       }

    // Draw the button edge with the            ||
    // appropriate 3D look depending on         ||
    // the button state.                        |+-----  <- Inner
    //                                          +------  <- Outer
    //                                          Inner colors are white & dark gray
    //                                          Outer colors are gray & black
    {
      CBrush brushInnDark(::GetSysColor(COLOR_BTNSHADOW)),
             brushInnLite(::GetSysColor(COLOR_BTNHIGHLIGHT)),
             brushOutDark(::GetSysColor(COLOR_BTNTEXT)),
             brushOutLite(::GetSysColor(COLOR_BTNFACE));
      CSize szEdge(::GetSystemMetrics(SM_CXEDGE)/2,::GetSystemMetrics(SM_CYEDGE)/2);
      CRect rc = m_rcButton;

      pDc->FillRect( rc, &CBrush(::GetSysColor( COLOR_BTNFACE )) );

      // Outer border
      pDc->FillRect(
                     CRect(rc.TopLeft(),CSize(szEdge.cx,rc.Height())),
                     bPressed?&brushInnDark:&brushOutLite
                   );
      pDc->FillRect(
                     CRect(rc.TopLeft(),CSize(rc.Width(),szEdge.cy)),
                     bPressed?&brushInnDark:&brushOutLite
                   );
      pDc->FillRect(
                     CRect(rc.BottomRight(),CSize(-szEdge.cx,-rc.Height())),
                     bPressed?&brushInnDark:&brushOutDark
                   );
      pDc->FillRect(
                     CRect(rc.BottomRight(),CSize(-rc.Width(),-szEdge.cy)),
                     bPressed?&brushInnDark:&brushOutDark
                   );

      rc.InflateRect(-szEdge.cx,-szEdge.cy);

      // Inner border
      pDc->FillRect(
                     CRect(rc.TopLeft(),CSize(szEdge.cx,rc.Height())),
                     bPressed?&brushOutLite:&brushInnLite
                   );
      pDc->FillRect(
                     CRect(rc.TopLeft(),CSize(rc.Width(),szEdge.cy)),
                     bPressed?&brushOutLite:&brushInnLite
                   );
      pDc->FillRect(
                     CRect(rc.BottomRight(),CSize(-szEdge.cx,-rc.Height())),
                     bPressed?&brushOutLite:&brushInnDark
                   );
      pDc->FillRect(
                     CRect(rc.BottomRight(),CSize(-rc.Width(),-szEdge.cy)),
                     bPressed?&brushOutLite:&brushInnDark
                   );
    }

    // Draw the dropdown arrow by drawing a
    // black triangle of 6x4 centered on
    // mid-point of the button tile.
    {
      CPoint center, allPts[3];

      center = m_rcButton.TopLeft();
      center.x += (m_rcButton.Width()-1) / 2;
      center.y += m_rcButton.Height() / 2;
      if (!bPressed) center.y--;
      
      allPts[0].x = center.x - 3; allPts[0].y = center.y - 1;
      allPts[1].x = center.x + 3; allPts[1].y = center.y - 1;
      allPts[2].x = center.x;     allPts[2].y = center.y + 2;

      pDc->SelectObject(penBlack);
      pDc->SelectObject(::GetStockObject(BLACK_BRUSH));

      pDc->SetPolyFillMode(ALTERNATE);
      pDc->Polygon(allPts, sizeof(allPts)/sizeof(CPoint));
    }

    // Restore pen & brush so run-time will take care
    // of neccessary deletion
    pDc->SelectObject( &oldPen );
    pDc->SelectObject( &oldBrush );
}

/////////////////////////////////////////////////////////////////////////////
// CComboDate message handlers

void CComboDate::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

    DrawButton(&dc);

    {
      CRect rc; GetClientRect( &rc );
      CSize sizeBorder(
                        GetSystemMetrics(SM_CXEDGE),
                        GetSystemMetrics(SM_CYEDGE)
                      );
      dc.DrawEdge(rc,EDGE_SUNKEN, BF_RECT);
      GetTopWindow()->GetWindowRect(&rc); ScreenToClient(&rc);
      rc.InflateRect(1,1);
      dc.SelectObject(GetStockObject(NULL_BRUSH));
      dc.SelectObject(GetStockObject(WHITE_PEN));

      dc.Rectangle(rc);
    }
	// Do not call CWnd::OnPaint() for painting messages
}

void CComboDate::DropdownButton( BOOL bPressed )
{
  static BOOL isPressed = FALSE;

  if (bPressed == isPressed) return;
  if (!GetCapture() || GetCapture()->GetSafeHwnd() != GetSafeHwnd()) return;

  // We draw the appropriate button state
  { 
    CDC* pDc = GetDC();
    isPressed = bPressed;
    DrawButton(pDc, isPressed);
    ReleaseDC( pDc );
  }
}

void CComboDate::OnLButtonDown(UINT nFlags, CPoint point) 
{
    m_wndEdt.SetFocus();
    if ( m_rcButton.PtInRect( point ) )
       {
         //ShowDropDown(FALSE);
         ShowDropDown(TRUE);
         DropdownButton( TRUE );
         return;
       }

    // Eat those messages, so we never call the
    // original ComboBox we are based on.
	// CWnd::OnLButtonDown(nFlags, point);
}

void CComboDate::OnLButtonUp(UINT nFlags, CPoint point) 
{
    DropdownButton( FALSE );
    if (GetCapture() == this)
       {
         ::ReleaseCapture();
         if (m_wndCal.GetSafeHwnd() != NULL)
            {
              m_wndCal.PostMessage( WM_NCHITTEST, 0, MAKELONG(point.x, point.y) );
            }
       }
	CWnd::OnLButtonUp(nFlags, point);
}

void CComboDate::OnMouseMove(UINT nFlags, CPoint point) 
{
    if (m_wndCal.GetSafeHwnd() != NULL)
       {
         CRect rc; m_wndCal.GetWindowRect( &rc );
         CPoint pt = point; ClientToScreen( &pt );
         if (rc.PtInRect( pt ))
            {
              m_wndCal.PostMessage( WM_NCHITTEST, 0, MAKELONG(point.x, point.y) );
            }
       }

    if ( m_rcButton.PtInRect( point ) )
       { // We are on the button
         DropdownButton( TRUE );
       }
    else
       {
         DropdownButton( FALSE );
       }
	
	CWnd::OnMouseMove(nFlags, point);
}

void CComboDate::PreSubclassWindow() 
{
    ///////////////////////////////////////////
    // The ComboBox into the resource template
    // need to have style CBS_DROPDOWN.
    // Check-it and assert also on strange combo
    CWnd* pEdit;
    VERIFY(pEdit = GetTopWindow());
    {
      TCHAR buf[256];
      ::GetClassName(pEdit->GetSafeHwnd(),buf,sizeof(buf));
      
      ASSERT(!CString(buf).CompareNoCase(_T("EDIT")));
    }

	CWnd::PreSubclassWindow();
    m_wndEdt.SubclassWindow(pEdit->GetSafeHwnd());
}

//
// Following functions are a pre-wired
// approach for group of date 
//
void CComboDate::ConsiderAsPredecessor( CComboDate* pPred )
{
  VERIFY(!m_ctrlPredecessor);
  VERIFY(!pPred->m_ctrlSuccessor);
  m_ctrlPredecessor = pPred;
  pPred->m_ctrlSuccessor = this;
}

void CComboDate::ConsiderAsSuccessor( CComboDate* pSucc )
{
  VERIFY(!m_ctrlSuccessor);
  VERIFY(!pSucc->m_ctrlPredecessor);
  m_ctrlSuccessor = pSucc;
  pSucc->m_ctrlPredecessor = this;
}

/////////////////////////////////////////////////////////////////////////////
// The DDX / DDV for CComboDate
void AFXAPI DDX_CBDate(CDataExchange* pDX, int nIDC, CDate& value)
{
	HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
    CComboDate* pCtl = (CComboDate*)CWnd::FromHandle( hWndCtrl );

	if (pDX->m_bSaveAndValidate)
	{
		value = *pCtl;
	}
	else
	{
        *pCtl = value;
	}
}

void AFXAPI DDV_DateFrame(CDataExchange* pDX, CDate& value, CDate& minVal, CDate& maxVal /*= CDate(9999,31,12)*/)
{
	if (!pDX->m_bSaveAndValidate)
	{
		TRACE0("Warning: initial dialog data is out of range.\n");
		return;     // don't stop now
	}

	ASSERT(minVal <= maxVal);
	if (value < minVal || value > maxVal)
       {
          pDX->Fail();
       }
}

/////////////////////////////////////////////////////////////////////////////
// CComboDate::SCalendarWnd

CComboDate::SCalendarWnd::SCalendarWnd( CComboDate* container )
{
  HDC hdc = ::GetDC(NULL);

  {
    LOGFONT lf; memset(&lf, 0, sizeof(LOGFONT));
    lf.lfHeight = -MulDiv(6, ::GetDeviceCaps(hdc, LOGPIXELSY), 72);
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfWeight = FW_NORMAL;
    lf.lfPitchAndFamily = DEFAULT_PITCH | FF_SWISS;
    // Some fonts can fit with this small dimensions,
    // but many are not as readable on that kind of
    // dimensions. So we force the "Small Fonts".
	lstrcpy(lf.lfFaceName, _T("Small Fonts"));

    m_fontSmall.CreateFontIndirect( &lf );
	m_fontSmall.GetLogFont(&lf);
  }

  ::ReleaseDC(NULL, hdc);

  m_pParent = container;
  m_pdtValue = &container->m_dtValue;

  m_dtPreview = *m_pdtValue;
  if (m_dtPreview == CDate::nullDate || !m_dtPreview.IsRelevant()) m_dtPreview = CDate::Today();

  m_dtPreview.SetDate( m_dtPreview.GetYear(), m_dtPreview.GetMonth(), 1);
}

CRect CComboDate::SCalendarWnd::m_rcDropDown( 0,0,120,108 );

CComboDate::SCalendarWnd::~SCalendarWnd()
{
}

BOOL CComboDate::SCalendarWnd::Create( CWnd* pWndParent, LPCTSTR lpszTitle /* = NULL */)
{
   CString title = lpszTitle;
   // Position the drop-down window right align with the 
   // lower right corner of the parent. Actually there is not check
   // to ensure that the whole drop-down window would be 
   // visible on screen...
   {
     CRect rcParent;
     pWndParent->GetWindowRect(&rcParent);
     m_rcDropDown.OffsetRect( -m_rcDropDown.left, -m_rcDropDown.top );
     m_rcDropDown.OffsetRect(
                              rcParent.right - m_rcDropDown.Width(),
                              rcParent.bottom + ::GetSystemMetrics(SM_CYEDGE)
                            );
   }

   if (!CreateEx(
                  0, // could be WS_EX_TOOLWINDOW, but don't understand what it's change
                  AfxRegisterWndClass(
                                       CS_DBLCLKS,
                                       ::LoadCursor(NULL, IDC_ARROW),
                                       (HBRUSH)::GetStockObject(WHITE_BRUSH)
                                     ),
                  NULL,
                  WS_BORDER|WS_CHILD, // |WS_VISIBLE,
                  m_rcDropDown,
                  GetDesktopWindow(),
                  0
                )
      )
      {
        return FALSE;
      }

   ::SetWindowLong(GetSafeHwnd(),GWL_HWNDPARENT, (long)pWndParent->GetSafeHwnd());
   SetWindowPos(&CWnd::wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_SHOWWINDOW);
   m_dtPreview.SetLCID(pWndParent->SendMessage(CB_GETLOCALE));
   if (title.IsEmpty())
      {
        title = CDate::Today().Format(DATE_YEARMONTH);
      }
   SetWindowText(title);
   return TRUE;
}

BOOL CComboDate::SCalendarWnd::SubclassDlgItem( UINT nID, CWnd* pParent )
{
   return CWnd::SubclassDlgItem( nID, pParent );
}

/* Message Map MACRO translation for sub-class fail
BEGIN_MESSAGE_MAP(CComboDate::SCalendarWnd, CWnd)
	//{{AFX_MSG_MAP(CComboDate::SCalendarWnd)
	ON_WM_NCPAINT()
	ON_WM_PAINT()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_CAPTURECHANGED()
	ON_WM_NCHITTEST()
    ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONUP()
    ON_WM_KEYDOWN()
    ON_MESSAGE(WM_SETTEXT, OnSetText)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
*/

///*
BEGIN_MESSAGE_MAP(CComboDate::SCalendarWnd, CWnd)
	{ WM_NCCALCSIZE,      0, 0, 0, AfxSig_vCALC, (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(BOOL, NCCALCSIZE_PARAMS*))&CComboDate::SCalendarWnd::OnNcCalcSize },
	{ WM_NCPAINT,         0, 0, 0, AfxSig_vv,    (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(void))&CComboDate::SCalendarWnd::OnNcPaint },
	{ WM_PAINT,           0, 0, 0, AfxSig_vv,    (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(void))&CComboDate::SCalendarWnd::OnPaint },
	{ WM_NCLBUTTONDOWN,   0, 0, 0, AfxSig_vwp,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&CComboDate::SCalendarWnd::OnNcLButtonDown },
	{ WM_CAPTURECHANGED,  0, 0, 0, AfxSig_vW2,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(CWnd*))&CComboDate::SCalendarWnd::OnCaptureChanged },
	{ WM_NCHITTEST,       0, 0, 0, AfxSig_wp,    (AFX_PMSG)(AFX_PMSGW)(UINT (AFX_MSG_CALL CWnd::*)(CPoint))&CComboDate::SCalendarWnd::OnNcHitTest },
	{ WM_MOUSEMOVE,       0, 0, 0, AfxSig_vwp,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&CComboDate::SCalendarWnd::OnMouseMove },
	{ WM_LBUTTONDOWN,     0, 0, 0, AfxSig_vwp,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&CComboDate::SCalendarWnd::OnLButtonDown },
	{ WM_LBUTTONDBLCLK,   0, 0, 0, AfxSig_vwp,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&CComboDate::SCalendarWnd::OnLButtonDblClk },
	{ WM_LBUTTONUP,       0, 0, 0, AfxSig_vwp,   (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, CPoint))&CComboDate::SCalendarWnd::OnLButtonUp },
	{ WM_KEYDOWN,         0, 0, 0, AfxSig_vwww,  (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CWnd::*)(UINT, UINT, UINT))&CComboDate::SCalendarWnd::OnKeyDown },
	{ WM_SETTEXT,         0, 0, 0, AfxSig_lwl,   (AFX_PMSG)(AFX_PMSGW)(LRESULT (AFX_MSG_CALL CWnd::*)(WPARAM, LPARAM))&CComboDate::SCalendarWnd::OnSetText },
END_MESSAGE_MAP()
//*/

/////////////////////////////////////////////////////////////////////////////
// CComboDate::SCalendarWnd message handlers

CSize CComboDate::SCalendarWnd::GetBorderMetrics()
{
  return CSize( ::GetSystemMetrics( SM_CXBORDER ), ::GetSystemMetrics( SM_CYBORDER ));
}

void CComboDate::SCalendarWnd::BorderPainter( CDC& dc )
{
	CRect   rc; GetWindowRect(&rc); rc.OffsetRect(-rc.left, -rc.top);
    CSize   border( ::GetSystemMetrics( SM_CXBORDER ), ::GetSystemMetrics( SM_CYBORDER ));
    CBrush  brushFrame( ::GetSysColor( COLOR_WINDOWFRAME ));

    dc.FillRect( CRect(rc.left, rc.top, rc.right, rc.top + border.cx), &brushFrame );
    dc.FillRect( CRect(rc.right - border.cy, rc.top, rc.right, rc.bottom), &brushFrame );
    dc.FillRect( CRect(rc.left, rc.top, rc.left + border.cx, rc.bottom), &brushFrame );
    dc.FillRect( CRect(rc.left, rc.bottom - border.cy, rc.right, rc.bottom), &brushFrame);
}

void CComboDate::SCalendarWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
    CFont* oldFont = (CFont*)dc.SelectObject(&m_fontSmall);

    DrawHeader( dc );
    {
      m_arrSelection.Add(*m_pdtValue);
      DrawCalendar( dc );
      m_arrSelection.RemoveAll();
    }
    dc.SelectObject(oldFont);
	
	// Do not call CWnd::OnPaint();// for painting messages
}

void CComboDate::SCalendarWnd::OnCaptureChanged(CWnd *pWnd) 
{
	CWnd::OnCaptureChanged(pWnd);
    DestroyWindow();
    m_pParent->PostNotifyMessage(CBN_CLOSEUP);
}

UINT CComboDate::SCalendarWnd::OnNcHitTest(CPoint point) 
{
    if (GetCapture() != this)
       {
         SetCapture();
       }
	return CListboxDate::OnNcHitTest(point);
}

void CComboDate::SCalendarWnd::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
    CListboxDate::OnNcLButtonDown(nHitTest, point);
    if (nHitTest == HTNOWHERE)  ::ReleaseCapture();
}

void CComboDate::SCalendarWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
    // During capture every click message fall there
    // we need to check if those click are really into the
    // client area
    if (GetCapture() == this)
       {
         CPoint pt = point;
         ClientToScreen( &pt );
         UINT nHit = OnNcHitTest( pt );

         if ( nHit != HTCLIENT )
            {
              OnNcLButtonDown( nHit, pt );
              return;
            }
       }

	CWnd::OnLButtonDown(nFlags, point);
}

void CComboDate::SCalendarWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
    // Are we on such a month day number?
    {
      CRect rc; GetClientRect(&rc);
      CSize sz = rc.Size(); sz.cx /= 7; sz.cy /= 1 + 6;
      CPoint RowCol(point.x / sz.cx, point.y / sz.cy);
      CRect  cells(0,1,7,7);

      if (cells.PtInRect(RowCol))
         { // Yes! Calculate the day...
           int nMonth = m_dtPreview.GetMonth();
           int nYear  = m_dtPreview.GetYear();
           int day = (RowCol.x+1) + ((RowCol.y-1)*7);
           day -= m_dtPreview.GetWeekDay();
           if (day < 1)
              { // The previous month has been selected
                nYear -= (nMonth==1)?1:0;
                nMonth -= (nMonth==1)?-11:1;
                m_dtPreview.SetDate(nYear,nMonth,1);
                day = m_dtPreview.GetMonthLastDay() + day;
              }
           else if (day > m_dtPreview.GetMonthLastDay())
              { // The next month has been selected
                nYear += (nMonth==12)?1:0;
                nMonth += (nMonth==12)?-11:1;
                day = day - m_dtPreview.GetMonthLastDay();
                m_dtPreview.SetDate(nYear,nMonth,1);
              }

           {
             m_pdtValue->SetDate(m_dtPreview.GetYear(), m_dtPreview.GetMonth(), day);
             m_pParent->m_wndEdt.SetWindowText(NULL);
             m_pParent->m_wndEdt.SetSel(0,-1);
           }

           // In case of click, just terminate the selector...
           m_pParent->PostNotifyMessage(CBN_SELCHANGE);
           ::ReleaseCapture();
           m_pParent->PostNotifyMessage(CBN_SELENDOK);
         }
    }

	CWnd::OnLButtonUp(nFlags, point);
}

void CComboDate::SCalendarWnd::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
    // A double-click react as a click
    OnLButtonDown( nFlags, point );
}

void CComboDate::SCalendarWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
    switch(nChar)
       {
         case VK_PRIOR: OnNavigatorClick(-1); break;
         case VK_NEXT:  OnNavigatorClick( 1); break;
       }
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CComboDate::SCalendarWnd::PickDate( UINT, CPoint )
{
  return;
}

/////////////////////////////////////////////////////////////////////////////
// CComboDate::SCalendarEdit

CComboDate::SCalendarEdit::SCalendarEdit( CComboDate* container )
{
  m_pParent = container;
  m_pdtValue = &container->m_dtValue;
}

CComboDate::SCalendarEdit::~SCalendarEdit()
{
}

BOOL CComboDate::SCalendarEdit::CheckChainedCtrl()
{
   if (*m_pdtValue == CDate::nullDate) return TRUE;

   // Check integrity on Successor/Predecessor chain
   if (m_pParent->m_ctrlPredecessor)
      {
        if (  CDate::nullDate != *(m_pParent->m_ctrlPredecessor)
            &&
              *m_pdtValue < *(m_pParent->m_ctrlPredecessor)
           )
           {
             MessageBeep(MB_ICONEXCLAMATION);
             SetSel(0,-1,TRUE);
             SetFocus();
             return FALSE;
           }
      }
   if (m_pParent->m_ctrlSuccessor)
      {
        if (  CDate::nullDate != *(m_pParent->m_ctrlSuccessor)
            &&
              *m_pdtValue > *(m_pParent->m_ctrlSuccessor)
           )
           {
             MessageBeep(MB_ICONEXCLAMATION);
             SetSel(0,-1,TRUE);
             SetFocus();
             return FALSE;
           }
      }
   return TRUE;
}

/* Message Map MACRO translation for sub-class fail
BEGIN_MESSAGE_MAP(CComboDate::SCalendarEdit, CEdit)
	//{{AFX_MSG_MAP(CComboDate::SCalendarEdit)
	ON_WM_KILLFOCUS()
    ON_MESSAGE(WM_SETTEXT,OnSetText)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
*/

///*
BEGIN_MESSAGE_MAP(CComboDate::SCalendarEdit, CWnd)
	{ WM_KILLFOCUS,       0, 0, 0, AfxSig_vW,    (AFX_PMSG)(AFX_PMSGW)(void (AFX_MSG_CALL CEdit::*)(CEdit*))&CComboDate::SCalendarEdit::OnKillFocus },
	{ WM_SETTEXT,         0, 0, 0, AfxSig_lwl,   (AFX_PMSG)(AFX_PMSGW)(LRESULT (AFX_MSG_CALL CEdit::*)(WPARAM, LPARAM))&CComboDate::SCalendarEdit::OnSetText },
END_MESSAGE_MAP()
//*/


/////////////////////////////////////////////////////////////////////////////
// CComboDate::SCalendarEdit message handlers

void CComboDate::SCalendarEdit::OnKillFocus(CWnd* pNewWnd) 
{

    {
      CString str; GetWindowText(str);
      if (!str.IsEmpty())
         {
           if (!m_pdtValue->ParseDate(str))
              {
                MessageBeep(MB_ICONEXCLAMATION);
                SetSel(0,-1,TRUE);
                SetFocus();
                return;
              }
         }
      else
         {
           *m_pdtValue = CDate::nullDate;
         }

      SetWindowText(NULL);
    }

    if (!CheckChainedCtrl()) return;
	CWnd::OnKillFocus(pNewWnd);
}

LRESULT CComboDate::SCalendarEdit::OnSetText( WPARAM wParam, LPARAM lParam)
{
  CString str;

  if (!lParam)
     { // This message is sent internaly, to inform the
       // SCalendarEdit control, that the m_dtUserEntry
       // have been changed and need to be reflected on
       // the EDIT control...
       CClientDC dc(this);
       CFont* pFont = GetFont();
       CFont* oldFont = (CFont*)dc.SelectObject(pFont);
       str = m_pdtValue->Format( this , CRect(0,0,0,0), &dc);
       dc.SelectObject(oldFont);
       lParam = (LPARAM)(LPCTSTR)str;

       if (!CheckChainedCtrl()) return FALSE;
     }

  return DefWindowProc(WM_SETTEXT, wParam, lParam);;
}

BOOL CComboDate::SCalendarEdit::PreTranslateMessage(MSG* pMsg) 
{
    if (pMsg->message == WM_KEYDOWN)
       {
         HWND hwnd = m_pParent->m_wndCal.GetSafeHwnd();
         switch(pMsg->wParam)
            {
              case VK_ESCAPE:
                   if (hwnd)
                      {
                        m_pParent->PostNotifyMessage(CBN_SELENDCANCEL);
                        ::ReleaseCapture();
                        return TRUE;
                      }
                   break;
              case VK_TAB:
                   {
                     ::ReleaseCapture();
                   }
                   break;
              case VK_RETURN:
                   {
                     if (hwnd) ::ReleaseCapture();
                     else break;
                   }
                   // Eat those KEY message
                   return TRUE;
                   break;
              case VK_PRIOR:
              case VK_NEXT:
                   { 
                     if (hwnd)
                        { // Re-route those two to the pseudo-list if any
                          pMsg->hwnd = hwnd;
                          ::TranslateMessage(pMsg);
                          ::DispatchMessage(pMsg);
                        }
                   }
                   // Whatever, eat those KEY message
                   return TRUE;
                   break;
              case VK_DOWN:
              case VK_UP:
                   {
                     *m_pdtValue += (pMsg->wParam == VK_UP)?-1:1;
                     SetWindowText(NULL);
                     SetSel(0,-1);
                     if (hwnd)
                        {
                          m_pParent->m_wndCal.m_dtPreview.SetDate(m_pdtValue->GetYear(), m_pdtValue->GetMonth(), 1);
                          m_pParent->m_wndCal.SendMessage(WM_NCPAINT);
                          m_pParent->m_wndCal.Invalidate();
                        }
                   }
                   // Eat those KEY message
                   return TRUE;
                   break;
            }
       }
    // Normal processing...
	return CEdit::PreTranslateMessage(pMsg);
}
