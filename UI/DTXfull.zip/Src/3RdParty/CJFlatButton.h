#ifndef __CJFLATBUTTON_H__
#define __CJFLATBUTTON_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// CCJFlatButton is a CButton derived class used to create flat buttons.
// this class can only be used with the BS_OWNERDRAW style bit set.
class CCJFlatButton : public CButton
{

public:
	
	// Default constructor
	//
	CCJFlatButton();

	// Virtual destructor
	//
	virtual ~CCJFlatButton();

protected:

	BOOL		m_bMouseOver;
	BOOL		m_bLBtnDown;	// true if left mouse button is pressed
	BOOL		m_bFlatLook;	// true for flat buttons see DisableFlatLook()
	CSize		m_sizeIcon;		// size of the icon if any associated with the button
	COLORREF	m_clrHilite;	// set to ::GetSysColor(COLOR_BTNHIGHLIGHT)
	COLORREF	m_clrShadow;	// set to ::GetSysColor(COLOR_BTNSHADOW)
	COLORREF	m_clrDkShad;	// set to ::GetSysColor(COLOR_3DDKSHADOW)
	COLORREF	m_clrNormal;	// set to ::GetSysColor(COLOR_BTNFACE)
	COLORREF	m_clrTextGy;	// set to ::GetSysColor(COLOR_GRAYTEXT)
	COLORREF	m_clrTextNm;	// set to ::GetSysColor(COLOR_BTNTEXT)
	COLORREF	m_clrAltNormal;	// user defined replacement for face color.
	COLORREF	m_clrAltHilite;	// user defined replacement for hilite color.
	COLORREF	m_clrAltShadow;	// user defined replacement for shadow color.
	COLORREF	m_clrAltTextNm; // user defined replacement for text color.
	BOOL		m_bAltColor;	// TRUE if user defined colors are used.
	BOOL		m_bPainted;		// used during paint operations
	HICON		m_hPushed;
	CFont*		m_pFont;
	CFont		m_Font;			// default font created by control if m_pFont is NULL
public:

	virtual void SetButtonFont(CFont* pFont);

	// this method will allow the user to define the default colors for the background
	// shadow and hilight colors for the button.
	//
	virtual void SetAlternateColors(COLORREF clrAltNormal, COLORREF clrAltHilite, COLORREF clrAltShadow, COLORREF clrAltTextNm);

	// this member function is used to disable or enable the flat
	// look for the button
	//
	virtual void DisableFlatLook(
		// set to true to disable the flat look.
		BOOL bDisable = FALSE);

	// this memeber function is used to associate an icon with the
	// flat button.
	//
	virtual void SetIcon(
		// handle to icon to be associated with button.
		HICON hIcon,
		// desired size of the icon, must be smaller than 
		// button size for best results.
		CSize size);

	// this memeber function is used to associate an icon with the
	// flat button.
	//
	virtual void SetIcon(
		// handle to icon to be associated with button.
		HICON hIcon,
		// handle of the pushed icon to be associated with button.
		HICON hPushed,
		// desired size of the icon, must be smaller than 
		// button size for best results.
		CSize size);

protected:

	// these memeber functions are called by the control during paint
	// operations.
	//
	virtual void DrawButtonIcon(CDC* pDC, UINT nState, CRect& rcItem);
	virtual void DrawButtonText(CDC* pDC, UINT nState, CRect& rcItem);
	virtual void DrawButtonBitmap(CDC* pDC, UINT nState, CRect& rcItem);

	// used by the control to initialize the default font.
	//
	virtual void UpdateFont();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCJFlatButton)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CCJFlatButton)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSysColorChange();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//	Inline Functions
/////////////////////////////////////////////////////////////////////////////

inline void CCJFlatButton::DisableFlatLook(BOOL bDisable)
	{ ASSERT(::IsWindow(m_hWnd)); m_bFlatLook = bDisable; Invalidate(); }

inline void CCJFlatButton::SetIcon(HICON hIcon, CSize size)
	{ ASSERT(::IsWindow(m_hWnd)); m_sizeIcon = size; CButton::SetIcon(hIcon); }

inline void CCJFlatButton::SetIcon(HICON hIcon, HICON hPushed, CSize size)
	{ ASSERT(::IsWindow(m_hWnd)); m_hPushed = hPushed; SetIcon(hIcon, size); }

inline void CCJFlatButton::SetButtonFont(CFont *pFont)
	{ ASSERT(::IsWindow(m_hWnd)); m_pFont = pFont; }

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __CJFLATBUTTON_H__
