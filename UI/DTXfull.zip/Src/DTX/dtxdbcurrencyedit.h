#if !defined(AFX_DTXDBCURRENCYEDIT_H__AA24F1A2_C584_4239_83BE_0E7E43678691__INCLUDED_)
#define AFX_DTXDBCURRENCYEDIT_H__AA24F1A2_C584_4239_83BE_0E7E43678691__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdbcurrencyedit.h : header file
//
#include "DTXDBNumericEdit.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXDBCurrencyEdit window

class CDTXDBCurrencyEdit : public CDTXDBNumericEdit
{
// Construction
public:
	CDTXDBCurrencyEdit();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBCurrencyEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBCurrencyEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBCurrencyEdit)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBCURRENCYEDIT_H__AA24F1A2_C584_4239_83BE_0E7E43678691__INCLUDED_)
