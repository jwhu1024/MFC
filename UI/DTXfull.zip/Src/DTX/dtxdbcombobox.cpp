// dtxdbcombobox.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdbcombobox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBComboBox

CDTXDBComboBox::CDTXDBComboBox()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBComboBox::~CDTXDBComboBox()
{
}

BEGIN_MESSAGE_MAP(CDTXDBComboBox, CDTXComboBox)
	//{{AFX_MSG_MAP(CDTXDBComboBox)
	ON_WM_SHOWWINDOW()
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBComboBox message handlers

void CDTXDBComboBox::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			if(nField->m_Type == dtxfInteger)
			{
				if(nField->intVal != GetCurSel())
				{
					CString nVal;
					nVal.Format(_T("%d"), GetCurSel());
					SetFieldValue(nVal);
				}
			}
			else
			{
				CString m_FieldText = DTXFieldToString(nField);
				CString m_WinText;
				GetWindowText(m_WinText);
				if(m_WinText != m_FieldText)
					SetFieldValue(m_WinText);
			}
		}
	}	
	CDTXComboBox::OnKillFocus(pNewWnd);
}

void CDTXDBComboBox::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
	CDTXComboBox::OnShowWindow(bShow, nStatus);
}

void CDTXDBComboBox::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			if(nField->m_Type == dtxfInteger)
			{
				SetCurSel(nField->intVal);
			}
			else
			{
				CString m_FieldText = DTXFieldToString(nField);
				CString m_WinText;
				GetWindowText(m_WinText);
				if(m_WinText != m_FieldText)
				{
					SetWindowText(m_FieldText);
					Invalidate();
				}
			}
			if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
		}
	}
}
