// dbcheckbox.cpp : implementation file
//

#include "stdafx.h"
#include "dbcheckbox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBCheckBox

CDBCheckBox::CDBCheckBox()
	: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBCheckBox::~CDBCheckBox()
{
}


BEGIN_MESSAGE_MAP(CDBCheckBox, CButton)
	//{{AFX_MSG_MAP(CDBCheckBox)
	ON_WM_KILLFOCUS()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBCheckBox message handlers

void CDBCheckBox::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			if(GetCheck() != nField->boolVal)
				SetCheck(nField->boolVal);
			if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
		}
	}
}

void CDBCheckBox::TableClosed()
{
	if(GetSafeHwnd())
	{
		SetCheck(0);
		EnableWindow(false);
	}
}

void CDBCheckBox::OnKillFocus(CWnd* pNewWnd) 
{
	DTXField* nField = GetField();
	if(nField && !nField->m_FieldName.IsEmpty())
	{
		if(GetCheck() != nField->boolVal)
			SetFieldValue(GetCheck() == 0 ? _T("FALSE") : _T("TRUE"));
	}
	CButton::OnKillFocus(pNewWnd);
}

void CDBCheckBox::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	DTXField* nField = GetField();
	if(nField && !nField->m_FieldName.IsEmpty())
	{
		if(GetCheck() != nField->boolVal)
			SetCheck(nField->boolVal);
	}
	CButton::OnShowWindow(bShow, nStatus);
}