#if !defined(AFX_DTXDAOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_)
#define AFX_DTXDAOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdaotable.h : header file
//

#ifndef __AFXDAO_H
#include <afxdao.h>
#endif

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDAOTable DAO recordset

class CDTXDAOTable : public CDTXTable, public CDaoRecordset
{
	CString m_DaoTableName;
	CString m_DaoSQL;
public:
	CDTXDAOTable(CWnd* nOwner, CString nDatabaseName, CDaoDatabase* pDatabase = NULL);
	CDTXDAOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName);
	~CDTXDAOTable();

	DECLARE_DYNAMIC(CDTXDAOTable)

	void SetSQL(CString nSQL)
	{ m_DaoSQL = nSQL; }

	void SetDAOTableName(CString nName)
	{ m_DaoTableName = nName; }
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDAOTable)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
	virtual void intGetCurrentRecord();
	virtual BOOL intOpen();
	virtual BOOL intClose();
	
	virtual void intGoFirst();
	virtual void intGoLast();
	virtual void intGoNext();
	virtual void intGoPrev();
	virtual void intGo(UINT nRec);

	virtual void intUpdateRecord();
	virtual void intInsertRecord();
	virtual void intDeleteRecord();

	virtual UINT intGetRecordCount();
	virtual UINT intGetRecordPos();

	virtual void ReadFieldArray();
	virtual BOOL intIsEOF()
	{ return CDaoRecordset::IsEOF(); }

	virtual BOOL intIsBOF()
	{ return CDaoRecordset::IsBOF(); }

	virtual BOOL TableOpened()
	{ return CDaoRecordset::IsOpen(); }
};

class CDAOTableCreator
{
	CDaoWorkspace m_WorkSpace;
	CDaoDatabase m_Database;
	CArray <CDaoIndexInfo, CDaoIndexInfo&> m_IndexArray;
	CArray <CDaoFieldInfo, CDaoFieldInfo&> m_FieldArray;
public:
	CDAOTableCreator();
	~CDAOTableCreator();

	void AddIndex(CString nName, BOOL nUnique = FALSE, BOOL nRequired = FALSE, BOOL nIgnoreNulls = FALSE);
	void AddIndex(CDaoIndexInfo nIndex);

	void AddField(LPCTSTR lpszName, short nType, long lSize, long lAttributes = 0);
	void AddField(CDaoFieldInfo nField);

	void CreateTable(LPCTSTR lpszName, long lAttributes = 0, LPCTSTR lpszSrcTable = NULL, LPCTSTR lpszConnect = NULL);
	void CreateTable(CString nTableName);
	void CreateDatabase(LPCTSTR lpszName, LPCTSTR lpszLocale = dbLangGeneral, int dwOptions = 0);
	void FreeFieldList();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDAOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_)
