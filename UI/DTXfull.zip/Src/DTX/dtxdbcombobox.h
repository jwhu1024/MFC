#if !defined(AFX_DTXDBCOMBOBOX_H__056C288B_DEEF_42CC_8E56_C7B1822EF732__INCLUDED_)
#define AFX_DTXDBCOMBOBOX_H__056C288B_DEEF_42CC_8E56_C7B1822EF732__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdbcombobox.h : header file
//

#include "DTXComboBox.h"

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBComboBox window

class CDTXDBComboBox : public CDTXComboBox, public CDTXEditBase
{
// Construction
public:
	CDTXDBComboBox();

// Attributes
public:
	virtual void TableDataChange();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBComboBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBComboBox)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBCOMBOBOX_H__056C288B_DEEF_42CC_8E56_C7B1822EF732__INCLUDED_)
