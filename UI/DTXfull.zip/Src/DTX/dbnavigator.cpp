// dbnavigator.cpp : implementation file
//

#include "stdafx.h"
#include "dtxlibrc.h"
#include "dbnavigator.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifndef WS_EX_LAYOUTRTL
#define WS_EX_LAYOUTRTL                    0x00400000L
#endif

#define ID_BTNFIRST         10099
#define ID_BTNPREV			(ID_BTNFIRST + 1)
#define ID_BTNNEXT			(ID_BTNFIRST + 2)
#define ID_BTNLAST			(ID_BTNFIRST + 3)
#define ID_BTNADD 			(ID_BTNFIRST + 4)
#define ID_BTNUPDATE		(ID_BTNFIRST + 5)
#define ID_BTNDELETE		(ID_BTNFIRST + 6)
#define ID_EDITGO			(ID_BTNFIRST + 7)
#define ID_TOTALSTATIC		(ID_BTNFIRST + 8)

#define BUTTONWIDTH			 25
#define BUTTONHEIGHT		 16
#define CONTROLCOUNT		  9
#define EDITWIDTH			 75
#define EDITHEIGHT			 16
#define STATICWIDTH			100

/////////////////////////////////////////////////////////////////////////////
// CDBNavigator

CDBNavigator::CDBNavigator()
: CDTXEditBase(NULL)
{
	m_ImageList.Create(IDB_NAVIGATOR, 16, 1, RGB(255,0,255));
	CDTXEditBase::SetOwner(this);
}

CDBNavigator::~CDBNavigator()
{
}


BEGIN_MESSAGE_MAP(CDBNavigator, CStatic)
	//{{AFX_MSG_MAP(CDBNavigator)
	ON_WM_CREATE()
	ON_BN_CLICKED(ID_BTNFIRST, OnFirst)
	ON_BN_CLICKED(ID_BTNPREV, OnPrev)
	ON_BN_CLICKED(ID_BTNNEXT, OnNext)
	ON_BN_CLICKED(ID_BTNLAST, OnLast)
	ON_BN_CLICKED(ID_BTNDELETE, OnDelete)
	ON_BN_CLICKED(ID_BTNUPDATE, OnUpdate)
	ON_BN_CLICKED(ID_BTNADD, OnAdd)
	ON_EN_KILLFOCUS(ID_EDITGO, OnGoKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDBNavigator message handlers

int CDBNavigator::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	lpCreateStruct->cx = (BUTTONWIDTH * (CONTROLCOUNT - 2)) + EDITWIDTH + STATICWIDTH;
	lpCreateStruct->cy = BUTTONHEIGHT;

	return CStatic::OnCreate(lpCreateStruct);
}

void CDBNavigator::PreSubclassWindow() 
{
	CStatic::PreSubclassWindow();
	CRect r;
	GetWindowRect(&r);

	
	::ScreenToClient(GetSafeHwnd(), (LPPOINT)&r);
	::ScreenToClient(GetSafeHwnd(), ((LPPOINT)&r)+1);
	if (GetExStyle() & WS_EX_LAYOUTRTL)
		CRect::SwapLeftRight(&r);
	
	r.top    += 1; 
	r.bottom -= 1;
	r.right  = BUTTONWIDTH;
	r.left   =  1;

	if(!m_First.Create(NULL, WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNFIRST))
		return;
	m_First.SetIcon(m_ImageList.ExtractIcon(0), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	if(!m_Prev.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNPREV))
		return;
	m_Prev.SetIcon(m_ImageList.ExtractIcon(1), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	if(!m_Add.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNADD))
		return;
	m_Add.SetIcon(m_ImageList.ExtractIcon(5), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	r.right = r.left + EDITWIDTH;
	CRect r2 = r;
	r2.top = (r.Height() - EDITHEIGHT) / 2 + 1;
	r2.bottom = r2.top + EDITHEIGHT + 1; // WS_BORDER
	if(!m_GotoEdit.Create(WS_CHILD|WS_VISIBLE|WS_BORDER|ES_RIGHT|ES_NUMBER, r2, this, ID_EDITGO))
		return;
	
	r.right = r.left + BUTTONWIDTH;
	r.OffsetRect(EDITWIDTH, 0);
	r.right = r.left + STATICWIDTH;
	if(!m_TotalRec.Create(NULL, WS_CHILD|WS_CHILD|WS_VISIBLE|SS_CENTERIMAGE, r, this, ID_TOTALSTATIC))
		return;
	
	r.left = r.right;
	r.right = r.left + BUTTONWIDTH;

	if(!m_Delete.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNDELETE))
		return;
	m_Delete.SetIcon(m_ImageList.ExtractIcon(4), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	if(!m_Update.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNUPDATE))
		return;
	m_Update.SetIcon(m_ImageList.ExtractIcon(6), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	if(!m_Next.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNNEXT))
		return;
	m_Next.SetIcon(m_ImageList.ExtractIcon(2), CSize(16, 16));

	r.OffsetRect(BUTTONWIDTH, 0);
	if(!m_Last.Create(NULL, WS_CHILD|WS_VISIBLE|BS_ICON|BS_OWNERDRAW|BS_CENTER|BS_VCENTER, r, this, ID_BTNLAST))
		return;
	m_Last.SetIcon(m_ImageList.ExtractIcon(3), CSize(16, 16));

	m_GotoEdit.SetFont(GetFont());
	m_TotalRec.SetFont(GetFont());

	TableClosed();
}

void CDBNavigator::DisableFlat(BOOL nDisable)
{
	m_First.DisableFlatLook(nDisable);
	m_Prev.DisableFlatLook(nDisable);
	m_Next.DisableFlatLook(nDisable);
	m_Last.DisableFlatLook(nDisable);
	m_Update.DisableFlatLook(nDisable);
	m_Add.DisableFlatLook(nDisable);
	m_Delete.DisableFlatLook(nDisable);
}

void CDBNavigator::EnableButtons(BOOL nEnable)
{
	m_First.EnableWindow(nEnable);
	m_Prev.EnableWindow(nEnable);
	m_Next.EnableWindow(nEnable);
	m_Last.EnableWindow(nEnable);
	m_Update.EnableWindow(nEnable);
	m_Delete.EnableWindow(nEnable);
	m_GotoEdit.EnableWindow(nEnable);
	if(m_OwnerTable && m_OwnerTable->TableOpened())
		m_Add.EnableWindow(true);
}

void CDBNavigator::TableDataChange()
{
	if(m_OwnerTable)
	{
		UINT nRecPos = m_OwnerTable->GetRecordPos();
		CString mPos;
		mPos.Format(_T("%d"), nRecPos + 1);
		m_GotoEdit.SetWindowText(mPos);

		UINT nRecCount = m_OwnerTable->GetRecordCount();
		CString mCount;
		mCount.Format(_T(" / %d"), nRecCount);
		m_TotalRec.SetWindowText(mCount);

		BOOL fEnable = nRecPos > 0;
		BOOL nEnable = nRecPos < nRecCount - 1;

		m_First.EnableWindow(fEnable);
		m_Prev.EnableWindow(fEnable);
		m_Next.EnableWindow(nEnable);
		m_Last.EnableWindow(nEnable);
		m_Add.EnableWindow(true);
	}
}

void CDBNavigator::TableClosed()
{
	if(GetSafeHwnd())
	{
		m_GotoEdit.SetWindowText(_T(""));
		m_TotalRec.SetWindowText(_T(""));
		EnableButtons(false);
		if (m_tooltip.GetSafeHwnd () == NULL)
			m_tooltip.Create (this);
		if (m_tooltip.GetSafeHwnd () != NULL)
			m_tooltip.Activate(false);
	}
}

void CDBNavigator::TableOpened()
{
	if(GetSafeHwnd())
	{
		EnableButtons(true);
		if (m_tooltip.GetSafeHwnd () != NULL)
			m_tooltip.Activate(true);
		TableDataChange();
	}
}

void CDBNavigator::OnFirst()
{
	if(m_OwnerTable)
		m_OwnerTable->GoFirst();
}

void CDBNavigator::OnPrev()
{
	if(m_OwnerTable)
		m_OwnerTable->GoPrev();
}

void CDBNavigator::OnNext()
{
	if(m_OwnerTable)
		m_OwnerTable->GoNext();
}

void CDBNavigator::OnLast()
{
	if(m_OwnerTable)
		m_OwnerTable->GoLast();
}

void CDBNavigator::OnDelete()
{
	if(m_OwnerTable)
		m_OwnerTable->DeleteRecord();
}

void CDBNavigator::OnUpdate()
{
	if(m_OwnerTable)
		m_OwnerTable->UpdateRecord();
}

void CDBNavigator::OnAdd()
{
	if(m_OwnerTable)
		m_OwnerTable->InsertRecord();
}

void CDBNavigator::CreateToolTip()
{
	if(!GetSafeHwnd()) return;

	if (m_tooltip.GetSafeHwnd () == NULL)
		m_tooltip.Create (this);
	if (m_tooltip.GetSafeHwnd () != NULL)
	{
		m_tooltip.AddTool(&m_First, IDS_FIRST); 
		m_tooltip.AddTool(&m_Prev, IDS_PREV);
		m_tooltip.AddTool(&m_Next, IDS_NEXT);
		m_tooltip.AddTool(&m_Last, IDS_LAST);
		m_tooltip.AddTool(&m_Update, IDS_UPDATE);
		m_tooltip.AddTool(&m_Add, IDS_ADD);
		m_tooltip.AddTool(&m_Delete, IDS_DELETE);
		m_tooltip.AddTool(&m_GotoEdit, IDS_GO);
	}
}

BOOL CDBNavigator::PreTranslateMessage(MSG* pMsg) 
{
	if (GetSafeHwnd() && m_tooltip.GetSafeHwnd() != NULL)
		m_tooltip.RelayEvent(pMsg);
	
	if (pMsg->message == WM_KEYDOWN && 
		pMsg->wParam == VK_RETURN && 
		m_GotoEdit.GetSafeHwnd() && 
		pMsg->hwnd == m_GotoEdit.GetSafeHwnd())
	{
			OnGoKillfocus();
			pMsg->wParam = 0;
	}
	return CStatic::PreTranslateMessage(pMsg);
}

void CDBNavigator::OnGoKillfocus()
{
	if(m_OwnerTable)
	{
		UINT nRecPos = GetDlgItemInt(ID_EDITGO) - 1;
		if (nRecPos <= m_OwnerTable->GetRecordCount()&&
			nRecPos != m_OwnerTable->GetRecordPos())
				m_OwnerTable->Go(nRecPos);
	}
}
