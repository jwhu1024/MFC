// dbimage.cpp : implementation file
//

#include "stdafx.h"
#include "dbimage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBImage

CDBImage::CDBImage()
	: CDTXEditBase(NULL)
{
	m_AutoSize = false;
	m_MenuID = 0;
	CDTXEditBase::SetOwner(this);
}

CDBImage::~CDBImage()
{
	m_Image.DeleteObject();
}


void CDBImage::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			ReadFromBLOB();
		}
	}	
}

BEGIN_MESSAGE_MAP(CDBImage, CWnd)
	//{{AFX_MSG_MAP(CDBImage)
	ON_WM_PAINT()
	ON_WM_RBUTTONDOWN()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDBImage message handlers

BOOL CDBImage::LoadBitmap(UINT nResID)
{
	BOOL nRes = m_Image.LoadBitmap(nResID);
	GetSizes();
	return nRes;
}

BOOL CDBImage::LoadBitmap(CString nFile)
{
	TRY
	{
		LoadPictureFile(nFile, &m_Image);
		GetSizes();
		if(IsWindowEnabled()) Invalidate();

		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CFile		fileImage;
			CFileStatus	fileStatus;

			fileImage.Open(nFile, CFile::modeRead);
			fileImage.GetStatus(fileStatus);
        
			nField->blobVal->m_dwDataLength = fileStatus.m_size;
		    nField->blobVal->m_hData = new char[nField->blobVal->m_dwDataLength];
		    fileImage.ReadHuge(nField->blobVal->m_hData, fileStatus.m_size);
			if(m_OwnerTable)
				m_OwnerTable->SetModified(true);
		}
	}
	CATCH(CException, e)
	{
		return false;
	}
	END_CATCH
	return true;
}

void CDBImage::GetSizes()
{
	BITMAP bm;
	GetObject(m_Image.m_hObject, sizeof(bm), &bm);
	m_ImageSize.cx = bm.bmWidth; //nWidth;
	m_ImageSize.cy = bm.bmHeight; //nHeight;
}

void CDBImage::OnPaint() 
{
	CRect r;
	GetClientRect(&r);
	
	CPaintDC dc(this);
	int w = m_ImageSize.cx, h = m_ImageSize.cy;
	if(w > 0 && h > 0)
	{
		r.DeflateRect(5, 5);
		int x = 5, y = 5;
		if(!m_AutoSize)
		{
			CSize sizeScaled = Scale(CSize(m_ImageSize.cx, m_ImageSize.cy), r.Size());
			w = sizeScaled.cx;
			h = sizeScaled.cy;
		}
		else
		{
			w = r.Width()  - 2;
			h = r.Height() - 2;
		}

		CPoint pt = r.TopLeft();
		x = ((r.Width() - w) / 2) + pt.x ;
	    y = ((r.Height() - h) / 2) + pt.y;
		
		CDC memdc;
		memdc.CreateCompatibleDC(&dc);
		memdc.SelectObject(m_Image);

		if(m_AutoSize)
			dc.BitBlt(x, y, w, h, &memdc, 0, 0, SRCCOPY);
		else
			dc.StretchBlt(x, y, w, h, &memdc, 0, 0, m_ImageSize.cx, m_ImageSize.cy, SRCCOPY);
	}
	else
	{
		UpdateWindow();
	}
}

BOOL CDBImage::ReadFromBLOB()
{
	m_Image.DeleteObject();
	DTXField* nField = GetField();
	if(!nField->blobVal->m_hData || nField->blobVal->m_dwDataLength == 0) 
	{
		Empty();
		GetSizes();
		return false;
	}
	int BufLen = nField->blobVal->m_dwDataLength;
	LPPICTURE gpPicture;
	HANDLE hMem = GlobalAlloc(GMEM_MOVEABLE, BufLen);
	_ASSERTE(NULL != hMem);
	if (hMem) 
	{
		LPVOID lpMem = GlobalLock(hMem);
		_ASSERTE(NULL != lpMem);
		if (lpMem) 
		{
			memcpy(lpMem, nField->blobVal->m_hData, BufLen);
			GlobalUnlock(hMem);
			// Create an IStream from the data.
			LPSTREAM pstm = NULL;
			if (CreateStreamOnHGlobal(hMem, TRUE, &pstm) == S_OK) 
			{
				if(::OleLoadPicture(pstm, BufLen, FALSE, IID_IPicture, (LPVOID *)&gpPicture) == S_OK)
				{
					pstm->Release();
					OLE_HANDLE m_picHandle;
					gpPicture->get_Handle(&m_picHandle);
					m_Image.Attach((HGDIOBJ) m_picHandle);
					GetSizes();
					Invalidate();
				}
			}
		}
	}
	return TRUE;
}

void CDBImage::SetMenuID(UINT mMenuID)
{
	m_MenuID = mMenuID;
}

void CDBImage::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (m_MenuID > 0)
	{
		CMenu popMenu;

		popMenu.LoadMenu(m_MenuID);
	
		CPoint posMouse;
		GetCursorPos(&posMouse);

		popMenu.GetSubMenu(0)->TrackPopupMenu(0, posMouse.x, posMouse.y, GetParent());
	} 
	CWnd::OnRButtonDown(nFlags, point);
}

BOOL CDBImage::OnEraseBkgnd(CDC* pDC) 
{
	ASSERT_VALID(pDC);
	CRect rect;
	GetClientRect(&rect);

	pDC->FillRect(&rect, NULL);
	ReleaseDC(pDC);
	return false;
}

void CDBImage::Empty()
{
	CRect r;
	GetClientRect(&r);
	m_Image.CreateBitmap(r.Width() - 5, r.Height() - 5, 1, 16, NULL);
	CDC* pDC = GetDC();
	pDC->SelectObject(&m_Image);
	pDC->FillRect(&r, NULL);
	ReleaseDC(pDC);
	GetSizes();
}