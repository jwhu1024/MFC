// dbcurrencyedit.cpp : implementation file
//

#include "stdafx.h"
#include "dbcurrencyedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBCurrencyEdit

CDBCurrencyEdit::CDBCurrencyEdit()
{
	char m_CurStr[32];
	int nLength= ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SCURRENCY, m_CurStr, 0);
    if(nLength)
    {
        ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_SCURRENCY, m_CurStr, nLength);
		m_Suffix.Format(_T(" %s"), m_CurStr);
    }

	nLength= ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_ICURRDIGITS, m_CurStr, 0);
    if(nLength)
    {
        ::GetLocaleInfo(LOCALE_USER_DEFAULT, LOCALE_ICURRDIGITS, m_CurStr, nLength);
		m_NumDecimalPlaces = atoi(m_CurStr);
    }
	m_InsertCommas = true;
}

CDBCurrencyEdit::~CDBCurrencyEdit()
{
}


BEGIN_MESSAGE_MAP(CDBCurrencyEdit, CDBNumericEdit)
	//{{AFX_MSG_MAP(CDBCurrencyEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBCurrencyEdit message handlers
