#if !defined(AFX_DTXDBNUMERICEDIT_H__CB114753_1118_4338_9C5F_81A4562137BD__INCLUDED_)
#define AFX_DTXDBNUMERICEDIT_H__CB114753_1118_4338_9C5F_81A4562137BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdbnumericedit.h : header file
//

#include "DTXBase.h"
#include "DBNumericEdit.h"

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBNumericEdit window

class CDTXDBNumericEdit : public CDBNumericEdit, public CDTXWndBase
{
// Construction
public:
	CDTXDBNumericEdit();

// Attributes
public:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBNumericEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBNumericEdit();

	// Generated message map functions
protected:
	virtual void DrawBorder(bool fHot = true);
	//{{AFX_MSG(CDTXDBNumericEdit)
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBNUMERICEDIT_H__CB114753_1118_4338_9C5F_81A4562137BD__INCLUDED_)
