#if !defined(AFX_DBCHECKBOX_H__CADADFC6_C964_4E09_9111_8A209D238E49__INCLUDED_)
#define AFX_DBCHECKBOX_H__CADADFC6_C964_4E09_9111_8A209D238E49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbcheckbox.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBCheckBox window

class CDBCheckBox : public CButton, public CDTXEditBase
{
// Construction
public:
	CDBCheckBox();

	virtual void TableDataChange();
	virtual void TableClosed();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBCheckBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBCheckBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBCheckBox)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBCHECKBOX_H__CADADFC6_C964_4E09_9111_8A209D238E49__INCLUDED_)
