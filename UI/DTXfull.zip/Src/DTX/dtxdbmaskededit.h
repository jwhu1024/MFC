#if !defined(AFX_DTXDBMASKEDEDIT_H__E070B3BA_8EFA_4144_8FC5_D87BF2801617__INCLUDED_)
#define AFX_DTXDBMASKEDEDIT_H__E070B3BA_8EFA_4144_8FC5_D87BF2801617__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdbmaskededit.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

#include "dtxmaskededit.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXDBMaskedEdit window

class CDTXDBMaskedEdit : public CDTXMaskedEdit, public CDTXEditBase
{
// Construction
public:
	CDTXDBMaskedEdit();

// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBMaskedEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBMaskedEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBMaskedEdit)
		afx_msg void OnKillFocus(CWnd* pNewWnd);
		afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBMASKEDEDIT_H__E070B3BA_8EFA_4144_8FC5_D87BF2801617__INCLUDED_)
