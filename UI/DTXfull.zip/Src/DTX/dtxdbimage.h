#if !defined(AFX_DTXDBIMAGE_H__636C1327_D202_44D7_8397_49C128373D88__INCLUDED_)
#define AFX_DTXDBIMAGE_H__636C1327_D202_44D7_8397_49C128373D88__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdbimage.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif
#include "dtximage.h"

/////////////////////////////////////////////////////////////////////////////
// CDTXDBImage window

class CDTXDBImage : public CDTXImage, public CDTXEditBase
{
// Construction
public:
	CDTXDBImage();

// Attributes
public:
	virtual void TableDataChange();
// Operations
public:
	BOOL LoadBitmap(CString nFile);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBImage)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBImage();

	// Generated message map functions
protected:
	BOOL ReadFromBLOB();
	//{{AFX_MSG(CDTXDBImage)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBIMAGE_H__636C1327_D202_44D7_8397_49C128373D88__INCLUDED_)
