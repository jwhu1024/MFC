#if !defined(AFX_DBDATECTRL_H__F0A8FB58_95A4_4EEB_852A_BE196AF0E7DA__INCLUDED_)
#define AFX_DBDATECTRL_H__F0A8FB58_95A4_4EEB_852A_BE196AF0E7DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbdatectrl.h : header file
//
 
#include "datectrl.h"
#include <dtx.h>

/////////////////////////////////////////////////////////////////////////////
// CDBListBoxDate window

class CDBListBoxDate : public CWnd, public CDTXEditBase
{
// Construction
public:
	CDBListBoxDate();

// Attributes
public:
	virtual void TableDataChange();
	virtual void TableClosed();
	virtual void TableOpened();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBListBoxDate)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBListBoxDate();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBListBoxDate)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnDateKillFocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	
	CListboxDate m_Ctrl;
};


class CDTXDBListBoxDate : public CDBListBoxDate, public CDTXWndBase
{
public:
	CDTXDBListBoxDate();
protected:
	//{{AFX_MSG(CDBListBoxDate)
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void DrawBorder(bool fHot = TRUE);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBDATECTRL_H__F0A8FB58_95A4_4EEB_852A_BE196AF0E7DA__INCLUDED_)
