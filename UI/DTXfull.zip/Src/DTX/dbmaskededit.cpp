// dbmaskededit.cpp : implementation file
//

#include "stdafx.h"
#include "dbmaskededit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBMaskedEdit

CDBMaskedEdit::CDBMaskedEdit()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBMaskedEdit::~CDBMaskedEdit()
{
}


BEGIN_MESSAGE_MAP(CDBMaskedEdit, COXMaskedEdit)
	//{{AFX_MSG_MAP(CDBMaskedEdit)
	ON_WM_KILLFOCUS()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBMaskedEdit message handlers

void CDBMaskedEdit::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}	
	COXMaskedEdit::OnKillFocus(pNewWnd);
}

void CDBMaskedEdit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	COXMaskedEdit::OnShowWindow(bShow, nStatus);
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
}
