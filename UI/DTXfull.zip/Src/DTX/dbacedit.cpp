// dbacedit.cpp : implementation file
//

#include "stdafx.h"
#include "dbacedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBACEdit

CDTXDBACEdit::CDTXDBACEdit()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBACEdit::~CDTXDBACEdit()
{
}


BEGIN_MESSAGE_MAP(CDTXDBACEdit, CACEditCtrl)
	//{{AFX_MSG_MAP(CDTXDBACEdit)
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBACEdit message handlers

void CDTXDBACEdit::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				SetFieldValue(m_WinText);
				Invalidate();
			}
			if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
		}
	}
	CACEditCtrl::OnKillFocus(pNewWnd);
}
