// dbdatectrl.cpp : implementation file
//

#include "stdafx.h"
#include "dbdatectrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBListBoxDate

CDBListBoxDate::CDBListBoxDate()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBListBoxDate::~CDBListBoxDate()
{
}

BEGIN_MESSAGE_MAP(CDBListBoxDate, CWnd)
	//{{AFX_MSG_MAP(CDBListBoxDate)
	ON_WM_SHOWWINDOW()
	ON_LBN_KILLFOCUS(1, OnDateKillFocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBListBoxDate message handlers

void CDBListBoxDate::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty() && nField->date)
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_FieldText != m_WinText)
			{
				CDate d;
				d.SetDate(nField->date->GetYear(), nField->date->GetMonth(), nField->date->GetDay());
				m_Ctrl = d;
			}
		}
	}
}

void CDBListBoxDate::TableClosed()
{
	m_Ctrl.EnableWindow(false);
}

void CDBListBoxDate::TableOpened()
{
	if(m_Ctrl.GetSafeHwnd() && m_OwnerTable)
	{
		m_Ctrl.EnableWindow();
		TableDataChange();		
	}
}

void CDBListBoxDate::PreSubclassWindow()
{
	CWnd::PreSubclassWindow();
	CRect r;
	GetClientRect(&r);

	r.DeflateRect(1, 1);
	m_Ctrl.Create(GetStyle()|WS_CHILD, r, this, 1); 
	m_Ctrl.SetFont(GetFont());
	m_Ctrl.EnableWindow(false);
	ModifyStyle(WS_TABSTOP, 0);
}

void CDBListBoxDate::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	TableDataChange();
	CWnd::OnShowWindow(bShow, nStatus);
}

BOOL CDBListBoxDate::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL nRes = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	CRect r(rect);
	r.DeflateRect(1, 1);
	if(nRes)
		if (nRes = m_Ctrl.Create(dwStyle, r, this, 1))
			m_Ctrl.SetFont(GetFont()); 
	ModifyStyle(WS_TABSTOP, 0);
	return nRes;
}

void CDBListBoxDate::OnDateKillFocus() 
{
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CDate d = m_Ctrl.GetShiftAnchor();
			SetFieldValue(d.Format(DATE_SHORTDATE));
		}
	}
}

BEGIN_MESSAGE_MAP(CDTXDBListBoxDate, CDBListBoxDate)
	//{{AFX_MSG_MAP(CDTXDBListBoxDate)
	ON_WM_PAINT()
	ON_LBN_KILLFOCUS(1, OnDateKillFocus)
	ON_LBN_SETFOCUS (1, OnDateKillFocus)
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CDTXDBListBoxDate::CDTXDBListBoxDate()
{
	m_UseControlColors = true;
	m_GotFocus =  m_TimerSet = false;
	m_GotFocus = m_DrawShadow = true;
	m_ShadowSize = 8;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor = m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = m_TextColor  = RGB(0, 0, 0);
}

void CDTXDBListBoxDate::OnPaint()
{
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
	if(IsWindow(m_Ctrl.GetSafeHwnd()))
		m_Ctrl.UpdateWindow();
}

void CDTXDBListBoxDate::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this, true);
}

void CDTXDBListBoxDate::OnSetFocus(CWnd* pOldWnd)
{
	CWnd::OnSetFocus(pOldWnd);
	m_GotFocus = true;
	Invalidate();
}

void CDTXDBListBoxDate::OnMouseMove(UINT nFlags, CPoint point)
{
	if (!m_GotFocus) 
	{
		if (!m_TimerSet) 
		{
			DrawBorder();
			SetTimer(1, 10, NULL);
			m_TimerSet = true;
		}
	}

	CWnd::OnMouseMove(nFlags, point);
}

void CDTXDBListBoxDate::OnTimer(UINT nIDEvent)
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) 
	{
		KillTimer(1);
		m_TimerSet = false;
		if (!m_GotFocus) 
			DrawBorder(false);
		else
			DrawBorder();
		return;
	}
	CWnd::OnTimer(nIDEvent);
}

HBRUSH CDTXDBListBoxDate::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	DWORD	dwStyle = GetStyle();

	if(pWnd->GetDlgCtrlID() == 1 &&
		m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		pDC->SetTextColor(m_FocusTextColor);
		pDC->SetBkColor(m_FocusColor);
		m_BackBrush.CreateSolidBrush(m_FocusColor);
		pDC->SelectObject(GetFont());
		return((HBRUSH) m_BackBrush);
	}
	return(CWnd::OnCtlColor(pDC, pWnd, nCtlColor));
}
