#if !defined(AFX_DTXADOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_)
#define AFX_DTXADOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdaotable.h : header file
//

#include "ado.h"

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include <DTXTable.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXADOTable recordset

class CDTXADOTable : public CDTXTable, public CADORecordset
{
	BOOL m_haveADODatabase;
	CString m_ConnectString;
	CString m_ADOTableName;
	CString m_ADOSQL;
	int m_fldCount;
public:
	CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CADODatabase* pDatabase = NULL);
	CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName);
	~CDTXADOTable();
public:
	void SetSQL(CString nSQL)
	{ m_ADOSQL = nSQL; }
	CString GetSQL()
	{ return m_ADOSQL; }

	void SetADOTableName(CString nName)
	{ 
		m_ADOTableName = nName; 
		CreateConnectString();
	}

	CString GetADOTableName()
	{ return m_ADOTableName; }

	int GetFieldCount()
	{ return m_fldCount; }
protected:
	void CreateConnectString();
	virtual BOOL intOpen();
	virtual BOOL intClose();

	virtual void ReadFieldArray();
	virtual void intUpdateRecord();
	virtual void intInsertRecord();
	virtual void intDeleteRecord();
	virtual void intGetCurrentRecord();

	virtual void intGoFirst();
	virtual void intGoLast();
	virtual void intGoNext();
	virtual void intGoPrev();
	virtual void intGo(UINT nRec);

	virtual UINT intGetRecordCount();
	virtual UINT intGetRecordPos();

	virtual BOOL intIsEOF()
	{ return CADORecordset::IsEOF(); }

	virtual BOOL intIsBOF()
	{ return CADORecordset::IsBOF(); }

	virtual BOOL TableOpened()
	{ return CADORecordset::IsOpen(); }

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDAOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_)
