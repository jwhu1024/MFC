#if !defined(AFX_DBCALCULATORCOMBO_H__C4B7E5F1_C31A_487D_B14B_F8288585043A__INCLUDED_)
#define AFX_DBCALCULATORCOMBO_H__C4B7E5F1_C31A_487D_B14B_F8288585043A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbcalculatorcombo.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

#include "CalculatorWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CDBCalculatorCombo window

class CDBCalculatorCombo : public CCalculatorCombo, public CDTXEditBase
{
// Construction
public:
	CDBCalculatorCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBCalculatorCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBCalculatorCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBCalculatorCombo)
	afx_msg void OnKillfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CDTXDBCalculatorCombo window

class CDTXDBCalculatorCombo : public CDTXCalculatorCombo, public CDTXEditBase
{
// Construction
public:
	CDTXDBCalculatorCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBCalculatorCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBCalculatorCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBCalculatorCombo)
	afx_msg void OnKillfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBCALCULATORCOMBO_H__C4B7E5F1_C31A_487D_B14B_F8288585043A__INCLUDED_)
