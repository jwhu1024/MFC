// dbgridctrl.cpp : implementation file
//

#include "stdafx.h"
#include "dbgridctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBGridCtrl

CDBGridCtrl::CDBGridCtrl()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
	m_FrDTXDBGridCtrl = false;
}

CDBGridCtrl::~CDBGridCtrl()
{
	for(int c = 0; c < m_Cols.GetSize(); c++)
	{
		DBColumn *nColumn = m_Cols.GetAt(c);
		if(nColumn)
		{
			delete nColumn;
		}
	}
	m_Cols.RemoveAll();
}


BEGIN_MESSAGE_MAP(CDBGridCtrl, CALXGridCtrl)
	//{{AFX_MSG_MAP(CDBGridCtrl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDBGridCtrl message handlers
void CDBGridCtrl::AddColumn(DBColumn* nColumn)
{
	m_Cols.AddColumn(nColumn);
}

void CDBGridCtrl::CreateCols()
{
	for(int c = 0; c < m_Cols.GetSize(); c++)
	{
		DBColumn *nColumn = m_Cols.GetAt(c);
		if(nColumn)
		{
			int colAlign;
			switch(nColumn->m_Align)
			{
				case dbcLeft  : colAlign = ACFF_LEFT; break;

				case dbcCenter: colAlign = ACFF_CENTER; break;

				case dbcRight : colAlign = ACFF_RIGHT; break;

			}
			DefineColCtrl(AddCol(nColumn->m_ColWidth, nColumn->m_Header, colAlign, AHFF_CENTER, 0, 0), 
				GA_EDITCTRL, WS_CHILD | ES_LEFT);
		}
	}
}

void CDBGridCtrl::TableDataChange()
{
	if(GetSafeHwnd() && m_OwnerTable && !m_FrDTXDBGridCtrl)
	{
		UINT nRowCnt = GetGridRowCount();
		UINT nRecCnt = m_OwnerTable->GetRecordCount();
		if(nRowCnt != nRecCnt)
		{
			SetGridRowCount(nRecCnt);
			Invalidate();
		}

		BOOL needUpdate = FALSE;
		for(int c = 0; c < m_Cols.GetSize(); c++)
		{
			CString nFld = m_Cols[c]->m_FieldName;
			DTXField* pField = m_OwnerTable->GetField(nFld);
			if(pField) 
			{
				CALXCellCtrl* pCellCtrl = GetCellCtrl(c, GetActiveRow());
				if(pCellCtrl != NULL)
				{
					CELL_DATA Data = pCellCtrl->GetCellData();
					CString nFieldText = DTXFieldToString(pField);
					if(Data.m_strText != nFieldText)
					{
						Data.m_strText = nFieldText;
						pCellCtrl->SetData(Data);
						needUpdate = TRUE;
					}
				}
			}
		}

		if(needUpdate)
		{
			CDC* pDC = m_pGridWnd->GetDC();
			UpdateRow(pDC, GetActiveRow());
			m_pGridWnd->ReleaseDC(pDC);
		}

		UINT nPos = m_OwnerTable->GetRecordPos();
		UINT nRow = GetActiveRow();
		if(nPos != nRow)
			SetActiveRow(nPos);
	}
}

void CDBGridCtrl::TableClosed()
{
	if(GetSafeHwnd() && m_OwnerTable)
	{
		SetGridRowCount(0);
		EnableWindow(FALSE);
	}
}

void CDBGridCtrl::TableOpened()
{
	if(GetSafeHwnd() && m_OwnerTable)
	{
		EnableWindow();
		TableDataChange();		
	}
}

CELL_DATA CDBGridCtrl::GetCellData(int nCol, int nRow)
{
	CELL_DATA CellData = CALXGrid::GetCellData(nCol,nRow);
	
	if(m_OwnerTable)
	{
		m_FrDTXDBGridCtrl = true;
		UINT m_CurRec = m_OwnerTable->GetRecordPos();
		m_OwnerTable->DisableControls();
		m_OwnerTable->Go(nRow);
		CString nFld = m_Cols[nCol]->m_FieldName;
		DTXField* pField = m_OwnerTable->GetField(nFld);
		if(pField) 
			CellData.m_strText = DTXFieldToString(pField);
		m_OwnerTable->Go(m_CurRec);
		m_OwnerTable->EnableControls(true);
		m_FrDTXDBGridCtrl = false;

	}
	return CellData;
}

BOOL CDBGridCtrl::OnSaveCellData(int nCol, int nRow)
{
	if(m_OwnerTable)
	{
		CString nFld = m_Cols[nCol]->m_FieldName;
		DTXField* pField = m_OwnerTable->GetField(nFld);
		if(pField) 
		{
			CALXCellCtrl* pCellCtrl = GetCellCtrl(nCol,nRow);
			if(pCellCtrl != NULL)
			{
				CELL_DATA Data = pCellCtrl->GetCellData();
				CDTXEditBase::SetEditField(nFld);
				CDTXEditBase::SetFieldValue(Data.m_strText);
			}
		}
		return true;
	}
	return false;
}

void CDBGridCtrl::OnSetActiveCell(int nCol, int nRow)
{
	if(m_OwnerTable && m_OwnerTable->TableOpened())
	{
		UINT nPos = m_OwnerTable->GetRecordPos();
		UINT nRow = GetActiveRow();
		if(nPos != nRow)
			m_OwnerTable->Go(nRow);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDBGridCtrl

BEGIN_MESSAGE_MAP(CDTXDBGridCtrl, CDBGridCtrl)
	//{{AFX_MSG_MAP(CDTXDBGridCtrl)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CDTXDBGridCtrl::OnPaint()
{
	CDBGridCtrl::OnPaint();
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

BOOL CDTXDBGridCtrl::OnEraseBkgnd(CDC* pDC)
{
	BOOL nRes = CALXGridCtrl::OnEraseBkgnd(pDC);
	if(IsWindow(GetSafeHwnd()))
		CDBGridCtrl::PostMessage(WM_ERASEBKGND);
	return nRes;
}

void CDTXDBGridCtrl::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}