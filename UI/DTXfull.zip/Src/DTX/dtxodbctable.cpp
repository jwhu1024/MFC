// dtxodbctable.cpp : implementation file
//

#include "stdafx.h"
#include "dtxodbctable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXODBCTable

IMPLEMENT_DYNAMIC(CDTXODBCTable, CRecordset)

CDTXODBCTable::CDTXODBCTable(CWnd* nOwner, CString nDatabaseName, CString nTableName) :
    CDTXTable(nOwner, nDatabaseName),
	CRecordset(NULL)
{
	m_ODBCTableName = nTableName;
	m_nDefaultType = dynaset; //snapshot;
	m_nFields = 255;
	m_SQLStr.Format(_T("Select * from %s"), m_ODBCTableName);
}

CDTXODBCTable::CDTXODBCTable(CWnd* nOwner, CDatabase* pDB, CString nTableName) :
    CDTXTable(nOwner, _T("")),
	CRecordset(pDB)
{
	m_ODBCTableName = nTableName;
	m_nDefaultType = dynaset; //snapshot;
	m_nFields = 255;
	m_SQLStr.Format(_T("Select * from %s"), m_ODBCTableName);

}

void CDTXODBCTable::SetODBCTableName(CString nName)
{
	m_ODBCTableName = nName;
	m_SQLStr.Format(_T("Select * from %s"), m_ODBCTableName);
}

CDTXODBCTable::~CDTXODBCTable()
{
	if(CRecordset::IsOpen())
		CRecordset::Close();
}

CString CDTXODBCTable::GetDefaultConnect()
{
	CString nName, nFName, nPath = CDTXTable::GetTableName();
	
	int i = nPath.ReverseFind(_T('\\'));
	if(i > 0)
	{
		nFName = nPath.Right(nPath.GetLength() - i - 1);
		nPath.Delete(i, nPath.GetLength() - i);
	}
	else
	{
		nFName = CDTXTable::GetTableName();
		nPath.Empty();
	}
	
	if(!nPath.IsEmpty())
		nName.Format(_T("ODBC;DRIVER={Microsoft Access Driver (*.mdb)};DEFAULTDIR=%s;DBQ=%s"), 
			nPath, nFName);
	else
		nName.Format(_T("ODBC;DRIVER={Microsoft Access Driver (*.mdb)};DBQ=%s"), nFName);
	return nName;
}

CString CDTXODBCTable::GetDefaultSQL()
{
	return m_SQLStr;
}

/////////////////////////////////////////////////////////////////////////////
// CDTXODBCTable diagnostics

#ifdef _DEBUG
void CDTXODBCTable::AssertValid() const
{
	CRecordset::AssertValid();
}

void CDTXODBCTable::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG


BOOL CDTXODBCTable::TableOpened()
{
	return CRecordset::IsOpen();
}

void CDTXODBCTable::intGetCurrentRecord()
{
}

BOOL CDTXODBCTable::intOpen()
{
	return CRecordset::Open(AFX_DB_USE_DEFAULT_TYPE, m_SQLStr, 
		m_dwOptions + CRecordset::useBookmarks + CRecordset::skipDeletedRecords);
}

BOOL CDTXODBCTable::intClose()
{
	CRecordset::Close();
	return true;
}

void CDTXODBCTable::intGoFirst()
{
	CRecordset::MoveFirst();
}

void CDTXODBCTable::intGoLast()
{
	CRecordset::MoveLast();
}

void CDTXODBCTable::intGoNext()
{
	CRecordset::MoveNext();
}

void CDTXODBCTable::intGoPrev()
{
	CRecordset::MovePrev();
}

void CDTXODBCTable::intGo(UINT nRec)
{
	CRecordset::SetAbsolutePosition(nRec + 1);
}

UINT CDTXODBCTable::intGetRecordCount()
{
	UINT nRecPos = intGetRecordPos();
	MoveLast();
	CDBVariant v;
	v.m_dwType = DBVT_LONG;
	v.m_lVal = 0;
	CRecordset::GetBookmark(v);
//	intGo(nRecPos);
	return v.m_lVal;
}

UINT CDTXODBCTable::intGetRecordPos()
{
	CDBVariant v;
	v.m_dwType = DBVT_LONG;
	v.m_lVal = 0;
	CRecordset::GetBookmark(v);
	return v.m_lVal;
}

void CDTXODBCTable::intUpdateRecord()
{
	Edit();
	SetFieldDirty(NULL);
	if(CanUpdate())
		Update();
}

void CDTXODBCTable::intInsertRecord()
{
	if(CanUpdate())
	{
		CRecordset::AddNew();
		CRecordset::Update();
	}
}

void CDTXODBCTable::intDeleteRecord()
{
	CRecordset::Delete();
}

void CDTXODBCTable::ReadFieldArray()
{
	if(m_FieldArray.GetSize() > 0) return;
	m_FieldArray.FreeAll();
	int strt = 0;
	for(int i = 0; i < GetODBCFieldCount(); i++)
	{
		CODBCFieldInfo dfi;
		DTXFieldType dtxf;
		GetODBCFieldInfo(i, dfi);
		switch(dfi.m_nSQLType)
		{
			case SQL_BIT     : dtxf = dtxfBool; break;

			case SQL_TINYINT : 
			case SQL_SMALLINT: 

			case SQL_DECIMAL :
			case SQL_INTEGER : dtxf = dtxfInteger; break;

			case SQL_NUMERIC :
			case SQL_BIGINT  : dtxf = dtxfCurrency; break;

			case SQL_REAL    :
			case SQL_FLOAT   : dtxf = dtxfFloat; break;
			case SQL_DOUBLE  : dtxf = dtxfFloat; break;

			case SQL_DATE	 : dtxf = dtxfDate; break;
			
			case SQL_TIME	 : dtxf = dtxfTime; break;

			case SQL_TIMESTAMP: dtxf = dtxfDateTime; break;

			case SQL_CHAR	 :
			case SQL_VARCHAR : dtxf = dtxfString; break;

			case SQL_LONGVARCHAR:
			case SQL_BINARY:
			case SQL_VARBINARY:
			case SQL_LONGVARBINARY:  dtxf = dtxfBlob; break;

			default: ASSERT( FALSE );
		}
		AddField(NewField(dtxf, dtxfkData, dfi.m_strName, strt, dfi.m_nPrecision, dfi.m_nSQLType));
		strt += dfi.m_nPrecision;
	}
	m_nFields = m_FieldArray.GetSize();
}

void CDTXODBCTable::DoFieldExchange(CFieldExchange* pFX)
{
	ReadFieldArray();
	pFX->SetFieldType(CFieldExchange::outputColumn);
	CString		cFieldName;
	for(int i = 0; i < m_FieldArray.GetSize(); i++ )
	{
		DTXField* nField = m_FieldArray[i];
		cFieldName.Format(_T("[%s]"), nField->m_FieldName );
		switch(nField->m_Type)
		{
			case	dtxfBool:
					RFX_Bool(pFX, cFieldName, (int&) nField->boolVal);
					break;

			case	dtxfInteger:
					RFX_Int( pFX, cFieldName, (int&) nField->intVal);
					break;

			case	dtxfLong:
					RFX_Long( pFX, cFieldName, nField->longVal);
					break;
	
			case	dtxfFloat:
					RFX_Single(pFX, cFieldName, nField->fltVal);
					break;
		
			case	dtxfDouble:
					RFX_Double(pFX, cFieldName, nField->dblVal);
					break;

			case	dtxfDateTime:
			case	dtxfTime:
			case	dtxfDate:
					RFX_Date(pFX, cFieldName, *nField->date);
					break;

			case	dtxfCurrency:
					RFX_Text(pFX, cFieldName, *nField->cyVal, nField->m_Length);
					break;

			case	dtxfString: 
					RFX_Text(pFX, cFieldName, *nField->strVal, nField->m_Length);
					break;

			case	dtxfBlob:
					RFX_LongBinary(pFX, cFieldName, *nField->blobVal);
					break;

			default:
				ASSERT( FALSE );
		}
	}
}