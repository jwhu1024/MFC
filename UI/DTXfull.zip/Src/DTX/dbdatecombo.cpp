// dbdatecombo.cpp : implementation file
//

#include "stdafx.h"
#include "dbdatecombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBDateCombo

CDBDateCombo::CDBDateCombo()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBDateCombo::~CDBDateCombo()
{
}


BEGIN_MESSAGE_MAP(CDBDateCombo, CDateComboBox)
	//{{AFX_MSG_MAP(CDBDateCombo)
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBDateCombo message handlers

void CDBDateCombo::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty() && nField->date)
		{
			CDate dt(nField->date->GetYear(), nField->date->GetMonth(), nField->date->GetDay());

			CString m_FieldText = dt.Format(DATE_SHORTDATE);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				SetWindowText(m_FieldText);
				Invalidate();
			}
			if(nField->m_Kind == dtxfkCalculated)
				m_Wnd->EnableWindow(false);
		}
	}
}

void CDBDateCombo::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty() && nField->date)
		{
			CDate dt(nField->date->GetYear(), nField->date->GetMonth(), nField->date->GetDay());
			CString m_FieldText = dt.Format(DATE_SHORTDATE);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDBDateCombo

CDTXDBDateCombo::CDTXDBDateCombo()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBDateCombo::~CDTXDBDateCombo()
{
}


BEGIN_MESSAGE_MAP(CDTXDBDateCombo, CDTXDateComboBox)
	//{{AFX_MSG_MAP(CDTXDBDateCombo)
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBDateCombo message handlers

void CDTXDBDateCombo::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty() && nField->date)
		{
			CDate dt(nField->date->GetYear(), nField->date->GetMonth(), nField->date->GetDay());

			CString m_FieldText = dt.Format(DATE_SHORTDATE);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				SetWindowText(m_FieldText);
				Invalidate();
			}
			if(nField->m_Kind == dtxfkCalculated)
				m_Wnd->EnableWindow(false);
		}
	}
}

void CDTXDBDateCombo::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty() && nField->date)
		{
			CDate dt(nField->date->GetYear(), nField->date->GetMonth(), nField->date->GetDay());
			CString m_FieldText = dt.Format(DATE_SHORTDATE);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}
	CDTXDateComboBox::OnKillfocus();
}

