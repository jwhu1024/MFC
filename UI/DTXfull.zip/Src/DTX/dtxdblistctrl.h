#if !defined(AFX_DTXDBLISTCTRL_H__E5094931_27DD_46FD_B17B_B6464272D38D__INCLUDED_)
#define AFX_DTXDBLISTCTRL_H__E5094931_27DD_46FD_B17B_B6464272D38D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxdblistctrl.h : header file
//

#include "ReportCtrl.h"
#include "dtxlistctrl.h"

#include <DTXBase.h>

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include <DTXTable.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBListCtrl window

class CDBListCtrl : public CWnd, public CDTXEditBase
{
	BOOL m_FrDTXDBListCtrl;
	INT m_iSelected;
	CDBColArray m_Cols;
// Construction
public:
	CDBListCtrl();

	CDTXReportCtrl m_Ctrl;
// Attributes
public:
	void AddColumn(DBColumn* nColumn);
	void CreateCols();

	virtual void TableDataChange();
	virtual void TableClosed();
	virtual void TableOpened();
	
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBListCtrl)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBListCtrl)
	afx_msg void OnRvnItemCallback(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRvnSelectionChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CDTXDBListCtrl window

class CDTXDBListCtrl : public CDBListCtrl, public CDTXWndBase
{
// Construction
public:
	CDTXDBListCtrl();

// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXListCtrl)
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBListCtrl )
	afx_msg void OnPaint();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	
private:
	void DrawBorder(bool fHot = TRUE);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXDBLISTCTRL_H__E5094931_27DD_46FD_B17B_B6464272D38D__INCLUDED_)
