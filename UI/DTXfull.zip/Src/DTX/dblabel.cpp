// dblabel.cpp : implementation file
//

#include "stdafx.h"
#include "dblabel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBLabel

CDBLabel::CDBLabel()
:CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBLabel::~CDBLabel()
{
}


BEGIN_MESSAGE_MAP(CDBLabel, CLabel)
	//{{AFX_MSG_MAP(CDBLabel)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBLabel message handlers

void CDBLabel::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				SetWindowText(m_FieldText);
				Invalidate();
			}
		}
	}
}