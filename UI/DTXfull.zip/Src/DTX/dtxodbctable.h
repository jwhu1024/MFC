#if !defined(AFX_DTXODBCTABLE_H__EAB56484_0743_4069_9A34_1ABA0D870D3B__INCLUDED_)
#define AFX_DTXODBCTABLE_H__EAB56484_0743_4069_9A34_1ABA0D870D3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxodbctable.h : header file
//
#ifndef __AFXDB_H__
#include <afxdb.h>
#endif

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXODBCTable recordset

class CDTXODBCTable : public CDTXTable, public CRecordset
{
	CString m_SQLStr;
	CString m_ODBCTableName;
	CString m_FldValue;
public:
	DECLARE_DYNAMIC(CDTXODBCTable)

	CDTXODBCTable(CWnd* nOwner, CDatabase* pDB, CString nTableName);
	CDTXODBCTable(CWnd* nOwner, CString nDatabaseName, CString nTableName);
	~CDTXODBCTable();

	virtual BOOL TableOpened();
	virtual void DoFieldExchange(CFieldExchange* pFX);

	CString GetSQL()
	{ return m_SQLStr; }

	void SetSQL(CString nNewSQL)
	{ m_SQLStr = nNewSQL; }

	void SetODBCTableName(CString nName);
	CString GetODBCTableName()
	{ return m_ODBCTableName; }
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXODBCTable)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
	virtual void intGetCurrentRecord();
	virtual BOOL intOpen();
	virtual BOOL intClose();
	
	virtual void intGoFirst();
	virtual void intGoLast();
	virtual void intGoNext();
	virtual void intGoPrev();
	virtual void intGo(UINT nRec);

	virtual void intUpdateRecord();
	virtual void intInsertRecord();
	virtual void intDeleteRecord();

	virtual UINT intGetRecordCount();
	virtual UINT intGetRecordPos();

	virtual void ReadFieldArray();
	virtual BOOL intIsEOF()
	{ return CRecordset::IsEOF(); }

	virtual BOOL intIsBOF()
	{ return CRecordset::IsBOF(); }
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXODBCTABLE_H__EAB56484_0743_4069_9A34_1ABA0D870D3B__INCLUDED_)
