// dtxdbedit.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdbedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBEdit

CDTXDBEdit::CDTXDBEdit()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBEdit::~CDTXDBEdit()
{
}


BEGIN_MESSAGE_MAP(CDTXDBEdit, CDTXEdit)
	//{{AFX_MSG_MAP(CDTXDBEdit)
	ON_WM_SHOWWINDOW()
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBEdit message handlers

void CDTXDBEdit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDTXEdit::OnShowWindow(bShow, nStatus);
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
}

void CDTXDBEdit::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}	
}
