#if !defined(AFX_DBNAVIGATOR_H__15252CC5_87AD_4C44_A8AE_D0624CF82948__INCLUDED_)
#define AFX_DBNAVIGATOR_H__15252CC5_87AD_4C44_A8AE_D0624CF82948__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbnavigator.h : header file
//

#ifndef __CJFLATBUTTON_H__
#include "cjflatbutton.h"
#endif

#ifndef __AFXCMN_H__
#include <afxcmn.h>
#endif

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBNavigator window

class CDBNavigator : public CStatic, public CDTXEditBase
{
	CCJFlatButton m_First;
	CCJFlatButton m_Prev;
	CCJFlatButton m_Next;
	CCJFlatButton m_Last;
	CCJFlatButton m_Update;
	CCJFlatButton m_Add;
	CCJFlatButton m_Delete;
	CEdit	 m_GotoEdit;
	CStatic  m_TotalRec;

	CImageList m_ImageList;
	CToolTipCtrl m_tooltip;
// Construction
public:
	CDBNavigator();

// Attributes
public:
	virtual void TableDataChange();
	virtual void TableClosed();
	virtual void TableOpened();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBNavigator)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void CreateToolTip();
	void DisableFlat(BOOL nDisable=false);
	virtual ~CDBNavigator();

	// Generated message map functions
protected:
	void EnableButtons(BOOL nEnable);
	//{{AFX_MSG(CDBNavigator)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFirst();
	afx_msg void OnPrev();
	afx_msg void OnNext();
	afx_msg void OnLast();
	afx_msg void OnDelete();
	afx_msg void OnUpdate();
	afx_msg void OnAdd();
	afx_msg void OnGoKillfocus();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBNAVIGATOR_H__15252CC5_87AD_4C44_A8AE_D0624CF82948__INCLUDED_)
