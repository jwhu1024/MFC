#if !defined(AFX_DBIMAGE_H__24519BA8_5837_4BD7_9E2F_D94EF3426113__INCLUDED_)
#define AFX_DBIMAGE_H__24519BA8_5837_4BD7_9E2F_D94EF3426113__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbimage.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

#include "dtxtools.h"
/////////////////////////////////////////////////////////////////////////////
// CDBImage window

class CDBImage : public CWnd, public CDTXEditBase
{
	CBitmap m_Image;
	CSize	m_ImageSize;
	CString m_ImageFileName;
// Construction
public:
	CDBImage();

	virtual void TableDataChange();

// Attributes
public:
	BOOL m_AutoSize;
	void GetImageSizes(CSize& nSize) { nSize = m_ImageSize; }
	CString GetFileName()            { return m_ImageFileName; }
	CBitmap& GetBitmap()			 { return m_Image; }
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBImage)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:
	void Empty();
	void SetMenuID(UINT mMenuID);
	BOOL LoadBitmap(CString nFile);
	BOOL LoadBitmap(UINT nResID);
	virtual ~CDBImage();

	// Generated message map functions
protected:
	UINT m_MenuID;
	BOOL ReadFromBLOB();
	void GetSizes();
	//{{AFX_MSG(CDBImage)
	afx_msg void OnPaint();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBIMAGE_H__24519BA8_5837_4BD7_9E2F_D94EF3426113__INCLUDED_)
