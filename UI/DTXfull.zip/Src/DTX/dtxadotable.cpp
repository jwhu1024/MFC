// dtxdaotable.cpp : implementation file
//

#include "stdafx.h"
#include "icrsint.h"
#include "dtxadotable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


void DumpError(_com_error & e)    // handy function to extract and display
{                                       // our com error's 
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	CString str;
	str.Format("\tCode = %08lx", e.Error());
	str += " Msg: ";	str += e.ErrorMessage();
	str += " Source: "; str += bstrSource;
	str += " Description: "; str += bstrDescription;
	AfxMessageBox(str);
	
}

#define DSN_CONNECT_STRING _T("Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=%s;" \
				"Mode=ReadWrite;Extended Properties=\"\";Jet OLEDB:" \
				"System database=\"\";Jet OLEDB:Registry Path=\"\";Jet OLEDB:Database Password=\"\"\
				"";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global"\
				" Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:"\
				"New Database Password=\"\";Jet OLEDB:Create System Database=False;Jet OLEDB:"\
				"Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact"\
				" Without Replica Repair=False;Jet OLEDB:SFP=False")

/////////////////////////////////////////////////////////////////////////////
// CDTXADOTable

CDTXADOTable::CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CADODatabase* pdb)
	: CADORecordset(pdb),
	  CDTXTable(nOwner, nDatabaseName) 
{
	m_ADOTableName.Empty();
	m_ADOSQL.Empty();
	m_fldCount = 0;
	m_pConnection = NULL;
	m_ConnectString = _T("");
	m_haveADODatabase = TRUE;
	m_ConnectString.Empty();
}

CDTXADOTable::CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName)
	: CDTXTable(nOwner, nDatabaseName) 
{
	m_ADOSQL.Format(_T("Select * from [%s]"), nTableName);
	m_ADOTableName = nTableName;
	m_fldCount = 0;
			
	m_pConnection = NULL;
	m_ConnectString = _T("");
	m_pConnection.CreateInstance(__uuidof(Connection));
	m_haveADODatabase = FALSE;
	m_ConnectString.Empty();
}

CDTXADOTable::~CDTXADOTable()
{
	if(CADORecordset::IsOpen())
		CADORecordset::Close();
	if(!m_haveADODatabase) 
	{
		if( m_pConnection)
		{
			m_pConnection.Release();
			m_pConnection = NULL;
		}
	}

}

void CDTXADOTable::CreateConnectString()
{
	m_ConnectString.Format(DSN_CONNECT_STRING, GetTableName());
}

BOOL CDTXADOTable::intClose()
{
	if(m_pConnection)
	{
		if(m_pConnection->GetState() != adStateClosed)
			m_pConnection->Close();
	}
	
	CADORecordset::Close();

	return TRUE;
}

BOOL CDTXADOTable::intOpen()
{
	if(m_pConnection == NULL)
		return FALSE;

	if(m_pRecordset == NULL)
		return FALSE;

	if(m_ConnectString.IsEmpty())
		CreateConnectString();

	if(!m_haveADODatabase)
		m_pConnection->Open(_bstr_t(m_ConnectString), _T(""), _T(""), NULL);

	try
	{
		m_pRecordset->CursorLocation = adUseClient;
		m_pRecordset->CursorType	 = adOpenKeyset;

		if(!m_haveADODatabase)
			CADORecordset::Open(m_ADOSQL, CADORecordset::openUnknown);
		else
			CADORecordset::Open(m_pConnection, m_ADOSQL, CADORecordset::openUnknown);
	} 
	catch( _com_error &e)
	{
		DumpError(e);
	}
	
	if(!CADORecordset::IsBOF() || !CADORecordset::IsEOF())
	{
		CADORecordset::MoveLast();
		CADORecordset::MoveFirst();
	}
	m_fldCount = m_pRecordset->Fields->Count;
	return TRUE;
}	

void CDTXADOTable::intGoFirst()
{
	CADORecordset::MoveFirst();
}

void CDTXADOTable::intGoLast()
{
	CADORecordset::MoveLast();
}

void CDTXADOTable::intGoNext()
{
	CADORecordset::MoveNext();
}

void CDTXADOTable::intGoPrev()
{
	CADORecordset::MovePrevious();
}

void CDTXADOTable::intGo(UINT nRec)
{
	CADORecordset::SetAbsolutePosition(nRec + 1);
}


UINT CDTXADOTable::intGetRecordCount()
{
	return CADORecordset::GetRecordCount();
}

UINT CDTXADOTable::intGetRecordPos()
{
	return CADORecordset::GetAbsolutePosition() - 1;
}

void CDTXADOTable::intUpdateRecord()
{
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind ==  dtxfkCalculated) continue;
		COleVariant ov, old;

		GetFieldValue(nField->m_FieldName, old);
		if(nField->m_Type == dtxfString)
		{
			CString str = DTXFieldToString(nField);
			if(str.IsEmpty())
				str = _T(" ");
			SetFieldValue(nField->m_FieldName, str);
		}
		else
		{
			ov = DTXFieldToVariant(nField);
			SetFieldValue(nField->m_FieldName, ov);
		}
	}

	try
	{
		Update();
	} 
	catch( _com_error &e)
	{
		CancelUpdate();
		DumpError(e);
	}

}

void CDTXADOTable::intInsertRecord()
{
	AddNew();
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind ==  dtxfkCalculated) continue;

		nField->SetValueToNull();
		COleVariant ov;
		ov.Clear();
		ov.vt = VT_NULL;
		SetFieldValue(nField->m_FieldName, ov);
	}
	try
	{
		m_pRecordset->UpdateBatch(adAffectAll);	
		m_pRecordset->Requery(0);
		MoveLast();
	} 
	catch( _com_error &e)
	{
		m_pRecordset->CancelUpdate();
		DumpError(e);
	}
}

void CDTXADOTable::intDeleteRecord()
{
	CADORecordset::Delete();
}

void CDTXADOTable::intGetCurrentRecord()
{
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind == dtxfkCalculated) continue;
		COleVariant ov;
		ov.Clear();
		GetFieldValue(nField->m_FieldName, ov);
		if(ov.vt != VT_NULL)
		{
			if(nField->m_Type == dtxfString)
			{
				CString n(ov.bstrVal);
				nField->strVal->Format(_T("%s"), n);

			}
			else
			 VariantToDTXField(ov, nField);
		}
		else
			nField->SetValueToNull();
	}
}

void CDTXADOTable::ReadFieldArray()
{
	m_FieldArray.FreeAll();
	int strt = 0;
	for(int i = 0; i < m_fldCount; i++)
	{
		CADOFieldInfo afi;
		GetFieldInfo(i, &afi);
		DTXFieldType dtxf;
		switch(afi.m_nType)
		{

			case adTinyInt:
			case adSmallInt:
			case adInteger:
			case adBigInt:
			case adUnsignedTinyInt:
			case adUnsignedSmallInt:
			case adUnsignedInt:
			case adUnsignedBigInt:
			case adDecimal:
			case adNumeric:
				dtxf = dtxfInteger; break;

			case adSingle:
			case adDouble:
				dtxf = dtxfFloat; break;

			case adCurrency:
				dtxf = dtxfCurrency; break;

			case adBoolean:
				dtxf = dtxfBool; break;
		
			case adDate:
			case adDBDate:
				dtxf = dtxfDate; break;

			case adDBTime:
				dtxf = dtxfTime; break;

			case adDBTimeStamp:
			case adFileTime:
				dtxf = dtxfDateTime; break;

			case adBSTR:
			case adChar:
		    case adVarChar:
			case adLongVarChar:
		    case adWChar:
			case adVarWChar:
			case adLongVarWChar:
			case adIDispatch:
		    case adGUID:
				dtxf = dtxfString; break;
    
			case adBinary:
			case adVarBinary:
			case adLongVarBinary:
				dtxf = dtxfBlob; break;
		}
		AddField(NewField(dtxf, dtxfkData, afi.m_strName, strt, afi.m_lSize, afi.m_nType));
		strt += afi.m_lSize;
	}
}
