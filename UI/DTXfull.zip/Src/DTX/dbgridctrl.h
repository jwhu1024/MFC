#if !defined(AFX_DBGRIDCTRL_H__B372CCE9_0B05_4C91_BE62_7E016E6EA6DB__INCLUDED_)
#define AFX_DBGRIDCTRL_H__B372CCE9_0B05_4C91_BE62_7E016E6EA6DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbgridctrl.h : header file
//

#include <ALXGridCtrl.h>
#include <DTXBase.h>

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include <DTXTable.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBGridCtrl window

class CDBGridCtrl : public CALXGridCtrl, public CDTXEditBase
{
	BOOL m_FrDTXDBGridCtrl;
	CDBColArray m_Cols;
// Construction
public:
	CDBGridCtrl();

// Attributes
public:
	void AddColumn(DBColumn* nColumn);

	virtual int GetFixedRowCount()
	{ return 1; }

	virtual int GetFixedColCount()
	{ return 1; }

	virtual void TableDataChange();
	virtual void TableClosed();
	virtual void TableOpened();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBGridCtrl)
	//}}AFX_VIRTUAL
	virtual CELL_DATA GetCellData(int nCol, int nRow);
	virtual BOOL OnSaveCellData(int nCol, int nRow);
// Implementation
protected:
	void CreateCols();
	virtual void OnSetActiveCell(int nCol, int nRow);
public:
	virtual ~CDBGridCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBGridCtrl)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CDTXDBGridCtrl : public CDBGridCtrl, public CDTXWndBase
{
protected:
	//{{AFX_MSG(CDTXDBGridCtrl)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DrawBorder(bool fHot = TRUE);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBGRIDCTRL_H__B372CCE9_0B05_4C91_BE62_7E016E6EA6DB__INCLUDED_)
