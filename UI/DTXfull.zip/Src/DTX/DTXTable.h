#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#define AFX_DTXTABLE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dtxtable.h : header file
//

#ifndef __AFXTEMPL_H__
#include <afxtempl.h>
#endif

#ifndef __AFXDISP_H__
#include <afxdisp.h>
#endif

#ifndef __AFXDB__H__
#include <AFXDB.H>
#endif
#include "dtxtools.h"

extern UINT WM_DTXRECORDCHANGE;
extern UINT WM_DTXTABLEOPEN;
extern UINT WM_DTXTABLECLOSE;
extern UINT WM_CALCULATERECORD;

class CDTXTable;
class DTXField;
class DBColumn;

typedef enum {dtxfInteger, dtxfLong, dtxfFloat, dtxfDouble, 
			  dtxfString, dtxfMemo, dtxfTime, dtxfDate, dtxfDateTime, 
			  dtxfCurrency, dtxfBool, dtxfBlob} DTXFieldType;

typedef enum { dtxfkData, dtxfkCalculated} DTXFieldKind;
typedef enum {dbcLeft, dbcCenter, dbcRight} dbCollAlign; 

void StringToDTXField(CString str, DTXField* var);
void VariantToDTXField(COleVariant var, DTXField* fld);
void VariantToLongBinary(COleVariant var, DTXField* fld);
void WriteBlobToFile(CString nFileName, DTXField* fld);

CString DTXFieldToString(DTXField* var);
DTXField* NewField(DTXFieldType m_Type, DTXFieldKind m_Kind, CString m_FieldName, UINT m_Start, UINT m_Length, int nOrigType);
COleVariant DTXFieldToVariant(DTXField* fld);
DBColumn* NewDBColumn(CString m_FldName, CString m_Header, int m_Width, dbCollAlign m_Align);

/////////////////////////////////////////////////////////////////////////////
// DBColumn

class DBColumn
{
public:
	CString m_Header;
	CString m_FieldName;
	int		m_ColWidth;
	dbCollAlign m_Align;
};

/////////////////////////////////////////////////////////////////////////////
// CDBColArray

class CDBColArray : public CArray <DBColumn*, DBColumn*>
{
public:
	void FreeAll();

	CDBColArray();
	~CDBColArray();

	void AddColumn(DBColumn* nNewColumn);
};

/////////////////////////////////////////////////////////////////////////////
// DTXField

class DTXField
{
public:
	void SetValueToNull();
	DTXFieldType m_Type;
	DTXFieldKind m_Kind;
	CString m_FieldName;
	int m_Start;   // Veri alan� ba�lang�c�
	int	m_Length;  // Veri uzunlu�u

	int m_OrigType;
	union
	{
	    INT intVal;
		LONG longVal;
	    FLOAT fltVal;
	    DOUBLE dblVal;
		CString* strVal;
		CLongBinary* blobVal;
	    COleDateTime* date;      
		BOOL boolVal;
	    CString* cyVal;
	};
	DTXField(DTXFieldType nType);
	~DTXField();	
};

/////////////////////////////////////////////////////////////////////////////
// CDTXFieldArray

class CDTXFieldArray : public CArray <DTXField*, DTXField*>
{
	BOOL m_HaveCalculated;
public:
	void FreeAll();

	CDTXFieldArray();
	CDTXFieldArray(CDTXTable* nTable);

	~CDTXFieldArray();

	void AddField(DTXField* nNewField);
	BOOL HaveCalculated() { return m_HaveCalculated; }
};

/////////////////////////////////////////////////////////////////////////////
// CDTXEditBase

class CDTXEditBase
{
protected:
	CDTXTable* m_OwnerTable;
	CWnd* m_Wnd;
	CString m_EditField;

	CString GetDisplayString();
public:
	CDTXEditBase(CWnd* pWnd);
	~CDTXEditBase();

	DTXField* GetField();

	CString GetFieldName()
	{ return m_EditField; }
	
	void SetOwner(CWnd* pWnd)
	{ m_Wnd = pWnd ; }
	void SetFieldValue(CString nValue);
	void SetTable(CDTXTable* nTable);
	void SetEditField(CString nField);
	virtual void TableDataChange();
	virtual void TableClosed();
	virtual void TableOpened();
};

/////////////////////////////////////////////////////////////////////////////
// CDTXTable 

class CDTXTable
{
	friend class CDTXEditBase;
	BOOL m_EnableControls;
protected:
	CArray <CDTXEditBase*, CDTXEditBase*> m_EditorList;
	CWnd* m_Owner;
	CString m_TableName;
	UINT m_RecordSize;
	BOOL m_IsModified;
	BOOL m_AutoUpdate;
	BOOL m_isOpen;
	CDTXFieldArray m_FieldArray;
public:
	CDTXTable(CWnd* nOwner, CString nTableName);
	virtual ~CDTXTable();

// Table i�lemleri
public:	
	DTXField* GetField(CString nName);
	void DisableControls();
	void EnableControls(BOOL nRefreshEditors = TRUE);
	void DeleteEditor(CString nFieldName);
	void Refresh();
	void AddEditor(CDTXEditBase* nEditor);
	
	void AddCalculatedField(CString nName, UINT nSize, DTXFieldType nType);
	void AddField(DTXField* nNewField);

	BOOL OpenTable();
	BOOL CloseTable();
	
	void GoFirst();
	void GoLast();
	void GoNext();
	void GoPrev();
	void Go(UINT nRec);

	BOOL IsEOF();
	BOOL IsBOF();

	UINT GetRecordCount();
	UINT GetRecordPos();

	void UpdateRecord();
	void InsertRecord();
	void DeleteRecord();

	int GetTableFieldCount()
	{ return m_FieldArray.GetSize(); }

	CString GetTableName()
	{ return m_TableName; }

	void SetTableName(CString nName)
	{ m_TableName = nName; }

	UINT GetRecordSize()
	{ return m_RecordSize; }

	void SetOwner(CWnd* nOwner)
	{	m_Owner = nOwner;	}

	BOOL GetModified()
	{ return m_IsModified; }

	void SetModified(BOOL nModified);

	BOOL GetAutoUpdate()
	{ return m_AutoUpdate; }

	void SetAutoUpdate(BOOL nUpdate)
	{ m_AutoUpdate = nUpdate; }

	virtual BOOL TableOpened() = 0;
// operat�rler
	DTXField* operator [](int nIndex);
	DTXField* operator [](CString nName);
	CWnd* GetOwner()
	{ return m_Owner; }
protected:
	virtual void ReadCurrentRecord();
	virtual BOOL intOpen() = 0;
	virtual BOOL intClose() = 0;
	
	virtual void intGoFirst() = 0;
	virtual void intGoLast() = 0;
	virtual void intGoNext() = 0;
	virtual void intGoPrev() = 0;
	virtual void intGo(UINT nRec) = 0;

	virtual UINT intGetRecordCount() = 0;
	virtual UINT intGetRecordPos() = 0;
	virtual void intGetCurrentRecord() = 0;
	virtual void ReadFieldArray() = 0;
	virtual BOOL intIsEOF() = 0;
	virtual BOOL intIsBOF() = 0;

	virtual void intUpdateRecord() = 0;
	virtual void intInsertRecord() = 0;
	virtual void intDeleteRecord() = 0;
private:
	void RecChange();
	void SendRecChangeMessage();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTXTABLE_H__D5589642_D1B7_422F_AF01_B82FFBD36E4C__INCLUDED_)
