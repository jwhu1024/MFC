#if !defined(AFX_DBNUMERICEDIT_H__1A3E64BA_9665_4748_9128_83EBC8A271DD__INCLUDED_)
#define AFX_DBNUMERICEDIT_H__1A3E64BA_9665_4748_9128_83EBC8A271DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbnumericedit.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBNumericEdit window

class CDBNumericEdit : public CEdit, public CDTXEditBase
{
// Construction
public:
	CDBNumericEdit();

	double GetNumericValue() {return m_NumericValue;}
	void SetNumericValue(double NumericValue);
	void SetAttributes(short NumDecimalPlaces, BOOL DisplayCommas = TRUE);
	void SetPrefix(CString Prefix);
	void SetSuffix(CString Suffix);

	virtual void TableDataChange();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBNumericEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetMinMax(double nmin, double nmax);
	virtual ~CDBNumericEdit();

	// Generated message map functions
protected:
	BOOL m_DecimalAlreadyUsed;   
	BOOL m_InsertCommas; 
	BOOL m_HasValue;
	BOOL m_UseMinMax;
	
	short m_NumDecimalPlaces;   
	double m_NumericValue;
	double m_MinValue;
	double m_MaxValue;
	
	CString m_Prefix;
	CString m_Suffix;
	

	void SetNumericText(BOOL InsertFormatting);
	double RoundToDecimal(double Value, short DecimalPlaces);
	BOOL DoesCharacterPass(UINT nChar, int CharacterPosition);
	
	//{{AFX_MSG(CDBNumericEdit)
		// NOTE - the ClassWizard will add and remove member functions here.
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnChange();
	afx_msg void OnSetfocus();
	afx_msg void OnKillfocus();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	
	afx_msg LRESULT OnPaste(WPARAM Wparam, LPARAM LParam);

	DECLARE_MESSAGE_MAP()
private:
	double GetDoubleFieldValue();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBNUMERICEDIT_H__1A3E64BA_9665_4748_9128_83EBC8A271DD__INCLUDED_)
