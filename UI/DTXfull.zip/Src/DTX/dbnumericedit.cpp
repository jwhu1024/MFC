// dbnumericedit.cpp : implementation file
//

#include "stdafx.h"
#include "dbnumericedit.h"
#include <math.h>
#include <afxole.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBNumericEdit

CDBNumericEdit::CDBNumericEdit()
: CDTXEditBase(NULL)
{
   m_DecimalAlreadyUsed = FALSE;
   m_NumDecimalPlaces = 2;
   m_InsertCommas = TRUE;
   m_Prefix = _T("");
   m_Suffix = _T("");
   m_HasValue = TRUE;
   m_UseMinMax = false;
   m_MinValue = m_MaxValue = m_NumericValue = 0;
   CDTXEditBase::SetOwner(this);
}

CDBNumericEdit::~CDBNumericEdit()
{
}


BEGIN_MESSAGE_MAP(CDBNumericEdit,CEdit)
	//{{AFX_MSG_MAP(CDBNumericEdit)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_WM_CHAR()
	ON_WM_SHOWWINDOW()
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_PASTE, OnPaste)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBNumericEdit message handlers

void CDBNumericEdit::TableDataChange()
{	
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				m_NumericValue = atof(m_FieldText);
   
			   // Set text with formatting if selected
				SetNumericText(TRUE);				
			}
			if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
		}
	}
}

void CDBNumericEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	int start_sel, end_sel;
	GetSel(start_sel, end_sel);

   // if character passes for the position, continue
   if(DoesCharacterPass(nChar, start_sel))
      {
		 CEdit::OnChar(nChar, nRepCnt, nFlags);
      }
}

BOOL CDBNumericEdit::DoesCharacterPass(UINT nChar, int CharacterPosition)
{ 
   BOOL allow_char = TRUE;

   // if the character is not allowed, return without doing anything
   // check isprint to ensure that unprinted characters are passed to cedit (ctrl-v,etc.)
   if(!isdigit(nChar) && isprint(nChar))
      {
      allow_char = FALSE;
      switch(nChar)
         {
         case '.':
            if(!m_DecimalAlreadyUsed)
               {
               allow_char = TRUE;
               }
            break;
         case '-':      // allow '-' only as first character
            if(CharacterPosition == 0)
               {
               allow_char = TRUE;
               }
            break;
         default:
            break;
         } 
      }
   return allow_char;
}

// use change to keep up with whether the decimal has been used
void CDBNumericEdit::OnChange() 
{
	CString workstr;

   GetWindowText(workstr);

   if(workstr.Find(".") != -1)
      {
      m_DecimalAlreadyUsed = TRUE;
      }
   else
      {
      m_DecimalAlreadyUsed = FALSE;
      }
}

void CDBNumericEdit::OnSetfocus() 
{
   // set text without formatting, since going into user edit mode
   if(m_HasValue)
      {
      SetNumericText(FALSE);
      }

}

void CDBNumericEdit::SetNumericText(BOOL ShowFormatting)
   {
   CString workstr1, workstr2 = _T("");
   int  decimal, sign, loop;
   int wholenum_place, string_length, num_whole_nums;

   // take value from edit control's double value
   workstr1 = fcvt( m_NumericValue, m_NumDecimalPlaces, &decimal, &sign );

   if(m_UseMinMax)
   {
		if(m_NumericValue < m_MinValue || m_NumericValue > m_MaxValue)
			return;
   }

   string_length = workstr1.GetLength();
   num_whole_nums = string_length - m_NumDecimalPlaces;

   if(sign == 0)
      {
      workstr2 = _T("");
      }
   else
      {
      workstr2 = _T("-");
      }

   for(loop = 0; loop < string_length; loop++)
      {
      wholenum_place = num_whole_nums - loop;
      if(ShowFormatting && m_InsertCommas && loop > 0 && wholenum_place > 2)
         {
         if((wholenum_place % 3) == 0)
            {
            workstr2 = workstr2 + _T(",");
            }
         }
      if(decimal == loop)
         {
         workstr2 = workstr2 + _T(".");
         }

      workstr2 = workstr2 + workstr1[loop];
      }

   if( ShowFormatting)
      {
      workstr2 = m_Prefix + workstr2 + m_Suffix;
      }

   SetWindowText(workstr2);
   }

void CDBNumericEdit::SetNumericValue(double NumericValue) 
{
   if(m_UseMinMax)
   {
		if(NumericValue < m_MinValue || NumericValue > m_MaxValue)
			return;
   }
   m_NumericValue = NumericValue;
   m_HasValue = TRUE;
 
   // Set text with formatting if selected
   SetNumericText(TRUE);
}

void CDBNumericEdit::OnKillfocus() 
{
   CString workstr;
   double value;

   GetWindowText(workstr);

   if(workstr.GetLength()>0)
      {
      m_HasValue = TRUE;
      }
   else
      {
      m_HasValue = FALSE;
      return;
      }

   // properly round and convert
   value = atof(workstr);
   value = RoundToDecimal(value, m_NumDecimalPlaces);

   if(m_UseMinMax)
   {
		if(value < m_MinValue || value > m_MaxValue)
			value = m_NumericValue;
   }

   // Set member value
   m_NumericValue = value;
   
   // Set text with formatting if selected
   SetNumericText(TRUE);
   if(m_NumericValue != GetDoubleFieldValue())
   {
	   SetFieldValue(workstr);
   }
}

double CDBNumericEdit::RoundToDecimal(double Value, short DecimalPlaces)
{
   double ret_value;
   long   temp_value;
   double raise_to;
   double tolerence;
   double final_diff;

   raise_to = pow(10.0,DecimalPlaces);
   tolerence = 1.0 / raise_to;
   if (Value >= 0)
      {
      //add tolerence/2 to round up since putting it into a long truncates the value
      temp_value = (long)((Value + (tolerence/2.0)) * raise_to);
      }
   else
      {
      //subtract tolerence/2 to round down since putting it into a long truncates the value
      temp_value = (long)((Value - (tolerence/2.0)) * raise_to);
      }

   ret_value = (double)temp_value / raise_to;

   final_diff = Value - ret_value;
   if ((final_diff < -tolerence) ||  (final_diff > tolerence))
      {
      // Removing ASSERT because it is annoying
      // ASSERT(FALSE);
      ret_value = Value;
      }

   return(ret_value);
}

void CDBNumericEdit::SetAttributes(short NumDecimalPlaces, BOOL DisplayCommas)
{
   m_NumDecimalPlaces = NumDecimalPlaces;
   m_InsertCommas = DisplayCommas;
   // Set text with formatting if selected
   SetNumericText(TRUE);
}

void CDBNumericEdit::SetPrefix(CString Prefix)
{
   m_Prefix = Prefix;
   // Set text with formatting if selected
   SetNumericText(TRUE);
}

void CDBNumericEdit::SetSuffix(CString Suffix)
{
   m_Suffix = Suffix;
   // Set text with formatting if selected
   SetNumericText(TRUE);
}


// this signature used for pasting function in order to get around
// bug mentioned in Article ID: Q195032 of the MS knowledge base 
LRESULT CDBNumericEdit::OnPaste(WPARAM Wparam, LPARAM LParam) 
{
   UINT this_char;
   int start_sel, end_sel, loop;
   BOOL does_clipstring_pass = TRUE, pre_was_decimal_used;
  	CString buffer, workstr;
	COleDataObject	obj;


	if (obj.AttachClipboard()) 
      {
		if (obj.IsDataAvailable(CF_TEXT)) 
         {
			HGLOBAL hmem = obj.GetGlobalData(CF_TEXT);
			CMemFile sf((BYTE*) ::GlobalLock(hmem), ::GlobalSize(hmem));
			CString buffer;

			LPSTR str = buffer.GetBufferSetLength(::GlobalSize(hmem));
			sf.Read(str, ::GlobalSize(hmem));
			::GlobalUnlock(hmem);

			// pass characters one at a time to control, allowing the control
         // to decide whether to paste it or not (this could be funky for mixed
         // alpha and digit strings)
         buffer.ReleaseBuffer();
         buffer.FreeExtra();

         //  Check buffer for validity- if any character invalid, don't paste
         GetSel(start_sel, end_sel);

         // if decimal is within selection, allow a decimal to be pasted
         // save decimal use flag
         pre_was_decimal_used = m_DecimalAlreadyUsed;
         if(pre_was_decimal_used == TRUE)
            {
            CString temp_str;
            GetWindowText(temp_str);
            for(loop = start_sel; loop < end_sel; loop++)
               {
               if(temp_str[loop] == '.')
                  {
                  m_DecimalAlreadyUsed = FALSE;
                  }
               }
            }

         for(loop = 0; loop < buffer.GetLength(); loop++)
            {
            this_char = buffer[loop];
            if(!DoesCharacterPass(this_char, start_sel+loop))
               {
               does_clipstring_pass = FALSE;
               break;
               }
            }

         // reset decimal use flag
         m_DecimalAlreadyUsed = pre_was_decimal_used;
  
         // continue default windows processing if string okay
         if(does_clipstring_pass)
            {
            Default();
            }
         else   // let user know that paste wasn't allowed
            {
            workstr = _T("Format of the following value is not compatible with this control\n\"")
                 + buffer; 
            workstr = workstr + _T("\"\nPaste Command Ignored");
            MessageBox( workstr, _T("Paste Notice"), MB_OK | MB_ICONINFORMATION);
            }
         }
      }

   // not used, but required
   return 0;  
}

double CDBNumericEdit::GetDoubleFieldValue()
{
	CString nText = GetDisplayString();
	return atof(nText);
}

void CDBNumericEdit::SetMinMax(double nmin, double nmax)
{
	m_UseMinMax = true;
	m_MinValue = nmin;
	m_MaxValue = nmax;
}

void CDBNumericEdit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CEdit::OnShowWindow(bShow, nStatus);
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
}
