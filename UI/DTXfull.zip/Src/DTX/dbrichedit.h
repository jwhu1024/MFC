#if !defined(AFX_DBRICHEDIT_H__16BC92BB_A8BD_4347_9D8C_EC1D179040AF__INCLUDED_)
#define AFX_DBRICHEDIT_H__16BC92BB_A8BD_4347_9D8C_EC1D179040AF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbrichedit.h : header file
//

#include "AutoRichEditCtrl.h"
#include "dtxrichedit.h"

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBRichEdit window

class CDBRichEdit : public CAutoRichEditCtrl, public CDTXEditBase
{
// Construction
public:
	CDBRichEdit();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBRichEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBRichEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBRichEdit)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	virtual void TableDataChange();
};

/////////////////////////////////////////////////////////////////////////////
// CDTXDBRichEdit window

class CDTXDBRichEdit : public CDTXRichEdit, public CDTXEditBase
{
// Construction
public:
	CDTXDBRichEdit();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTXDBRichEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBRichEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBRichEdit)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	virtual void TableDataChange();
};
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBRICHEDIT_H__16BC92BB_A8BD_4347_9D8C_EC1D179040AF__INCLUDED_)
