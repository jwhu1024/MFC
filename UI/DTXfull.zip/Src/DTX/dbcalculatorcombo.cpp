// dbcalculatorcombo.cpp : implementation file
//

#include "stdafx.h"
#include "dbcalculatorcombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBCalculatorCombo

CDBCalculatorCombo::CDBCalculatorCombo()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBCalculatorCombo::~CDBCalculatorCombo()
{
}


BEGIN_MESSAGE_MAP(CDBCalculatorCombo, CCalculatorCombo)
	//{{AFX_MSG_MAP(CDBCalculatorCombo)
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBCalculatorCombo message handlers

void CDBCalculatorCombo::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDBCalculatorCombo

CDTXDBCalculatorCombo::CDTXDBCalculatorCombo()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBCalculatorCombo::~CDTXDBCalculatorCombo()
{
}


BEGIN_MESSAGE_MAP(CDTXDBCalculatorCombo, CDTXCalculatorCombo)
	//{{AFX_MSG_MAP(CDTXDBCalculatorCombo)
	ON_CONTROL_REFLECT(CBN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBCalculatorCombo message handlers

void CDTXDBCalculatorCombo::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}
}

