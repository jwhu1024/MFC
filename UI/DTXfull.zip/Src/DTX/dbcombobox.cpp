// dbcombobox.cpp : implementation file
//

#include "stdafx.h"
#include "dbcombobox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBComboBox

CDBComboBox::CDBComboBox()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBComboBox::~CDBComboBox()
{
}


BEGIN_MESSAGE_MAP(CDBComboBox, CFlatComboBox)
	//{{AFX_MSG_MAP(CDBComboBox)
	ON_WM_KILLFOCUS()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBComboBox message handlers

void CDBComboBox::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			if(nField->m_Type == dtxfInteger)
			{
				SetCurSel(nField->intVal);
			}
			else
			{
				CString m_FieldText = DTXFieldToString(nField);
				CString m_WinText;
				GetWindowText(m_WinText);
				if(m_WinText != m_FieldText)
				{
					SetWindowText(m_FieldText);
					Invalidate();
				}
			}
			if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
		}
	}
}

void CDBComboBox::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			if(nField->m_Type == dtxfInteger)
			{
				if(nField->intVal != GetCurSel())
				{
					CString nVal;
					nVal.Format(_T("%d"), GetCurSel());
					SetFieldValue(nVal);
				}
			}
			else
			{
				CString m_FieldText = DTXFieldToString(nField);
				CString m_WinText;
				GetWindowText(m_WinText);
				if(m_WinText != m_FieldText)
					SetFieldValue(m_WinText);
			}
		}
	}	
	CFlatComboBox::OnKillFocus(pNewWnd);
}

void CDBComboBox::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
	CFlatComboBox::OnShowWindow(bShow, nStatus);
}
