// dtxdblistctrl.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdblistctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBListCtrl

CDBListCtrl::CDBListCtrl()
	: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
	m_iSelected = RVI_INVALID;
	m_FrDTXDBListCtrl = false;
}

CDBListCtrl::~CDBListCtrl()
{
	for(int c = 0; c < m_Cols.GetSize(); c++)
	{
		DBColumn *nColumn = m_Cols.GetAt(c);
		if(nColumn)
		{
			delete nColumn;
		}
	}
	m_Cols.RemoveAll();
}

BEGIN_MESSAGE_MAP(CDBListCtrl, CWnd)
	//{{AFX_MSG_MAP(CDBListCtrl)
	ON_NOTIFY(RVN_ITEMCALLBACK, 1, OnRvnItemCallback)
	ON_NOTIFY(RVN_SELECTIONCHANGED, 1, OnRvnSelectionChanged)
	ON_WM_SHOWWINDOW()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBListCtrl message handlers

void CDBListCtrl::TableDataChange()
{
	if(GetSafeHwnd() && m_OwnerTable && !m_FrDTXDBListCtrl)
	{
		UINT nRecCnt = m_OwnerTable->GetRecordCount();
		if((UINT) m_Ctrl.GetItemCount() != nRecCnt)
			m_Ctrl.SetItemCount(nRecCnt);
		m_Ctrl.SetSelection(m_OwnerTable->GetRecordPos(), TRUE);
		m_Ctrl.ScrollWindow(SB_VERT, m_OwnerTable->GetRecordPos());
		m_Ctrl.UpdateWindow();
	}
}

void CDBListCtrl::TableClosed()
{
	m_Ctrl.SetItemCount(0);
	m_Ctrl.UpdateWindow();
	EnableWindow(false);
}

void CDBListCtrl::TableOpened()
{
	if(GetSafeHwnd())
	{
		EnableWindow();
		TableDataChange();
	}
}

void CDBListCtrl::AddColumn(DBColumn *nColumn)
{
	m_Cols.AddColumn(nColumn);
}

void CDBListCtrl::CreateCols()
{
	RVSUBITEM rvs;
	for(int c = 0; c < m_Cols.GetSize(); c++)
	{
		DBColumn *nColumn = m_Cols.GetAt(c);
		if(nColumn)
		{
			rvs.nFormat = RVCF_TEXT|RVCF_EX_TOOLTIP;
			switch(nColumn->m_Align)
			{
				case dbcLeft  : rvs.nFormat |= RVCF_LEFT; break;
				case dbcCenter: rvs.nFormat |= RVCF_CENTER; break;
				case dbcRight : rvs.nFormat |= RVCF_RIGHT; break;
			}

			rvs.iWidth = nColumn->m_ColWidth;
			rvs.lpszText = nColumn->m_Header.GetBuffer(0);
			
			m_Ctrl.DefineSubItem(c, &rvs);
			m_Ctrl.ActivateSubItem(c, c);
		}
	}
	m_Ctrl.SetItemCount(0);
}

void CDBListCtrl::OnRvnItemCallback(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMRVITEMCALLBACK lpnmrvic = (LPNMRVITEMCALLBACK)pNMHDR;
	UINT m_CurRec = m_OwnerTable->GetRecordPos();

	if(lpnmrvic->item.iItem >= 0 && lpnmrvic->item.iSubItem >= 0 &&
		lpnmrvic->item.iSubItem < m_Cols.GetSize())
	{
		m_FrDTXDBListCtrl = true;
		m_OwnerTable->DisableControls();
		m_OwnerTable->Go(lpnmrvic->item.iItem);
		CString nFld = m_Cols[lpnmrvic->item.iSubItem]->m_FieldName;
		DTXField* pField = m_OwnerTable->GetField(nFld);
		if(pField) 
			_stprintf(lpnmrvic->item.lpszText, _T("%s"), DTXFieldToString(pField));
		m_OwnerTable->Go(m_CurRec);
		m_OwnerTable->EnableControls(true);
		m_FrDTXDBListCtrl = false;
	}
	
	lpnmrvic->item.nMask |= RVIM_PREVIEW;
	lpnmrvic->item.nPreview = 0;

	
	if((UINT) lpnmrvic->item.iItem == m_CurRec)
	{
		m_iSelected = m_CurRec;
		lpnmrvic->item.nMask |= RVIM_STATE;
		lpnmrvic->item.nState |= RVIS_SELECTED;
	}
	pResult = FALSE;
}

void CDBListCtrl::OnRvnSelectionChanged(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMREPORTVIEW lpnmrv = (LPNMREPORTVIEW)pNMHDR;

	if(lpnmrv->nState & RVIS_SELECTED)
	{
		m_iSelected = lpnmrv->iItem;
		if(m_OwnerTable)
		{
			m_FrDTXDBListCtrl = true;
			m_OwnerTable->Go(m_iSelected);
			m_FrDTXDBListCtrl = false;
		}
	}

	pResult = FALSE;
}

void CDBListCtrl::PreSubclassWindow() 
{
	CWnd::PreSubclassWindow();
	CRect r;
	GetClientRect(&r);
	r.DeflateRect(1, 1);

	m_Ctrl.Create(GetStyle()|RVS_SINGLESELECT|RVS_SHOWSELALWAYS|WS_CHILD, r, this, 1); 
	m_Ctrl.SetFont(GetFont());
}

void CDBListCtrl::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CWnd::OnShowWindow(bShow, nStatus);
	m_Ctrl.SetItemCount(0);
	if(m_OwnerTable)
	{
		m_OwnerTable->GoFirst();
		TableDataChange();
	}
}

BOOL CDBListCtrl::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL nRes = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if(nRes)
	{
		CRect r(rect);
		r.DeflateRect(1, 1);
		if(nRes = m_Ctrl.Create(dwStyle, r, this, 1))
			m_Ctrl.SetFont(GetFont()); 
	}
	return nRes;
}

void CDBListCtrl::OnPaint() 
{
	if(IsWindow(m_Ctrl.GetSafeHwnd()))
		m_Ctrl.UpdateWindow();
}


/////////////////////////////////////////////////////////////////////////////
// CDTXDBListCtrl

CDTXDBListCtrl::CDTXDBListCtrl()
{
	m_UseControlColors = m_GotFocus =  m_TimerSet = false;
	m_DrawShadow = true;
	m_ShadowSize = 5;
	
	m_ShadowColor = GetSysColor(COLOR_BTNSHADOW) | 0x80000000;
	m_borderColor = RGB(192, 0, 255);
	m_FocusColor = RGB(192, 0, 255);
	m_ControlColor = RGB(255, 255, 255);
	m_FocusTextColor = RGB(0xFF, 0xFF, 0x00);
	m_TextColor  = RGB(0, 0, 0);
}

BEGIN_MESSAGE_MAP(CDTXDBListCtrl, CDBListCtrl)
	//{{AFX_MSG_MAP(CDTXDBListCtrl)
	ON_WM_PAINT()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CDTXDBListCtrl::OnPaint()
{
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
	if(IsWindow(m_Ctrl.GetSafeHwnd()))
		m_Ctrl.UpdateWindow();
}

void CDTXDBListCtrl::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}

void CDTXDBListCtrl::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDBListCtrl::OnShowWindow(bShow, nStatus);
}

BOOL CDTXDBListCtrl::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext)
{
	BOOL nRes = CDBListCtrl::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if(nRes)
	{
		m_Ctrl.SetBackColor(m_ControlColor);
		m_Ctrl.SetBkSelectedColor(m_FocusColor);
		m_Ctrl.SetBkSelectedNoFocusColor(m_FocusColor);
		m_Ctrl.SetTextColor(m_TextColor);
		m_Ctrl.SetTextSelectedColor(m_FocusTextColor);
		m_Ctrl.SetTextSelectedNoFocusColor(m_FocusTextColor);
	}
	return nRes;
}

void CDTXDBListCtrl::PreSubclassWindow() 
{
	CDBListCtrl::PreSubclassWindow();
	m_Ctrl.SetBackColor(m_ControlColor);
	m_Ctrl.SetBkSelectedColor(m_FocusColor);
	m_Ctrl.SetBkSelectedNoFocusColor(m_FocusColor);
	m_Ctrl.SetTextColor(m_TextColor);
	m_Ctrl.SetTextSelectedColor(m_FocusTextColor);
	m_Ctrl.SetTextSelectedNoFocusColor(m_FocusTextColor);
}
