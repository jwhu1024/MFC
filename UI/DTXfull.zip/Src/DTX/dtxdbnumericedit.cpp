// dtxdbnumericedit.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdbnumericedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBNumericEdit

CDTXDBNumericEdit::CDTXDBNumericEdit()
{
}

CDTXDBNumericEdit::~CDTXDBNumericEdit()
{
}


BEGIN_MESSAGE_MAP(CDTXDBNumericEdit, CDBNumericEdit)
	//{{AFX_MSG_MAP(CDTXDBNumericEdit)
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBNumericEdit message handlers
/*
void CDTXDBNumericEdit::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
			{
				SetWindowText(m_FieldText);
				Invalidate();
			}
		}
	}
}

void CDTXDBNumericEdit::TableClosed()
{
	if(GetSafeHwnd())
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
}

void CDTXDBNumericEdit::TableOpened()
{
	if(GetSafeHwnd())
	{
		EnableWindow();
		TableDataChange();
	}
}
*/

void CDTXDBNumericEdit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDBNumericEdit::OnShowWindow(bShow, nStatus);
}

void CDTXDBNumericEdit::DrawBorder(bool fHot)
{
	CDTXWndBase::DrawBorder(fHot, this);
}

void CDTXDBNumericEdit::OnPaint() 
{
	Default();
	if (m_GotFocus) 
		DrawBorder();
	else 
		DrawBorder(false);
}

void CDTXDBNumericEdit::OnSetFocus(CWnd* pOldWnd) 
{
	CDBNumericEdit::OnSetFocus(pOldWnd);
	m_GotFocus = true;
	Invalidate();
}

void CDTXDBNumericEdit::OnKillFocus(CWnd* pNewWnd) 
{
	CDBNumericEdit::OnKillFocus(pNewWnd);
	m_GotFocus = false;
	Invalidate();
}

void CDTXDBNumericEdit::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_GotFocus) 
	{
		if (!m_TimerSet) 
		{
			DrawBorder();
			SetTimer(1, 10, NULL);
			m_TimerSet = true;
		}
	}

	CDBNumericEdit::OnMouseMove(nFlags, point);
}

void CDTXDBNumericEdit::OnTimer(UINT nIDEvent) 
{
	POINT pt;
	GetCursorPos(&pt);
	CRect rcItem;
	GetWindowRect(&rcItem);

	// if the mouse cursor within the control?
	if(!rcItem.PtInRect(pt)) 
	{
		KillTimer(1);
		m_TimerSet = false;
		if (!m_GotFocus) 
			DrawBorder(false);
		else
			DrawBorder();
		return;
	}
	CDBNumericEdit::OnTimer(nIDEvent);
}

BOOL CDTXDBNumericEdit::OnEraseBkgnd(CDC* pDC) 
{
	DWORD dwStyle = GetStyle();
	CRect rClient;
	BOOL  bStatus = false;

	if(m_UseControlColors && 
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		GetClientRect(&rClient);
		if(GetFocus() == this)
			pDC->FillSolidRect(rClient, m_FocusColor);
		else
			pDC->FillSolidRect(rClient, m_ControlColor);

	}
	else
	{
		bStatus = CDBNumericEdit::OnEraseBkgnd( pDC );
	}
	return( bStatus );
}

HBRUSH CDTXDBNumericEdit::CtlColor(CDC* pDC, UINT nCtlColor)
{
	DWORD	dwStyle = GetStyle();

	if(m_UseControlColors &&
		(!(dwStyle & WS_DISABLED)) && 
		(!(dwStyle & ES_READONLY)))
	{
		m_BackBrush.DeleteObject();
		if(m_GotFocus)
		{
			pDC->SetTextColor(m_FocusTextColor);
			pDC->SetBkColor(m_FocusColor);
			m_BackBrush.CreateSolidBrush(m_FocusColor);
		}
		else
		{
			pDC->SetTextColor(m_TextColor);
			pDC->SetBkColor(m_ControlColor);
			m_BackBrush.CreateSolidBrush(m_ControlColor);
		}
		return((HBRUSH) m_BackBrush);
	}
	return(NULL);
}
