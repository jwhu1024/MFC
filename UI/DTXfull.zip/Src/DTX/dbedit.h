#if !defined(AFX_DBEDIT_H__95E95434_2F69_481E_8B38_FA2E0920FC08__INCLUDED_)
#define AFX_DBEDIT_H__95E95434_2F69_481E_8B38_FA2E0920FC08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbedit.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBEdit window

class CDBEdit : public CEdit, public CDTXEditBase
{
// Construction
public:
	CDBEdit();
// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBEdit)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnKillfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBEDIT_H__95E95434_2F69_481E_8B38_FA2E0920FC08__INCLUDED_)
