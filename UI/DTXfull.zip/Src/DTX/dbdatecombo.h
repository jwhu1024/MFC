#if !defined(AFX_DBDATECOMBO_H__07E11BC9_58A9_43C7_B489_04866F200CE5__INCLUDED_)
#define AFX_DBDATECOMBO_H__07E11BC9_58A9_43C7_B489_04866F200CE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbdatecombo.h : header file
//

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

#include "dtxdatecombo.h"

/////////////////////////////////////////////////////////////////////////////
// CDBDateCombo window

class CDBDateCombo : public CDateComboBox, public CDTXEditBase
{
protected:
	virtual void TableDataChange();
// Construction
public:
	CDBDateCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBDateCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBDateCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBDateCombo)
	afx_msg void OnKillfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

class CDTXDBDateCombo : public CDTXDateComboBox, public CDTXEditBase
{
protected:
	virtual void TableDataChange();
// Construction
public:
	CDTXDBDateCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBDateCombo)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTXDBDateCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDTXDBDateCombo)
	afx_msg void OnKillfocus();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBDATECOMBO_H__07E11BC9_58A9_43C7_B489_04866F200CE5__INCLUDED_)
