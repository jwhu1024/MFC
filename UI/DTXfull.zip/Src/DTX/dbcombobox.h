#if !defined(AFX_DBCOMBOBOX_H__7D8A9804_8483_4B1D_9753_A3C852929939__INCLUDED_)
#define AFX_DBCOMBOBOX_H__7D8A9804_8483_4B1D_9753_A3C852929939__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbcombobox.h : header file
//
#include "FlatComboBox.h"
#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBComboBox window

class CDBComboBox : public CFlatComboBox, public CDTXEditBase
{
// Construction
public:
	CDBComboBox();

// Attributes
public:
	virtual void TableDataChange();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBComboBox)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBComboBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBComboBox)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBCOMBOBOX_H__7D8A9804_8483_4B1D_9753_A3C852929939__INCLUDED_)
