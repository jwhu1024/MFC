// dbedit.cpp : implementation file
//

#include "stdafx.h"
#include "dbedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBEdit

CDBEdit::CDBEdit()
	: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBEdit::~CDBEdit()
{
}

BEGIN_MESSAGE_MAP(CDBEdit, CEdit)
	//{{AFX_MSG_MAP(CDBEdit)
	ON_WM_SHOWWINDOW()
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBEdit message handlers

void CDBEdit::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CEdit::OnShowWindow(bShow, nStatus);
	if(!m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
			SetWindowText(DTXFieldToString(nField));
		else
			SetWindowText(_T(""));
		if(nField->m_Kind == dtxfkCalculated)
			EnableWindow(false);
	}
	else
	{
		SetWindowText(_T(""));
		EnableWindow(false);
	}
}

void CDBEdit::OnKillfocus() 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText;
			GetWindowText(m_WinText);
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
	}	
}
