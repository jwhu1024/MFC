#if !defined(AFX_DBLABEL_H__B23CADA1_D6A2_4338_B995_FBA553E0D8F3__INCLUDED_)
#define AFX_DBLABEL_H__B23CADA1_D6A2_4338_B995_FBA553E0D8F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dblabel.h : header file
//

#include "Label.h"

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBLabel window

class CDBLabel : public CLabel, public CDTXEditBase
{
// Construction
public:
	CDBLabel();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBLabel)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBLabel();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBLabel)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	virtual void TableDataChange();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBLABEL_H__B23CADA1_D6A2_4338_B995_FBA553E0D8F3__INCLUDED_)
