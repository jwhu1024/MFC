// dtxdaotable.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdaotable.h"
#include "field.h"
#include "tabledef.h"
#include "index.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDAOTable

IMPLEMENT_DYNAMIC(CDTXDAOTable, CDaoRecordset)

CDTXDAOTable::CDTXDAOTable(CWnd* nOwner, CString nDatabaseName, CDaoDatabase* pdb)
	: CDaoRecordset(pdb),
	  CDTXTable(nOwner, nDatabaseName) 
{
	m_DaoTableName.Empty();
	m_DaoSQL.Empty();
}

CDTXDAOTable::CDTXDAOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName)
	: CDaoRecordset(NULL),
	  CDTXTable(nOwner, nDatabaseName) 
{
	m_DaoTableName = nTableName;
	m_DaoSQL.Format(_T("Select * from [%s]"), nTableName);
}

CDTXDAOTable::~CDTXDAOTable()
{
	if(CDaoRecordset::IsOpen())
		CDaoRecordset::Close();
}

CString CDTXDAOTable::GetDefaultDBName()
{
	return GetTableName();
}

CString CDTXDAOTable::GetDefaultSQL()
{
	return m_DaoSQL;
}

void CDTXDAOTable::DoFieldExchange(CDaoFieldExchange* pFX)
{
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	CString		cFieldName;
	for(int i = 0; i < m_FieldArray.GetSize(); i++ )
	{
		DTXField* nField = m_FieldArray[i];
		cFieldName.Format(_T("[%s]"), nField->m_FieldName );
		switch(nField->m_Type)
		{
			case	dtxfBool:
					DFX_Bool(pFX, cFieldName, (int&) nField->boolVal);
					break;

			case	dtxfInteger:
					DFX_Long( pFX, cFieldName, (long&) nField->intVal);
					break;

			case	dtxfLong:
					DFX_Long( pFX, cFieldName, nField->longVal);
					break;
	
			case	dtxfFloat:
					DFX_Single(pFX, cFieldName, nField->fltVal);
					break;
		
			case	dtxfDouble:
					DFX_Double(pFX, cFieldName, nField->dblVal);
					break;

			case	dtxfDateTime:
			case	dtxfTime:
			case	dtxfDate:
					DFX_DateTime(pFX, cFieldName, *nField->date);
					break;

			case	dtxfCurrency:
					DFX_Text(pFX, cFieldName, *nField->cyVal, nField->m_Length);
					break;

			case	dtxfString: 
					DFX_Text(pFX, cFieldName, *nField->strVal, nField->m_Length);
					break;

			case	dtxfBlob:
					DFX_LongBinary(pFX, cFieldName, *nField->blobVal);
					break;

			default:
				ASSERT( FALSE );
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDAOTable diagnostics

#ifdef _DEBUG
void CDTXDAOTable::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CDTXDAOTable::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

BOOL CDTXDAOTable::intClose()
{
	CDaoRecordset::Close();
	return TRUE;
}

void CDTXDAOTable::intGoFirst()
{
	CDaoRecordset::MoveFirst();
}

void CDTXDAOTable::intGoLast()
{
	CDaoRecordset::MoveLast();
}

void CDTXDAOTable::intGoNext()
{
	CDaoRecordset::MoveNext();
}

void CDTXDAOTable::intGoPrev()
{
	CDaoRecordset::MovePrev();
}

UINT CDTXDAOTable::intGetRecordCount()
{
	return CDaoRecordset::GetRecordCount();
}

void CDTXDAOTable::intGo(UINT nRec)
{
	CDaoRecordset::SetAbsolutePosition(nRec);
}

UINT CDTXDAOTable::intGetRecordPos()
{
	return CDaoRecordset::GetAbsolutePosition();
}

void CDTXDAOTable::intGetCurrentRecord()
{
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind == dtxfkCalculated) continue;
		COleVariant ov;
		ov.Clear();
		GetFieldValue(i, ov);
		if(ov.vt != VT_NULL)
			VariantToDTXField(ov, nField);
		else
			nField->SetValueToNull();
	}
}

BOOL CDTXDAOTable::intOpen()
{
	CDaoRecordset::Open(dbOpenDynaset, m_DaoSQL); //, dbInconsistent);
	if(!CDaoRecordset::IsBOF() || !CDaoRecordset::IsEOF() || !CDaoRecordset::IsDeleted())
	{
		CDaoRecordset::MoveLast();
		CDaoRecordset::MoveFirst();
	}
	return TRUE;
}	

void CDTXDAOTable::intUpdateRecord()
{
	Edit();
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind ==  dtxfkCalculated) continue;
		CString str = DTXFieldToString(nField);
		if(nField->m_Type == dtxfBlob)
			SetFieldValue(nField->m_FieldName, DTXFieldToVariant(nField));
		else if(!str.IsEmpty())
			SetFieldValue(nField->m_FieldName, (LPCTSTR) str);
		else
		{
			COleVariant ov;
			ov.Clear();
			SetFieldValue(i, ov);
		}
	}
	if(CanUpdate())
		Update();
}

void CDTXDAOTable::intInsertRecord()
{
	if(CanUpdate())
	{
		AddNew();
		for(int i = 0; i < GetTableFieldCount(); i++)
		{
			DTXField* nField = m_FieldArray.GetAt(i);
			if(nField->m_Kind ==  dtxfkCalculated) continue;
			COleVariant ov;
			ov.Clear();
			ov.vt = VT_NULL;
			SetFieldValue(i, ov);
			nField->SetValueToNull();
		}
		Update();
		MoveLast();
	}
}

void CDTXDAOTable::intDeleteRecord()
{
	CDaoRecordset::Delete();
}

void CDTXDAOTable::ReadFieldArray()
{
	m_FieldArray.FreeAll();
	int strt = 0;
	for(int i = 0; i < GetFieldCount(); i++)
	{
		CDaoFieldInfo dfi;
		DTXFieldType dtxf;
		GetFieldInfo(i, dfi);
		switch(dfi.m_nType)
		{
			case dbBoolean: dtxf = dtxfBool; break;
			
			case dbByte   : dtxf = dtxfInteger; break;
			
			case dbInteger: 
			case dbLong   : 
			case dbDecimal: 
			case dbNumeric: dtxf = dtxfInteger; break;
			
			case dbBigInt : dtxf = dtxfInteger; break;

			case dbCurrency: dtxf = dtxfCurrency; break;
			
			case dbSingle :
			case dbFloat  : dtxf = dtxfFloat; break;

			case dbDouble : dtxf = dtxfFloat; break;

			case dbChar   : dtxf = dtxfString; break;

			case dbMemo   : dtxf = dtxfMemo; break;

			case dbText   : dtxf = dtxfString; break;

			case dbGUID   : dtxf = dtxfString; break;
			
			case dbDate   : dtxf = dtxfDate; break;
			case dbTime   : dtxf = dtxfTime; break;
			case dbTimeStamp: dtxf = dtxfDateTime; break;

			case dbBinary : 
			case dbVarBinary: 
			case dbLongBinary: dtxf = dtxfBlob; break;
		}
		AddField(NewField(dtxf, dtxfkData, dfi.m_strName, strt, dfi.m_lSize, dfi.m_nType));
		strt += dfi.m_lSize;
	}
}

//////////////////////////////////////////////////////////////////////
////// CDAOTableCreator

CDAOTableCreator::CDAOTableCreator()
{ 
}

CDAOTableCreator::~CDAOTableCreator()
{
	FreeFieldList();
	if(m_Database.IsOpen())
		m_Database.Close();
}

void CDAOTableCreator::FreeFieldList()
{
	m_FieldArray.RemoveAll();
	m_IndexArray.RemoveAll();
}

void CDAOTableCreator::CreateDatabase(LPCTSTR lpszName, LPCTSTR lpszLocale, int dwOptions)
{
	if(!FileExist(lpszName))
		m_Database.Create(lpszName, lpszLocale, dwOptions);
	else
		m_Database.Open(lpszName);
}

void CDAOTableCreator::CreateTable(LPCTSTR lpszName, long lAttributes, LPCTSTR lpszSrcTable, LPCTSTR lpszConnect)
{
	CDaoTableDef m_TableDef(&m_Database);
	if(!IsExistentTable(&m_Database, lpszName))
		m_TableDef.Create(lpszName, lAttributes, lpszSrcTable, lpszConnect);
	else
		m_TableDef.Open(lpszName);
	BOOL m_Create = FALSE;
	if(m_FieldArray.GetSize() > 0)
	{
		for(int i = 0; i < m_FieldArray.GetSize(); i++)
		{
			CDaoFieldInfo nField = m_FieldArray[i];
			if (!IsExistentField(&m_TableDef, nField.m_strName))
			{
				createNewField(&m_TableDef, &nField);
				m_Create = TRUE;
			}
		}
		for(i = 0; i < m_IndexArray.GetSize(); i++)
		{
			CDaoIndexInfo nIndex = m_IndexArray[i];
			if(!IsExistentIndex(&m_TableDef, nIndex.m_strName))
			{
				createNewIndex(&m_TableDef, &nIndex);
				m_Create = TRUE;
			}
		}
	}
	if(m_Create)
		m_TableDef.Append();
	if(m_TableDef.IsOpen())
		m_TableDef.Close();
}

void CDAOTableCreator::AddField(CDaoFieldInfo nField)
{
	nField.m_strDefaultValue = _T("");
	nField.m_bRequired = FALSE;
	nField.m_lAttributes = dbUpdatableField;
#if _MFC_VER == 0x400
	nField.m_bAllowZeroLength = TRUE;
#else
	nField.m_bAllowZeroLength = FALSE;
#endif;
	nField.m_strValidationRule = _T("");
	nField.m_strValidationText = _T("");

	nField.m_nOrdinalPosition = m_FieldArray.GetSize() + 1;

	switch(nField.m_nType)
	{
		case dbBoolean:
		case dbByte   :	nField.m_lSize = 1;
						nField.m_lAttributes &= ~dbVariableField;
						nField.m_lAttributes |= dbFixedField;
						break;

		case dbInteger: nField.m_lSize = 2;
						nField.m_lAttributes &= ~dbVariableField;
						nField.m_lAttributes |= dbFixedField;
						break;

		case dbLong:
		case dbSingle:  nField.m_lSize = 4;
						nField.m_lAttributes &= ~dbVariableField;
						nField.m_lAttributes |= dbFixedField;
						break;

		case dbCurrency:
		case dbDate:
		case dbDouble:  nField.m_lSize = 8;
						nField.m_lAttributes &= ~dbVariableField;
						nField.m_lAttributes |= dbFixedField;
						break;

		case dbText:    nField.m_lAttributes &= ~dbFixedField;
						nField.m_lAttributes |= dbVariableField;
						break;

		case dbLongBinary:nField.m_lAttributes &= ~dbFixedField;
						nField.m_lAttributes |= dbVariableField;
						break;

		case dbMemo:   nField.m_lAttributes &= ~dbFixedField;
					   nField.m_lAttributes |= dbVariableField;
					   break;

	} // end of switch
	m_FieldArray.Add(nField);
}

void CDAOTableCreator::AddField(LPCTSTR lpszName, short nType, long lSize, long lAttributes)
{
	CDaoFieldInfo nField;
	nField.m_strName = lpszName;
	nField.m_nType   = nType;
	nField.m_lSize	 = lSize;
	nField.m_lAttributes = lAttributes;

	AddField(nField);
}

void CDAOTableCreator::AddIndex(CDaoIndexInfo nIndex)
{
	m_IndexArray.Add(nIndex);
}

void CDAOTableCreator::AddIndex(CString nName, BOOL nUnique, BOOL nRequired, BOOL nIgnoreNulls)
{
	CDaoIndexInfo nIndex;
	if(nUnique)
		nRequired = TRUE;
	nIndex.m_strName = nName;
	nIndex.m_bRequired = nRequired;
	nIndex.m_bUnique = nUnique;
	nIndex.m_bIgnoreNulls = nIgnoreNulls;
	AddIndex(nIndex);
}
