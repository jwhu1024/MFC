// dbrichedit.cpp : implementation file
//

#include "stdafx.h"
#include "dbrichedit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBRichEdit

CDBRichEdit::CDBRichEdit()
:CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDBRichEdit::~CDBRichEdit()
{
}


BEGIN_MESSAGE_MAP(CDBRichEdit, CAutoRichEditCtrl)
	//{{AFX_MSG_MAP(CDBRichEdit)
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDBRichEdit message handlers

void CDBRichEdit::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText = GetRTF();
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
		if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
	}

	CAutoRichEditCtrl::OnKillFocus(pNewWnd);
}

void CDBRichEdit::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText = GetRTF();
			if(m_WinText != m_FieldText)
				SetRTF(m_FieldText);
		}
		if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDTXDBRichEdit

CDTXDBRichEdit::CDTXDBRichEdit()
:CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBRichEdit::~CDTXDBRichEdit()
{
}
 

BEGIN_MESSAGE_MAP(CDTXDBRichEdit, CDTXRichEdit)
	//{{AFX_MSG_MAP(CDTXDBRichEdit)
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTXDBRichEdit message handlers

void CDTXDBRichEdit::OnKillFocus(CWnd* pNewWnd) 
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText = GetRTF();
			if(m_WinText != m_FieldText)
				SetFieldValue(m_WinText);
		}
		if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
	}
	CDTXRichEdit::OnKillFocus(pNewWnd);
}

void CDTXDBRichEdit::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CString m_FieldText = DTXFieldToString(nField);
			CString m_WinText = GetRTF();
			if(m_WinText != m_FieldText)
				SetRTF(m_FieldText);
		}
		if(nField->m_Kind == dtxfkCalculated)
				EnableWindow(false);
	}
}
