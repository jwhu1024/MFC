// dtxdbimage.cpp : implementation file
//

#include "stdafx.h"
#include "dtxdbimage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTXDBImage

CDTXDBImage::CDTXDBImage()
: CDTXEditBase(NULL)
{
	CDTXEditBase::SetOwner(this);
}

CDTXDBImage::~CDTXDBImage()
{
}

BEGIN_MESSAGE_MAP(CDTXDBImage, CDTXImage)
	//{{AFX_MSG_MAP(CDTXDBImage)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDTXDBImage message handlers

void CDTXDBImage::TableDataChange()
{
	if(GetSafeHwnd() && !m_EditField.IsEmpty())
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			ReadFromBLOB();
		}
	}	
}


BOOL CDTXDBImage::ReadFromBLOB()
{
	m_Image.DeleteObject();
	DTXField* nField = GetField();
	if(!nField->blobVal->m_hData || nField->blobVal->m_dwDataLength == 0) 
	{
		Empty();
		return false;
	}
	int BufLen = nField->blobVal->m_dwDataLength;
	LPPICTURE gpPicture;
	HANDLE hMem = GlobalAlloc(GMEM_MOVEABLE, BufLen);
	_ASSERTE(NULL != hMem);
	if (hMem) 
	{
		LPVOID lpMem = GlobalLock(hMem);
		_ASSERTE(NULL != lpMem);
		if (lpMem) 
		{
			memcpy(lpMem, nField->blobVal->m_hData, BufLen);
			GlobalUnlock(hMem);
			// Create an IStream from the data.
			LPSTREAM pstm = NULL;
			if (CreateStreamOnHGlobal(hMem, TRUE, &pstm) == S_OK) 
			{
				if(::OleLoadPicture(pstm, BufLen, FALSE, IID_IPicture, (LPVOID *)&gpPicture) == S_OK)
				{
					pstm->Release();
					OLE_HANDLE m_picHandle;
					gpPicture->get_Handle(&m_picHandle);
					m_Image.Attach((HGDIOBJ) m_picHandle);
					InternalGetSizes();
					Invalidate();
				}
			}
		}
	}
	return TRUE;
}

BOOL CDTXDBImage::LoadBitmap(CString nFile)
{
	if(CDTXImage::LoadBitmap(nFile))
	{
		DTXField* nField = GetField();
		if(nField && !nField->m_FieldName.IsEmpty())
		{
			CFile		fileImage;
			CFileStatus	fileStatus;

			fileImage.Open(nFile, CFile::modeRead);
			fileImage.GetStatus(fileStatus);
        
			nField->blobVal->m_dwDataLength = fileStatus.m_size;
		    nField->blobVal->m_hData = new char[nField->blobVal->m_dwDataLength];
		    fileImage.ReadHuge(nField->blobVal->m_hData, fileStatus.m_size);
			if(m_OwnerTable)
				m_OwnerTable->SetModified(true);
		}
		return true;
	}
	return false;
}
