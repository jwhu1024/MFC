#if !defined(AFX_DBMASKEDEDIT_H__733566DB_C53E_4348_A16B_5B66244D4AE0__INCLUDED_)
#define AFX_DBMASKEDEDIT_H__733566DB_C53E_4348_A16B_5B66244D4AE0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dbmaskededit.h : header file
//

#ifndef __OXMaskedEdit_h__
#include "OXMaskedEdit.h"
#endif

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDBMaskedEdit window

class CDBMaskedEdit : public COXMaskedEdit, public CDTXEditBase
{
// Construction
public:
	CDBMaskedEdit();


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBMaskedEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDBMaskedEdit();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDBMaskedEdit)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBMASKEDEDIT_H__733566DB_C53E_4348_A16B_5B66244D4AE0__INCLUDED_)
