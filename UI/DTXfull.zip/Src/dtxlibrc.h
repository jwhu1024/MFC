//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DTXLib.rc
//
#define IDS_FIRST                       102
#define IDS_PREV                        104
#define IDS_NEXT                        105
#define IDS_LAST                        106
#define IDS_UPDATE                      107
#define IDS_ADD                         108
#define IDS_DELETE                      109
#define IDS_GO                          110
#define IDD_CALCULATORDIALOG            130
#define IDB_NAVIGATOR                   131

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
