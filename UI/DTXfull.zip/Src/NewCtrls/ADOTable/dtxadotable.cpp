#include "stdafx.h"
#include "DTXADOTable.h"

BOOL CInitCom::m_InitCom = false;

#define DSN_CONNECT_STRING _T("Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=%s;" \
				"Mode=ReadWrite;Extended Properties=\"\";Jet OLEDB:" \
				"System database=\"\";Jet OLEDB:Registry Path=\"\";Jet OLEDB:Database Password=\"\"\
				"";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global"\
				" Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:"\
				"New Database Password=\"\";Jet OLEDB:Create System Database=False;Jet OLEDB:"\
				"Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact"\
				" Without Replica Repair=False;Jet OLEDB:SFP=False")

void DumpComError(_com_error & e)
{
	_bstr_t bstrSource(e.Source());
	_bstr_t bstrDescription(e.Description());
	CString str;
	str.Format("\tCode = %08lx", e.Error());
	str += " Msg: ";	str += e.ErrorMessage();
	str += " Source: "; str += bstrSource;
	str += " Description: "; str += bstrDescription;
	AfxMessageBox(str);
}

CDTXADOTable::CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName)
	: CDTXTable(nOwner, nDatabaseName) 
{
	m_pConnection = NULL;
	m_pRecordset = NULL;
	m_ADOSQL.Format(_T("select * from [%s]"), nTableName);
	m_AutoDisconnect = true;
	m_ConnectionStr.Empty();
	m_UserName.Empty();
	m_Password.Empty();
	m_CursorType = adOpenKeyset;
	m_LockType = adLockBatchOptimistic;
	m_OpenOptions = -1;
}

CDTXADOTable::~CDTXADOTable()
{
	if(m_pRecordset)
	{
		if(TableOpened())
			m_pRecordset->Close();
		m_pRecordset->Release();
		m_pRecordset = NULL;
	}

	if(m_AutoDisconnect)
		if(m_pConnection)
		{
			m_pConnection->Close();
			m_pConnection->Release();
			m_pConnection = NULL;
		}
}

void CDTXADOTable::CreateConnection()
{
	HRESULT hr = m_pConnection.CreateInstance(__uuidof(Connection));
	if (FAILED(hr))
	{
		CString strErr;	
		strErr.Format(_T("Connection Olu�turma Hatas� = %x"), hr);
		AfxMessageBox(strErr);	
		exit(-1);
	}
	if(m_ConnectionStr.IsEmpty())
		m_ConnectionStr.Format(_T("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=%s;"), GetTableName());

	_bstr_t bstrConnectionString(m_ConnectionStr);
	m_pConnection->ConnectionString = bstrConnectionString;
	_bstr_t bstr_empty (L"");

	m_pConnection->Open(bstr_empty, bstr_empty, bstr_empty, -1);
		//	m_UserName.AllocSysString(), m_Password.AllocSysString(), -1);
}

BOOL CDTXADOTable::intOpen() 
{
	if(m_pRecordset)
	{
		AfxMessageBox(_T("Recordset Zaten Kullan�l�yor"));
		return true;
	}

	if(m_pConnection == NULL)
		CreateConnection();
	if(m_pConnection == NULL)
	{
		AfxMessageBox(_T("Connection Olu�turulamad�"));
		exit(-1);
	}

	try
	{
		HRESULT hr = m_pRecordset.CreateInstance(__uuidof(Recordset));
		if (FAILED(hr))
		{
			CString strErr;	
			strErr.Format(_T("Recordset Olu�turma Hatas� = %x"), hr);
			AfxMessageBox(strErr);	
			return false;
		}
		m_pRecordset->PutRefActiveConnection(m_pConnection);
		m_pRecordset->Open(m_ADOSQL.AllocSysString(), vtMissing, 
			m_CursorType, m_LockType, m_OpenOptions);
	}
	catch( _com_error &e)
	{
		DumpComError(e);
		return false;
	}

	return true;
}

BOOL CDTXADOTable::intClose() 
{
	if(TableOpened())
		m_pRecordset->Close();
	return true;
}

BOOL CDTXADOTable::TableOpened() 
{
	if(m_pRecordset)
		try
		{
			return m_pRecordset->GetState() != adStateClosed;
		}
		catch( _com_error &e)
		{
			DumpComError(e);
			return false;
		}

	return false;
}

void CDTXADOTable::intDeleteRecord() 
{
	if(m_pRecordset)
	{
		try
		{
			if(m_pRecordset->Delete(adAffectCurrent) != S_OK)
				return;

			if(m_pRecordset->Update() != S_OK)
				return;
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
	}
}

void CDTXADOTable::intGoFirst() 
{
	if(m_pRecordset)
		try
		{
			if(m_pRecordset->BOF != VARIANT_FALSE )
				m_pRecordset->MoveFirst();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
}

void CDTXADOTable::intGoLast() 
{
	if(m_pRecordset)
		try
		{
			m_pRecordset->MoveLast();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
}

void CDTXADOTable::intGoNext() 
{
	if(m_pRecordset)
		try
		{
			if(m_pRecordset->EOF == VARIANT_FALSE )
				m_pRecordset->MoveNext();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
}

void CDTXADOTable::intGoPrev() 
{
	if(m_pRecordset)
		try
		{
			if(m_pRecordset->BOF == VARIANT_FALSE )
				m_pRecordset->MovePrevious();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
}

void CDTXADOTable::intGo(UINT nRec) 
{
	if(m_pRecordset)
		try
		{
			m_pRecordset->PutAbsolutePosition((enum PositionEnum) nRec);
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
}

UINT CDTXADOTable::intGetRecordCount() 
{
	if(m_pRecordset)
		try
		{
			return m_pRecordset->GetRecordCount();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
	return 0;
}

UINT CDTXADOTable::intGetRecordPos() 
{
	if(m_pRecordset)
		try
		{
			return (UINT) m_pRecordset->GetAbsolutePosition();
		}
		catch( _com_error &e)
		{
			DumpComError(e);
		}
	return 0;
}

BOOL CDTXADOTable::intIsEOF() 
{
	if(m_pRecordset)
		try
		{
			return m_pRecordset->EOF == VARIANT_TRUE;
		}
		catch( _com_error &e)
		{
			DumpComError(e);
			return false;
		}
	return true;
}

BOOL CDTXADOTable::intIsBOF() 
{
	if(m_pRecordset)
		try
		{
			return m_pRecordset->BOF == VARIANT_TRUE;
		}
		catch( _com_error &e)
		{
			DumpComError(e);
			return false;
		}
	return true;
}

void CDTXADOTable::intInsertRecord() 
{
	m_pRecordset->AddNew();
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind ==  dtxfkCalculated) continue;

		nField->SetValueToNull();
		COleVariant ov;
		ov.Clear();
		ov.vt = VT_NULL;
		SetFieldValue(nField->m_FieldName, ov);
	}
	try
	{
		m_pRecordset->UpdateBatch(adAffectCurrent);	
		m_pRecordset->Requery(0);
		GoLast();
	} 
	catch( _com_error &e)
	{
		m_pRecordset->CancelUpdate();
		DumpComError(e);
	}
}

void CDTXADOTable::SetFieldValue(int nIndex, COleVariant &varValue)
{
	_variant_t vtIndex;
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;

	try
	{
		m_pRecordset->Fields->GetItem(vtIndex)->Value = varValue;
	} 
	catch( _com_error &e)
	{
		DumpComError(e);
	}
}

void CDTXADOTable::SetFieldValue(LPCTSTR lpszName, COleVariant &varValue)
{
	_variant_t vtValue(varValue);
	try
	{
		m_pRecordset->Fields->GetItem(lpszName)->Value = vtValue;
	} 
	catch( _com_error &e)
	{
		DumpComError(e);
	}
}

void CDTXADOTable::GetFieldValue(LPCTSTR lpszName, COleVariant& varValue)
{
	try
	{
		varValue = m_pRecordset->Fields->GetItem(lpszName)->Value;
	} 
	catch( _com_error &e)
	{
		DumpComError(e);
	}
}

void CDTXADOTable::GetFieldValue(int nIndex, COleVariant& varValue)
{
	_variant_t vtFld;
	_variant_t vtIndex;

	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		varValue = m_pRecordset->Fields->GetItem(vtIndex)->Value;
	} 
	catch( _com_error &e)
	{
		DumpComError(e);
	}
}

void CDTXADOTable::intUpdateRecord() 
{
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind ==  dtxfkCalculated) continue;
		COleVariant ov;

		if(nField->m_Type == dtxfString)
		{
			CString str = DTXFieldToString(nField);
			if(str.IsEmpty())
				str = _T(" ");
		
			_variant_t vtFld;
			vtFld.vt = VT_BSTR;
			vtFld.bstrVal = _bstr_t(str);
	
			try
			{
				m_pRecordset->Fields->GetItem((LPCTSTR) nField->m_FieldName)->Value = _bstr_t(vtFld);
			} 
			catch( _com_error &e)
			{
				DumpComError(e);
			}
		}
		else
		{
			ov = DTXFieldToVariant(nField);
			SetFieldValue(nField->m_FieldName, ov);
		}
	}

	try
	{
		m_pRecordset->Update();
	} 
	catch( _com_error &e)
	{
		m_pRecordset->CancelUpdate();
		DumpComError(e);
	}
}

void CDTXADOTable::intGetCurrentRecord() 
{
	for(int i = 0; i < GetTableFieldCount(); i++)
	{
		DTXField* nField = m_FieldArray.GetAt(i);
		if(nField->m_Kind == dtxfkCalculated) continue;
		COleVariant ov;
		ov.Clear();
		GetFieldValue(nField->m_FieldName, ov);
		if(ov.vt != VT_NULL)
		{
			if(nField->m_Type == dtxfString)
			{
				CString n(ov.bstrVal);
				nField->strVal->Format(_T("%s"), n);

			}
			else
			 VariantToDTXField(ov, nField);
		}
		else
			nField->SetValueToNull();
	}
}

bool CDTXADOTable::GetFieldInfo(LPCTSTR lpFieldName, CADOFieldInfo* fldInfo)
{
	_variant_t vtFld;
	
	try
	{
		strcpy(fldInfo->m_strName, (LPCTSTR)m_pRecordset->Fields->GetItem(lpFieldName)->GetName());
		fldInfo->m_lSize = m_pRecordset->Fields->GetItem(lpFieldName)->GetActualSize();
		fldInfo->m_lDefinedSize = m_pRecordset->Fields->GetItem(lpFieldName)->GetDefinedSize();
		fldInfo->m_nType = m_pRecordset->Fields->GetItem(lpFieldName)->GetType();
		fldInfo->m_lAttributes = m_pRecordset->Fields->GetItem(lpFieldName)->GetAttributes();
	}
	catch( _com_error &e)
	{
		DumpComError(e);
		return false;
	}
	return true;
}

bool CDTXADOTable::GetFieldInfo(int nIndex, CADOFieldInfo* fldInfo)
{
	_variant_t vtFld;
	_variant_t vtIndex;
	
	vtIndex.vt = VT_I2;
	vtIndex.iVal = nIndex;
	
	try
	{
		strcpy(fldInfo->m_strName, (LPCTSTR)m_pRecordset->Fields->GetItem(vtIndex)->GetName());
		fldInfo->m_lSize = m_pRecordset->Fields->GetItem(vtIndex)->GetActualSize();
		fldInfo->m_lDefinedSize = m_pRecordset->Fields->GetItem(vtIndex)->GetDefinedSize();
		fldInfo->m_nType = m_pRecordset->Fields->GetItem(vtIndex)->GetType();
		fldInfo->m_lAttributes = m_pRecordset->Fields->GetItem(vtIndex)->GetAttributes();
	}
	catch( _com_error &e)
	{
		DumpComError(e);
		return false;
	}
	return true;
}

void CDTXADOTable::ReadFieldArray() 
{
	if(m_pRecordset == NULL)
		return;

	m_FieldArray.FreeAll();
	int strt = 0;
	for(int i = 0; i < m_pRecordset->Fields->Count; i++)
	{
		CADOFieldInfo afi;
		GetFieldInfo(i, &afi);
		DTXFieldType dtxf;
		switch(afi.m_nType)
		{
			case adTinyInt:
			case adSmallInt:
			case adInteger:
			case adBigInt:
			case adUnsignedTinyInt:
			case adUnsignedSmallInt:
			case adUnsignedInt:
			case adUnsignedBigInt:
			case adDecimal:
			case adNumeric:
				dtxf = dtxfInteger; break;

			case adSingle:
			case adDouble:
				dtxf = dtxfFloat; break;

			case adCurrency:
				dtxf = dtxfCurrency; break;

			case adBoolean:
				dtxf = dtxfBool; break;
		
			case adDate:
			case adDBDate:
				dtxf = dtxfDate; break;

			case adDBTime:
				dtxf = dtxfTime; break;

			case adDBTimeStamp:
			case adFileTime:
				dtxf = dtxfDateTime; break;

			case adBSTR:
			case adChar:
		    case adVarChar:
			case adLongVarChar:
		    case adWChar:
			case adVarWChar:
			case adLongVarWChar:
			case adIDispatch:
		    case adGUID:
				dtxf = dtxfString; break;
    
			case adBinary:
			case adVarBinary:
			case adLongVarBinary:
				dtxf = dtxfBlob; break;
		}
		AddField(NewField(dtxf, dtxfkData, afi.m_strName, strt, afi.m_lSize, afi.m_nType));
		strt += afi.m_lSize;
	}
}
