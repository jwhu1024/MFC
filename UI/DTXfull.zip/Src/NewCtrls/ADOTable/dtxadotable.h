#if !defined(AFX_DTXADOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_)
#define AFX_DTXADOTABLE_H__92C5D3CC_0A12_4896_B6F5_DC1212E6F495__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// dtxdaotable.h : header file
//

#undef EOF
#import <msado15.dll> rename_namespace("ado15")
using namespace ado15;

#if !defined(AFX_DTXTABLE_H_INCLUDED_)
#include "DTXTable.h"
#endif

#ifndef _ICRSINT_H_
#include <icrsint.h>
#endif

#ifndef __AFXDISP_H__
#include <afxdisp.h>
#endif

#ifndef __AFXPRIV_H__
#include <afxpriv.h>
#endif

struct CADOFieldInfo
{
	char m_strName[30]; 
	short m_nType;
	long m_lSize; 
	long m_lDefinedSize;
	long m_lAttributes;
	short m_nOrdinalPosition;
	BOOL m_bRequired;   
	BOOL m_bAllowZeroLength; 
	long m_lCollatingOrder;  
};

class CInitCom 
{
public:
	static BOOL m_InitCom;

	CInitCom()
	{
		m_InitCom = false;
		if(!m_InitCom)
		{
			::CoInitialize(NULL); 
			m_InitCom = true;
		}
	}

	~CInitCom()
	{
		if(m_InitCom)
		{
			 ::CoUninitialize(); 
			m_InitCom = false;
		}
	}

};
 

class CDTXADOTable: public CDTXTable
{
	CInitCom m_DTXInitOle;
	CString m_ADOSQL;
	CString m_ConnectionStr;
protected:
	_ConnectionPtr m_pConnection;
	_RecordsetPtr m_pRecordset;

	virtual BOOL intOpen();
	virtual BOOL intClose();

	virtual void ReadFieldArray();
	virtual void intUpdateRecord();
	virtual void intInsertRecord();
	virtual void intDeleteRecord();
	virtual void intGetCurrentRecord();

	virtual void intGoFirst();
	virtual void intGoLast();
	virtual void intGoNext();
	virtual void intGoPrev();
	virtual void intGo(UINT nRec);

	virtual UINT intGetRecordCount();
	virtual UINT intGetRecordPos();

	virtual BOOL intIsEOF();
	virtual BOOL intIsBOF();
	virtual BOOL TableOpened();
public:
	BOOL m_AutoDisconnect;
	CString m_UserName;
	CString m_Password;

	ado15::CursorTypeEnum	m_CursorType;
	ado15::LockTypeEnum		m_LockType;
	long m_OpenOptions;

	CDTXADOTable(CWnd* nOwner, CString nDatabaseName, CString nTableName = _T(""));
	~CDTXADOTable();

	_ConnectionPtr GetConnectionPtr()
	{ return m_pConnection; }

	void SetConnectionPtr(_ConnectionPtr nConnectionPtr)
	{ m_pConnection = nConnectionPtr; }

	_RecordsetPtr GetRecordsetPtr()
	{ return m_pRecordset; }

	CString GetConnectionStr()
	{ return m_ConnectionStr; }

	void SetConnectionStr(CString nStr)
	{ m_ConnectionStr = nStr; }

	CString GetSQLStr()
	{ return m_ADOSQL; }

	void SetSQLStr(CString nStr)
	{ m_ADOSQL = nStr; }

	virtual void SetFieldValue(LPCTSTR lpszName, COleVariant& varValue);
	virtual void SetFieldValue(int nIndex, COleVariant& varValue);
	virtual void GetFieldValue(LPCTSTR lpszName, COleVariant& varValue);
	virtual void GetFieldValue(int nIndex, COleVariant& varValue);
	
	bool GetFieldInfo(LPCTSTR lpFieldName, CADOFieldInfo* fldInfo);
	bool GetFieldInfo(int nIndex, CADOFieldInfo* fldInfo);
private:
	void CreateConnection();
};

#endif