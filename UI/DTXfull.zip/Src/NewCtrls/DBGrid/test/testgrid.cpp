// testgrid.cpp : implementation file
//

#include "stdafx.h"
#include "DBGrid.h"
#include "testgrid.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestGrid

CTestGrid::CTestGrid()
{
	AddDBCols();
	CreateCols();
}

CTestGrid::~CTestGrid()
{
}


BEGIN_MESSAGE_MAP(CTestGrid, CDTXDBGridCtrl)
	//{{AFX_MSG_MAP(CTestGrid)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTestGrid message handlers

void CTestGrid::AddDBCols()
{
/*
	CDAOTableCreator m_TestCreator;
	m_TestCreator.CreateDatabase(GetAppPath() + _T("DTX.mdb"), dbLangTurkish);

	m_TestCreator.AddField(_T("Name"), dbText, 32);
	m_TestCreator.AddField(_T("WEBSite"), dbText, 64);
	m_TestCreator.AddField(_T("EMail"), dbText, 64);
	m_TestCreator.AddField(_T("ICQ"), dbLong, 1);
	m_TestCreator.AddField(_T("Remarks"), dbMemo, 1);
	m_TestCreator.AddField(_T("AlarmOnBirthDay"), dbBoolean, 1);
	m_TestCreator.AddField(_T("BirthDay"), dbDate, 1);
	m_TestCreator.AddField(_T("Picture"), dbLongBinary, 0);
	m_TestCreator.CreateTable(_T("MyFriends"));
*/

//NewDBColumn(CString m_FldName, CString m_Header, int m_Width, dbCollAlign m_Align);
	AddColumn(NewDBColumn(_T("HastaNo"), _T("Kay�t No"), 150, dbcRight));
	AddColumn(NewDBColumn(_T("Adi"), _T("Adi"), 150, dbcLeft));
	AddColumn(NewDBColumn(_T("Soyadi"), _T("Soyadi"), 150, dbcLeft));
	AddColumn(NewDBColumn(_T("DogumYeri"), _T("DogumYeri"), 150, dbcLeft));
	AddColumn(NewDBColumn(_T("DogumTarih"), _T("DogumTarihi"), 150, dbcRight));
	AddColumn(NewDBColumn(_T("BabaAdi"), _T("BabaAdi"), 150, dbcLeft));
}

BOOL CTestGrid::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;   
	cs.style &= ~WS_BORDER;
	cs.style |= WS_HSCROLL | WS_VSCROLL;
	return CDTXDBGridCtrl::PreCreateWindow(cs);
}
