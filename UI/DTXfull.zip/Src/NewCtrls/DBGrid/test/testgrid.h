#if !defined(AFX_TESTGRID_H__61C63788_D72C_4033_9B93_129A039CD412__INCLUDED_)
#define AFX_TESTGRID_H__61C63788_D72C_4033_9B93_129A039CD412__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// testgrid.h : header file
//
#include "./ctrl/dbgridctrl.h"
/////////////////////////////////////////////////////////////////////////////
// CTestGrid window

class CTestGrid : public CDTXDBGridCtrl
{
// Construction
public:
	CTestGrid();
	void AddDBCols();
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestGrid)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestGrid();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTestGrid)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTGRID_H__61C63788_D72C_4033_9B93_129A039CD412__INCLUDED_)
