// DBGridDlg.h : header file
//

#if !defined(AFX_DBGRIDDLG_H__9EAEE069_D8BE_4632_B5C5_E2889BC3A645__INCLUDED_)
#define AFX_DBGRIDDLG_H__9EAEE069_D8BE_4632_B5C5_E2889BC3A645__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TestGrid.h"
#include <dtx.h>

/////////////////////////////////////////////////////////////////////////////
// CDBGridDlg dialog

class CDBGridDlg : public CDialog
{
	CDTXDAOTable m_Table;
// Construction
public:
	CDBGridDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDBGridDlg)
	enum { IDD = IDD_DBGRID_DIALOG };
	CDTXDBEdit		m_Name;
	CDBNavigator	m_Navigator;
	CTestGrid		m_DBGrid;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDBGridDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDBGridDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBGRIDDLG_H__9EAEE069_D8BE_4632_B5C5_E2889BC3A645__INCLUDED_)
