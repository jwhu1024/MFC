// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__8AFAA58C_D1B2_11D4_90CF_0050040D57DF__INCLUDED_)
#define AFX_MAINDLG_H__8AFAA58C_D1B2_11D4_90CF_0050040D57DF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define ID_ROTATE_TIMER 101

#include "ATLLabel.h"

class CMainDlg : public CDialogImpl<CMainDlg>, public CUpdateUI<CMainDlg>,
		public CMessageFilter, public CIdleHandler
{
public:
	
  CLabel m_ctlGradient;
  CLabel m_ctl3D2;
  CLabel m_ctl3D;
  CLabel m_ctltcolor;
  CLabel m_ctlbcolor;
  CLabel m_ctluline;
  CLabel m_ctlflash;
  CLabel m_ctllblTrans;
  CLabel m_ctlitalics;
  CLabel m_ctllink;
  CLabel m_ctlfname;
  CLabel m_ctlfsize;
  CLabel m_ctlbold;
  CLabel m_ctlborder;
  CLabel m_ctlmonty;
  CLabel m_ctlsunken;
  CLabel m_ctllblRotate;
	UINT m_nAngle;

  
  enum { IDD = IDD_MAINDLG };

	virtual BOOL PreTranslateMessage(MSG* pMsg)
	{
		return IsDialogMessage(pMsg);
	}

	virtual BOOL OnIdle()
	{
		return FALSE;
	}

	BEGIN_MSG_MAP(CMainDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		MESSAGE_HANDLER(WM_TIMER, OnTimer)
	END_MSG_MAP()

	BEGIN_UPDATE_UI_MAP(CMainDlg)
	END_UPDATE_UI_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		// center the dialog on the screen
		CenterWindow();

		// set icons
		HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		SetIcon(hIcon, TRUE);
		HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		SetIcon(hIconSmall, FALSE);

    m_ctlGradient.SubclassWindow(GetDlgItem(IDC_GRADIENT));
	  m_ctlGradient.SetBkColor(RGB(255,255,255),RGB(0,0,255), CLabel::Gradient);

    m_ctl3D2.SubclassWindow(GetDlgItem(IDC_3D2));
	  m_ctl3D2.SetFont3D(TRUE,CLabel::Raised)
		  .SetText3DHiliteColor(RGB(0,0,255))
		  .SetFontName("Times New Roman")
		  .SetFontSize(16)
		  .SetFontBold(TRUE);

    m_ctl3D.SubclassWindow(GetDlgItem(IDC_3D));
	  m_ctl3D.SetFont3D(TRUE,CLabel::Sunken)
		  .SetFontName("Arial")
		  .SetFontSize(16)
		  .SetFontBold(TRUE);

    m_ctltcolor.SubclassWindow(GetDlgItem(IDC_TCOLOR));
	  m_ctltcolor.SetTextColor(RGB(255,0,0));

    m_ctlbcolor.SubclassWindow(GetDlgItem(IDC_BCOLOR));
  	m_ctlbcolor.SetBkColor(RGB(0,255,255));

    m_ctluline.SubclassWindow(GetDlgItem(IDC_TULINE));
	  m_ctluline.SetFontUnderline(TRUE);

    m_ctlflash.SubclassWindow(GetDlgItem(IDC_FLASH));
	  m_ctlflash.SetBkColor(RGB(0,0,0));
	  m_ctlflash.SetTextColor(RGB(255,0,0));
	  m_ctlflash.SetFontBold(TRUE);
	  m_ctlflash.SetTextColor(RGB(0,255,0));
	  
	  m_ctlflash.SetWindowText(_T("Payload\r\nBay"));
	  m_ctlflash.FlashText(TRUE);

    m_ctllblTrans.SubclassWindow(GetDlgItem(IDC_TRANS));
	  m_ctllblTrans.SetTextColor(RGB(255,255,255)).SetTransparent(TRUE);

    m_ctlitalics.SubclassWindow(GetDlgItem(IDC_ITALICS));
	  m_ctlitalics.SetFontItalic(TRUE);

    m_ctllink.SubclassWindow(GetDlgItem(IDC_LINK));	  
    m_ctllink.SetLink(TRUE,FALSE)
		  .SetTextColor(RGB(0,0,255))
		  .SetFontUnderline(TRUE)
      .SetLinkCursor();

    m_ctlfname.SubclassWindow(GetDlgItem(IDC_FNAME));	  
	  m_ctlfname.SetFontName("System");

    m_ctlfsize.SubclassWindow(GetDlgItem(IDC_FSIZE));	  
	  m_ctlfsize.SetFontSize(14);

    m_ctlbold.SubclassWindow(GetDlgItem(IDC_BOLD));	  
	  m_ctlbold.SetFontBold(TRUE);

    m_ctlborder.SubclassWindow(GetDlgItem(IDC_BORDER));	  
    m_ctlborder.SetBorder(TRUE);

    m_ctlmonty.SubclassWindow(GetDlgItem(IDC_MONTY));	  
	  m_ctlmonty
		.SetFontName("Arial")
		.SetFontSize(12)
		.SetTextColor(RGB(255,255,0))
		.SetFontUnderline(TRUE)
		.SetBkColor(RGB(0,0,0))
		.SetFontItalic(TRUE)
		.SetFontBold(TRUE)
		.SetBorder(TRUE)
		.SetSunken(TRUE);

    m_ctlsunken.SubclassWindow(GetDlgItem(IDC_SUNKEN));	  
    m_ctlsunken.SetSunken(TRUE);

    m_nAngle = 0;
    m_ctllblRotate.SubclassWindow(GetDlgItem(IDC_MONTY2));	  	  
	  m_ctllblRotate
		.SetTextColor(RGB(192,0,0))
		.SetFontSize(14)
		.SetFontBold(TRUE)
		.SetFontName("Arial")
    .SetRotationAngle(m_nAngle,true);
	  
    SetTimer(ID_ROTATE_TIMER,100);

    // register object for message filtering and idle updates
		CMessageLoop* pLoop = _Module.GetMessageLoop();
		ATLASSERT(pLoop != NULL);
		pLoop->AddMessageFilter(this);
		pLoop->AddIdleHandler(this);

		UIAddChildWindowContainer(m_hWnd);

		return TRUE;
	}

	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CAboutDlg dlg;
		dlg.DoModal();
		return 0;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// TODO: Add validation code 
		CloseDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CloseDialog(wID);
		return 0;
	}

	void CloseDialog(int nVal)
	{
    DestroyWindow();
		::PostQuitMessage(nVal);
	}
	
  LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
	  if (m_nAngle == 360)
		  m_nAngle = 0;

	  m_nAngle+=10;

	  m_ctllblRotate.SetRotationAngle(m_nAngle,true);

		return 0;
	}
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__8AFAA58C_D1B2_11D4_90CF_0050040D57DF__INCLUDED_)
