// SetTransPlusDlg.cpp : implementation file
//

#include "stdafx.h"
#include <winuser.h>
#include "SetTransPlus.h"
#include "SetTransPlusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002


extern "C" {
	WINUSERAPI
BOOL
WINAPI
SetLayeredWindowAttributes(
    HWND hwnd,
    COLORREF crKey,
    BYTE bAlpha,
    DWORD dwFlags);
}
/////////////////////////////////////////////////////////////////////////////
// CSetTransPlusDlg dialog

CSetTransPlusDlg::CSetTransPlusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetTransPlusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetTransPlusDlg)
	m_strWindowTitle = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSetTransPlusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetTransPlusDlg)
	DDX_Control(pDX, IDC_GREEN, m_green);
	DDX_Control(pDX, IDC_RED, m_red);
	DDX_Control(pDX, IDC_STATIC2, m_opaque);
	DDX_Control(pDX, IDC_STATIC1, m_transp);
	DDX_Control(pDX, IDC_SLIDER1, m_slider);
	DDX_Control(pDX, IDC_EDIT1, m_edtTitle);
	DDX_Text(pDX, IDC_EDIT1, m_strWindowTitle);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSetTransPlusDlg, CDialog)
	//{{AFX_MSG_MAP(CSetTransPlusDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDC_BUTTON1, OnSelect)
	ON_BN_CLICKED(IDC_BUTTON2, OnApply)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetTransPlusDlg message handlers

BOOL CSetTransPlusDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	m_slider.SetRange(0, 255);
	m_slider.SetPos(180);
	// TODO: Add extra initialization here
	SetTimer(1,50,NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetTransPlusDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetTransPlusDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSetTransPlusDlg::OnOk() 
{
	HWND hWnd;
	CString title;
	m_edtTitle.GetWindowText(title);
	hWnd=::FindWindow(NULL,title);
	ToggleTransparency(hWnd);	
}

void CSetTransPlusDlg::OnSelect() 
{
	CString title;
	CWnd *wnd;
	POINT pt;
	::GetCursorPos(&pt);
	wnd=WindowFromPoint(pt);
	wnd->GetWindowText(title);
	m_edtTitle.SetWindowText(title);
	
}

void CSetTransPlusDlg::OnApply() 
{
	HWND hWnd;
	POINT pt;
	::GetCursorPos(&pt);
	hWnd=::WindowFromPoint(pt);
	ToggleTransparency(hWnd);
}

void CSetTransPlusDlg::OnTimer(UINT nIDEvent) 
{
	
	HWND hWnd;
	POINT pt;
	::GetCursorPos(&pt);
	hWnd=::WindowFromPoint(pt);
	
	if (::GetParent(hWnd)==NULL || ::GetWindowLong(hWnd,GWL_STYLE) & WS_POPUP)
	{
		m_green.ShowWindow(SW_SHOWNORMAL);
		m_red.ShowWindow(SW_HIDE);
		if (hWnd!=this->m_hWnd)
			OnSelect();

	}
	else
	{
		m_red.ShowWindow(SW_SHOWNORMAL);
		m_green.ShowWindow(SW_HIDE);
	}
	CDialog::OnTimer(nIDEvent);
}

void CSetTransPlusDlg::ToggleTransparency(HWND hWnd)
{
	SetWindowLong(hWnd,GWL_EXSTYLE,GetWindowLong(hWnd,GWL_EXSTYLE)^WS_EX_LAYERED);
	SetLayeredWindowAttributes(hWnd,RGB(0,0,0),m_slider.GetPos(),LWA_ALPHA);

}
