// ColorToGrayscaleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ColorToGrayscale.h"
#include "ColorToGrayscaleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CColorToGrayscaleDlg dialog




CColorToGrayscaleDlg::CColorToGrayscaleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CColorToGrayscaleDlg::IDD, pParent)
	, m_imageFilePath(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CColorToGrayscaleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CColorToGrayscaleDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_OPEN_IMG, &CColorToGrayscaleDlg::OnBnClickedBtnOpenImg)
	ON_BN_CLICKED(IDC_BTN_SHOW_IMG, &CColorToGrayscaleDlg::OnBnClickedBtnShowImg)
END_MESSAGE_MAP()


// CColorToGrayscaleDlg message handlers

BOOL CColorToGrayscaleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CColorToGrayscaleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CColorToGrayscaleDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		DrawImage();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CColorToGrayscaleDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CColorToGrayscaleDlg::OnBnClickedBtnOpenImg()
{
	CFileDialog dlg( TRUE,
					_T("bmp"),
					NULL,
					OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
					_T("BMP Files (*.bmp)|*.bmp|JPEG Files (*.jpg;*.jpeg)|*.jpg;*.jpeg|All Files (*.*)|*.*||"),
					NULL );

	if( dlg.DoModal() == IDOK )
	{
		m_imageFilePath = dlg.GetPathName();
		SetDlgItemText( IDC_EDT_FILEPATH, m_imageFilePath );
	}
}

void CColorToGrayscaleDlg::OnBnClickedBtnShowImg()
{
	if( !m_image.IsNull() )
	{
		m_image.Destroy();
	}

	m_image.Load( m_imageFilePath );
	//MakeGrayscale_Slow();
	MakeGrayscale_Fast();
	
	Invalidate();
}

void CColorToGrayscaleDlg::DrawImage()
{
	if( m_image.IsNull() || m_imageGrayscale.IsNull() )
	{
		return;
	}

	CWnd* pWnd = GetDlgItem( IDC_STC_IMAGE );
	CDC* pDC = pWnd->GetDC();

	pDC->SetStretchBltMode(COLORONCOLOR);

	CRect rect;
	pWnd->GetClientRect( &rect );
	ClientToScreen( &rect );

	int newWidth = (m_image.GetWidth()*rect.Height()) / m_image.GetHeight();
	int newHeight = rect.Height();
	
	CButton* pChkGrayscale = (CButton*)GetDlgItem( IDC_CHK_GRAYSCALE );
	if( BST_CHECKED == pChkGrayscale->GetCheck())
	{
		m_imageGrayscale.Draw( pDC->GetSafeHdc(), 0, 0, newWidth, newHeight );
	}
	else
	{
		m_image.Draw( pDC->GetSafeHdc(), 0, 0, newWidth, newHeight );		
	}

	pWnd->ReleaseDC(pDC);
}


void CColorToGrayscaleDlg::MakeGrayscale_Slow()
{
	int	width = m_image.GetWidth();
	int	height = m_image.GetHeight();	
	
	if(!m_imageGrayscale.IsNull())
	{
		m_imageGrayscale.Destroy();
	}
	m_imageGrayscale.Create(width, height, m_image.GetBPP());
	
	double gray;
	COLORREF c;

	DWORD start = GetTickCount();
	for (int y=0; y<height; y++)
	{
		for(int x=0; x<width; x++)
		{
			c = m_image.GetPixel(x, y);
			gray = GetRValue(c)*0.587 + GetGValue(c)*0.299 + GetBValue(c)*0.114;
			m_imageGrayscale.SetPixel(x, y, RGB(gray, gray, gray));
		}
	}
	DWORD end = GetTickCount();
	DWORD time = end - start;

	CString tmp;
	tmp.Format(_T("%d"), start);
	SetDlgItemText(IDC_STC_START, tmp);

	tmp.Format(_T("%d"), end);
	SetDlgItemText(IDC_STC_END, tmp);

	tmp.Format(_T("%d ms"), time);
	SetDlgItemText(IDC_STC_TIME, tmp);
}

void CColorToGrayscaleDlg::MakeGrayscale_Fast()
{
	int	width = m_image.GetWidth();
	int	height = m_image.GetHeight();	
	
	if(!m_imageGrayscale.IsNull())
	{
		m_imageGrayscale.Destroy();
	}
	m_imageGrayscale.Create(width, height, m_image.GetBPP());
	
	int pitch = m_image.GetPitch();
	BYTE* pInImage = (BYTE*)m_image.GetBits();
	BYTE* pOutImage = (BYTE*)m_imageGrayscale.GetBits();
	
	long lAdrs;
	double gray;
	BYTE bRed, bGreen, bBlue;

	DWORD start = GetTickCount();
	for (int y = 0; y<height; ++y)
	{
		for (int x = 0; x<width; ++x)
		{
			lAdrs  = y * pitch + x*3;
			bRed   = *( pInImage + lAdrs );
			bGreen = *( pInImage + lAdrs + 1 );
			bBlue  = *( pInImage + lAdrs + 2 );

			gray = bRed*0.587 + bGreen*0.299 + bBlue*0.114;			
			*( pOutImage + lAdrs )     = static_cast<BYTE>(gray);
			*( pOutImage + lAdrs + 1 ) = static_cast<BYTE>(gray);
			*( pOutImage + lAdrs + 2 ) = static_cast<BYTE>(gray);

		}
	}
	DWORD end = GetTickCount();
	DWORD time = end - start;

	CString tmp;
	tmp.Format(_T("%d"), start);
	SetDlgItemText(IDC_STC_START, tmp);

	tmp.Format(_T("%d"), end);
	SetDlgItemText(IDC_STC_END, tmp);

	tmp.Format(_T("%d ms"), time);
	SetDlgItemText(IDC_STC_TIME, tmp);
}