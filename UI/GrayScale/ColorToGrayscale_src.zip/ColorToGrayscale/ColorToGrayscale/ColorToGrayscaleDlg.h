// ColorToGrayscaleDlg.h : header file
//

#pragma once
#include "atlimage.h"

// CColorToGrayscaleDlg dialog
class CColorToGrayscaleDlg : public CDialog
{
// Construction
public:
	CColorToGrayscaleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_COLORTOGRAYSCALE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private:
	afx_msg void OnBnClickedBtnOpenImg();
	afx_msg void OnBnClickedBtnShowImg();

	/**
	 * @brief Shows image fie.
	 */
	void DrawImage();

	/**
	 * @brief Make grayscale (slow).
	 */
	void MakeGrayscale_Slow();

	/**
	 * @brief Make grayscale (fast).
	 */
	void MakeGrayscale_Fast();

private:
	CString m_imageFilePath;
	ATL::CImage m_image;
	ATL::CImage m_imageGrayscale;
};
