// This is the main project file for VC++ application project // generated using an Application Wizard.

#include "stdafx.h"

#using <mscorlib.dll>

using namespace System;
using namespace System::IO;
using namespace System::Collections::Generic;

// Sends standard input to standard output and to all files in command line.
// Chip Camden, Camden Software Consulting, November 2005
// 	... and Anonymous Cowards everywhere!
//
// TEE [-a | --append] [-i | --ignore] [--help | /?] [-f] [file1] [...]
//    Example:
// 	tee --append file0.txt -f --help file2.txt
//    will append to file0.txt, --help, and file2.txt
// 
// -a | --append	Appends files instead of overwriting
// 			  (setting is per tee instance)
// -i | --ignore	Ignore cancel Ctrl+C keypress: see UnixUtils tee
// /? | --help		Displays this message and immediately quits
// -f			Stop recognizing flags, force all following filenames literally
//
// Duplicate filenames are quietly ignored.
// Press Ctrl+Z (End of File character) then Enter to abort.
//
// http://www.camdensoftware.com
// http://chipstips.com/?tag=cpptee

void OnCancelKeyPressed(Object^ sender, 
    ConsoleCancelEventArgs^ args)
{
    // Set the Cancel property to true to prevent the process from 
    // terminating.
    args->Cancel = true;
}

int _tmain(int argc, TCHAR *argv[])
{
	List<BinaryWriter^> bw;

	try
	{		
		int ndx;
		String^ workArg;

		
		//I want to get TCHAR *argv[] into a List of (Unicode) Strings (argc-1) long
		List<String^>^ myArgv = gcnew List<String^>(argc-1);


		bool bAppend = false;
		bool bStopFlag = false;
		bool bIgnoreCancel = false;
		
		for (ndx = 1; ndx < argc; ndx++)
		{
			//Since we're already parsing.... might as well check for flags:
			workArg = gcnew String(argv[ndx]);

			if (bStopFlag)			//Stop interpreting flags, assume is filename
			{
				myArgv->Add(workArg);
			}
			else if (workArg->Equals("/?") || workArg->Equals("--help"))
			{
				Console::Error->WriteLine("Sends standard input to standard output and to all files in command line.");
				Console::Error->WriteLine("Chip Camden, Camden Software Consulting, November 2005");
				Console::Error->WriteLine("	... and Anonymous Cowards everywhere!");
				Console::Error->WriteLine("http://www.camdensoftware.com");
				Console::Error->WriteLine("http://chipstips.com/?tag=cpptee");
				Console::Error->WriteLine("");
				Console::Error->WriteLine("TEE [-a | --append] [-i | --ignore] [--help | /?] [-f] [file1] [...]");
				Console::Error->WriteLine("   Example:");
				Console::Error->WriteLine(" tee --append file0.txt -f --help file2.txt");
				Console::Error->WriteLine("   will append to file0.txt, --help, and file2.txt");
				Console::Error->WriteLine("");
				Console::Error->WriteLine("-a | --append    Appends files instead of overwriting");
				Console::Error->WriteLine("                 (setting is per tee instance)");
				Console::Error->WriteLine("-i | --ignore    Ignore cancel Ctrl+C keypress: see UnixUtils tee");
				Console::Error->WriteLine("/? | --help      Displays this message and immediately quits");
				Console::Error->WriteLine("-f               Stop recognizing flags, force all following filenames literally");
				Console::Error->WriteLine("");
				Console::Error->WriteLine("Duplicate filenames are quietly ignored.");
				Console::Error->WriteLine("Press Ctrl+Z (End of File character) then Enter to abort.");

				return 1;		//Quit immediately
			}
			else if (workArg->Equals("-a") || workArg->Equals("--append"))
			{
				bAppend = true;
			}
			else if (workArg->Equals("-i") || workArg->Equals("--ignore"))
			{
				bIgnoreCancel = true;
			}
			else if (workArg->Equals("-f"))
			{
				bStopFlag = true;
			}
			else {				//If it isn't any of the above, it's a filename
				myArgv->Add(workArg);
			}

			//Add more flags as necessary, just remember to SKIP adding them to the file processing stream!

		}

		if (bIgnoreCancel)		//Implement the Ctrl+C fix selectively (mirror UnixUtils tee behavior)
		{
			Console::CancelKeyPress += gcnew ConsoleCancelEventHandler(OnCancelKeyPressed);
		}

		for (ndx = myArgv->Count-1; ndx >=0; ndx--)
		{
			if (myArgv->IndexOf(myArgv[ndx]) < ndx)	// Got another one?
				myArgv->RemoveAt(ndx);				// Remove this one
		}
		bw.Capacity = myArgv->Count;				 //Add only as many streams as there are distinct files

		for (ndx = 0; ndx <  myArgv->Count; ndx++)
			bw.Add(gcnew BinaryWriter(bAppend ?
				File::AppendText(myArgv[ndx])->BaseStream : File::Create(myArgv[ndx])));	// Open the files specified as arguments
		BinaryReader^ in = gcnew BinaryReader(Console::OpenStandardInput());
		BinaryWriter^ out = gcnew BinaryWriter(Console::OpenStandardOutput());
		Byte b;
		for (;;)									// Read standard in
		{
			try
			{
				b = in->ReadByte();
			}
			catch (EndOfStreamException^)
			{
				break;
			}

			out->Write(b);					// Write standard out
			for (ndx = 0; ndx < bw.Count; ndx++)
			{
				bw[ndx]->Write(b);					// Write to each file
			}
		}
		for (ndx = 0; ndx < bw.Count; ndx++)
		{
			bw[ndx]->Flush();								// Flush and close each file
			bw[ndx]->Close();
		}
	}
	catch (Exception^ ex)
	{
		Console::Error->WriteLine(String::Concat("tee: ", ex->Message));	// Send error messages to stderr
	}

	return 0;
}

