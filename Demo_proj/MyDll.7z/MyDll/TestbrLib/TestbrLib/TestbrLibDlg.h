// TestbrLibDlg.h : ���Y��
//

#pragma once
#include "afxwin.h"
#include "brLib.h"

/* Convert Use */
__declspec(dllexport) int UnicodeToAnsi(TCHAR *unicode, char* ansi);
__declspec(dllexport) int AnsiToUnicode(char* ansi, TCHAR* unicode);
__declspec(dllexport) int CStringToChar(CString strsrc, char* dest);
__declspec(dllexport) int CharToCString(char* source, CString* dest);

/* Debug Use */
__declspec(dllexport) int DbgPrint(char* chString, CString strData=NULL);

/* General Use */
__declspec(dllexport) BOOL CheckFileExist(char* path);

// CTestbrLibDlg ��ܤ��
class CTestbrLibDlg : public CDialog
{
// �غc
public:
	CTestbrLibDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_TESTBRLIB_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickAnsiToUnicode();
public:
	CEdit edit_ret;
public:
	CEdit edit_unicode;
};
