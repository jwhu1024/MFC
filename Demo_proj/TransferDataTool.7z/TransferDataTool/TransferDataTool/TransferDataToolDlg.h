// TransferDataToolDlg.h : ���Y��
//

#pragma once
//#include "winsock2.h"
#include "Socket.h"

// CTransferDataToolDlg ��ܤ��
class CTransferDataToolDlg : public CDialog
{
// �غc
public:
	CTransferDataToolDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_TRANSFERDATATOOL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedSend();

public:
	CSocketCtrl m_DUTCtrl;
public:
	afx_msg void OnBnClickedConnect();
public:
	afx_msg void OnClose();
};
