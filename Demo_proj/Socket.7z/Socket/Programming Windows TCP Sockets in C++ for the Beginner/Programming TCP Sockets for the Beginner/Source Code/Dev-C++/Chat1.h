#define DLG_MAIN        500
#define DLG_CONNECT     501
#define DLG_LISTEN      502

#define ID_EDIT_DATA    600
#define ID_EDIT_SEND    601
#define ID_EDIT_HOST    602
#define ID_EDIT_PORT    603

#define ID_BTN_CONNECT  700
#define ID_BTN_CLEAR    701
#define ID_BTN_SEND     702
#define ID_BTN_GO       703
#define ID_BTN_LISTEN   704

#define ID_STATUS_MAIN  800

#define CUSTOM_NOTIFICATION     1045
