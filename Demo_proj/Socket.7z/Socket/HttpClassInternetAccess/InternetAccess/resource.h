//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by InternetAccess.rc
//
#define IDD_INTERNETACCESS_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDR_MAIN                        129
#define IDD_DIALOG1                     130
#define IDC_URL                         1000
#define IDC_POST_DATA                   1001
#define IDC_URL_DATA                    1002
#define IDC_CONNECTION_TYPE             1004
#define IDC_PROXY                       1005
#define IDC_BYPASS                      1006
#define IDC_DATA_RECEIVED               1007
#define IDC_SEND                        1008
#define IDC_DATA_SENT                   1009
#define IDC_STATUS                      1010
#define ID_TEST_GETTEST                 32771
#define ID_TEST_POSTTEST                32772
#define ID_TEST_EXIT                    32773
#define ID_HELP_ABOUTCWEBACCESS         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
