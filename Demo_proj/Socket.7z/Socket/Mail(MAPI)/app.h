class CApp : public CWinApp
{
public:
	CApp();

	//{{AFX_VIRTUAL(CApp)
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


