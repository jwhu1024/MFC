//Please agree with this : http://www.gnu.org/licenses/gpl.txt

#include "CLogFile.h"

CLogFile::Exception::Exception() : mMessage("CLogFile Exception")
{
}

CLogFile::Exception::Exception(const Exception& other)
{
	mMessage = other.mMessage;
}

CLogFile::Exception::Exception(const string& Message) : mMessage("CLogFile Exception : " + Message)
{
}

CLogFile::Exception::~Exception()
{
	mMessage = "";
}

CLogFile::CLogFile(void) : mFilename("")
{
}

CLogFile::CLogFile(const CLogFile& other)
{
    mFilename = other.mFilename;
    mType = other.mType;
}

CLogFile::CLogFile(const string& Filename, ELogType Type) : mFilename("")
{
	open(Filename, Type);
}

CLogFile::~CLogFile(void)
{
	close();
}

void CLogFile::open(const string& Filename, ELogType Type)
{
	if(mFilename != "")
		throw Exception("There is currently another LogFile in use");

	mFilename = Filename;
	mType = Type;

	if(mType == ELT_HTML)
		mFilename += ".html";
	else
		mFilename += ".log";

	FileStream file;

	if(exists(path(mFilename)))
	{
		remove(path(mFilename));
		file.open(path(mFilename), ios::out|ios::ate|ios::app);
	}
	else
		file.open(path(mFilename), ios::out|ios::ate|ios::app);

	if(!file.is_open())
		throw Exception("Cannot open file \"" + mFilename + "\"");

	tm* pTime;
	time_t ctTime;
	time(&ctTime);
	pTime = localtime(&ctTime);

	if(mType == ELT_HTML)
	{
		file << "<html><head><title>Log File</title></head><body>" << endl;
		file << "<font style=\"font-family: \'Comic Sans MS\'\">" << endl;
		file << "<center><h1>LogFile</h1>" << endl;
		file << "<h3>Created on ";
		file << "<i>" << setfill('0') << setw(2) << pTime->tm_mday << "/" << setfill('0') << setw(2) << pTime->tm_mon << "/" << (pTime->tm_year+1900) << "</i>";
		file << " at ";
		file << "<i>" << setfill('0') << setw(2) << pTime->tm_hour << ":" << setfill('0') << setw(2) << pTime->tm_min << ":" << setfill('0') << setw(2) << pTime->tm_sec << "</i>";
		file << "</h3></center></font>" << endl;
		file << "<hr style=\"width: 75%; height: 3px;\" noshade/>" << endl << endl;
	}
	else
	{
	    file << "\t    |-------|" << endl;
        file << "\t    |LogFile|" << endl;
        file << "\t    |-------|" << endl;

        file << "Created on ";
        file << setfill('0') << setw(2) << pTime->tm_mday << "/" << setfill('0') << setw(2) << pTime->tm_mon << "/" << (pTime->tm_year+1900);
        file << " at ";
        file << setfill('0') << setw(2) << pTime->tm_hour << ":" << setfill('0') << setw(2) << pTime->tm_min << ":" << setfill('0') << setw(2) << pTime->tm_sec;
        file << endl << "*********************************" << endl << endl;
	}

	file.flush();
}

void CLogFile::close(void)
{
	if(mFilename == "")
		throw Exception("There is currently no LogFile opened");

	FileStream file(path(mFilename), ios::out|ios::ate|ios::app);

	if(!file.is_open())
		throw Exception("Cannot open file \"" + mFilename + "\"");

	if(mType == ELT_HTML)
		file << endl << "</body></html>" << endl;

	file.flush();

	mFilename = "";
}

void CLogFile::log(const string& Message, ELogLevel Level)
{
	if(mFilename == "")
		throw Exception("There is currently no LogFile opened");

	FileStream file(path(mFilename), ios::out|ios::ate|ios::app);

	if(!file.is_open())
		throw Exception("Cannot open file \"" + mFilename + "\"");

	tm* pTime;
	time_t ctTime;
	time(&ctTime);
	pTime = localtime(&ctTime);

	if(mType == ELT_HTML)
	{
		file << "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" << endl;

		if(Level == ELL_DEBUG)
			file << "<font color=\"black\" style=\"font-family: \'Courier New\'\" size=2><b>";
		else if(Level == ELL_WARNING)
			file << "<font color=\"blue\"  style=\"font-family: \'Courier New\'\" size=2><b>";
		else
			file << "<font color=\"red\"   style=\"font-family: \'Courier New\'\" size=2><b>";

        file << setfill('0') << setw(2) << pTime->tm_hour << ":" << setfill('0') << setw(2) << pTime->tm_min << ":" << setfill('0') << setw(2) << pTime->tm_sec;

        if(Level == ELL_DEBUG)
            file << " -------> " << Message;
        else if(Level == ELL_WARNING)
            file << " WARNING: " << Message;
        else
            file << " |ERROR|> " << Message;

        file << "</b></font><br/>" << endl;
	}
	else
	{
        file << setfill('0') << setw(2) << pTime->tm_hour << ":" << setfill('0') << setw(2) << pTime->tm_min << ":" << setfill('0') << setw(2) << pTime->tm_sec;

        if(Level == ELL_DEBUG)
            file << " -------> " << Message << endl;
        else if(Level == ELL_WARNING)
            file << " WARNING: " << Message << endl;
        else
            file << " |ERROR|> " << Message << endl;
	}

	file.flush();
}

void CLogFile::log(const format& Message, ELogLevel Level)
{
	log(str(Message), Level);
}
