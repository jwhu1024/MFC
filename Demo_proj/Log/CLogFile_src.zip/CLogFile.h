//Please agree with this : http://www.gnu.org/licenses/gpl.txt

#ifndef _LOG_FILE_H_
#define _LOG_FILE_H_

#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/fstream.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/format.hpp>
#include <iomanip>
#include <string>
#include <time.h>

using namespace boost;
using namespace filesystem;
using namespace std;

class CLogFile
{
public:
	class Exception
	{
	public:
		Exception();
		Exception(const Exception& other);
		Exception(const string& Message);

		~Exception();

		inline const char*  getMessageAsChar() {return mMessage.c_str();}
		inline const string getMessageAsStr () {return mMessage;}

	protected:
		string mMessage;
	};

	typedef enum ELogType
	{
		ELT_TEXT,
		ELT_HTML,
	};

	typedef enum ELogLevel
	{
		ELL_DEBUG,
		ELL_WARNING,
		ELL_ERROR
	};

	CLogFile(void);
	CLogFile(const CLogFile& other);
	CLogFile(const string& Filename, ELogType Type = ELT_TEXT);

	~CLogFile(void);

	void open(const string& Filename, ELogType Type = ELT_TEXT);
	void close(void);

	void log(const string& Message, ELogLevel Level = ELL_DEBUG);
	void log(const format& Message, ELogLevel Level = ELL_DEBUG);

private:
	typedef filesystem::basic_fstream<char> FileStream;

	ELogType mType;
	string mFilename;
};

#endif
