//Please agree with this : http://www.gnu.org/licenses/gpl.txt

#include <iostream>
#include <stdlib.h>

#include "CLogFile.h"

CLogFile* log1;
CLogFile* log2;

#define my_log(a, b) log1->log(a, b); log2->log(a, b); //Just to make a macro that does all for me!! ;)

int main(int argc, char* argv[])
{
	try
	{
		log1 = new CLogFile("log", CLogFile::ELT_HTML);
		log2 = new CLogFile("log", CLogFile::ELT_TEXT);

		my_log("PROGRAM STARTED", CLogFile::ELL_DEBUG);

		my_log("", CLogFile::ELL_WARNING);
		my_log("This is a Warning", CLogFile::ELL_WARNING);
		my_log("", CLogFile::ELL_WARNING);

		my_log("", CLogFile::ELL_ERROR);
		my_log("This is an Error", CLogFile::ELL_ERROR);
		my_log("", CLogFile::ELL_ERROR);

		system("pause");

		my_log("PROGRAM ENDED", CLogFile::ELL_DEBUG);
		delete log1;
		delete log2;
	}
	catch(CLogFile::Exception& e)
	{
		std::cout << e.getMessageAsStr() << std::endl;
		system("pause");
	}
	catch(...)
	{
		std::cout << "Unknown Exception Thrown" << std::endl;
		system("pause");
	}

	return 0;
}
