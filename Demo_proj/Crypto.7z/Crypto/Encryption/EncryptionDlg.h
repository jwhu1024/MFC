// EncryptionDlg.h : ���Y��
//

#pragma once
#include "afxwin.h"
#include <wincrypt.h>

// CEncryptionDlg ��ܤ��
class CEncryptionDlg : public CDialog
{
// �غc
public:
	CEncryptionDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_ENCRYPTION_DIALOG };
	CString strInput;
	CString strOutput;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedEncryp();
public:
	afx_msg void OnBnClickedDecryp();
public:
	afx_msg void OnBnClickedExit();
	void CString2Char(CString source, char* dest);
	void Char2CString(char* source, CString* dest);
public:
	CEdit m_input;
	CEdit m_output;
	BYTE *pbuff;
	BYTE *tmp;	
	CString gString;
	CFile srcFile;
	CFile destFile;
	CFileException e;
public:
	afx_msg void OnBnClickedOk4();
	void Initialize();

private:
	DWORD dwResult;
	HCRYPTPROV hProv;
	HCRYPTKEY hKey;
	HCRYPTKEY hSessionKey;
	DWORD cbBlob;
	BYTE *pbBlob;
};
