// EncryptionDlg.cpp : ��@��
//

#include "stdafx.h"
#include "Encryption.h"
#include "EncryptionDlg.h"
#include "key.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

const char KEY_FILE[255] = "C:\\key.txt";

// �� App About �ϥ� CAboutDlg ��ܤ��

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CEncryptionDlg ��ܤ��

CEncryptionDlg::CEncryptionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEncryptionDlg::IDD, pParent)
{
	// This function acquires a handle to a specific key container within
	// a particular cryptographic service provider (CSP).
	if(!CryptAcquireContext(&hProv, NULL, MS_DEF_PROV, PROV_RSA_FULL, 0))
	{		
		if(GetLastError() == NTE_BAD_KEY)
		{
			if(!CryptAcquireContext(&hProv, 
								  NULL, 
								  MS_DEF_PROV, 
								  PROV_RSA_FULL,
								  CRYPT_NEWKEYSET))
			{
				dwResult = GetLastError();
				AfxMessageBox("Fail to acquire Context.");
				return;
			}			
		}
		else
			return;
	}

	if (!CryptImportKey(hProv, PrivateKeyWithExponentOfOne, sizeof(PrivateKeyWithExponentOfOne), 0, 0, &hKey))
	{
		dwResult = GetLastError();
		MessageBox("Error CryptImportKey() failed.", "Information", MB_OK);
		return;
	}

	if (!CryptGenKey(hProv, CALG_RC4, CRYPT_EXPORTABLE, &hSessionKey))
	{
		dwResult = GetLastError();
		MessageBox("Error CryptGenKey() failed.", "Information", MB_OK);
		return;
	}		


	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEncryptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_input);
	DDX_Control(pDX, IDC_EDIT2, m_output);
	DDX_Text(pDX, IDC_EDIT1, strInput);
	DDX_Text(pDX, IDC_EDIT2, strOutput);
}

BEGIN_MESSAGE_MAP(CEncryptionDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CEncryptionDlg::OnBnClickedEncryp)
	ON_BN_CLICKED(IDOK2, &CEncryptionDlg::OnBnClickedDecryp)
	ON_BN_CLICKED(IDOK3, &CEncryptionDlg::OnBnClickedExit)
	ON_BN_CLICKED(IDOK4, &CEncryptionDlg::OnBnClickedOk4)
END_MESSAGE_MAP()


// CEncryptionDlg �T���B�z�`��

BOOL CEncryptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w

	return TRUE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CEncryptionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CEncryptionDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CEncryptionDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CEncryptionDlg::OnBnClickedEncryp()
{	
	UpdateData();

	if(strInput.IsEmpty())
	{
		AfxMessageBox("Empty input");
		return;
	}

	GetDlgItem(IDOK2)->EnableWindow();

	unsigned long length = strInput.GetLength() +1;
	unsigned char * cipherBlock = (unsigned char*)malloc(length);
	memset(cipherBlock, 0, length);
	memcpy(cipherBlock, strInput, length -1);	

	if (!CryptEncrypt(hSessionKey, 0, TRUE, 0, cipherBlock, &length, length))
	{
		dwResult = GetLastError();
		MessageBox("Error CryptEncrypt() failed.", "Information", MB_OK);
		return;
	}

	strOutput = cipherBlock;
	strInput = "";

	free(cipherBlock);

	UpdateData(FALSE);
	GetDlgItem(IDOK)->EnableWindow(FALSE);
}

void CEncryptionDlg::OnBnClickedDecryp()
{	
	UpdateData();

	if(strOutput.IsEmpty())
	{
		AfxMessageBox("Empty Output");
		return;
	}

	GetDlgItem(IDOK)->EnableWindow();

	unsigned long length = strOutput.GetLength() +1;
	unsigned char * cipherBlock = (unsigned char*)malloc(length);
	memset(cipherBlock, 0, length);
	memcpy(cipherBlock, strOutput, length -1);	

	if (!CryptDecrypt(hSessionKey, 0, TRUE, 0, cipherBlock, &length))
	{
		dwResult = GetLastError();
		MessageBox("Error CryptDecrypt() failed.", "Information", MB_OK);
		return;
	}

	strInput = cipherBlock;
	strOutput = "";

	free(cipherBlock);

	UpdateData(FALSE);
	GetDlgItem(IDOK2)->EnableWindow(FALSE);
}

void CEncryptionDlg::OnBnClickedExit()
{
	OnOK();
}

void CEncryptionDlg::CString2Char(CString source, char* dest) 
{
	WCHAR *wch = new WCHAR[source.GetLength()]; 
	memcpy(wch,source,sizeof(WCHAR)*source.GetLength()); 
	wcstombs(dest,wch,source.GetLength()*sizeof(char)); 
	dest[source.GetLength()] = '\0'; 
	delete[] wch; 
} 

void CEncryptionDlg::Char2CString(char* source, CString* dest) 
{
	dest->SetString(CA2CT(source)); 
} 
void CEncryptionDlg::OnBnClickedOk4()
{
	m_input.SetWindowText("");
	m_output.SetWindowText("");
	GetDlgItem(IDOK)->EnableWindow();
	GetDlgItem(IDOK2)->EnableWindow();
}

void CEncryptionDlg::Initialize()
{

}