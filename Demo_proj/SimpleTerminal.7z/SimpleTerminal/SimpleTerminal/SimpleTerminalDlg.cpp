// SimpleTerminalDlg.cpp : ��@��
//

#include "stdafx.h"
#include "SimpleTerminal.h"
#include "SimpleTerminalDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define MAX_RUN 50

// �� App About �ϥ� CAboutDlg ��ܤ��
// 
struct SSerInfo {
	SSerInfo() : bUsbDevice(FALSE) {}
	CString strDevPath;           // Device path for use with CreateFile()
	CString strPortName;          // Simple name (i.e. COM1)
	CString strFriendlyName;      // Full name to be displayed to a user
	BOOL bUsbDevice;              // Provided through a USB connection?
	CString strPortDesc;          // friendly name without the COMx
};

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CSimpleTerminalDlg ��ܤ��

CSimpleTerminalDlg::~CSimpleTerminalDlg(void)
{
	stopThread = FALSE;
	Sleep(300);
}

CSimpleTerminalDlg::CSimpleTerminalDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSimpleTerminalDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSimpleTerminalDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO1, m_comport);
	DDX_Control(pDX, IDC_EDIT1, edit_WriteCMD);
	DDX_Control(pDX, IDC_EDIT2, m_preCommand);
	DDX_Control(pDX, IDC_COMBO2, m_ComboRate);
	DDX_Control(pDX, IDC_BUTTON2, m_connectbtn);
	DDX_Control(pDX, IDC_BUTTON3, m_SendBtn);
	DDX_Control(pDX, IDC_LIST5, m_log);
	DDX_Control(pDX, IDC_EDIT3, m_marq);
}

BEGIN_MESSAGE_MAP(CSimpleTerminalDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON3, &CSimpleTerminalDlg::OnBnClickedSend)
	ON_BN_CLICKED(IDC_CLEAR, &CSimpleTerminalDlg::OnBnClickedClear)
	ON_BN_CLICKED(IDC_BUTTON2, &CSimpleTerminalDlg::OnBnOpenClose)
	ON_BN_CLICKED(IDC_EXIT, &CSimpleTerminalDlg::OnBnClickedExit)
	//ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


BOOL CSimpleTerminalDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message==WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_RETURN:
		case VK_ESCAPE:
				OnBnClickedSend();
			return TRUE;
			break;
		default:
			break;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

// Thread to set window text
UINT MarqueeThread(LPVOID pParam)
{
	CSimpleTerminalDlg* pThis = (CSimpleTerminalDlg*)pParam;
	BOOL b_Terminal=FALSE;
	while(pThis->stopThread)
	{
		UINT counter=0;
		CString strSpace=L"   ";
		CString strEmbed = L"Author : lester_hu@bandrich.com";
		CString strResult=L"";
		for(counter=0; counter<MAX_RUN; counter++)
		{	
			if(pThis->stopThread)
			{
				strResult=L"";
				if(counter == NULL)
				{
					//strResult.Append(strSpace);
					strResult.Append(strEmbed);
				}
				else
				{
					UINT ii;
					for(ii=0; ii<counter; ii++)
					{
						strResult.Append(strSpace);
					}
					strResult.Append(strEmbed);
				}

				pThis->m_marq.SetWindowText(L"");
				pThis->m_marq.SetWindowText(strResult);
				Sleep(300);
			}
			else
			{
				b_Terminal = TRUE;
				break;
			}
		}
		if(b_Terminal)
			break;
	}
	return 1;
}

// CSimpleTerminalDlg �T���B�z�`��

BOOL CSimpleTerminalDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w	
	LONG mListStyle = GetWindowLong(m_log.m_hWnd, GWL_STYLE);
	mListStyle &= ~LVS_TYPEMASK;
	mListStyle |= LVS_REPORT;
	SetWindowLong(m_log.m_hWnd, GWL_STYLE, mListStyle);

	
	m_log.InsertColumn(0, L"LogMessage");
	m_log.SetColumnWidth(0, 595);
	

	//BaudRate = 115200;
	ByteSize = 8;
	fParity = 0;
	Parity	= 0;
	StopBits = 0;
	Timeout = 100;
	Multiplier = 1;
	TimeoutMultiplier = 1;
	TimeoutConstant = 100;

	m_ComboRate.InsertString(0, L"9600");
	m_ComboRate.InsertString(1, L"19200");
	m_ComboRate.InsertString(2, L"57600");
	m_ComboRate.InsertString(3, L"115200");
	m_ComboRate.InsertString(4, L"921600");

	m_ComboRate.SetCurSel(3); // Default : 115200

	b_isConnected = FALSE;
	edit_WriteCMD.SetWindowText(L"Send Command Here...");
	edit_WriteCMD.EnableWindow(FALSE);
	//m_SendBtn.EnableWindow(FALSE);
	m_preCommand.EnableWindow(FALSE);
	Enumport();
	(CEdit*)GetDlgItem(IDC_COMBO1)->SetFocus();

	paintcount=0;

	stopThread = TRUE;
	m_Thread = AfxBeginThread(MarqueeThread, (LPVOID)this);

	return FALSE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CSimpleTerminalDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CSimpleTerminalDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
	
	if(paintcount == NULL)
	{
		CBitmap   dis_Bitmap, con_Bitmap, sdis_Bitmap, scon_Bitmap, clean_Bitmap, exit_Bitmap, send_Bitmap; 

		dis_Bitmap.LoadBitmap(IDB_Disconnectbtn);
		con_Bitmap.LoadBitmap(IDB_Connectbtn);
		sdis_Bitmap.LoadBitmap(IDB_sta_Disconnect);
		scon_Bitmap.LoadBitmap(IDB_sta_Connect);
		clean_Bitmap.LoadBitmap(IDB_CLEAN);
		exit_Bitmap.LoadBitmap(IDB_EXIT);
		send_Bitmap.LoadBitmap(IDB_SEND);

		HBITMAP   hdBitmap   = (HBITMAP)dis_Bitmap.Detach(); 
		HBITMAP   hcBitmap   = (HBITMAP)con_Bitmap.Detach(); 
		HBITMAP   hsdBitmap  = (HBITMAP)sdis_Bitmap.Detach(); 
		HBITMAP   hscBitmap  = (HBITMAP)scon_Bitmap.Detach(); 
		HBITMAP   cleanBitmap= (HBITMAP)clean_Bitmap.Detach();
		HBITMAP   exitBitmap = (HBITMAP)exit_Bitmap.Detach(); 
		HBITMAP   sendBitmap = (HBITMAP)send_Bitmap.Detach(); 

		CButton   *cdButton    = (CButton*)GetDlgItem(IDC_BUTTON2); 
		CButton   *statusButton= (CButton*)GetDlgItem(IDC_BUTTON1);
		CButton   *clearButton = (CButton*)GetDlgItem(IDC_CLEAR);
		CButton   *exitButton  = (CButton*)GetDlgItem(IDC_EXIT);
		CButton   *sendButton  = (CButton *)GetDlgItem(IDC_BUTTON3);

		cdButton    -> SetBitmap(hcBitmap);
		statusButton-> SetBitmap(hsdBitmap);
		clearButton -> SetBitmap(cleanBitmap);
		exitButton  -> SetBitmap(exitBitmap);
		sendButton  -> SetBitmap(sendBitmap);
		paintcount++;
	}
	
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CSimpleTerminalDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSimpleTerminalDlg::Enumport()
{
	CString result, result1;
	CString portName, portName1;
	int count=0;

	EnumPortsWdm(portName, portName1);//, portNum);

	result.Format(_T("%s"), portName);
	result1.Format(_T("%s"), portName1);

	if(!result.IsEmpty())
	{
		m_comport.AddString(result);
		count++;
	}
	if(!result1.IsEmpty())
	{
		m_comport.AddString(result1);
		count++;
	}

	if(count == 1)
		m_comport.SetCurSel(0);
	if(count == 2)
		m_comport.SetCurSel(1);
#if 0
	HKEY   hKey; 
	LONG   ret; 
	char   comm_name[200];
	char   ValueName[200]; 
	int    i; 
	DWORD  sType,Reserved,cbData,cbValueName=0; 	
	CString result;

	sType=REG_SZ;
	Reserved=0; 

	ret=RegOpenKeyEx(HKEY_LOCAL_MACHINE,_T("HARDWARE\\DEVICEMAP\\SERIALCOMM"),0,KEY_ALL_ACCESS,&hKey); 

	if(ret==ERROR_SUCCESS)
	{ 
		i=0;
		m_comport.ResetContent();
		do
		{ 
			cbData=200;
			cbValueName=200; 
			memset(comm_name,0,200);   
			memset(ValueName,0,200); 
			ret=RegEnumValue(hKey, i, (LPWSTR)ValueName, &cbValueName, NULL, &sType, (LPBYTE)comm_name, &cbData); 
			if(ret==ERROR_SUCCESS) 
			{ 
				result.Format(_T("%s"), comm_name);
				if(result.CompareNoCase(L"COM1") != 0)
					m_comport.AddString(result);
				i++;
			} 			
			if(i==0)
				AfxMessageBox(_T("No device!!"));
		}while(ret==ERROR_SUCCESS);
		m_comport.SetCurSel(0);
	}
	else
	{
		OutputDebugString(_T("RegOpenKey-Fail!!"));
		::AfxMessageBox(_T("No device"));
	}
	RegCloseKey(hKey);
#endif
}
BOOL CSimpleTerminalDlg::ClosePort()
{
	if (hComm)
	{
		try
		{
			::CloseHandle(hComm);
		} 
		catch (int e)
		{
			_RPTF1(_CRT_WARN, "ClosePort - exception(%d)...\n",e);
			return FALSE;
		}

		hComm = NULL;
	}
}

BOOL CSimpleTerminalDlg::OpenPort()
{
	int selected = 0;
	CString m_ItemText;

	selected = m_comport.GetCurSel();

	if(selected < 0)
	{
		AfxMessageBox(_T("Pls select port to open!!"));
		return FALSE;
	}

	m_comport.GetLBText(selected, m_ItemText);
	//m_ItemText = "BandLuxe Wideband AT CMD Interface (COM5)"
	int indexPort = m_ItemText.Find(L"(", 0);
	CString item_tok = m_ItemText.Tokenize(L"(", indexPort);
	item_tok.Replace(L")", L"");

	if(m_ItemText.Find(L"COM") == -1)
	{
		AfxMessageBox(L"Error Com number");
		return FALSE;
	}

	m_ItemText= _T("\\\\.\\") + item_tok;

	hComm = CreateFile(m_ItemText,
		GENERIC_READ | GENERIC_WRITE,
		0,
		0,
		OPEN_EXISTING,
		0,
		0);

	if((hComm==INVALID_HANDLE_VALUE) || (hComm==NULL))
		return false;
	
	// Get baudrate that user selected
	CString strBaudrate;
	int sel = m_ComboRate.GetCurSel();	
	m_ComboRate.GetLBText(sel, strBaudrate);
	BaudRate = _wtol(strBaudrate);

	b_configure = ConfigurePort(BaudRate, ByteSize, fParity, Parity, StopBits);	

	b_Setcomm = SetCommunicationTimeouts(Timeout, Multiplier, TimeoutConstant, TimeoutMultiplier, TimeoutConstantwr);
	
	return true;
}

BOOL CSimpleTerminalDlg::SetCommunicationTimeouts(DWORD ReadIntervalTimeout, DWORD ReadTotalTimeoutMultiplier, DWORD ReadTotalTimeoutConstant, DWORD WriteTotalTimeoutMultiplier, DWORD WriteTotalTimeoutConstant)
{
#if 1
	memset(&m_CommTimeouts, 0, sizeof(m_CommTimeouts));
	//m_CommTimeouts = NULL;
	m_bPortReady = GetCommTimeouts (hComm, &m_CommTimeouts);

	m_CommTimeouts.ReadIntervalTimeout =ReadIntervalTimeout;
	m_CommTimeouts.ReadTotalTimeoutConstant =ReadTotalTimeoutConstant;
	m_CommTimeouts.ReadTotalTimeoutMultiplier =ReadTotalTimeoutMultiplier;
	m_CommTimeouts.WriteTotalTimeoutConstant = WriteTotalTimeoutConstant;
	m_CommTimeouts.WriteTotalTimeoutMultiplier =WriteTotalTimeoutMultiplier;

	m_bPortReady = SetCommTimeouts (hComm, &m_CommTimeouts);

	if(m_bPortReady ==0)
	{
		MessageBox(_T("StCommTimeouts function failed"),_T("Com Port Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;
	}
#endif
	return true;
}



BOOL CSimpleTerminalDlg::ConfigurePort(DWORD BaudRate, BYTE ByteSize, DWORD fParity, BYTE Parity, BYTE StopBits)
{
	if((m_bPortReady = GetCommState(hComm, &m_dcb))==0){
		MessageBox(_T("GetCommState Error"),_T("Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;}
	m_dcb.BaudRate =BaudRate;
	m_dcb.ByteSize = ByteSize;
	m_dcb.Parity =Parity ;
	m_dcb.StopBits =StopBits;
	m_dcb.fBinary=TRUE;
	m_dcb.fDsrSensitivity=false;
	m_dcb.fParity=fParity;
	m_dcb.fOutX=false;
	m_dcb.fInX=false;
	m_dcb.fNull=false;
	m_dcb.fAbortOnError=TRUE;
	m_dcb.fOutxCtsFlow=FALSE;
	m_dcb.fOutxDsrFlow=false;
	m_dcb.fDtrControl=DTR_CONTROL_DISABLE;
	m_dcb.fDsrSensitivity=false;
	m_dcb.fRtsControl=RTS_CONTROL_DISABLE;
	m_dcb.fOutxCtsFlow=false;
	m_dcb.fOutxCtsFlow=false;

	m_bPortReady = SetCommState(hComm, &m_dcb);
	if(m_bPortReady ==0){
		MessageBox(_T("SetCommState Error"),_T("Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;}
	return true;
}

void CSimpleTerminalDlg::OnBnClickedSend()
{
	//LPVOID lpBuffer;
	DWORD dwBytesTransferred=0;
	char  wBuffer[512];
	char  sBuffer[512];
	DWORD iBytesWritten=0;
	int l_nReadSize = 0;
	CString temp;	
	CSize size;
	size.cx=0;
	size.cy=30;
	
	edit_WriteCMD.GetWindowText(temp);

	if(edit_WriteCMD.GetWindowTextLength() <= 0)
	{
		AfxMessageBox(L"Enter your command");
		return;
	}
	else if((temp.Find(L"AT") != 0) && (temp.Find(L"at") != 0))
	{
		AfxMessageBox(L"Command Error");
		return;
	}

	memset(wBuffer, 0, sizeof(wBuffer));
	memset(sBuffer, 0, sizeof(sBuffer));

	//UpdateData();
	l_nReadSize = edit_WriteCMD.GetLine(0, (LPTSTR)wBuffer, 50);
	
	temp.Format(L"%s",wBuffer);

	if(BST_CHECKED == ((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck())
		temp.MakeUpper();
	else if(BST_CHECKED == ((CButton*)GetDlgItem(IDC_RADIO2))->GetCheck())
		temp.MakeLower();	

	int len = temp.GetLength();
	memset(wBuffer, 0, sizeof(wBuffer));
	WideCharToMultiByte(CP_OEMCP, NULL, temp, -1, wBuffer, 255, NULL, FALSE); 

	//int len = sizeof(wBuffer);
	wBuffer[len] = '\r\n';	// Null-Terminated

	b_WrFile = WriteFile(hComm, wBuffer, l_nReadSize+1, &iBytesWritten, NULL);	
	//Sleep(300);
	b_ReFile = ReadFile (hComm, sBuffer, 512, &dwBytesTransferred, NULL);

	CString strCmdWrite(wBuffer);
	CString strCmdRead(sBuffer);
	strCmdWrite.Append(L"\r\n\n");	

	if(!strCmdRead.IsEmpty())
	{
		strCmdRead.Replace(temp, L"");
		strCmdRead = strCmdRead.Trim();
		m_preCommand.SetWindowText(strCmdWrite); //.SetWindowText(test);

		// Write part
		CString wrtTemp = L"> ";
		wrtTemp.Append(strCmdWrite);
		m_log.InsertItem(0, wrtTemp);
		m_log.InsertItem(1, L"");
		
		// Read part
		int endidx = strCmdRead.Find(L"OK");

		if(strCmdRead.Find(L"ERROR") != NULL)
		{
			if(endidx == NULL) // AT -> OK
			{
				m_log.InsertItem(2, strCmdRead);
				m_log.InsertItem(3, L"");
			}
			else // AT+CPIN?
			{
				if(strCmdRead.GetLength() > 100) // ATI
				{
					int counter=0;
					BOOL endflag = TRUE;
					while(endflag)
					{
						CString temp;
						int startidx = 2;
						if(counter != NULL)
							startidx += counter;
						
						temp = strCmdRead;
							
						int ManuIdx  = strCmdRead.Find(L"Manufacturer:");
						int ModelIdx = strCmdRead.Find(L"Model:");
						int RevIdx   = strCmdRead.Find(L"Revision:");
						int ImeiIdx  = strCmdRead.Find(L"IMEI:");
						int endIdx   = strCmdRead.Find(L"OK");

						if(counter == NULL)
							temp.Truncate(ModelIdx);
						else if(counter == 1)
							temp.Truncate(RevIdx);
						else if(counter == 2)
							temp.Truncate(ImeiIdx);
						else if(counter == 3)
						    temp.Truncate(endIdx);

						m_log.InsertItem(startidx, temp);
						m_log.InsertItem(startidx+1, L"");

						strCmdRead.Replace(temp, L"");
						if(!strCmdRead.CompareNoCase(L"OK"))
						{
							m_log.InsertItem(startidx+2, strCmdRead);
							//m_log.InsertItem(startidx+3, L"");
							endflag = FALSE;
						}
						counter++;
					}					
				}
				else
				{
					BOOL endflag = TRUE;
					int counter=0;
					while(endflag)
					{
						CString strTemp = strCmdRead.Left(endidx);				

						int startidx = 2;
						if(counter != NULL)
							startidx += counter;

						m_log.InsertItem(startidx, strTemp);
						m_log.InsertItem(startidx+1, L"");
						strCmdRead.Replace(strTemp, L"");
						if(!strCmdRead.CompareNoCase(L"OK"))
						{
							m_log.InsertItem(startidx+1, strCmdRead);
							m_log.InsertItem(startidx+2, L"");

							endflag = FALSE;
						}
						else if(strCmdRead.Find(L"ERROR"))
						{
							m_log.InsertItem(startidx+1, strCmdRead);
							m_log.InsertItem(startidx+2, L"");
							endflag = FALSE;
						}
						counter++;
					}
				}				
			}
		}
		else // Show at command error
		{
			m_log.InsertItem(2, strCmdRead);
			m_log.InsertItem(3, L"");
		}

		strCmdRead.SetString(L"");
	}
	
	//ClosePort();	
	//WriteCMD.Clear();
	(CEdit*)GetDlgItem(IDC_EDIT1)->SetFocus();	
	int templength = edit_WriteCMD.GetWindowTextLength();
	edit_WriteCMD.SetSel(0, templength);
}

void CSimpleTerminalDlg::OnBnClickedClear()
{
	m_preCommand.SetWindowText(L"");
	m_log.DeleteAllItems();
}

void CSimpleTerminalDlg::OnBnOpenClose()
{
	BOOL Op = FALSE;
	CBitmap   dis_Bitmap, con_Bitmap, sdis_Bitmap, scon_Bitmap; 

	dis_Bitmap.LoadBitmap(IDB_Disconnectbtn);
	con_Bitmap.LoadBitmap(IDB_Connectbtn);
	sdis_Bitmap.LoadBitmap(IDB_sta_Disconnect);
	scon_Bitmap.LoadBitmap(IDB_sta_Connect);

	HBITMAP   hdBitmap=(HBITMAP)dis_Bitmap.Detach(); 
	HBITMAP   hcBitmap=(HBITMAP)con_Bitmap.Detach(); 
	HBITMAP   hsdBitmap=(HBITMAP)sdis_Bitmap.Detach(); 
	HBITMAP   hscBitmap=(HBITMAP)scon_Bitmap.Detach(); 

	CButton   *pButton=(CButton*)GetDlgItem(IDC_BUTTON2); 
	CButton   *sButton=(CButton*)GetDlgItem(IDC_BUTTON1);
	
	//Open one time
	if(!b_isConnected) // Not connected
	{		
		if(!OpenPort())
		{
			//AfxMessageBox(L"Open COM port Error!");
			return;
		}

		pButton-> SetBitmap(hdBitmap);
		sButton-> SetBitmap(hscBitmap);
		m_SendBtn.EnableWindow(TRUE);
		edit_WriteCMD.EnableWindow(TRUE);
		int templength = edit_WriteCMD.GetWindowTextLength();
		edit_WriteCMD.SetSel(0, templength);

		m_comport.EnableWindow(FALSE);
		m_preCommand.EnableWindow(TRUE);
		m_ComboRate.EnableWindow(FALSE);
		m_connectbtn.SetWindowText(L"Close");
		(CEdit*)GetDlgItem(IDC_EDIT1)->SetFocus();
		b_isConnected = TRUE;   // Open flag
	}
	else // Connected
	{
		pButton-> SetBitmap(hcBitmap);
		sButton-> SetBitmap(hsdBitmap);

		m_SendBtn.EnableWindow(FALSE);
		edit_WriteCMD.EnableWindow(FALSE);
		m_comport.EnableWindow(TRUE);
		m_preCommand.EnableWindow(FALSE);
		m_ComboRate.EnableWindow(TRUE);
		m_connectbtn.SetWindowText(L"Connect");
		(CEdit*)GetDlgItem(IDC_LIST5)->SetFocus();
		if(ClosePort())	
			b_isConnected = FALSE;   // Open flag
	}
}

void CSimpleTerminalDlg::EnumPortsWdm(CString& portname, CString& portname1)//CArray<SSerInfo,SSerInfo&> &asi)
{
	// get the set of network adapters on the system
	HDEVINFO hDevInfo = SetupDiGetClassDevs(&GUID_CLASS_COMPORT,
		NULL,
		NULL,
		DIGCF_PRESENT|DIGCF_DEVICEINTERFACE);

	// Enumerate through all devices in the set
	SP_DEVINFO_DATA DeviceInfoData;
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	for (DWORD i = 0; SetupDiEnumDeviceInfo(hDevInfo,i,&DeviceInfoData); i++)
	{
		DWORD regDataType = 0;
		TCHAR MyBuf[256] = {0};
		DWORD MyBufSize = 256;

		// get the device capabilities
		SetupDiGetDeviceRegistryProperty(hDevInfo,
			&DeviceInfoData,
			SPDRP_ENUMERATOR_NAME,
			&regDataType,
			(PBYTE)&MyBuf,
			MyBufSize,
			&MyBufSize);

		// we are only interested in removable devices
		if (wcsncmp(MyBuf,_T("USB"), 3) == 0) // || (wcsncmp(MyBuf,_T("USB"), 3) == 0))
		{
			TCHAR fname[256] = {0};
			DWORD bufSize = 256;

			// get the device friendly name
			SetupDiGetDeviceRegistryProperty(hDevInfo,
				&DeviceInfoData,
				SPDRP_FRIENDLYNAME,
				&regDataType,
				(PBYTE)fname,
				bufSize,
				&bufSize);

			if((_tcsstr(fname,_T(BR_AT_PORT_NAME))) || (_tcsstr(fname, _T(BR_ICERA_PORT_NAME))))
			{
				// Add an entry to the array
				TCHAR desc[256] = {0};
				SSerInfo si;
				si.strFriendlyName = fname;
				if(portname.IsEmpty())
					portname.Format(L"%s", fname);
				else
					portname1.Format(L"%s", fname);
				// if no device friendly name, get the device description
				// get the device friendly name
				SetupDiGetDeviceRegistryProperty(
					hDevInfo,
					&DeviceInfoData,
					SPDRP_DEVICEDESC,
					&regDataType,
					(PBYTE)desc,
					bufSize,
					&bufSize);

				si.strPortDesc = desc;

				HKEY hKey = SetupDiOpenDevRegKey(
					hDevInfo, 
					&DeviceInfoData, 
					DICS_FLAG_GLOBAL,
					NULL,
					DIREG_DEV,KEY_READ);

				TCHAR szPortName[MAX_PATH];
				if (hKey)
				{
					DWORD dwType = REG_SZ;
					DWORD dwReqSize = sizeof(szPortName);

					// Query for portname
					if (RegQueryValueEx(hKey,_T("PortName"), 0, &dwType, (LPBYTE)&szPortName, &dwReqSize) == ERROR_SUCCESS)
					{
						//portnum.Format(L"%s", szPortName);
						si.strPortName = szPortName;

					}
				}				
			}
		}
	}

	//  Cleanup
	SetupDiDestroyDeviceInfoList(hDevInfo);
}
void CSimpleTerminalDlg::OnBnClickedExit()
{
	// same as double-clicking on main window close box
	ASSERT(AfxGetApp()->m_pMainWnd != NULL);
	AfxGetApp()->m_pMainWnd->SendMessage(WM_CLOSE);
	stopThread = FALSE;
	Sleep(300);
}

#if 0
void CSimpleTerminalDlg::OnMouseMove(UINT nFlags, CPoint point)
{
#if 1
	// TODO: �b���[�J�z���T���B�z�`���{���X�M (��) �I�s�w�]��
	CRect   rc; 
	GetDlgItem(IDC_CLEAR)-> GetWindowRect(rc); 
	
	ScreenToClient(&rc);
	//ClientToScreen(&rc);
	if(rc.PtInRect(point))
	{
		CDC   *dc=GetDC(); 
		dc-> TextOut(rc.left,rc.top, L"����1 "); 
		//AfxMessageBox(L"!!!!");
	}
	if((point.x >= rc.top) && (point.x <= rc.bottom))
	{
		if((point.y >= rc.left) && (point.y <= rc.right))
		{
			CDC   *dc=GetDC(); 
			dc-> TextOut(rc.left,rc.top, L"���� "); 
			//AfxMessageBox(L"!!!!");
		}
		
	}
	CDialog::OnMouseMove(nFlags, point);
#endif
}
#endif
