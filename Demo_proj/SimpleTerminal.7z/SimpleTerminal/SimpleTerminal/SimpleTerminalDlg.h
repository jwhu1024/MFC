// SimpleTerminalDlg.h : ���Y��
//

#pragma once
#include "afxwin.h"
#include <setupapi.h>
#include <WinIoCtl.h>
#include "afxcmn.h"

#define BR_AT_PORT_NAME    "BandLuxe Wideband AT CMD Interface"
#define BR_ICERA_PORT_NAME "BandLuxe AT Port"
#define BR_MODEM_PORT_NAME "BandLuxe Wideband Modem Adapter"

// CSimpleTerminalDlg ��ܤ��
class CSimpleTerminalDlg : public CDialog
{
// �غc
public:
	CSimpleTerminalDlg(CWnd* pParent = NULL);	// �зǫغc�禡
	virtual ~CSimpleTerminalDlg(void);

// ��ܤ�����
	enum { IDD = IDD_SIMPLETERMINAL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩

// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedSend();
	DECLARE_MESSAGE_MAP()	

public:	
	BOOL PreTranslateMessage(MSG* pMsg);
	BOOL OpenPort();
	void Enumport();
	BOOL ClosePort();
	BOOL ConfigurePort(DWORD BaudRate, BYTE ByteSize, DWORD fParity, BYTE Parity, BYTE StopBits);
	BOOL SetCommunicationTimeouts(DWORD ReadIntervalTimeout, DWORD ReadTotalTimeoutMultiplier, DWORD ReadTotalTimeoutConstant, DWORD WriteTotalTimeoutMultiplier, DWORD WriteTotalTimeoutConstant);
	CComboBox m_comport;
	DWORD BaudRate, fParity;
	BYTE ByteSize, Parity, StopBits;
	HANDLE hComm;
	DCB m_dcb;
	BOOL m_bPortReady, b_configure, b_Setcomm, b_WrFile, b_ReFile;
	BOOL b_isConnected;
	COMMTIMEOUTS m_CommTimeouts;
	DWORD Timeout;
	DWORD Multiplier;
	DWORD TimeoutConstant;
	DWORD TimeoutMultiplier;
	DWORD TimeoutConstantwr;
	CEdit edit_WriteCMD;
	CEdit m_preCommand;
public:
	CComboBox m_ComboRate;
public:
	afx_msg void OnBnOpenClose();
	void EnumPortsWdm(CString& portname, CString& portname1);
public:
	CButton m_connectbtn;
public:
	CButton m_SendBtn;
public:
	CListCtrl m_log;

	int paintcount;
public:
	afx_msg void OnBnClickedExit();
	CWinThread* m_Thread;
public:
	CEdit m_marq;
	BOOL  stopThread;
};
