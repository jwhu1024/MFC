// FORMVIEWMY.cpp : ��@��
//

#include "stdafx.h"
#include "MDIL.h"
#include "FORMVIEWMY.h"


// FORMVIEWMY

IMPLEMENT_DYNCREATE(FORMVIEWMY, CFormView)

FORMVIEWMY::FORMVIEWMY()
	: CFormView(FORMVIEWMY::IDD)
	, m_hCommand( ::CreateEvent(FALSE, FALSE, NULL, NULL) )
{

}

FORMVIEWMY::~FORMVIEWMY()
{
}

void FORMVIEWMY::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, WriteCMD);
	DDX_Control(pDX, IDC_COMBO1, Box);
	DDX_Control(pDX, IDC_EDIT2, m_resp);
}

BEGIN_MESSAGE_MAP(FORMVIEWMY, CFormView)
	ON_BN_CLICKED(IDC_BUTTON2, &FORMVIEWMY::OnBnClickedChangePort)
	ON_BN_CLICKED(IDC_BUTTON1, &FORMVIEWMY::OnBnClickedSend)
	ON_BN_CLICKED(IDC_BUTTON3, &FORMVIEWMY::OnBnClickedClear)
	ON_BN_CLICKED(IDC_BUTTON4, &FORMVIEWMY::OnBnClickedExit)
END_MESSAGE_MAP()

#if 1
// FORMVIEWMY �E�_
BOOL FORMVIEWMY::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message==WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_RETURN:
		case VK_ESCAPE:
				OnBnClickedSend();
			return TRUE;
			break;
		default:
			break;
		}
	}
	return CFormView::PreTranslateMessage(pMsg);
}
#endif
#ifdef _DEBUG
void FORMVIEWMY::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void FORMVIEWMY::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif
#endif //_DEBUG



// FORMVIEWMY �T���B�z�`��
void FORMVIEWMY::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	ResizeParentToFit();
	BaudRate = 115200;
	ByteSize = 8;
	fParity = 0;
	Parity	= 0;
	StopBits = 0;
	Timeout = 250;
	Multiplier = 1;
	TimeoutMultiplier = 1;
	TimeoutConstant = 250;

	b_open=TRUE;
	Enumport();
	(CEdit*)GetDlgItem(IDC_EDIT1)->SetFocus();	
#if 0	
	DWORD dwThreadId;
	m_hUpdateThread = ::CreateThread(0,0,RunDld,(LPVOID)this,0,&dwThreadId);
#endif

}
#if 0
DWORD WINAPI FORMVIEWMY::RunDld (LPVOID lpArg)
{
	// Route the method to the actual object
	FORMVIEWMY* pThis = reinterpret_cast<FORMVIEWMY*>(lpArg);
	return pThis->UpdateThread();
}
#endif

void FORMVIEWMY::Enumport()
{
	HKEY   hKey; 
	LONG   ret; 
	char   comm_name[200];
	char   ValueName[200]; 
	int    i; 
	DWORD  sType,Reserved,cbData,cbValueName=0; 	
	CString result;

	sType=REG_SZ;
	Reserved=0; 

	ret=RegOpenKeyEx(HKEY_LOCAL_MACHINE,_T("HARDWARE\\DEVICEMAP\\SERIALCOMM"),0,KEY_ALL_ACCESS,&hKey); 

	if(ret==ERROR_SUCCESS)
	{ 
		i=0;
		Box.ResetContent();
		do
		{ 
			cbData=200;
			cbValueName=200; 
			memset(comm_name,0,200);   
			memset(ValueName,0,200); 
			ret=RegEnumValue(hKey, i, (LPWSTR)ValueName, &cbValueName, NULL, &sType, (LPBYTE)comm_name, &cbData); 
			if(ret==ERROR_SUCCESS) 
			{ 
				result.Format(_T("%s"), comm_name);
				Box.AddString(result);
				i++;
			} 			
			if(i==0)
				AfxMessageBox(_T("No device!!"));
		}while(ret==ERROR_SUCCESS);
		Box.SetCurSel(0);
	}
	else
	{
		OutputDebugString(_T("RegOpenKey-Fail!!"));
		::AfxMessageBox(_T("No device"));
	}
	RegCloseKey(hKey);
}
BOOL FORMVIEWMY::ClosePort()
{
	if (hComm)
	{
		try
		{
			::CloseHandle(hComm);
		} 
		catch (int e)
		{
			_RPTF1(_CRT_WARN, "ClosePort - exception(%d)...\n",e);
			return FALSE;
		}

		hComm = NULL;
	}
}

BOOL FORMVIEWMY::OpenPort()
{
	int selected = 0;
	CString m_ItemText;

	selected = Box.GetCurSel();

	if(selected < 0)
	{
		AfxMessageBox(_T("Pls select port to open!!"));
		return FALSE;
	}

	Box.GetLBText(selected, m_ItemText);

	if(m_ItemText.Find(L"COM") == -1)
	{
		AfxMessageBox(L"Error Com number");
		return FALSE;
	}

	m_ItemText= _T("\\\\.\\") + m_ItemText;

	hComm = CreateFile(m_ItemText,
		GENERIC_READ | GENERIC_WRITE,
		0,
		0,
		OPEN_EXISTING,
		0,
		0);

	if((hComm==INVALID_HANDLE_VALUE) || (hComm==NULL))
		return false;

	b_configure = ConfigurePort(BaudRate, ByteSize, fParity, Parity, StopBits);	

	b_Setcomm = SetCommunicationTimeouts(Timeout, Multiplier, TimeoutConstant, TimeoutMultiplier, TimeoutConstantwr);

	b_open=FALSE;
	return true;
}

BOOL FORMVIEWMY::SetCommunicationTimeouts(DWORD ReadIntervalTimeout, DWORD ReadTotalTimeoutMultiplier, DWORD ReadTotalTimeoutConstant, DWORD WriteTotalTimeoutMultiplier, DWORD WriteTotalTimeoutConstant)
{
#if 1
	memset(&m_CommTimeouts, 0, sizeof(m_CommTimeouts));
	//m_CommTimeouts = NULL;
	m_bPortReady = GetCommTimeouts (hComm, &m_CommTimeouts);

	m_CommTimeouts.ReadIntervalTimeout =ReadIntervalTimeout;
	m_CommTimeouts.ReadTotalTimeoutConstant =ReadTotalTimeoutConstant;
	m_CommTimeouts.ReadTotalTimeoutMultiplier =ReadTotalTimeoutMultiplier;
	m_CommTimeouts.WriteTotalTimeoutConstant = WriteTotalTimeoutConstant;
	m_CommTimeouts.WriteTotalTimeoutMultiplier =WriteTotalTimeoutMultiplier;

	m_bPortReady = SetCommTimeouts (hComm, &m_CommTimeouts);

	if(m_bPortReady ==0)
	{
		MessageBox(_T("StCommTimeouts function failed"),_T("Com Port Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;
	}
#endif
	return true;
}



BOOL FORMVIEWMY::ConfigurePort(DWORD BaudRate, BYTE ByteSize, DWORD fParity, BYTE Parity, BYTE StopBits)
{
	if((m_bPortReady = GetCommState(hComm, &m_dcb))==0){
		MessageBox(_T("GetCommState Error"),_T("Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;}
	m_dcb.BaudRate =BaudRate;
	m_dcb.ByteSize = ByteSize;
	m_dcb.Parity =Parity ;
	m_dcb.StopBits =StopBits;
	m_dcb.fBinary=TRUE;
	m_dcb.fDsrSensitivity=false;
	m_dcb.fParity=fParity;
	m_dcb.fOutX=false;
	m_dcb.fInX=false;
	m_dcb.fNull=false;
	m_dcb.fAbortOnError=TRUE;
	m_dcb.fOutxCtsFlow=FALSE;
	m_dcb.fOutxDsrFlow=false;
	m_dcb.fDtrControl=DTR_CONTROL_DISABLE;
	m_dcb.fDsrSensitivity=false;
	m_dcb.fRtsControl=RTS_CONTROL_DISABLE;
	m_dcb.fOutxCtsFlow=false;
	m_dcb.fOutxCtsFlow=false;

	m_bPortReady = SetCommState(hComm, &m_dcb);
	if(m_bPortReady ==0){
		MessageBox(_T("SetCommState Error"),_T("Error"),MB_OK+MB_ICONERROR);
		CloseHandle(hComm);
		return false;}
	return true;
}

void FORMVIEWMY::OnBnClickedChangePort()
{
	b_open = TRUE;
	Box.EnableWindow(TRUE);
	ClosePort();
}

void FORMVIEWMY::OnBnClickedSend()
{
	SetEvent(m_hCommand);
	//LPVOID lpBuffer;
	DWORD dwBytesTransferred=0;
	char  wBuffer[256];
	char  sBuffer[256];
	DWORD iBytesWritten=0;
	int l_nReadSize = 0;
	CString temp;	
	BOOL Op = FALSE;

	if(WriteCMD.GetWindowTextLength() <= 0)
	{
		AfxMessageBox(L"Enter your command");
		return;
	}

	//Open one time
	//if(b_open)
	//{
		Op = OpenPort();
		if(!Op)
			return;
	//}

	Box.EnableWindow(FALSE);
	m_resp.Clear();

	memset(wBuffer, 0, sizeof(wBuffer));
	memset(sBuffer, 0, sizeof(sBuffer));

	//UpdateData();
	l_nReadSize=WriteCMD.GetLine(0, (LPTSTR)wBuffer, 50);

	temp.Format(L"%s",wBuffer);
	int len = temp.GetLength();
	memset(wBuffer, 0, sizeof(wBuffer));
	WideCharToMultiByte(CP_OEMCP, NULL, temp, -1, wBuffer, 255, NULL, FALSE); 

	//int len = sizeof(wBuffer);
	wBuffer[len] = '\r\n';	// Null-Terminated
	
	//PurgeComm(hComm, PURGE_TXCLEAR);
	b_WrFile = WriteFile(hComm, wBuffer, l_nReadSize+1, &iBytesWritten, NULL);	
	//PurgeComm(hComm, PURGE_RXCLEAR);
	b_ReFile = ReadFile (hComm, sBuffer, 256, &dwBytesTransferred, NULL);

	CString test(sBuffer);
	if(!test.IsEmpty())
	{
		test.Replace(temp, L"");
		test = test.Trim();
		m_resp.SetWindowText(test); //.SetWindowText(test);
		test.SetString(L"");
	}

	ClosePort();	
	//WriteCMD.Clear();
}

#if 0
DWORD FORMVIEWMY::UpdateThread ()
{
	DWORD	wWaitObject = WAIT_TIMEOUT;
	
	while ((::WaitForSingleObject(m_hCommand, INFINITE)) != WAIT_OBJECT_0 )
	{
		OutputDebugString(L"Event coming!");
	}
	return 1;
}
#endif
void FORMVIEWMY::OnBnClickedClear()
{
	m_resp.SetWindowText(L"");
}

void FORMVIEWMY::OnBnClickedExit()
{
	// TODO: �b���[�J����i���B�z�`���{���X
}
