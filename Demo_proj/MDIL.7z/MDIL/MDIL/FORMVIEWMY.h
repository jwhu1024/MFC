#pragma once
#include "afxwin.h"


// FORMVIEWMY �����˵�

class FORMVIEWMY : public CFormView
{
	DECLARE_DYNCREATE(FORMVIEWMY)

protected:
	FORMVIEWMY();           // �ʺA�إߩҨϥΪ��O�@�غc�禡
	virtual ~FORMVIEWMY();

public:
	enum { IDD = IDD_FORMVIEWMY };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩
	virtual void OnInitialUpdate(); // called first time after construct
	
	DECLARE_MESSAGE_MAP()
#if 0
protected:
	// Firmware Update Operation
	static DWORD WINAPI RunDld(LPVOID lpArg);
	DWORD UpdateThread();
#endif
public:
	afx_msg void OnBnClickedChangePort();
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedClear();
public:	
	BOOL PreTranslateMessage(MSG* pMsg);
	HANDLE m_hUpdateThread;
	HANDLE m_hCommand;
	BOOL OpenPort();
	void Enumport();
	BOOL ClosePort();
	BOOL ConfigurePort(DWORD BaudRate, BYTE ByteSize, DWORD fParity, BYTE Parity, BYTE StopBits);
	BOOL SetCommunicationTimeouts(DWORD ReadIntervalTimeout, DWORD ReadTotalTimeoutMultiplier, DWORD ReadTotalTimeoutConstant, DWORD WriteTotalTimeoutMultiplier, DWORD WriteTotalTimeoutConstant);
	CComboBox Box;
	BOOL b_open;
	DWORD BaudRate, fParity;
	BYTE ByteSize, Parity, StopBits;
	HANDLE hComm;
	DCB m_dcb;
	BOOL m_bPortReady, b_configure, b_Setcomm, b_WrFile, b_ReFile;
	COMMTIMEOUTS m_CommTimeouts;
	DWORD Timeout;
	DWORD Multiplier;
	DWORD TimeoutConstant;
	DWORD TimeoutMultiplier;
	DWORD TimeoutConstantwr;
	CEdit WriteCMD;
	CEdit m_resp;
	
public:
	afx_msg void OnBnClickedExit();
};


