// FinalChatSocketCliDlg.cpp : ��@��
//

#include "stdafx.h"
#include "FinalChatSocketCli.h"
#include "FinalChatSocketCliDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// �� App About �ϥ� CAboutDlg ��ܤ��

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CFinalChatSocketCliDlg ��ܤ��




CFinalChatSocketCliDlg::CFinalChatSocketCliDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFinalChatSocketCliDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFinalChatSocketCliDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_EDIT1, m_edit);
	DDX_Control(pDX, IDC_BUTTON1, m_send);
	DDX_Control(pDX, IDC_EDIT2, m_ip);
	DDX_Control(pDX, IDC_EDIT3, m_user);
	DDX_Control(pDX, IDC_BUTTON2, m_connect);
	DDX_Control(pDX, IDC_BUTTON3, m_disconnect);
}

BEGIN_MESSAGE_MAP(CFinalChatSocketCliDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON2, &CFinalChatSocketCliDlg::OnBnClickedConnect)
	ON_BN_CLICKED(IDC_BUTTON3, &CFinalChatSocketCliDlg::OnBnClickedDisconnet)
	ON_BN_CLICKED(IDC_BUTTON1, &CFinalChatSocketCliDlg::OnBnClickedSend)
	ON_BN_CLICKED(IDC_BUTTON4, &CFinalChatSocketCliDlg::OnBnClickedClear)
END_MESSAGE_MAP()


// CFinalChatSocketCliDlg �T���B�z�`��

BOOL CFinalChatSocketCliDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message==WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_RETURN:
		case VK_ESCAPE:
			if(flagConnect)
				OnBnClickedSend();
			return TRUE;
			break;
		default:
			break;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

BOOL CFinalChatSocketCliDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w
	LONG mListStyle = GetWindowLong(m_list.m_hWnd, GWL_STYLE);
	mListStyle &= ~LVS_TYPEMASK;
	mListStyle |= LVS_REPORT;
	SetWindowLong(m_list.m_hWnd, GWL_STYLE, mListStyle);

	m_list.InsertColumn(0,"Message");
	m_list.SetColumnWidth(0,500);

	m_ip.SetWindowText("192.168.3.85");
	m_edit.SetLimitText(90);
	m_edit.SetFocus();	

	m_connect.EnableWindow(TRUE);
	m_disconnect.EnableWindow(FALSE);
	m_send.EnableWindow(FALSE);

	count = 0;

	return FALSE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CFinalChatSocketCliDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CFinalChatSocketCliDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CFinalChatSocketCliDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

UINT thread (LPVOID p)
{
	CFinalChatSocketCliDlg *dlg=(CFinalChatSocketCliDlg*) AfxGetApp()->GetMainWnd();
	
	char buff[100], member[100];
	memset(buff, 0, sizeof(buff));

	CSize size;
	size.cx=0;
	size.cy=30;
	int s=1;
	while(connect(dlg->clisock,(sockaddr*)&(dlg->cli),sizeof(dlg->cli)))
	{
		dlg->m_edit.SetWindowText("Wait...");
	}
	dlg->flagConnect = 1;

	strcpy(member, dlg->username);
	send(dlg->clisock, member, 100,0);
	//test recv member name
	// Connected action
	dlg->m_user.EnableWindow(FALSE);
	dlg->m_send.EnableWindow(TRUE);	
	dlg->m_connect.EnableWindow(FALSE);
	dlg->m_disconnect.EnableWindow(TRUE);
	dlg->GetDlgItem(IDC_STATICSTATUS)->SetWindowText("Connected");

	if(dlg->clisock != INVALID_SOCKET)
	{
		while(s != SOCKET_ERROR && dlg->flagConnect != 0)
		{
			s = recv(dlg->clisock, buff, 100, 0);
			if(s != SOCKET_ERROR && dlg->flagConnect != 0)
			{
				dlg->m_list.InsertItem(dlg->count++, buff);
				dlg->m_list.Scroll(size);
			}
		}	
		// Disconnect action
		dlg->m_send.EnableWindow(FALSE);
		dlg->m_connect.EnableWindow(TRUE);
		dlg->m_disconnect.EnableWindow(FALSE);
		dlg->m_user.EnableWindow(TRUE);
		dlg->GetDlgItem(IDC_STATICSTATUS)->SetWindowText("Disconnected");	
		dlg->flagConnect = 0;
	}
	return 1;
}

void CFinalChatSocketCliDlg::OnBnClickedConnect()
{
	char ipaddress[35];
	m_ip.GetWindowText(ipaddress,30);
	cli.sin_addr.s_addr = inet_addr(ipaddress);
	cli.sin_family = AF_INET;
	cli.sin_port = htons(7199);	

	//Get user name for window
	m_user.GetWindowText(username);
	if(username.IsEmpty())
	{
		AfxMessageBox("Please enter your name");
		return;
	}
	//----------------------
	// Initialize Winsock
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR) {
		wprintf(L"WSAStartup function failed with error: %d\n", iResult);
		//return 1;
	}
	//----------------------
	// Create a SOCKET for connecting to server
	clisock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (clisock == INVALID_SOCKET) {
		AfxMessageBox("error");
		WSACleanup();
		//return 1;
	}
	else
		AfxBeginThread(thread,0);
}

void CFinalChatSocketCliDlg::OnBnClickedDisconnet()
{
	flagConnect = 0;
	closesocket(clisock);
}

void CFinalChatSocketCliDlg::OnBnClickedSend()
{
	CSize size;
	size.cx=0;
	size.cy=30;
	char buff[100];	
	CString temp;
	int user_length;

	m_edit.GetWindowText(buff, 100);
	m_edit.SetWindowText("");

	temp = username;
	//char to cstring
	CString usertext(buff);
	temp.Append(" : ");
	temp.Append(usertext);
	user_length = username.GetLength();


	//cstring to char
	strcpy(buff, temp);
	
	if(buff[user_length+3] != 0)
	{
		m_list.InsertItem(count++, buff);
		m_list.Scroll(size);
		send(clisock, buff, 100, 0);
	}
}

void CFinalChatSocketCliDlg::OnBnClickedClear()
{
	m_list.DeleteAllItems();
	count = 0;
}
