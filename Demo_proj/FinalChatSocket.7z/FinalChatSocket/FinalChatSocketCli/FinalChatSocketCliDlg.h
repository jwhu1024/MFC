// FinalChatSocketCliDlg.h : ���Y��
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CFinalChatSocketCliDlg ��ܤ��
class CFinalChatSocketCliDlg : public CDialog
{
// �غc
public:
	CFinalChatSocketCliDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_FINALCHATSOCKETCLI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_list;
	CEdit m_edit;
	CButton m_send;
	CEdit m_ip;
	SOCKET clisock;
	sockaddr_in cli;
	afx_msg void OnBnClickedConnect();
	int flagConnect;
	int count;
	afx_msg void OnBnClickedDisconnet();
	afx_msg void OnBnClickedSend();
	BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedClear();
	CEdit m_user;
	CString username;
	CButton m_connect;
	CButton m_disconnect;
	BOOL connect_state;
};
