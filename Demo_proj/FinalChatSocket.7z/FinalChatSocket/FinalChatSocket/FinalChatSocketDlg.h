// FinalChatSocketDlg.h : ���Y��
//

#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CFinalChatSocketDlg ��ܤ��
class CFinalChatSocketDlg : public CDialog
{
// �غc
public:
	CFinalChatSocketDlg(CWnd* pParent = NULL);	// �зǫغc�禡
	~CFinalChatSocketDlg();

// ��ܤ�����
	enum { IDD = IDD_FINALCHATSOCKET_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_list;
	CEdit m_edit;
	CButton m_send;
	SOCKET sock,msgsock[100],clisock;
	int addlen;
	sockaddr_in serv;
	int count;
	int msgcount;
	int jj;
	int getcount();
	void sendtoall(SOCKET s,char*);
	afx_msg void OnBnClickedSend();
	BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnBnClickedClear();
	CString ParseMemberName(char * buff);
	CString username;
	CListCtrl m_listclient;
	int m_itemCount;
	int flagConnect;
};
