// FinalChatSocketDlg.cpp : ��@��
//

#include "stdafx.h"
#include "FinalChatSocket.h"
#include "FinalChatSocketDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// �� App About �ϥ� CAboutDlg ��ܤ��

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CFinalChatSocketDlg ��ܤ��




CFinalChatSocketDlg::CFinalChatSocketDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFinalChatSocketDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CFinalChatSocketDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Control(pDX, IDC_EDIT1, m_edit);
	DDX_Control(pDX, IDC_BUTTON1, m_send);
	DDX_Control(pDX, IDC_LIST3, m_listclient);
}

BEGIN_MESSAGE_MAP(CFinalChatSocketDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CFinalChatSocketDlg::OnBnClickedSend)
	ON_BN_CLICKED(IDC_BUTTON2, &CFinalChatSocketDlg::OnBnClickedClear)
END_MESSAGE_MAP()


// CFinalChatSocketDlg �T���B�z�`��

CFinalChatSocketDlg::~CFinalChatSocketDlg()
{
	send(clisock,"Disconnected",100,0);
}

BOOL CFinalChatSocketDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message==WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
		case VK_RETURN:
		case VK_ESCAPE:
			//if(flagConnect)
			OnBnClickedSend();
			return TRUE;
			break;
		default:
			break;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

int CFinalChatSocketDlg::getcount()
{
	for(int i=0; i<50; i++)
	{
		if(msgsock[i] == NULL)
		{
			return i;
		}
	}
	return -1;
}

UINT thread (LPVOID p)
{
	//CFinalChatSocketDlg* pThis = (CFinalChatSocketDlg*)p;
	CFinalChatSocketDlg *pThis=(CFinalChatSocketDlg*)AfxGetApp()->GetMainWnd();
	CSize size;
	size.cx=0;
	size.cy=30;
	char buff[100], member[100];
	int s=1, loop=0;
	int static_count, m_tempcount;
	//CString clientName;

	memset(buff, 0, sizeof(buff));
	
	pThis->msgcount = pThis->getcount();
	if(pThis->msgcount != -1)
		loop = 1;
	else
		loop = 0;

	static_count = pThis->msgcount;

	if(loop)
	{
		int item_check;
		
		pThis->msgsock[static_count] = accept(pThis->sock,(sockaddr*)&(pThis->serv),&(pThis->addlen));
		pThis->flagConnect = 1;
		//recv member name
		recv(pThis->msgsock[static_count], member, 100, 0);
		CString temp_member(member);
		pThis->m_listclient.InsertItem(pThis->m_itemCount, member);
		pThis->m_list.Scroll(size);
		m_tempcount = pThis->m_itemCount;
		pThis->m_itemCount++;
		if(pThis->msgsock[static_count] == INVALID_SOCKET)
			AfxMessageBox("Error Accept!!");
		else
		{		
			CString str_member(member);
			CString str_ip;
			pThis->m_send.EnableWindow(TRUE);
			pThis->SetForegroundWindow();
			str_member.Insert(0, "[System] ");
			str_member.Append(" login...");
			pThis->m_list.InsertItem(pThis->count++, str_member);
			pThis->m_list.Scroll(size);
			str_ip.Format("[System] IP:%s", inet_ntoa(pThis->serv.sin_addr));
			pThis->m_list.InsertItem(pThis->count++, str_ip);
			pThis->m_list.Scroll(size);

			pThis->m_list.Scroll(size);
			AfxBeginThread(thread, 0);
			while(s != SOCKET_ERROR)
			{
				s = recv(pThis->msgsock[static_count], buff,100,0);
				pThis->SetForegroundWindow();
				if(s != SOCKET_ERROR)
				{
					pThis->m_list.InsertItem(pThis->count++, buff);
					pThis->m_list.Scroll(size);
					pThis->sendtoall(pThis->msgsock[static_count], buff);
				}
				memset(buff, 0, sizeof(buff));
			}
		}
		// Disconnect action
		pThis->flagConnect = 0;		
		CString str_dis;
		str_dis.Format("[System] %s logout...", member);
		send(pThis->msgsock[static_count],"Disconnected", 100, 0);
		pThis->m_list.InsertItem(pThis->count++, str_dis);
		pThis->m_list.Scroll(size);
		int ttt = pThis->m_listclient.GetItemCount();
		// Check client in listbox and remove it when disconnect.
		for(item_check=0; item_check<(pThis->msgcount); item_check++)
		{
			if(pThis->m_listclient.GetItemText(item_check,0) == temp_member)
			{
				pThis->m_listclient.DeleteItem(item_check);
				pThis->m_itemCount--;	
			}			
		}
		// If no client connect on server, disable the send button.
		if(pThis->m_listclient.GetItemCount() == 0)
		{
			pThis->m_send.EnableWindow(FALSE);
			pThis->m_itemCount = 0;
		}
		// Close socket and end the thread when disconnect.
		closesocket(pThis->msgsock[pThis->msgcount]);
		AfxEndThread(0);
	}	
	
	return 1;
}

BOOL CFinalChatSocketDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, TRUE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w
	LONG mListStyle = GetWindowLong(m_list.m_hWnd, GWL_STYLE);
	mListStyle &= ~LVS_TYPEMASK;
	mListStyle |= LVS_REPORT;
	SetWindowLong(m_list.m_hWnd, GWL_STYLE, mListStyle);

	LONG mListStyleC = GetWindowLong(m_listclient.m_hWnd, GWL_STYLE);
	mListStyleC &= ~LVS_TYPEMASK;
	mListStyleC |= LVS_LIST;
	SetWindowLong(m_listclient.m_hWnd, GWL_STYLE, mListStyle);

	m_list.InsertColumn(0,"Message");
	m_list.SetColumnWidth(0,500);
	m_listclient.InsertColumn(0,"Client");
	m_listclient.SetColumnWidth(0,80);
	m_send.EnableWindow(FALSE);
	count = 0;
	m_itemCount = 0;
	flagConnect = 0;
	m_edit.SetLimitText(90);
	m_edit.SetFocus();

	username = "Server : ";
	//----------------------
	// Initialize Winsock
	for(int i=0; i<50; i++)
		msgsock[i] = NULL;

	WSADATA wsaData;
	int iResult = 0;            // used to return function results

	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != NO_ERROR) {
		wprintf(L"Error at WSAStartup()\n");
		return 1;
	}	

	sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (sock == INVALID_SOCKET) {
		wprintf(L"socket function failed with error: %u\n", WSAGetLastError());
		WSACleanup();
		return 1;
	}

	serv.sin_family = AF_INET;
	serv.sin_addr.s_addr = INADDR_ANY; //inet_addr("192.168.56.1"); //INADDR_ANY;
	//sin_addr.S_un.S.addr=htonl("IP�a�}");
	serv.sin_port = htons(7199); //23); //
	addlen = sizeof(serv);

	iResult = bind(sock, (SOCKADDR *) &serv, sizeof (serv));
	if (iResult == SOCKET_ERROR) {
		wprintf(L"bind failed with error %u\n", WSAGetLastError());
		closesocket(sock);
		WSACleanup();
		return 1;
	}
	else
		wprintf(L"bind returned success\n");
	//----------------------
	// Listen for incoming connection requests.
	// on the created socket
	if (listen(sock, 5) == SOCKET_ERROR) {
		wprintf(L"listen failed with error: %ld\n", WSAGetLastError());
		closesocket(sock);
		WSACleanup();
		return 1;
	}	
	else
		AfxBeginThread(thread, 0);

	return FALSE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CFinalChatSocketDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CFinalChatSocketDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CFinalChatSocketDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CFinalChatSocketDlg::OnBnClickedSend()
{
	int showtime=0, user_length;
	CSize size;
	size.cx=0;
	size.cy=30;
	char buff[100];
	m_edit.GetWindowText(buff, 100);
	m_edit.SetWindowText("");
	CString temp;

	user_length = username.GetLength();
	temp = username;

	//char to cstring
	CString usertext(buff);
	temp.Append(usertext);

	//cstring to char
	strcpy(buff, temp);
	
	if(buff[user_length] != 0)
	{
		for(int i=0; i<50; i++)
		{
			if(msgsock[i] != NULL)
			{				
				send(msgsock[i], buff, 100, 0);
				if(showtime < 1 && (m_listclient.GetItemCount() > 0))
				{
					m_list.InsertItem(count++, buff);
					m_list.Scroll(size);
				}
				showtime++;
			}
			else
				break;
		}	
		return;
	}
}


void CFinalChatSocketDlg::OnBnClickedClear()
{
	m_list.DeleteAllItems();
}

void CFinalChatSocketDlg::sendtoall(SOCKET s,char* buff)
{
	for(int i=0; i<50; i++)
	{
		if((msgsock[i] != s) && (msgsock[i] != NULL))
		{
			send(msgsock[i], buff, 100, 0);
		}
	}	
}

CString CFinalChatSocketDlg::ParseMemberName(char * buff)
{
	CString sStr(buff);
	int count = sStr.Find(":"); // 123 :
	sStr = sStr.Left(count-1);

	return sStr;
	//clientName = pThis->ParseMemberName(buff); // Get Client Name
	//pThis->m_listclient.InsertItem(pThis->m_itemCount, clientName);
}