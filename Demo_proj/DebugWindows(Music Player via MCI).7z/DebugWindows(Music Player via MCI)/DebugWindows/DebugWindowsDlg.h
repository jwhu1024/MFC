// DebugWindowsDlg.h : ���Y��
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include "Mmsystem.h"
#include "MediaInterface.h"

typedef enum
{
	MODE_NOT_READY,
	MODE_PAUSE,
	MODE_PLAY,
	MODE_STOP,
	MODE_OPEN,
	MODE_RECORD,
	MODE_SEEK,
	MODE_ERROR
} PLAY_MODE;

// CDebugWindowsDlg ��ܤ��
class CDebugWindowsDlg : public CDialog
{
// �غc
public:
	CDebugWindowsDlg(CWnd* pParent = NULL);	// �зǫغc�禡
	~CDebugWindowsDlg();

// ��ܤ�����
	enum { IDD = IDD_DEBUGWINDOWS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	static DWORD WINAPI StatusThread(LPVOID lpArg);
	DWORD  StatusThread();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedBrowse();
	afx_msg void OnBnClickedCleanLog();
	afx_msg void OnBnClickedPlay();
	afx_msg void OnBnClickedStop();
public:
	CListBox lb_debug;
	CEdit m_filepath;
	CString g_strTmp;
	MCIERROR iError;	
	HANDLE hStatusThread;
	BOOL bIsPlaying;
	BOOL bUserStop;
	PLAY_MODE cMode;

private:	
	void ShowLogMessage(CString strTmp, UINT uIndex=NULL);
	void CleanLogMessage();
	void SaveIdAfterOpen(MCI_OPEN_PARMS *params);
	void AddToList(CString strName);
	void StartThread();	
	CMediaInterface gMciCtrl;
public:
	CListCtrl m_listctl;
	
public:
	CButton m_btnPlay;	
	BOOL nCountinue;
	UINT oldCount;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
