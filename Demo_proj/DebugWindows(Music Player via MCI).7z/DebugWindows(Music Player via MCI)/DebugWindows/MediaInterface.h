#pragma once
#include "afxwin.h"
#include "Mmsystem.h"

struct MyInfo{
	MCIDEVICEID iMaxOpen;
	MCIDEVICEID iCurrentPlay;
};

class CMediaInterface :	public CDialog
{
public:
	CMediaInterface(void);
public:
	~CMediaInterface(void);

public:
	void SetOpenParams(MCI_OPEN_PARMS *params, CString strPath);
	UINT MciOpenDevice(CString filePath);
	UINT MciCloseDevice(MCIDEVICEID devId);
	UINT MciStopDevice(MCIDEVICEID devId);
	UINT MciPlay(MCIDEVICEID devId);
	MCI_STATUS_PARMS MciGetStatus(MCIDEVICEID devId);
	UINT MciSetTimeFormat(DWORD nFormat);
	DWORD giError;
	MyInfo pInfo;
	MCI_OPEN_PARMS OpenParms;
	
};
