#include "StdAfx.h"
#include "MediaInterface.h"

CMediaInterface::CMediaInterface(void)
{
}

CMediaInterface::~CMediaInterface(void)
{
}

UINT CMediaInterface::MciCloseDevice(MCIDEVICEID devId)
{	
	giError = mciSendCommand(devId, MCI_CLOSE, NULL, NULL);

	return giError;
}

UINT CMediaInterface::MciPlay(MCIDEVICEID devId)
{	
	MCI_PLAY_PARMS PlayParms;
	PlayParms.dwFrom = 0;
	giError = mciSendCommand (devId, MCI_PLAY, MCI_FROM, (DWORD)(LPVOID)&PlayParms);

	return giError;
}

UINT CMediaInterface::MciOpenDevice(CString filePath)
{	
	/* Open the file by using MCI */
	OpenParms.dwCallback		 = NULL;
	OpenParms.lpstrDeviceType    = NULL;
	OpenParms.lpstrElementName   = filePath;
	OpenParms.wDeviceID		     = NULL;
	OpenParms.lpstrAlias		 = NULL;

	if(DWORD ret = mciSendCommand(NULL, 
		MCI_OPEN, 
		MCI_OPEN_ELEMENT, 
		(DWORD)&OpenParms) != ERROR_SUCCESS)
	{
		return ret;
	}

	return ERROR_SUCCESS;
}

UINT CMediaInterface::MciStopDevice(MCIDEVICEID devId)
{
	return mciSendCommand(devId, MCI_STOP, NULL, NULL);
}

void CMediaInterface::SetOpenParams(MCI_OPEN_PARMS *params, CString strPath)
{
	params->dwCallback		  = NULL;
	params->lpstrDeviceType   = NULL;
	params->lpstrElementName  = strPath;
	params->wDeviceID		  = NULL;
	params->lpstrAlias		  = NULL;
}

MCI_STATUS_PARMS CMediaInterface::MciGetStatus(MCIDEVICEID devId)
{	
	MCI_STATUS_PARMS StatusParms={0};
	StatusParms.dwItem = MCI_STATUS_MODE;
	giError = mciSendCommand (devId, MCI_STATUS, 
		MCI_NOTIFY | MCI_STATUS_ITEM,
		(DWORD)(LPVOID) &StatusParms);

	return StatusParms;
}

UINT CMediaInterface::MciSetTimeFormat(DWORD nFormat)
{
	MCI_SET_PARMS SetParms; 
	SetParms.dwTimeFormat = nFormat;
	return mciSendCommand(pInfo.iCurrentPlay, MCI_SET, MCI_SET_TIME_FORMAT, (DWORD)(LPVOID) &SetParms);
}
#if 0
MCI_STATUS_PARMS StatusParms={0};
StatusParms.dwItem = MCI_STATUS_LENGTH;
giError = mciSendCommand (devId, MCI_STATUS, 
						  MCI_STATUS_ITEM,
						  (DWORD)(LPVOID) &StatusParms);

return StatusParms;
#endif