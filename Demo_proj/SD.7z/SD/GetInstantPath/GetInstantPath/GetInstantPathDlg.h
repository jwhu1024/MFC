// GetInstantPathDlg.h : ���Y��
//

#pragma once
#include <SetupAPI.h>
#include <devguid.h>
//#include <WinIoCtl.h>
#include <cfgmgr32.h>
#include "afxwin.h"
#include <WinReg.h>
//#include "Ntddstor.h"
#define BUFFER_SIZE  256
#define MAX_DRIVES   26
// CGetInstantPathDlg ��ܤ��

class CGetInstantPathDlg : public CDialog
{
// �غc
public:
	CGetInstantPathDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_GETINSTANTPATH_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	BOOL GetVolumeLabel();
	BOOL WriteFileToSD();
	BOOL EnumStorageFineVID();
	WCHAR GetSpecificDrive(LPTSTR lpDevID);
	BOOL GetAllRemovableDisks();
	WCHAR GetUSBDrive();
	TCHAR cdrive[10];
	TCHAR volumelabel[10];
	CString str;
public:
	CEdit m_show;
	UINT g_count;
};
