// GetInstantPathDlg.cpp : ��@��
//

#include "stdafx.h"
#include "GetInstantPath.h"
#include "GetInstantPathDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// �� App About �ϥ� CAboutDlg ��ܤ��

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CGetInstantPathDlg ��ܤ��




CGetInstantPathDlg::CGetInstantPathDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetInstantPathDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGetInstantPathDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_show);
}

BEGIN_MESSAGE_MAP(CGetInstantPathDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CGetInstantPathDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CGetInstantPathDlg �T���B�z�`��

BOOL CGetInstantPathDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w

	return TRUE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CGetInstantPathDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CGetInstantPathDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CGetInstantPathDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
//
void CGetInstantPathDlg::OnBnClickedButton1()
{
	// 1. Enum Storage in DM and Find VID/PID
	if(EnumStorageFineVID())
		m_show.SetWindowText(L"Find VID/PID Success!!");
	else
	{
		m_show.SetWindowText(L"Find VID/PID Error!!");
		return;
	}
	
	//Sleep(3000);

	// 2. Get Physical Drive (Removable) (ex:H:\)
	if(GetVolumeLabel())
		m_show.SetWindowText(L"Get Volume Label Success!!");
	else
	{
		m_show.SetWindowText(L"Get Volume Label Fail!!");
		return;
	}

	//Sleep(3000);

	// 3. Read/Write file to SD and Compare
	if(WriteFileToSD())
		m_show.SetWindowText(L"Write File To SD Success!!");
	else
	{
		m_show.SetWindowText(L"Write File To SD Fail!!");
		return;
	}

#if 0
#if 0 //test
	m_show.SetWindowText(L"");

	GetVolumeLabel();
	if(WriteFileToSD())
		m_show.SetWindowText(L"Pass");
	else
		m_show.SetWindowText(L"Fail");

#endif
		
#endif
}

BOOL CGetInstantPathDlg::EnumStorageFineVID()
{
	HDEVINFO hDevice;
	//hDevice = SetupDiGetClassDevs(&GUID_DEVCLASS_NET, NULL, NULL, DIGCF_ALLCLASSES | DIGCF_PRESENT);// TODO: �b���[�J����i���B�z�`���{���X
	hDevice = SetupDiGetClassDevs(&GUID_DEVCLASS_DISKDRIVE, NULL, NULL, //GUID_DEVINTERFACE_DISK
		DIGCF_PRESENT);// | DIGCF_DEVICEINTERFACE);

	GUID  *guid = (GUID *)&GUID_DEVCLASS_USB;

	SP_DEVINFO_DATA DeviceInfoData;
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	for (int ret=0; SetupDiEnumDeviceInfo(hDevice, ret, &DeviceInfoData); ret++)
	{
		DWORD regDataType = 0;
		TCHAR MyBuf[256] = {0};
		DWORD MyBufSize = 256;
		SP_DEVICE_INTERFACE_DATA spDevIntData; 
		
		ZeroMemory(&spDevIntData, sizeof(spDevIntData));
		spDevIntData.cbSize = sizeof(spDevIntData);
		SetupDiEnumDeviceInterfaces(
			hDevice, 
			&DeviceInfoData,
			guid,
			ret,
			&spDevIntData
			);
		
		SetupDiGetDeviceInterfaceDetail(
			hDevice)

		// get the device capabilities
		SetupDiGetDeviceRegistryProperty(
			hDevice,
			&DeviceInfoData,
			SPDRP_ENUMERATOR_NAME ,
			&regDataType,
			(PBYTE)&MyBuf,
			MyBufSize,
			&MyBufSize);

		// we are only interested in removable devices
		if (_tcsncmp(MyBuf,_T("USBSTOR"), 7) == 0)
		{
			TCHAR fname[256] = {0};
			DWORD bufSize = 256;
			TCHAR szDescription[MAX_PATH];
			memset(szDescription, 0, MAX_PATH);
			//PTSTR deviceinstanceid;
			SetupDiGetDeviceInstanceId(
				hDevice,
				&DeviceInfoData,
				szDescription,
				MAX_PATH,
				0
				);

			// No Friendly Name was found for the enumerated device.
			if ( _tcslen(szDescription) != 0 )
			{
				CString descrip(szDescription);
				if(descrip.Find(L"VEN_BANDLUXE") > -1)
				{
					//test area 
					TCHAR szBuff[MAX_PATH];
					HKEY hKey = SetupDiOpenDevRegKey(hDevice, &DeviceInfoData, DICS_FLAG_GLOBAL, NULL, DIREG_DEV,KEY_READ);
					if (hKey) 
					{ 
						DWORD dwType = REG_SZ; 
						DWORD dwReqSize = sizeof(szBuff); 

						// Query for portname 
						if (RegQueryValueEx(hKey, _T("Class"), 0, &dwType, (LPBYTE)szBuff, &dwReqSize) == ERROR_SUCCESS) 
						{ 
						}
					}
					TCHAR szDeviceIdString[MAX_PATH];
					DEVINST DevInstParent = 0;
					CM_Get_Parent(&DevInstParent, DeviceInfoData.DevInst, 0); 
					CM_Get_Device_ID(DevInstParent, szDeviceIdString, MAX_PATH, 0);

					if(wcsstr(szDeviceIdString, L"VID_1A8D&PID_100D"))
					{
						return TRUE;
					}					
				}				
			} // if ( _tcslen(szDescription) != 0 )					
		} // if (_tcsncmp(MyBuf,_T("USB"), 3) == 0)		
		//break; // not USBSTOR
	} // for (DWORD i=0;SetupDiEnumDeviceInfo(hDevInfo,i,&DeviceInfoData);i++)	
#if 0
	DWORD drives;
	int x;
	drives = GetLogicalDrives();
	CString str;
	str.Format(L"Logical drives on this machine:\n");
	//cout << "Logical drives on this machine: ";


	for (x=0; x<26; x++)
	{
		if (drives & 1!=0)
		{

			CString fmt;
			char ch=(char)('A'+x);
			fmt.Format(L"%c",ch);
			str+=fmt;
		}
		drives = drives >> 1;
	}
	MessageBox(str); 
#endif

	return FALSE;
}

BOOL CGetInstantPathDlg::GetVolumeLabel()
{
	int   i;
	int   CDRom_Exist;
	TCHAR  drive_name[8];
	TCHAR  LabelName[MAX_PATH+1],VolumeName[MAX_PATH+1];
	TCHAR filesysname[10];
	DWORD serialnumber;
	DWORD maxclength;
	DWORD filesysflag;

	memset(VolumeName, NULL, sizeof(VolumeName));
	memset(LabelName, NULL, sizeof(LabelName));
	memset(drive_name, NULL, sizeof(drive_name));
	memset(cdrive, NULL, sizeof(cdrive));

	drive_name[1]=':';
	drive_name[2]='\\';
	drive_name[3]='\0';
	CString m_volume;
	//m_editCtlVolume.GetWindowText(m_volume);
	wcscpy(LabelName, LPCTSTR(m_volume));
	//strcpy(LabelName,"Lexar");
	CDRom_Exist = FALSE;

	
	for (i='D'; i<='Z'; i++)
	{
		drive_name[0]=i;
		UINT type = GetDriveType(drive_name);

		if(type==DRIVE_REMOVABLE)//DRIVE_REMOVABLE)
		{
			BOOL getvol = GetVolumeInformation(drive_name, VolumeName, 255, &serialnumber, &maxclength, &filesysflag, filesysname, 255);
			long lerror = GetLastError();
			CDRom_Exist=TRUE;

			//if(wcscmp(LabelName, VolumeName)==0)
			if(wcscmp(filesysname, L"FAT32")==0)
			{
				//strcpy_s(volumelabel, sizeof(VolumeName), VolumeName); // Save volume label to global variable
				wcscpy(volumelabel, VolumeName); // Save volume label to global variable
				drive_name[2] = 0;
				//strcpy_s(cdrive, sizeof(drive_name), drive_name); // Save volume label to global variable
				wcscpy(cdrive, drive_name); // Save volume label to global variable
				CString temp1(cdrive);
				//m_drivename.SetWindowText(temp1);
				//CString temp1(cdrive);
				//m_edit.SetWindowText(temp1);
				if(  cdrive[0] != '\0')
					return TRUE;					
			}
		}
	}
	return FALSE;
}

