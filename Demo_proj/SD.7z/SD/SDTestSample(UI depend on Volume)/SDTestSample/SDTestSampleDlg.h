// SDTestSampleDlg.h : ���Y��
//

#pragma once
#include "afxwin.h"


// CSDTestSampleDlg ��ܤ��
class CSDTestSampleDlg : public CDialog
{
// �غc
public:
	CSDTestSampleDlg(CWnd* pParent = NULL);	// �зǫغc�禡

// ��ܤ�����
	enum { IDD = IDD_SDTESTSAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �䴩


// �{���X��@
protected:
	HICON m_hIcon;

	// ���ͪ��T�������禡
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_editCtlVolume;
	afx_msg void OnBnClickedStartTest();
	BOOL GetVolumeLabel();
	BOOL WriteFileToSD();
	TCHAR cdrive[10];
	TCHAR volumelabel[10];
	CEdit m_editCtlString;
	CEdit m_showString;
	CEdit m_ShowRead;
	CEdit m_editResult;
	CEdit m_drivename;
	afx_msg void OnBnClickedButton2();
};
