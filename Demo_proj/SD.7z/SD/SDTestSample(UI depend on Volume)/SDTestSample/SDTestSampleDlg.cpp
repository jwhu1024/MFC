// SDTestSampleDlg.cpp : ��@��
//

#include "stdafx.h"
#include "SDTestSample.h"
#include "SDTestSampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// �� App About �ϥ� CAboutDlg ��ܤ��

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ܤ�����
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

// �{���X��@
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CSDTestSampleDlg ��ܤ��




CSDTestSampleDlg::CSDTestSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSDTestSampleDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSDTestSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_editCtlVolume);
	DDX_Control(pDX, IDC_EDIT3, m_editCtlString);
	DDX_Control(pDX, IDC_EDIT2, m_showString);
	DDX_Control(pDX, IDC_EDIT4, m_ShowRead);
	DDX_Control(pDX, IDC_EDIT5, m_editResult);
	DDX_Control(pDX, IDC_EDIT6, m_drivename);
}

BEGIN_MESSAGE_MAP(CSDTestSampleDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CSDTestSampleDlg::OnBnClickedStartTest)
	ON_BN_CLICKED(IDC_BUTTON2, &CSDTestSampleDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


// CSDTestSampleDlg �T���B�z�`��

BOOL CSDTestSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �N [����...] �\����[�J�t�Υ\����C

	// IDM_ABOUTBOX �����b�t�ΩR�O�d�򤧤��C
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �]�w����ܤ�����ϥܡC�����ε{�����D�������O��ܤ���ɡA
	// �ج[�|�۰ʱq�Ʀ��@�~
	SetIcon(m_hIcon, TRUE);			// �]�w�j�ϥ�
	SetIcon(m_hIcon, FALSE);		// �]�w�p�ϥ�

	// TODO: �b���[�J�B�~����l�]�w
	memset(cdrive, NULL, sizeof(cdrive));
	memset(volumelabel, NULL, sizeof(volumelabel));
	m_editCtlVolume.SetWindowText(L"Lexar"); //test only
	m_editCtlString.SetWindowText(L"1235jlkdshfksj");

	return TRUE;  // �Ǧ^ TRUE�A���D�z�ﱱ��]�w�J�I
}

void CSDTestSampleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �p�G�N�̤p�ƫ��s�[�J�z����ܤ���A�z�ݭn�U�C���{���X�A
// �H�Kø�s�ϥܡC���ϥΤ��/�˵��Ҧ��� MFC ���ε{���A
// �ج[�|�۰ʧ������@�~�C

void CSDTestSampleDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ø�s���˸m���e

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// �N�ϥܸm����Τ�ݯx��
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �yø�ϥ�
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ���ϥΪ̩즲�̤p�Ƶ����ɡA
// �t�ΩI�s�o�ӥ\����o�����ܡC
HCURSOR CSDTestSampleDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CSDTestSampleDlg::OnBnClickedStartTest()
{
	BOOL res;
	res = GetVolumeLabel();
	if(!res)
	{
		AfxMessageBox(L"Get Volume Label Fail!");
		return;
	}
	res = WriteFileToSD();

}

BOOL CSDTestSampleDlg::WriteFileToSD()
{
	TCHAR destdrive[64];
	TCHAR destfile[64] = L"\\testlog.log";		     //SD location
	TCHAR srcfile[64] = L"C:\\testlog.log";  //PC source location
	TCHAR outfile[64] = L"C:\\outlog.log";    //PC output location	
	TCHAR testlog[64];// = "This is a test";	
	TCHAR templog[64];
	TCHAR resultlog[64];

	// Get test string from UI
	CString strtemp=L"";
	m_editCtlString.GetWindowText(strtemp);
	m_showString.SetWindowText(strtemp);
	//strcpy(testlog, LPCWSTR(strtemp));
	wcscpy(testlog, LPCWSTR(strtemp));

	memset(resultlog, NULL, sizeof(resultlog));
	memset(templog, 0, sizeof(templog));
	memset(destdrive, 0, sizeof(destdrive));

	CFile f_srcFile, f_outfile, f_Sd;

	// src file process
	//size_t length = strlen(testlog);
	size_t length = wcslen(testlog);
	f_srcFile.Open(srcfile, CFile::modeCreate | CFile::modeReadWrite);
	//f_srcFile.Open(srcfile, CFile::modeRead);	
	f_srcFile.Write(testlog, length*2+1);
	f_srcFile.SeekToBegin();
	f_srcFile.Read(templog, length*2+1);

	// write to SD drive
	//strcpy_s(destdrive, sizeof(cdrive), cdrive);
	//strcat_s(destdrive, destfile);
	wcscpy_s(destdrive, sizeof(cdrive), cdrive);
	wcscat_s(destdrive, destfile);
	f_Sd.Open(destdrive, CFile::modeCreate | CFile::modeReadWrite);
	f_Sd.Write(templog,length*2+1);
	//strcpy_s(resultlog, templog);
	wcscpy_s(resultlog, templog);
	memset(templog, 0, sizeof(templog));
	f_Sd.SeekToBegin();
	f_Sd.Read(templog, length*2+1);

	m_ShowRead.SetWindowText(templog);
	// output file process
	f_outfile.Open(outfile, CFile::modeCreate | CFile::modeWrite);
	f_outfile.Write(templog, length*2+1);

	
	f_srcFile.Close();
	f_outfile.Close();
	f_Sd.Close();
	//f_srcFile.Remove(L"C:\\testlog.log");
	//f_srcFile.Remove(L"C:\\outlog.log");
	//f_srcFile.Remove(destdrive);
	if(wcscmp(resultlog, templog) == 0)
	{
		m_editResult.SetWindowText(L"File is same");
		return TRUE;
	}
	else
	{
		m_editResult.SetWindowText(L"File no same");
		return FALSE;
	}
}

BOOL CSDTestSampleDlg::GetVolumeLabel()
{
	int   i;
	int   CDRom_Exist;
	TCHAR  drive_name[8];
	TCHAR  LabelName[MAX_PATH+1],VolumeName[MAX_PATH+1];
	TCHAR filesysname[10];
	DWORD serialnumber;
	DWORD maxclength;
	DWORD filesysflag;

	memset(VolumeName, NULL, sizeof(VolumeName));
	memset(LabelName, NULL, sizeof(LabelName));
	memset(drive_name, NULL, sizeof(drive_name));

	drive_name[1]=':';
	drive_name[2]='\\';
	drive_name[3]='\0';
	CString m_volume;
	m_editCtlVolume.GetWindowText(m_volume);
	wcscpy(LabelName, LPCTSTR(m_volume));
	//strcpy(LabelName,"Lexar");
	CDRom_Exist = FALSE;

	do
	{
		for (i='D'; i<='Z'; i++)
		{
			drive_name[0]=i;
			UINT type = GetDriveType(drive_name);
			
			if(type==DRIVE_REMOVABLE)
			{
				BOOL getvol = GetVolumeInformation(drive_name, VolumeName, 255, &serialnumber, &maxclength, &filesysflag, filesysname, 255);
				long lerror = GetLastError();
				CDRom_Exist=TRUE;

				if(wcscmp(LabelName, VolumeName)==0)
				{
					//strcpy_s(volumelabel, sizeof(VolumeName), VolumeName); // Save volume label to global variable
					wcscpy(volumelabel, VolumeName); // Save volume label to global variable
					drive_name[2] = 0;
					//strcpy_s(cdrive, sizeof(drive_name), drive_name); // Save volume label to global variable
					wcscpy(cdrive, drive_name); // Save volume label to global variable
					CString temp1(cdrive);
					m_drivename.SetWindowText(temp1);
					//CString temp1(cdrive);
					//m_edit.SetWindowText(temp1);
					break; 
				}
			}
		}
		if(i>'Z')
		{
			if(CDRom_Exist)
			{
				CDRom_Exist = FALSE;
			}
			else
			{
				OutputDebugString(L"Not found the label\n");
			}
			return FALSE;
		}		
		break;
	}while(CDRom_Exist==FALSE); 

	return TRUE;
}


void CSDTestSampleDlg::OnBnClickedButton2()
{
	m_drivename.SetWindowText(L"");
	m_showString.SetWindowText(L"");
	m_ShowRead.SetWindowText(L"");
	m_editResult.SetWindowText(L"");
	
}
