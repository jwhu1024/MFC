//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Telnet.rc
//
#define IDD_ABOUTBOX                    100
#define ID_PANE1                        101
#define IDR_MAINFRAME                   128
#define IDR_TelnetTYPE                  129
#define IDR_ClientTYPE                  129
#define IDD_CONNECT_DIALOG              130
#define IDR_ServerTYPE                  130
#define IDD_LISTEN_DIALOG               131
#define IDD_SENDCANCEL_DIALOG           132
#define IDC_ADDR_COMBO                  1000
#define IDC_PORT_EDIT                   1001
#define IDC_CLIENTS_LIST                1003
#define ID_SEND_SEND                    32771
#define ID_FILE_SENDDATA                32776
#define ID_SERV_NEW                     32779
#define ID_CLNT_NEW                     32780
#define ID_CLNT_REDIAL                  32784
#define ID_Menu                         32785
#define ID_CLNT_DISCONNECT              32787
#define ID_CLNT_SHELL                   32792

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
