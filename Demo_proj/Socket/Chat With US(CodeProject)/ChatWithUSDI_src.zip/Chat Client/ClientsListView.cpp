// ClientsListView.cpp : implementation file
//

#include "stdafx.h"
#include "Chat Client.h"
#include "ClientsListView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientsListView

CClientsListView::CClientsListView()
{
}

CClientsListView::~CClientsListView()
{
}

void CClientsListView::Init(CMainFrame* pMainFrame)
{
	ASSERT(pMainFrame);
	m_pMainFrame = pMainFrame;
}


BEGIN_MESSAGE_MAP(CClientsListView, baseCMyBar)
	//{{AFX_MSG_MAP(CClientsListView)
	ON_WM_CREATE()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMyBar message handlers

int CClientsListView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (baseCMyBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	SetSCBStyle(GetSCBStyle() | SCBS_SIZECHILD);

	if (!m_ListCtrl.Create(WS_CHILD|WS_VISIBLE|
			LVS_REPORT|LVS_SINGLESEL|LVS_LIST|LVS_SHOWSELALWAYS|LVS_SORTASCENDING,
		CRect(0,0,0,0), this, 1234))
		return -1;

	m_ListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	m_ListCtrl.ModifyStyleEx(0, WS_EX_CLIENTEDGE);
	
	m_ImgList.Create(16,16,TRUE,1,1);
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN1));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN2));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN3));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN4));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN5));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN6));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN7));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN8));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN9));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN10));
	m_ListCtrl.SetImageList(&m_ImgList, LVSIL_SMALL);


#ifdef TEST_MODE
	m_ListCtrl.InsertItem(0, "TheBringToTop");
#endif

	return 0;
}

void CClientsListView::AddClient(CString szClient, UINT nSignIcon)
{
	LVFINDINFO lv;
	lv.flags = LVFI_STRING;
	lv.psz = szClient;
	
	int nIdx = m_ListCtrl.FindItem(&lv);
	if (nIdx == -1) {

		LV_ITEM lvItem;
		ZeroMemory(&lvItem, sizeof(LV_ITEM));
		lvItem.mask = LVIF_TEXT|LVIF_IMAGE;
		lvItem.iImage = nSignIcon;
		lvItem.pszText = szClient.GetBuffer(szClient.GetLength());
		lvItem.cchTextMax = szClient.GetLength();
		szClient.ReleaseBuffer(); 
		m_ListCtrl.InsertItem(&lvItem);
	}
}

void CClientsListView::RemoveClient(CString szClient)
{
	LVFINDINFO lv;
	lv.flags = LVFI_STRING;
	lv.psz = szClient;
	
	int nIdx = m_ListCtrl.FindItem(&lv);
	if (nIdx != -1)
		m_ListCtrl.DeleteItem(nIdx);
}

void CClientsListView::ClearList()
{
	m_ListCtrl.DeleteAllItems(); 
}


void CClientsListView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (!m_ListCtrl.GetItemCount())
		return;

	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	if (!pos)
		return;

	CRect rc;
	m_ListCtrl.GetItemRect(m_ListCtrl.GetNextSelectedItem(pos), rc, LVIR_BOUNDS); 

	CPoint pt(point);
	ScreenToClient(&pt);
	if (!rc.PtInRect(pt))
		return;

    BCMenu cMenu;	
    cMenu.LoadMenu(IDR_CLIENTS_CONTEXTUAL_MENU);
    cMenu.LoadToolbar(IDR_CLIENTS_CONTEXTUAL_TOOLSBAR);
    
    CMenu* pMenu = cMenu.GetSubMenu(0);
    pMenu->TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON, point.x, point.y, (CWnd*)AfxGetMainWnd());    	
    cMenu.DestroyMenu();
}

CString CClientsListView::GetClient()
{
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();
	CString szBuf;
	CString szBuf2;
	szBuf = m_ListCtrl.GetItemText(m_ListCtrl.GetNextSelectedItem(pos), 0);  
	
	return szBuf;
}

void CClientsListView::UpdateCols()
{
	CString szBuf;
	szBuf.LoadString(IDS_TAB_CLIENTS); 
	SetWindowText(szBuf);
}
