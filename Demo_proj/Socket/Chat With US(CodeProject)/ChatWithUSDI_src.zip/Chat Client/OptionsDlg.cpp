// OptionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "chat client.h"
#include "OptionsDlg.h"
#include "..\\Commun\\ShellLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog


COptionsDlg::COptionsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionsDlg)
	//}}AFX_DATA_INIT
}


void COptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsDlg)
	DDX_Control(pDX, IDC_CHECK_SPLASH, m_bSplash);
	DDX_Control(pDX, IDC_CHECK_BALLON_ADD_CLIENT, m_bNotifyAdd);
	DDX_Control(pDX, IDC_CHECK_BALLON_PRIVATE_MESSAGE, m_bNotifyPrivateMessage);
	DDX_Control(pDX, IDC_CHECK_BALLON_REMOVE_CLIENT, m_bNotifyRemove);
	DDX_Control(pDX, IDC_CHECK_MINIMIZE_TO_TRAY, m_bMinimizeToTray);
	DDX_Control(pDX, IDC_CHECK_SHORTCUT_DESKTOP, m_bShortcutDesktop);
	DDX_Control(pDX, IDC_CHECK_SHORTCUT_MENU, m_bShortcutMenu);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsDlg, CDialog)
	//{{AFX_MSG_MAP(COptionsDlg)
	ON_BN_CLICKED(IDC_CHECK_MINIMIZE_TO_TRAY, OnCheckMinimizeToTray)
	ON_BN_CLICKED(IDC_CHECK_SHORTCUT_MENU, OnCheckShortcutMenu)
	ON_BN_CLICKED(IDC_CHECK_SHORTCUT_DESKTOP, OnCheckShortcutDesktop)
	ON_BN_CLICKED(IDC_CHECK_BALLON_ADD_CLIENT, OnCheckBallonAddClient)
	ON_BN_CLICKED(IDC_CHECK_BALLON_REMOVE_CLIENT, OnCheckBallonRemoveClient)
	ON_BN_CLICKED(IDC_CHECK_BALLON_PRIVATE_MESSAGE, OnCheckBallonPrivateMessage)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_CHECK_SPLASH, OnCheckSplash)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg message handlers

BOOL COptionsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_bSplash.SetCheck(AfxGetApp()->GetProfileInt("Options", "ShowSplash", FALSE));
	m_bMinimizeToTray.SetCheck(AfxGetApp()->GetProfileInt("Options", "MinimizeToTray", TRUE));
	m_bShortcutDesktop.SetCheck(AfxGetApp()->GetProfileInt("Options", "ShortcutDesktop", TRUE));
	m_bShortcutMenu.SetCheck(AfxGetApp()->GetProfileInt("Options", "ShortcutMenu", TRUE));
	m_bNotifyAdd.SetCheck(AfxGetApp()->GetProfileInt("Options", "NotifyAdd", TRUE));
	m_bNotifyRemove.SetCheck(AfxGetApp()->GetProfileInt("Options", "NotifyRemove", TRUE));
	m_bNotifyPrivateMessage.SetCheck(AfxGetApp()->GetProfileInt("Options", "NotifyPrivateMessage", TRUE));

	//Initialise the OLE subsystem
	HRESULT hRes = ::CoInitialize(NULL);
	if (!SUCCEEDED(hRes))
	{
		TRACE(_T("Failed to initialize OLE\n"));
		return FALSE;
	}

	return TRUE;
}


void COptionsDlg::OnCheckMinimizeToTray() 
{
	AfxGetApp()->WriteProfileInt("Options", "MinimizeToTray", m_bMinimizeToTray.GetCheck());
}

void COptionsDlg::OnCheckShortcutMenu() 
{
	BOOL bAdd = m_bShortcutMenu.GetCheck();
	AfxGetApp()->WriteProfileInt("Options", "ShortcutMenu", bAdd);
	CreateShortcut(bAdd, CSIDL_STARTMENU);
}

void COptionsDlg::OnCheckShortcutDesktop() 
{
	BOOL bAdd = m_bShortcutDesktop.GetCheck();
	AfxGetApp()->WriteProfileInt("Options", "ShortcutDesktop", bAdd);
	CreateShortcut(bAdd, CSIDL_DESKTOPDIRECTORY);
}

void COptionsDlg::OnCheckBallonAddClient() 
{
	AfxGetApp()->WriteProfileInt("Options", "NotifyAdd", m_bNotifyAdd.GetCheck());
}

void COptionsDlg::OnCheckBallonRemoveClient() 
{
	AfxGetApp()->WriteProfileInt("Options", "NotifyRemove", m_bNotifyRemove.GetCheck());
}

void COptionsDlg::OnCheckBallonPrivateMessage() 
{
	AfxGetApp()->WriteProfileInt("Options", "NotifyPrivateMessage", m_bNotifyPrivateMessage.GetCheck());
}


void COptionsDlg::CreateShortcut(BOOL bAdd, long lWhere)
{
	CString szLink;
	char szThis[MAX_PATH];
	CShellLinkInfo sli1;

	GetModuleFileName(NULL, szThis, MAX_PATH);

	sli1.m_sTarget = _T(szThis);
	sli1.m_sArguments = _T("");
	sli1.m_sWorkingDirectory = _T("");
	sli1.m_sDescription = _T(CString((LPCTSTR)IDS_SHORTCUT_DESCRIPTION));
	sli1.m_sIconLocation = _T(szThis);
	sli1.m_nIconIndex = 0; //Use an interesting icon
	sli1.m_nShowCmd = SW_SHOWNORMAL;
	
	ITEMIDLIST* ItmLst;
	char strPath[MAX_PATH];
	if (!SHGetSpecialFolderLocation(GetSafeHwnd(), lWhere, &ItmLst)) {
		SHGetPathFromIDList(ItmLst, strPath);
	}
	szLink.Format("%s\\%s.lnk", strPath, CString((LPCTSTR)AFX_IDS_APP_TITLE));

	if (bAdd) {

		CShellLink sl1;
		if (sl1.Create(sli1))
		{
			if (!sl1.Save(szLink))
				TRACE(_T("Failed to save link\n"));
		}
		else
			TRACE(_T("Failed to create link\n"));
	}
	else {
		DeleteFile(szLink);
	}	
}



void COptionsDlg::OnClose() 
{
  //Closedown the OLE subsystem
  ::CoUninitialize();
  
	CDialog::OnClose();
}

void COptionsDlg::OnCheckSplash() 
{
	AfxGetApp()->WriteProfileInt("Options", "ShowSplash", m_bSplash.GetCheck());
}
