// Chat Client.h : main header file for the CHAT CLIENT application
//

#if !defined(AFX_CHATCLIENT_H__95F384AC_BC84_4584_BF6C_E20B237FFCC3__INCLUDED_)
#define AFX_CHATCLIENT_H__95F384AC_BC84_4584_BF6C_E20B237FFCC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


#define MIN_FRAME_WITH 600
#define MIN_FRAME_HEIGTH 400
#define DEFAULT_LANGUAGE_ENGLISH 1
#define TIMER_TIME_VALUE 1000
#define TIMER_INITIALIZATION_VALUE 100

#define DEFAULT_MIN_PORT_NUMBER 1500
#define DEFAULT_MAX_PORT_NUMBER 65000

#define MIN_SIGN_NAME_LENGTH 5
#define ELAPSE_BALLON_SHOW 3000
#define ICON_OF_SERVER 11
//#define TEST_MODE

/////////////////////////////////////////////////////////////////////////////
// CChatClientApp:
// See Chat Client.cpp for the implementation of this class
//

class CChatClientApp : public CWinApp
{
public:
	CChatClientApp();
	HINSTANCE GetEnglishRessource() { return m_hEnglishRessource; }

private:
	HINSTANCE m_hEnglishRessource;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChatClientApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CChatClientApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATCLIENT_H__95F384AC_BC84_4584_BF6C_E20B237FFCC3__INCLUDED_)
