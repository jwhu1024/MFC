// DialogBarUtil.cpp: implementation of the MyDialogBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Chat Client.h"
#include "DialogBarUtil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define REBAR_HEIGTH 27
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
 
/////////////////////////////////////////////////////////////////////////////
// CMyDialogBar

CDialogBarUtil::CDialogBarUtil()
{
	m_pApp	= (CChatClientApp*)AfxGetApp();

}

CDialogBarUtil::~CDialogBarUtil()
{
}


BEGIN_MESSAGE_MAP(CDialogBarUtil,  CDialogBarEx)
	//{{AFX_MSG_MAP(CDialogBarUtil)
	ON_WM_MOVE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDialogBarUtil message handlers

void CDialogBarUtil::DoDataExchange(CDataExchange* pDX) 
{
	// TODO: Add your specialized code here and/or call the base class
	DDX_Control(pDX, IDC_IPADDRESS, m_ctrlIPAdress);
	DDX_Control(pDX, IDC_EDIT_PORT, m_edtPort);
	DDX_Control(pDX, IDC_SPIN_PORT, m_ctrlSpinPort);
	DDX_Control(pDX, IDC_EDIT_SIGN_IN_NAME, m_edtSignInName);
	DDX_Control(pDX, IDC_CAPTION_SIGN_NAME, m_szScreenName);
	DDX_Control(pDX, IDC_COMBO_SIGN_IN_NAME, m_cboScreenName);
	CDialogBarEx::DoDataExchange(pDX);
}

void CDialogBarUtil::OnInitDialogBar()
{
	m_ctrlIPAdress.SetAddress(m_pApp->GetProfileInt("Settings", "IPAdress", 0));

	m_ctrlSpinPort.SetRange32(DEFAULT_MIN_PORT_NUMBER, DEFAULT_MAX_PORT_NUMBER);
	m_ctrlSpinPort.SetPos(m_pApp->GetProfileInt("Settings", "PortNumber", DEFAULT_MIN_PORT_NUMBER)); 

	m_edtSignInName.SetWindowText(m_pApp->GetProfileString("Settings", "SignInName", ""));	

	m_cboScreenName.AddIcon(IDI_SIGN1);
	m_cboScreenName.AddIcon(IDI_SIGN2);
	m_cboScreenName.AddIcon(IDI_SIGN3);
	m_cboScreenName.AddIcon(IDI_SIGN4);
	m_cboScreenName.AddIcon(IDI_SIGN5);
	m_cboScreenName.AddIcon(IDI_SIGN6);
	m_cboScreenName.AddIcon(IDI_SIGN7);
	m_cboScreenName.AddIcon(IDI_SIGN8);
	m_cboScreenName.AddIcon(IDI_SIGN9);
	m_cboScreenName.AddIcon(IDI_SIGN10);
	m_cboScreenName.SetCurSelIcon(m_pApp->GetProfileInt("Settings", "SignIndex", 0));
}

void CDialogBarUtil::OnMove(int x, int y) 
{
	CDialogBarEx::OnMove(x, y);
	
	CRect rc;
	GetClientRect(rc);
	SetWindowPos(NULL, 0, 0, rc.Width()-3, REBAR_HEIGTH, SWP_NOMOVE);	
}

void CDialogBarUtil::OnDestroy() 
{
	CDialogBarEx::OnDestroy();

	DWORD dwIPAdress;
	m_ctrlIPAdress.GetAddress(dwIPAdress);
	m_pApp->WriteProfileInt("Settings", "IPAdress", dwIPAdress);
	
	m_pApp->WriteProfileInt("Settings", "PortNumber", m_ctrlSpinPort.GetPos());

	CString szBuf;
	m_edtSignInName.GetWindowText(szBuf);	
	m_pApp->WriteProfileString("Settings", "SignInName", szBuf);
	m_pApp->WriteProfileInt("Settings", "SignIndex", m_cboScreenName.GetCurSelIcon());
}


CString CDialogBarUtil::GetIPAdress()
{
	CString szBuf;

	if (m_ctrlIPAdress.IsBlank())
		return szBuf;	

	BYTE n1, n2, n3, n4;

	if (m_ctrlIPAdress.GetAddress(n1, n2, n3, n4) != 4)
		return "";
	
	szBuf.Format("%d.%d.%d.%d", n1, n2, n3, n4); 
	if (szBuf == "0.0.0.0")
		return "";
	
	return szBuf;
}

int CDialogBarUtil::GetPort()
{
	return m_ctrlSpinPort.GetPos();
}

CString CDialogBarUtil::GetSignInName()
{
	CString szBuf;
	m_edtSignInName.GetWindowText(szBuf);
	return szBuf;
}

int CDialogBarUtil::GetSignInNameIcon()
{
	return m_cboScreenName.GetCurSelIcon();
}

void CDialogBarUtil::BlockConrols(BOOL bNotEnable)
{
	m_edtPort.EnableWindow(!bNotEnable);
	m_ctrlSpinPort.EnableWindow(!bNotEnable);
	m_edtSignInName.EnableWindow(!bNotEnable);
	m_ctrlIPAdress.EnableWindow(!bNotEnable);
	m_cboScreenName.EnableWindow(!bNotEnable);
}

void CDialogBarUtil::UpdateCaptions()
{
	if (m_szScreenName.GetSafeHwnd()) {
		CString szBuf((LPCTSTR)IDS_CAPTION_SIGN_NAME);
		m_szScreenName.SetWindowText(szBuf);
	}
}

