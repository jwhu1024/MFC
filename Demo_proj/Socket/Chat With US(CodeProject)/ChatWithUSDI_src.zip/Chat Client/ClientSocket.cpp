// ClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Chat Client.h"
#include "ClientSocket.h"
#include "..\\Commun\\ComData.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientSocket


CClientSocket::CClientSocket(CMainFrame* pMainFrame, CString szSignInName, UINT uSignIcon)
{
	ASSERT(pMainFrame);
	m_pMainFrame = pMainFrame;
	m_szSignInName = szSignInName;
	m_uSignIcon = uSignIcon;

	Create();
	m_pSocketFile = new CSocketFile(this);
	m_pArchiveIn  = new CArchive(m_pSocketFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pSocketFile,CArchive::store);
}

CClientSocket::~CClientSocket()
{
	Finalize();
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSocket, CSocket)
	//{{AFX_MSG_MAP(CClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSocket member functions

void CClientSocket::OnReceive(int nErrorCode) 
{
	CSocket::OnReceive(nErrorCode);

	ProcessServerCom();
}


void CClientSocket::ProcessServerCom()
{
	CComData ComData;

	try {
		do {
			ComData.Serialize(*m_pArchiveIn);
		}
		while(!m_pArchiveIn->IsBufferEmpty());
	}
	catch(CFileException* e) {
		e->Delete();
		m_pArchiveIn->Abort();
	}

	if(ComData.uMessage == CComData::COM_SIGN_IN) {

		m_pMainFrame->AddClientsCom(CTime::GetCurrentTime(),
									ComData.szFrom,
									ComData.uSignIcon,
									ComData.szMessage);	
		try {
			//send the connection confirmation
			CComData ComData;
			ComData.szFrom	  = m_szSignInName; 
			ComData.uSignIcon = m_uSignIcon; 
			ComData.szMessage = "";
			ComData.uMessage  = CComData::COM_SIGN_IN;
			SendCom(&ComData);
		}
		catch(CFileException* e) {
			TCHAR csError[CHAR_BUFFER_SIZE];
			e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
			AfxMessageBox(csError);
		}
	}
	else if(ComData.uMessage == CComData::COM_SIGN_OUT) {

		m_pMainFrame->AddClientsCom(CTime::GetCurrentTime(),
									ComData.szFrom,
									ComData.uSignIcon,
									ComData.szMessage);	
		m_pMainFrame->ClientClosed();
	}
	else if(ComData.uMessage == CComData::COM_ADD_CLIENT) {

		m_pMainFrame->AddClientToList(ComData.szMessage, ComData.uSignIcon);	
	}
	else if(ComData.uMessage == CComData::COM_REMOVE_CLIENT) {

		m_pMainFrame->RemoveClientFromList(ComData.szMessage);	
	}
	else if(ComData.uMessage == CComData::COM_PRIVATE_MESSAGE) {

		m_pMainFrame->AddPrivateClientCom(CTime::GetCurrentTime(),
										   ComData.szFrom,
										   ComData.uSignIcon,
										   ComData.szMessage);	
	}
	else if(ComData.uMessage == CComData::COM_MESSAGE) {

		m_pMainFrame->AddClientsCom(CTime::GetCurrentTime(),
									ComData.szFrom,
									ComData.uSignIcon,
									ComData.szMessage);	
	}
	else if(ComData.uMessage == CComData::COM_CLOSE) {

		m_pMainFrame->AddClientsCom(CTime::GetCurrentTime(),
									ComData.szFrom,
									ComData.uSignIcon,
									ComData.szMessage);	

		m_pMainFrame->ClientClosed();
	}
}

void CClientSocket::SendCom(CComData* pComData)
{
	ASSERT(pComData);
	try {
		if(m_pArchiveOut != NULL) {
			pComData->Serialize(*m_pArchiveOut);
			m_pArchiveOut->Flush();
		}
	}
	catch(CFileException* e) {
		e->Delete(); 
		m_pArchiveOut->Abort();
	}
}

void CClientSocket::ClientSignOut()
{
	try {
		CComData ComData;
		ComData.szFrom	  = m_szSignInName;
		ComData.szMessage = "";
		ComData.uMessage  = CComData::COM_SIGN_OUT;
		SendCom(&ComData);
	}
	catch(CFileException* e){
		TCHAR csError[CHAR_BUFFER_SIZE];
		e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
		AfxMessageBox(csError);
	}
}

void CClientSocket::SendClientMessage(CString szMessage)
{
	try {
		CComData ComData;
		ComData.szFrom	  = m_szSignInName;
		ComData.uSignIcon = m_uSignIcon;
		ComData.szMessage = szMessage;
		ComData.uMessage  = CComData::COM_MESSAGE;
		SendCom(&ComData);
	}
	catch(CFileException* e){
		TCHAR csError[CHAR_BUFFER_SIZE];
		e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
		AfxMessageBox(csError);
	}
}


void CClientSocket::SendMessageTo(CString szClient, CString szMessage)
{
	try {
		CComData ComData;
		ComData.szFrom	  = m_szSignInName;
		ComData.uSignIcon = m_uSignIcon;
		ComData.szMessage = szClient + ": " + szMessage;
		ComData.uMessage  = CComData::COM_PRIVATE_MESSAGE;
		SendCom(&ComData);
	}
	catch(CFileException* e){
		TCHAR csError[CHAR_BUFFER_SIZE];
		e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
		AfxMessageBox(csError);
	}
}

void CClientSocket::Finalize()
{
	if(m_pArchiveIn != NULL){
		delete m_pArchiveIn;
		m_pArchiveIn = NULL;
	}
	if(m_pArchiveOut != NULL){
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}
	if(m_pSocketFile != NULL){
		delete m_pSocketFile;
		m_pSocketFile = NULL;
	}
	
	Close();
}
