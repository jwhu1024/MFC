// MessageView.cpp : implementation file
//

#include "stdafx.h"
#include "chat client.h"
#include "MessageView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMessageView

IMPLEMENT_DYNCREATE(CMessageView, CFormView)

CMessageView::CMessageView()
	: CFormView(CMessageView::IDD)
{
	//{{AFX_DATA_INIT(CMessageView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CMessageView::Init(CMainFrame* pMainFrame)
{
	ASSERT(pMainFrame);
	m_pMainFrame = pMainFrame;
}

CMessageView::~CMessageView()
{
}

void CMessageView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMessageView)
	DDX_Control(pDX, IDC_EDIT_MESSAGE, m_edtMessage);
	DDX_Control(pDX, IDC_BUTTON_SEND, m_btnSend);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMessageView, CFormView)
	//{{AFX_MSG_MAP(CMessageView)
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMessageView diagnostics

#ifdef _DEBUG
void CMessageView::AssertValid() const
{
	CFormView::AssertValid();
}

void CMessageView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMessageView message handlers



void CMessageView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);
	
	if (!IsWindowVisible())
		return;
	
	Resize();
}

void CMessageView::Resize()
{
	CRect rc;	
	GetClientRect(rc);

	if (m_btnSend.GetSafeHwnd() && m_edtMessage.GetSafeHwnd()) {
		m_btnSend.SetWindowPos(NULL, rc.right - 55, rc.top + 5, 0, 0, SWP_NOSIZE); 
		m_edtMessage.SetWindowPos(NULL, 0, 0, rc.right - 60, 20, SWP_NOMOVE);
	}
}

void CMessageView::BlockConrols(BOOL bNotEnable)
{
	if (m_btnSend.GetSafeHwnd() && m_edtMessage.GetSafeHwnd()) {
		m_edtMessage.SetWindowText(""); 
		m_edtMessage.EnableWindow(!bNotEnable);
		m_btnSend.EnableWindow(!bNotEnable);
		
		CString szBuf((LPCTSTR)IDS_CAPTION_SEND_BUTTON);
		m_btnSend.SetWindowText(szBuf);
	}	
}

void CMessageView::OnButtonSend() 
{
	CString szBuf;
	m_edtMessage.GetWindowText(szBuf);

	if (!szBuf.IsEmpty()) {
		m_pMainFrame->SendClientMessage(szBuf);
		m_edtMessage.SetWindowText("");
	}

	m_edtMessage.SetFocus(); 
}

void CMessageView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	BOOL bFirst = TRUE;

	if (bFirst) {
		bFirst = FALSE;
		SetScrollSizes(MM_TEXT, CSize(1, 1));
	}
}
