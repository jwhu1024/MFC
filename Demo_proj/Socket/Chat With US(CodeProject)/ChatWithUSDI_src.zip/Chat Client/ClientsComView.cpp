// ClientsComView.cpp : implementation file
//

#include "stdafx.h"
#include "chat client.h"
#include "ClientsComView.h"
#include "..\\Commun\\LCLayout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


enum eClientsComView {
    CLIENTSCOMVIEW_COL_TIME = 0,
    CLIENTSCOMVIEW_COL_FROM,
    CLIENTSCOMVIEW_COL_MESSAGE,
};


/////////////////////////////////////////////////////////////////////////////
// CClientsComView

IMPLEMENT_DYNCREATE(CClientsComView, CListView)

CClientsComView::CClientsComView()
{
}

CClientsComView::~CClientsComView()
{
}


BEGIN_MESSAGE_MAP(CClientsComView, CListView)
	//{{AFX_MSG_MAP(CClientsComView)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_SAVE_AS, OnViewSaveAs)
	ON_WM_DESTROY()
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientsComView drawing

void CClientsComView::OnPaint()
{
	CListCtrl& lc = GetListCtrl();

	Default();

	if (!lc.GetItemCount()) {

        CDC* pDC = GetDC();
        int nSavedDC = pDC->SaveDC();

        CRect rc;
        GetClientRect(&rc);

        CHeaderCtrl* pHC;
        pHC = lc.GetHeaderCtrl();
        if (pHC != NULL)
        {
            CRect rcH;
            pHC->GetItemRect(0, &rcH);
            rc.top += rcH.bottom;
        }

        pDC->FillRect(rc, &CBrush(::GetSysColor(COLOR_WINDOW)));
		pDC->SetBkMode(TRANSPARENT); 
        pDC->SelectStockObject(ANSI_VAR_FONT);
        pDC->DrawText(CString((LPCSTR)IDS_EMPTY_LIST), rc, 
                      DT_CENTER|DT_WORDBREAK|DT_NOPREFIX|
					  DT_NOCLIP|DT_VCENTER|DT_SINGLELINE);

        pDC->RestoreDC(nSavedDC);
        ReleaseDC(pDC);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CClientsComView printing

BOOL CClientsComView::OnPreparePrinting(CPrintInfo* pInfo)
{
    return m_printer.OnPreparePrinting(pInfo, this, &GetListCtrl());
}

void CClientsComView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    CTime   oTime   = CTime::GetCurrentTime();
    CString timeStr = oTime.Format(IDS_TIME_FORMAT);
    CString szAppName((LPCTSTR)IDR_MAINFRAME);
    CString szTabName((LPCTSTR)IDS_TAB_CLIENTSCOM);
	CString szBuf;
	szBuf.Format("%s - %s", szAppName, szTabName);

    m_printer.OnBeginPrinting(pDC, pInfo, szBuf, timeStr);
}

void CClientsComView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    m_printer.OnEndPrinting(pDC, pInfo);
    CListView::OnEndPrinting(pDC, pInfo);
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientsComView::OnFilePrint() 
{
	if (ListIsEmpty()) {
		AfxMessageBox(IDS_PRINT_EMPTY_LIST);
		return;
	}

    CListView::OnFilePrint();
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientsComView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
    m_printer.OnPrint(pDC, pInfo);
}

void CClientsComView::OnUpdateFilePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());	
}

/////////////////////////////////////////////////////////////////////////////
// CClientsComView message handlers

BOOL CClientsComView::PreCreateWindow(CREATESTRUCT& cs) 
{
    cs.style |= LVS_REPORT;
    cs.style |= LVS_SHOWSELALWAYS;
    cs.style |= LVS_SINGLESEL;
	
	return CListView::PreCreateWindow(cs);
}

int CClientsComView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CString szBuf;
	CListCtrl& lc = GetListCtrl();
	lc.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_SUBITEMIMAGES);
	// insert columns
	szBuf.LoadString(IDS_COL_TIME); 
	lc.InsertColumn(CLIENTSCOMVIEW_COL_TIME, szBuf, LVCFMT_LEFT, 130);
	szBuf.LoadString(IDS_COL_FROM); 
	lc.InsertColumn(CLIENTSCOMVIEW_COL_FROM, szBuf, LVCFMT_LEFT, 100);
	szBuf.LoadString(IDS_COL_MESSAGE); 
	lc.InsertColumn(CLIENTSCOMVIEW_COL_MESSAGE, szBuf, LVCFMT_LEFT, 240);
	
	//set imagelist for the listctrl
	m_ImgList.Create(16,16,TRUE,1,1);
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_TIME));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_MESSAGE));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SERVER));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN1));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN2));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN3));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN4));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN5));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN6));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN7));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN8));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN9));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN10));
	lc.SetImageList(&m_ImgList, LVSIL_SMALL);

	CLCLayout::RestoreLayout(&lc, "CClientsComView");

	return 0;
}

void CClientsComView::OnDestroy() 
{
    CLCLayout::SaveLayout(&GetListCtrl(), "CClientsComView");
	CListView::OnDestroy();
}


void CClientsComView::UpdateCols()
{
	CString szBuf;
	LVCOLUMN pCol;
	CListCtrl& lc = GetListCtrl();

	ZeroMemory(&pCol, sizeof(LVCOLUMN));
	pCol.mask = LVCF_TEXT;

	szBuf.LoadString(IDS_COL_TIME); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTSCOMVIEW_COL_TIME, &pCol);

	szBuf.LoadString(IDS_COL_FROM); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTSCOMVIEW_COL_FROM, &pCol);

	szBuf.LoadString(IDS_COL_MESSAGE); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTSCOMVIEW_COL_MESSAGE, &pCol);

	Invalidate();
}


/*============================================================================

Description:    Save the content of the view to a disk file.

Return:             

============================================================================*/
void CClientsComView::OnViewSaveAs() 
{
    CStdioFile		file;
    static CString	szFileName;
    CString			szFileExt;
    CString			szFileFilter;
    CString			szMessage;
	CString         szBuf1;
	CString			szBuf2;
	CString			szBuf3;
	BOOL            bOpen;

	if (ListIsEmpty()) {
		AfxMessageBox(IDS_SAVE_EMPTY_LIST);
		return;
	}

    szFileExt.LoadString(IDS_TXT_FILE_EXT);
    szFileFilter.LoadString(IDS_TXT_FILE_FLT);

    CFileDialog Dlg(FALSE, szFileExt, szFileName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFileFilter);

    if (Dlg.DoModal() == IDOK) {
        szFileName = Dlg.GetPathName();
                
        try {
			bOpen = file.Open(szFileName, CFile::modeWrite | CFile::modeCreate);
            if (bOpen) {
				
                CListCtrl& lc = GetListCtrl();
				szBuf1.LoadString(IDR_MAINFRAME);
				szBuf2.LoadString(IDS_TAB_CLIENTSCOM);
				szBuf3.LoadString(IDS_FILE_LOG_HEADER);
				szMessage.Format("%s - %s\n%s", szBuf1, szBuf2, szBuf3);
                file.WriteString(szMessage);
				
				szBuf1.LoadString(IDS_COL_TIME); 
				szBuf2.LoadString(IDS_COL_FROM); 
				szBuf3.LoadString(IDS_COL_MESSAGE); 
                szMessage.Format(_T("%s\t\t     %s\t\t%s\n"), szBuf1, szBuf2, szBuf3);
                file.WriteString(szMessage); 
				szBuf1.LoadString(IDS_FILE_LOG_HEADER);
                file.WriteString(szBuf1);
				
                for (int i = 0; i < lc.GetItemCount(); i++) {
                    szMessage.Format(_T("%s  %s\t\t%s\n"),
									 lc.GetItemText(i, CLIENTSCOMVIEW_COL_TIME),
									 lc.GetItemText(i, CLIENTSCOMVIEW_COL_FROM),
									 lc.GetItemText(i, CLIENTSCOMVIEW_COL_MESSAGE));
                    file.WriteString(szMessage);
                }
            }
        }
        catch (CException *e) {
            e->Delete();
        }
        if (bOpen) {
            file.Close();
        }
        else {
            szBuf1.LoadString(IDS_MSG_SAVE_AS_FAILED);
            szMessage.Format(szBuf1, szFileName);
            AfxMessageBox(szMessage, MB_ICONSTOP);
        }
    }
}

void CClientsComView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());		
}

void CClientsComView::AddMessage(CString szTime, CString szFrom, int uSignIcon, CString szMessage)
{
	CListCtrl& lc = GetListCtrl();
	lc.InsertItem(CLIENTSCOMVIEW_COL_TIME, szTime, 0);

	LV_ITEM lvi2;
	lvi2.mask = LVIF_TEXT | LVIF_IMAGE; 
	lvi2.iItem = CLIENTSCOMVIEW_COL_TIME; //item to set 
	lvi2.iSubItem = CLIENTSCOMVIEW_COL_FROM; 
	lvi2.pszText = szFrom.GetBuffer(szFrom.GetLength());
	szFrom.ReleaseBuffer(); 
	lvi2.cchTextMax  = szFrom.GetLength(); 
	lvi2.iImage = uSignIcon == -1 ? 2 : uSignIcon + 3; //image index 
	lc.SetItem(&lvi2); 

	LV_ITEM lvi3;
	lvi3.mask = LVIF_TEXT | LVIF_IMAGE; 
	lvi3.iItem = CLIENTSCOMVIEW_COL_TIME; //item to set 
	lvi3.iSubItem = CLIENTSCOMVIEW_COL_MESSAGE; 
	lvi3.pszText = szMessage.GetBuffer(szMessage.GetLength());
	szMessage.ReleaseBuffer(); 
	lvi3.cchTextMax  = szMessage.GetLength(); 
	lvi3.iImage = 1; //image index 
	lc.SetItem(&lvi3); 
}

