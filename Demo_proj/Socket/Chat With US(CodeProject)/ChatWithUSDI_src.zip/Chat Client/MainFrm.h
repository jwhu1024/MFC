// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__687B5E45_6721_47AD_B27D_D868E5B1C42D__INCLUDED_)
#define AFX_MAINFRM_H__687B5E45_6721_47AD_B27D_D868E5B1C42D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\\Commun\\VisualFx.h"
#include "..\\Commun\\InfoBar.h"
#include "..\\Commun\\MainTray.h"
#include "ClientsListView.h"
#include "DialogBarUtil.h"

class CClientsComView;
class CMessageView;
class CClientSocket;
class CClientPrivateComView;

class CMainFrame : public CMainTray
{
protected:
	enum eMainFrame { BALLON_PRIVATE_MESSAGE = 0, BALLON_ADD_CLIENT, BALLON_REMOVE_CLIENT,};
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	TVisualFramework		m_Framework;
	
private:
	CChatClientApp*			m_pApp;
	BCMenu m_menu;
	CClientSocket*		m_pClientSocket;
    CClientsListView	m_ClientsList; // instant bar
	CClientsComView*	m_pClientsComView;
	CMessageView*		m_pMessagesView;
	TTabWnd*			m_pTabClientsCom;
	TTabWnd*			m_pTabClientPrivateComView;
	CSplitterWnd*       m_pSplitter;
	CClientPrivateComView* m_pClientPrivateComView;
	
	BOOL				 m_bEnglishLanguage;
	BOOL				m_bClientConnected;
	BOOL				m_bWindowOnTop;
	DWORD                 m_dwStartTimeConnected;	

// Operations
public:
	void ClientClosed();
	void AddClientsCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage);
	void AddPrivateClientCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage);
	void SendClientMessage(CString szMessage);
	void AddClientToList(CString szClient, UINT nSignIcon);
	void RemoveClientFromList(CString szClient);
	void SendMessageTo(CString szClient, CString szMessage);
	
protected:
	void SetLanguage(BOOL bEnglish = TRUE, BOOL bRestore = TRUE);
	void SaveWindowPlacement();
	void RestoreWindowPlacement();
	void UpdateAllView();
	BOOL FrenchLibraryExist();
	BOOL DisconnectClient();
	void UpdateMenu();
	void NotifyBallonClient(eMainFrame eMode, CString szClient);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CDialogBarUtil m_DlgBarUtil;
	CInfoBar	m_InfoBar;
	
// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnOperationsConnectserver();
	afx_msg void OnUpdateOperationsConnectserver(CCmdUI* pCmdUI);
	afx_msg void OnOperationsDisconnectserver();
	afx_msg void OnUpdateOperationsDisconnectserver(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI );
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnInformationsViewlocalips();
    afx_msg void    OnUpdateConnectionStatus(CCmdUI* pCmdUI); 
    afx_msg void    OnUpdateNbPrivateMessages(CCmdUI* pCmdUI); 
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLanguageEnglish();
	afx_msg void OnUpdateLanguageEnglish(CCmdUI* pCmdUI);
	afx_msg void OnLanguageFrench();
	afx_msg void OnUpdateLanguageFrench(CCmdUI* pCmdUI);
	afx_msg void OnPopupSendmessage();
	afx_msg LRESULT OnMenuChar( UINT nChar, UINT nFlags, CMenu* pMenu );
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnOptionsPreferences();
	afx_msg void OnViewParameters();
	afx_msg void OnUpdateViewParameters(CCmdUI* pCmdUI);
	afx_msg void OnViewClientslist();
	afx_msg void OnUpdateViewClientslist(CCmdUI* pCmdUI);
	afx_msg void OnTraymenuShowchatwithusclient();
	afx_msg void OnOptionsAlwaysvisible();
	afx_msg void OnUpdateOptionsAlwaysvisible(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__687B5E45_6721_47AD_B27D_D868E5B1C42D__INCLUDED_)
