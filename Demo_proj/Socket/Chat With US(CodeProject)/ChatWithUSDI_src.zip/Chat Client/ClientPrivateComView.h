#if !defined(AFX_CLIENTPRIVATECOMVIEW_H__2AF3FAC3_E118_42BE_AAF9_B14BC3E3169C__INCLUDED_)
#define AFX_CLIENTPRIVATECOMVIEW_H__2AF3FAC3_E118_42BE_AAF9_B14BC3E3169C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientPrivateComView.h : header file
//
#include "..\\Commun\\LCPrinter.h"

/////////////////////////////////////////////////////////////////////////////
// CClientPrivateComView view

class CClientPrivateComView : public CListView
{
protected:
	CClientPrivateComView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CClientPrivateComView)

// Attributes
public:
private:
	CLCPrinter m_printer;
	CImageList m_ImgList;

// Operations
public:
	void UpdateCols();
	void AddMessage(CString szTime, CString szFrom, int uSignIcon, CString szMessage);
	int GetMessagesCount();

private:
	void OnPaint();      // overridden to draw this view
	BOOL ListIsEmpty() { return (GetListCtrl().GetItemCount() > 0)?FALSE:TRUE; } 

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientPrivateComView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CClientPrivateComView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CClientPrivateComView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void    OnFilePrint();
    afx_msg void    OnViewSaveAs();
	afx_msg void	OnDestroy();
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTPRIVATECOMVIEW_H__2AF3FAC3_E118_42BE_AAF9_B14BC3E3169C__INCLUDED_)
