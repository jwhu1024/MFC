#if !defined(AFX_CLIENTSOCKET_H__3B8B0270_0C17_49DE_BBA1_6AA70E51C29D__INCLUDED_)
#define AFX_CLIENTSOCKET_H__3B8B0270_0C17_49DE_BBA1_6AA70E51C29D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientSocket.h : header file
//

class CMainFrame;
class CComData;


/////////////////////////////////////////////////////////////////////////////
// CClientSocket command target

class CClientSocket : public CSocket
{
// Attributes
public:

private:
	CMainFrame*     m_pMainFrame;
	CSocketFile*	m_pSocketFile;
	CArchive*		m_pArchiveIn;
	CArchive*		m_pArchiveOut;
	CString         m_szSignInName;
	UINT	         m_uSignIcon;

// Operations
public:
	CClientSocket(CMainFrame* pMainFrame, CString szSignInName, UINT uSignIcon);
	virtual ~CClientSocket();
	void ClientSignOut();	
	CString GetSignInName() { return m_szSignInName; }
	void SendClientMessage(CString szMessage);
	void SendMessageTo(CString szClient, CString szMessage);

private:
	void Finalize();
	void ProcessServerCom();
	void SendCom(CComData* pComData);
	
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CClientSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTSOCKET_H__3B8B0270_0C17_49DE_BBA1_6AA70E51C29D__INCLUDED_)
