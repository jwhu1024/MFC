#ifndef __ClientsListView_H__
#define __ClientsListView_H__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ClientsListView.h : header file
//

class CMainFrame;
/////////////////////////////////////////////////////////////////////////////
// ClientsListView window

#ifndef baseCMyBar
#define baseCMyBar CSizingControlBarG
#endif

class CClientsListView : public baseCMyBar
{
// Construction
public:
	CClientsListView();

// Attributes
private:
	CMainFrame* m_pMainFrame;
	CImageList m_ImgList;


// Operations
public:
	void Init(CMainFrame* pMainFrame);
	void AddClient(CString szClient, UINT nSignIcon);
	void RemoveClient(CString szClient);
	void ClearList();
	CString GetClient();
	void UpdateCols();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientsListView)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CClientsListView();

protected:
	CListCtrl	m_ListCtrl;

	// Generated message map functions
protected:
	//{{AFX_MSG(CClientsListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined __ClientsListView_H__
