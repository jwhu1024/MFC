// DialogBarUtil.h: interface for the MyDialogBar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DialogBarUtil_H__D614B259_C5EC_11D2_B8C5_B41E04C10000__INCLUDED_)
#define AFX_DialogBarUtil_H__D614B259_C5EC_11D2_B8C5_B41E04C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "..\\Commun\\DialogBarEx.h"
#include "..\\Commun\\IconComboBox.h"

class CChatClientApp;

/////////////////////////////////////////////////////////////////////////////
// CMyDialogBar window

class CDialogBarUtil : public  CDialogBarEx 
{
// Construction
public:
	CDialogBarUtil();

// Attributes
private:
	CChatClientApp* m_pApp;
	
	CIPAddressCtrl m_ctrlIPAdress;
	CEdit m_edtPort;
	CSpinButtonCtrl m_ctrlSpinPort;

	CEdit m_edtSignInName;
	CStatic m_szScreenName;

	CSmallIconComboBox m_cboScreenName;
	
// Operations
public:
	CString GetIPAdress();
	int GetPort();
	CString GetSignInName();
	int GetSignInNameIcon();
	void BlockConrols(BOOL bNotEnable = TRUE);
	void UpdateCaptions();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogBarUtil)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual void OnInitDialogBar();
	virtual ~CDialogBarUtil();

	// Generated message map functions
protected:
	//{{AFX_MSG(CDialogBarUtil)
	afx_msg void OnMove(int x, int y);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
#endif // !defined(AFX_DialogBarUtil_H__D614B259_C5EC_11D2_B8C5_B41E04C10000__INCLUDED_)
