#if !defined(AFX_MESSAGEVIEW_H__D98BC106_291D_476F_AD6A_746E280DDB89__INCLUDED_)
#define AFX_MESSAGEVIEW_H__D98BC106_291D_476F_AD6A_746E280DDB89__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MessageView.h : header file
//

class CMainFrame;
/////////////////////////////////////////////////////////////////////////////
// CMessageView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CMessageView : public CFormView
{
protected:
	CMessageView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMessageView)

// Form Data
public:
	//{{AFX_DATA(CMessageView)
	enum { IDD = IDD_FORMVIEW };
	CEdit	m_edtMessage;
	CButton	m_btnSend;
	//}}AFX_DATA

// Attributes
public:

private:
	CMainFrame* m_pMainFrame;

// Operations
public:
	void Init(CMainFrame* pMainFrame);
	void BlockConrols(BOOL bNotEnable = TRUE);
	void Resize();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMessageView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMessageView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMessageView)
	afx_msg void OnButtonSend();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MESSAGEVIEW_H__D98BC106_291D_476F_AD6A_746E280DDB89__INCLUDED_)
