// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Chat Client.h"
#include "MainFrm.h"
#include "ClientsComView.h"
#include "MessageView.h"
#include "ClientPrivateComView.h"
#include "ClientSocket.h"
#include "MessageDlg.h"
#include "OptionsDlg.h"
#include "..\\Commun\\IPInfos.h"
#include "..\\Commun\\TBalloon.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CMainTray)

BEGIN_MESSAGE_MAP(CMainFrame, CMainTray)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_OPERATIONS_CONNECTSERVER, OnOperationsConnectserver)
	ON_UPDATE_COMMAND_UI(ID_OPERATIONS_CONNECTSERVER, OnUpdateOperationsConnectserver)
	ON_COMMAND(ID_OPERATIONS_DISCONNECTSERVER, OnOperationsDisconnectserver)
	ON_UPDATE_COMMAND_UI(ID_OPERATIONS_DISCONNECTSERVER, OnUpdateOperationsDisconnectserver)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_WM_GETMINMAXINFO()
	ON_WM_SIZE()
	ON_COMMAND(ID_INFORMATIONS_VIEWLOCALIPS, OnInformationsViewlocalips)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_CONNECTION_STATUS, OnUpdateConnectionStatus)         
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_NBPRIVATE_MESSAGES, OnUpdateNbPrivateMessages)         
	ON_WM_TIMER()
	ON_COMMAND(ID_LANGUAGE_ENGLISH, OnLanguageEnglish)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_ENGLISH, OnUpdateLanguageEnglish)
	ON_COMMAND(ID_LANGUAGE_FRENCH, OnLanguageFrench)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_FRENCH, OnUpdateLanguageFrench)
	ON_COMMAND(ID_POPUP_SENDMESSAGE, OnPopupSendmessage)
	ON_WM_MENUCHAR()
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(ID_OPTIONS_PREFERENCES, OnOptionsPreferences)
	ON_COMMAND(ID_VIEW_PARAMETERS, OnViewParameters)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PARAMETERS, OnUpdateViewParameters)
	ON_COMMAND(ID_VIEW_CLIENTSLIST, OnViewClientslist)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CLIENTSLIST, OnUpdateViewClientslist)
	ON_COMMAND(ID_TRAYMENU_SHOWCHATWITHUSCLIENT, OnTraymenuShowchatwithusclient)
	ON_COMMAND(ID_OPTIONS_ALWAYSVISIBLE, OnOptionsAlwaysvisible)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_ALWAYSVISIBLE, OnUpdateOptionsAlwaysvisible)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CONNECTION_STATUS,
	ID_INDICATOR_NBPRIVATE_MESSAGES,
	ID_INDICATOR_TIME,
};


/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_pApp				= (CChatClientApp*)AfxGetApp();

	m_pClientsComView   = NULL;
	m_pMessagesView     = NULL;
	m_pTabClientsCom    = NULL;
	m_pClientPrivateComView = NULL;
	m_pTabClientPrivateComView = NULL;
	m_pClientSocket     = NULL;
	m_pSplitter         = NULL;
	m_bEnglishLanguage	= m_pApp->GetProfileInt("Settings", "Language", DEFAULT_LANGUAGE_ENGLISH);
	m_bClientConnected	= FALSE;
	m_bWindowOnTop			= m_pApp->GetProfileInt("Settings", "OnTop", FALSE);
	m_dwStartTimeConnected = 0;
}


CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMainTray::PreCreateWindow(cs) )
		return FALSE;
	
	cs.style = WS_OVERLAPPEDWINDOW;

	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMainTray::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_DlgBarUtil.Create(this, IDD_DIALOGBAR_UTIL, CBRS_GRIPPER|CBRS_TOOLTIPS|
		CBRS_FLYBY|CBRS_SIZE_DYNAMIC|TBSTYLE_FLAT|CBRS_TOP, IDD_DIALOGBAR_UTIL))
	{
		TRACE0("Failed to create dialog bar from CDialogBarUtil class\n");
		return -1;      // fail to create
	}

	/// Creation de l'INFO BAR  //////////////////////////
	if (!m_InfoBar.Create(NULL, NULL, WS_VISIBLE|WS_CHILD|WS_CLIPSIBLINGS|CBRS_TOP,
		                  CRect(0,0,0,0), this, AFX_IDW_DIALOGBAR))
	{
		 TRACE("Failed to create InfoBar\n");
		 return -1;
	}


	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
    m_wndStatusBar.SetPaneInfo(m_wndStatusBar.CommandToIndex(ID_INDICATOR_CONNECTION_STATUS),
								ID_INDICATOR_CONNECTION_STATUS,
								SBPS_POPOUT, 60);

	CString szBuf;
	szBuf.LoadString(IDS_TAB_CLIENTS);
	if (!m_ClientsList.Create(szBuf, this, CSize(100,150), FALSE, 123))
	{
		TRACE0("Failed to create m_ClientsList\n");
		return -1;		// fail to create
	}
	m_ClientsList.SetBarStyle(m_ClientsList.GetBarStyle() |
	        CBRS_TOOLTIPS | CBRS_RIGHT | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	EnableDocking(CBRS_ALIGN_ANY);
	
#ifdef _SCB_REPLACE_MINIFRAME
    m_pFloatingFrameClass = RUNTIME_CLASS(CSCBMiniDockFrameWnd);
#endif //_SCB_REPLACE_MINIFRAME

	szBuf.LoadString(IDS_TOOLSBAR_UTIL);
	m_DlgBarUtil.SetWindowText(szBuf);
 	m_DlgBarUtil.EnableDocking(CBRS_ALIGN_ANY);
    DockControlBar(&m_DlgBarUtil);
    RecalcLayout();

	szBuf.LoadString(IDS_TOOLSBAR_MAIN);
	m_wndToolBar.SetWindowText(szBuf); 
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	CRect rc;
    m_DlgBarUtil.GetWindowRect(rc);
    DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP, rc);
    RecalcLayout();
	
	szBuf.LoadString(AFX_IDS_APP_TITLE);
	m_InfoBar.SetText(szBuf);
	m_InfoBar.SetIcon(IDR_MAINFRAME);
	m_InfoBar.SetBarStyle(CBRS_ALIGN_TOP);

	m_ClientsList.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_ClientsList, AFX_IDW_DOCKBAR_RIGHT);
	
	//Change title caption
	SetWindowText(szBuf);

	//Set window placement
	RestoreWindowPlacement();
 
	//Apply App Language
	SetLanguage(m_bEnglishLanguage);

	LoadBarState("ControlsPos");


// System Tray
	TraySetIcon(IDR_MAINFRAME);
	TraySetToolTip(szBuf);
	TraySetMenu(IDR_TRAY_MENU, IDR_BITMAP_MENU);
	TraySetMinimizeToTray(m_pApp->GetProfileInt("Options", "MinimizeToTray", TRUE));
	
	m_bWindowOnTop = !m_bWindowOnTop;
	OnOptionsAlwaysvisible();

	SetTimer(ID_TIMER_TIME, TIMER_TIME_VALUE, NULL);
	SetTimer(ID_TIMER_INITIALIZATION, TIMER_INITIALIZATION_VALUE, NULL);
	
	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	CString szBuf((LPCTSTR)IDS_TAB_CLIENTSCOM);

	TVisualObject* pTab						= new TVisualObject(1, "", pContext, RUNTIME_CLASS(TTabWnd),TVisualObject::TOS_TABTOP);
	TVisualObject* pTabClients				= new TVisualObject(2, szBuf, 2, 1, pContext);
	TVisualObject* pClientsComView			= new TVisualObject(3, 0, 0, pContext, RUNTIME_CLASS(CClientsComView), CSize(0,195));
	TVisualObject* pMessageView				= new TVisualObject(4, 1, 0, pContext, RUNTIME_CLASS(CMessageView), CSize(0, 35));
	szBuf.LoadString(IDS_TAB_PRIVATE_COM); 
	TVisualObject* pTabClientPrivateComView	= new TVisualObject(5, szBuf, pContext, RUNTIME_CLASS(CClientPrivateComView));

	pTabClients->SetIcon(IDI_CLIENTSCOM);
	pTabClientPrivateComView->SetIcon(IDI_PRIVATECOM);

	m_Framework.Add(pTab);
	m_Framework.Add(pTab, pTabClients);
	m_Framework.Add(pTabClients, pClientsComView);
	m_Framework.Add(pTabClients, pMessageView);
	m_Framework.Add(pTab, pTabClientPrivateComView);
	m_Framework.Create(this);
 

	m_pTabClientsCom  = (TTabWnd*)pTab->GetWnd();
	m_pSplitter       = (CSplitterWnd*)pTabClients->GetWnd();
	m_pClientsComView = (CClientsComView*)pClientsComView->GetWnd();
	m_pMessagesView   = (CMessageView*)pMessageView->GetWnd();
	m_pMessagesView->Init(this);
	m_pTabClientPrivateComView = (TTabWnd*)pTab->GetWnd();
	m_pClientPrivateComView = (CClientPrivateComView*)pTabClientPrivateComView->GetWnd();
		
	return TRUE;
}

void CMainFrame::OnClose() 
{
	if (!DisconnectClient())
		return;

	KillTimer(ID_TIMER_TIME);
	SetLanguage(DEFAULT_LANGUAGE_ENGLISH, FALSE);
	SaveWindowPlacement();
	SaveBarState("ControlsPos");
	m_pApp->WriteProfileInt("Settings", "OnTop", m_bWindowOnTop);

	Sleep(100);

	CMainTray::OnClose();
}

void CMainFrame::OnDestroy() 
{
	CMainTray::OnDestroy();
	
	m_Framework.Destroy();
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::UpdateMenu()
{
	CMenu* pMenu = GetMenu();
	if (pMenu)
		pMenu->DestroyMenu();

	m_menu.LoadMenu(IDR_MAINFRAME);  
	m_menu.LoadToolbar(IDR_BITMAP_MENU);
	HMENU hMenu = m_menu.Detach();
	::SetMenu(GetSafeHwnd(), hMenu); 
	m_hMenuDefault = hMenu;
}

void CMainFrame::SaveWindowPlacement()
{
    WINDOWPLACEMENT wp;
    GetWindowPlacement(&wp);
    m_pApp->WriteProfileBinary("Settings", "WindowPos", (LPBYTE)&wp, sizeof(wp));
}

void CMainFrame::RestoreWindowPlacement()
{
    WINDOWPLACEMENT *lwp;
    UINT nl;
    
    if(m_pApp->GetProfileBinary("Settings", "WindowPos", (LPBYTE*)&lwp, &nl))
    {
        SetWindowPlacement(lwp);
        delete [] lwp;
    }
	else {
		CenterWindow(GetDesktopWindow());
	}
}

void CMainFrame::OnLanguageEnglish() 
{
	m_bEnglishLanguage = TRUE;	
	SetLanguage();	
}

void CMainFrame::OnUpdateLanguageEnglish(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bEnglishLanguage); 	
}

void CMainFrame::OnLanguageFrench() 
{ 
	m_bEnglishLanguage = FALSE;
	SetLanguage(m_bEnglishLanguage);
}

void CMainFrame::OnUpdateLanguageFrench(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bEnglishLanguage);
	pCmdUI->Enable(FrenchLibraryExist()); 
}

BOOL CMainFrame::FrenchLibraryExist()
{
	HINSTANCE hFrenchRessource = LoadLibrary("CWUCliFr.dll");
	if (hFrenchRessource) {
		FreeLibrary(hFrenchRessource);
		return TRUE;
	}

	return FALSE;
}

void CMainFrame::SetLanguage(BOOL bEnglish, BOOL bRestore)
{
	static HINSTANCE hLanguageRessource = NULL;

	if (bRestore)
		m_pApp->WriteProfileInt("Settings", "Language", bEnglish);
	
	if (bEnglish) {
		FreeLibrary(hLanguageRessource);
		hLanguageRessource = m_pApp->GetEnglishRessource();
	}
	else {
		hLanguageRessource = LoadLibrary("CWUCliFr.dll");
	}

	if (hLanguageRessource) {
		AfxSetResourceHandle(hLanguageRessource);

		UpdateMenu();
		SetMessageText(AFX_IDS_IDLEMESSAGE);
		SetWindowText(CString((LPCTSTR)AFX_IDS_APP_TITLE));

		TraySetToolTip(CString((LPCTSTR)AFX_IDS_APP_TITLE));
		TraySetMenu(IDR_TRAY_MENU, IDR_BITMAP_MENU);

		if (bRestore)
			UpdateAllView();
	}
	else {
		AfxMessageBox(IDS_LANGUAGE_DEFAULT);
		m_bEnglishLanguage = DEFAULT_LANGUAGE_ENGLISH;	
		m_pApp->WriteProfileInt("Settings", "Language", DEFAULT_LANGUAGE_ENGLISH);
	}
}

void CMainFrame::UpdateAllView()
{
	CString szBuf;
	szBuf.LoadString(IDS_TAB_CLIENTSCOM);
	m_pTabClientsCom->SetTabLabel(0, szBuf);
	szBuf.LoadString(IDS_TAB_PRIVATE_COM);
	m_pTabClientPrivateComView->SetTabLabel(1, szBuf);
	
	m_pClientsComView->UpdateCols();
	m_pClientPrivateComView->UpdateCols();
	m_ClientsList.UpdateCols();
	m_pMessagesView->BlockConrols(!m_bClientConnected);

	szBuf.LoadString(AFX_IDS_APP_TITLE);
	m_InfoBar.SetText(szBuf);

	m_DlgBarUtil.UpdateCaptions();
}


void CMainFrame::OnOperationsConnectserver() 
{
	CString szIPAdress;
	szIPAdress = m_DlgBarUtil.GetIPAdress();
	if (szIPAdress.IsEmpty()) {
		AfxMessageBox(IDS_INVALID_IP_ADRESS);
		return;
	}
	
	UINT uPort = m_DlgBarUtil.GetPort();
	if (uPort < DEFAULT_MIN_PORT_NUMBER || uPort > DEFAULT_MAX_PORT_NUMBER) {
		CString szBuf;
		szBuf.Format(IDS_INVALID_PORT_NUMBER, DEFAULT_MIN_PORT_NUMBER,
											  DEFAULT_MAX_PORT_NUMBER); 
		AfxMessageBox(szBuf);
		return;
	}

	CString szSignInName = m_DlgBarUtil.GetSignInName();
	if (szSignInName.IsEmpty() || szSignInName.GetLength() < MIN_SIGN_NAME_LENGTH) {
		AfxMessageBox(IDS_EMPTY_SIGN_IN_NAME);
		return;
	}

	m_pClientSocket = new CClientSocket(this, szSignInName, m_DlgBarUtil.GetSignInNameIcon());

	while(!m_pClientSocket->Connect(szIPAdress, uPort)){

		int nRet = AfxMessageBox(IDS_RETRY_CONNECTION , MB_ICONQUESTION|MB_YESNO);
		if(nRet == IDNO) {
			DisconnectClient();
			return;
		}
	}

	m_DlgBarUtil.BlockConrols();
	m_pMessagesView->BlockConrols(FALSE);
	m_ClientsList.ClearList();
	m_bClientConnected = TRUE;
	m_dwStartTimeConnected = GetTickCount();
}

void CMainFrame::OnUpdateOperationsConnectserver(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_bClientConnected);
}

void CMainFrame::OnOperationsDisconnectserver() 
{
	CString szBuf = m_pClientSocket->GetSignInName();
	if (DisconnectClient()) {
		AddClientsCom(CTime::GetCurrentTime(), szBuf, ICON_OF_SERVER, CString((LPCTSTR)IDS_CLIENT_SIGN_OUT));
		m_DlgBarUtil.BlockConrols(FALSE);
		m_pMessagesView->BlockConrols();
		m_ClientsList.ClearList();
	}
}

void CMainFrame::OnUpdateOperationsDisconnectserver(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bClientConnected); 
}

BOOL CMainFrame::DisconnectClient()
{
	if (!m_bClientConnected)
		return TRUE;
	
	if (m_bClientConnected) {
		int nRet = AfxMessageBox(IDS_DISCONNECT_CLIENT , MB_ICONQUESTION|MB_YESNO);
		if (nRet == IDNO)
			return FALSE;
	}

	if (m_pClientSocket) {
		m_pClientSocket->ClientSignOut();
		delete m_pClientSocket;
		m_pClientSocket = NULL;
	}

	m_bClientConnected = FALSE;
	
	return TRUE;
}


void CMainFrame::ClientClosed()
{
	m_DlgBarUtil.BlockConrols(FALSE);
	m_pMessagesView->BlockConrols();
	m_ClientsList.ClearList();

	if (m_pClientSocket) {
		delete m_pClientSocket;
		m_pClientSocket = NULL;
	}

	m_bClientConnected = FALSE;
}

void CMainFrame::AddClientsCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage)
{
	m_pClientsComView->AddMessage(Time.Format(IDS_TIME_FORMAT), szFrom, uSignIcon, szMessage);
}

void CMainFrame::AddPrivateClientCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage)
{
	m_pClientPrivateComView->AddMessage(Time.Format(IDS_TIME_FORMAT), szFrom, uSignIcon, szMessage);
	NotifyBallonClient(BALLON_PRIVATE_MESSAGE, szFrom);
}

void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{ 
	CMainTray::OnGetMinMaxInfo(lpMMI); 

	CPoint minSize(MIN_FRAME_WITH, MIN_FRAME_HEIGTH); 
//	CPoint maxSize(640, 480); 
	lpMMI->ptMinTrackSize.x = minSize.x; 
	lpMMI->ptMinTrackSize.y = minSize.y; 
//	lpMMI->ptMaxTrackSize.x = maxSize.x; 
//	lpMMI->ptMaxTrackSize.y = maxSize.y; 
} 

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	CMainTray::OnSize(nType, cx, cy);
	
	if (!IsWindowVisible())
		return;

	m_pSplitter->SetRowInfo(0, cy - 150, 0);
}

void CMainFrame::SendClientMessage(CString szMessage)
{
	ASSERT(m_pClientSocket);
	m_pClientSocket->SendClientMessage(szMessage);
	AddClientsCom(CTime::GetCurrentTime(), m_DlgBarUtil.GetSignInName(), m_DlgBarUtil.GetSignInNameIcon(), szMessage);
}

/*============================================================================

Description:    Update the status bar connection status indicator

Return:         -

============================================================================*/
void CMainFrame::OnUpdateConnectionStatus(CCmdUI* pCmdUI) 
{
	m_wndStatusBar.SetPaneStyle(m_wndStatusBar.CommandToIndex(ID_INDICATOR_CONNECTION_STATUS),
		                        m_bClientConnected ? SBPS_NORMAL : SBPS_POPOUT);

    pCmdUI->SetText(m_bClientConnected ? CString((LPCTSTR)IDS_CLIENT_CONNECTED) : CString((LPCTSTR)IDS_CLIENT_DISCONNECTED));
}

/*============================================================================

Description:    Update the status bar connection status indicator

Return:         -

============================================================================*/
void CMainFrame::OnUpdateNbPrivateMessages(CCmdUI* pCmdUI) 
{
	CString szBuf;
	szBuf.Format(IDS_NBPRIVATE_MESSAGES, m_pClientPrivateComView->GetMessagesCount()); 
    pCmdUI->SetText(szBuf);
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
    switch (nIDEvent) {

    case ID_TIMER_TIME:
		m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_TIME),
			                       CTime::GetCurrentTime().Format(IDS_TIME_FORMAT));

		TraySetMinimizeToTray(m_pApp->GetProfileInt("Options", "MinimizeToTray", TRUE));
		break;

    case ID_TIMER_INITIALIZATION:
		KillTimer(ID_TIMER_INITIALIZATION);
        m_pMessagesView->BlockConrols();
        m_pMessagesView->Resize();
		m_DlgBarUtil.UpdateCaptions();
		break;
    
    default:
	    CMainTray::OnTimer(nIDEvent);
        break;
	} 
}


void CMainFrame::OnInformationsViewlocalips() 
{
	CIPInfos InfoIP;
	CString szBuf((LPCTSTR)IDS_LOCAL_IP_HEADER);
	CString szBuf2;

	szBuf += "------------------------\n";

	for (int i = 0; i < InfoIP.GetLocalIPCount(); i++) {
		szBuf2.Format("%d- %s\n", i+1, InfoIP.GetLocalIP(i));
		szBuf += szBuf2; 
	}
	MessageBox(szBuf); 	
}

void CMainFrame::AddClientToList(CString szClient, UINT nSignIcon)
{
	m_ClientsList.AddClient(szClient, nSignIcon);
	NotifyBallonClient(BALLON_ADD_CLIENT, szClient);
}

void CMainFrame::RemoveClientFromList(CString szClient)
{
	m_ClientsList.RemoveClient(szClient);
	NotifyBallonClient(BALLON_REMOVE_CLIENT, szClient);
}

void CMainFrame::SendMessageTo(CString szClient, CString szMessage)
{
	m_pClientSocket->SendMessageTo(szClient, szMessage);
}

void CMainFrame::OnPopupSendmessage() 
{
	CString szClient(m_ClientsList.GetClient());
	if (szClient.IsEmpty())
		return;
	
	CMessageDlg Dlg;
	if (Dlg.DoModal() == IDOK) {
		SendMessageTo(szClient, Dlg.GetMessage());	
	}
}


//This handler ensures that keyboard shortcuts work
LRESULT CMainFrame::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
	LRESULT lresult;

	if (m_menu.IsMenu(pMenu))
		lresult = BCMenu::FindKeyboardShortcut(nChar, nFlags, pMenu);
	else
		lresult = CMainTray::OnMenuChar(nChar, nFlags, pMenu);
	
	return(lresult);
}

//This handler updates the menus from time to time
void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CMainTray::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	if (!bSysMenu) {
		if (m_menu.IsMenu(pPopupMenu))
			BCMenu::UpdateMenu(pPopupMenu);
	}
}

void CMainFrame::NotifyBallonClient(eMainFrame eMode, CString szClient)
{
	CString szBuf;
	switch (eMode) {
	case BALLON_PRIVATE_MESSAGE:
		if (!m_pApp->GetProfileInt("Options", "NotifyPrivateMessage", TRUE))
			return;

		szBuf.Format(IDS_BALLON_PRIVATE_MESSAGE, CString((LPCTSTR)AFX_IDS_APP_TITLE), szClient);
		break;
	case BALLON_ADD_CLIENT:
		if (!m_pApp->GetProfileInt("Options", "NotifyAdd", TRUE))
			return;

		if ((m_dwStartTimeConnected + ELAPSE_BALLON_SHOW) < GetTickCount())
			return;
		
		m_dwStartTimeConnected = GetTickCount();
		szBuf.Format(IDS_BALLON_ADD_USER, CString((LPCTSTR)AFX_IDS_APP_TITLE), szClient);
		break;
	case BALLON_REMOVE_CLIENT:
		if (!m_pApp->GetProfileInt("Options", "NotifyRemove", TRUE))
			return;

		szBuf.Format(IDS_BALLON_REMOVE_CLIENT, CString((LPCTSTR)AFX_IDS_APP_TITLE), szClient);
		break;
	}

	CTBalloon * pBallon = new CTBalloon(130,85);
	pBallon->SetText(szBuf);
	pBallon->SetLifeTime(2);
	pBallon->CreateAndShow();
}

void CMainFrame::OnOptionsPreferences() 
{
	COptionsDlg Dlg;
	Dlg.DoModal();
}

void CMainFrame::OnViewParameters() 
{
    ShowControlBar(&m_DlgBarUtil, !m_DlgBarUtil.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewParameters(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_DlgBarUtil.IsVisible());
}

void CMainFrame::OnViewClientslist() 
{
    ShowControlBar(&m_ClientsList, !m_ClientsList.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewClientslist(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_ClientsList.IsVisible());
}

void CMainFrame::OnTraymenuShowchatwithusclient() 
{
	TrayShowMainWindow();	
}

void CMainFrame::OnOptionsAlwaysvisible() 
{
	if (!m_bWindowOnTop) {
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	}
	else {
		SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	}
	m_bWindowOnTop = !m_bWindowOnTop;
}

void CMainFrame::OnUpdateOptionsAlwaysvisible(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_bWindowOnTop);
}
