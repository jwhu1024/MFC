#if !defined(AFX_CLIENTSLISTVIEW_H__E4C6EDB6_27FC_4129_A89C_BDB448BBFB35__INCLUDED_)
#define AFX_CLIENTSLISTVIEW_H__E4C6EDB6_27FC_4129_A89C_BDB448BBFB35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientsListView.h : header file
//

#include "..\\Commun\\LCPrinter.h"
class CComData;
class CMainFrame;

/////////////////////////////////////////////////////////////////////////////
// CClientsListView view

class CClientsListView : public CListView
{
protected:
	CClientsListView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CClientsListView)

// Attributes
public:
	
private:
	CMainFrame* m_pMainFrame;
	CLCPrinter m_printer;
	CImageList m_ImgList;
	BOOL       m_bSorted;

// Operations
public:
	void Init(CMainFrame* pMainFrame);
	void UpdateCols();
	CString GetClientName();
	void UpdateClientsList(CPtrList* pClientstList);
	CString GetFormatedClientInfos();	

private:
	void OnPaint();      // overridden to draw this view
	BOOL ListIsEmpty() { return (GetListCtrl().GetItemCount() > 0)?FALSE:TRUE; } 
	void ShowClientInfos();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientsListView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CClientsListView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CClientsListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void    OnFilePrint();
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnFileSaveAs();
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void    OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnPopupSendmessage();
	afx_msg void OnPopupKickthisuser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTSLISTVIEW_H__E4C6EDB6_27FC_4129_A89C_BDB448BBFB35__INCLUDED_)
