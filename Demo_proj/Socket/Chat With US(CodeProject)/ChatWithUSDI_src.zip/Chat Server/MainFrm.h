// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__BC12B97F_B030_4F34_811A_0EA96B32F97D__INCLUDED_)
#define AFX_MAINFRM_H__BC12B97F_B030_4F34_811A_0EA96B32F97D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "..\\Commun\\VisualFx.h"
#include "..\\Commun\\InfoBar.h"
#include "..\\Commun\\MainTray.h"
#include "DialogBarUtil.h"

class CChatServerApp;
class CClientsComView;
class CServerComView;
class CClientsListView;
class CClientInfosView;
class CClientMessagesView;
class CServerSocket;

class CMainFrame : public CMainTray
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	TVisualFramework		m_Framework;

private:
	BCMenu m_menu;
	CChatServerApp*			m_pApp;
	TTabWnd*				m_pTabServerClients;			
	TTabWnd*				m_pTabServerClientsCom;			
	CClientsComView*		m_pClientsComView;
	CServerComView*			m_pServerComView;
	CClientsListView*		m_pClientsListView;
	CClientInfosView*		m_pClientInfosView;
	CClientMessagesView*	m_pClientMessagesView;
	
	BOOL m_bEnglishLanguage;
	BOOL m_bServerStarted;
	BOOL m_bWindowOnTop;

	CServerSocket* m_pServerSocket;
	CDialogBarUtil m_DlgBarUtil;

// Operations
public:
	void UpdateClientsList(CPtrList* pClientstList);
	void AddServerCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage);
	void AddClientsCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage);
	void AddClientInfos(CString szIPAddresse, CString szPort, CString szMessCount, CTime TimeStarted);
	void AddClientMessage(CStringList* pMessageList);
	CPtrList* GetClientsList();
	void ClearClientView();
	void ClearAllViews();
	CString GetFormatedClientInfos();
	void KickUser(CString szClient);
	void SendMessageTo(CString szClient, CString szMessage);
	
protected:
	void SetLanguage(BOOL bEnglish = TRUE, BOOL bRestore = TRUE);
	void SaveWindowPlacement();
	void RestoreWindowPlacement();
	void UpdateAllView();
	BOOL FrenchLibraryExist();
	BOOL DisconnectServer();
	void UpdateMenu();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CInfoBar	m_InfoBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnLanguageEnglish();
	afx_msg void OnUpdateLanguageEnglish(CCmdUI* pCmdUI);
	afx_msg void OnLanguageFrench();
	afx_msg void OnUpdateLanguageFrench(CCmdUI* pCmdUI);
	afx_msg void OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI );
	afx_msg void OnOperationsStartserver();
	afx_msg void OnUpdateOperationsStartserver(CCmdUI* pCmdUI);
	afx_msg void OnOperationsStopserver();
	afx_msg void OnUpdateOperationsStopserver(CCmdUI* pCmdUI);
	afx_msg void OnClose();
    afx_msg void    OnUpdateConnectionStatus(CCmdUI* pCmdUI); 
    afx_msg void    OnUpdateConnectionClients(CCmdUI* pCmdUI); 
    afx_msg void    OnUpdateNbMessages(CCmdUI* pCmdUI); 
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnInformationsViewsystemips();
	afx_msg LRESULT OnMenuChar( UINT nChar, UINT nFlags, CMenu* pMenu );
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg void OnViewParameters();
	afx_msg void OnUpdateViewParameters(CCmdUI* pCmdUI);
	afx_msg void OnTraymenuShowchatwithusserver();
	afx_msg void OnOptionsPreferences();
	afx_msg void OnOptionsAlwaysvisible();
	afx_msg void OnUpdateOptionsAlwaysvisible(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__BC12B97F_B030_4F34_811A_0EA96B32F97D__INCLUDED_)
