#include "stdafx.h"
#include "Chat Server.h"

#include "ServerSocket.h"
#include "ClientSocket.h"
#include "..\\Commun\\ComData.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CServerSocket

CServerSocket::CServerSocket(CMainFrame* pMainFrame)
{
	ASSERT(pMainFrame);
	m_pMainFrame = pMainFrame;
	m_nMaxClients = -1;
}

CServerSocket::~CServerSocket()
{
	CloseClients();
	UpdateClientsList();
	Close();
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CServerSocket, CSocket)
	//{{AFX_MSG_MAP(CServerSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CListeningSocket member functions

BOOL CServerSocket::BeginListening(UINT uPort, int nMaxClients)
{
	m_nMaxClients = nMaxClients;
	
	if(!m_ClientstList.IsEmpty())
		CloseClients();

	if (!Create(uPort))
		return FALSE;

	if (!Listen())
		return FALSE;

	return TRUE;
}

void CServerSocket::OnAccept(int nErrorCode) 
{
	CSocket::OnAccept(nErrorCode);

	ProcessAccept();
}

//when got a connection message from a client
void CServerSocket::ProcessAccept()
{
	CClientSocket* pClientSocket = new CClientSocket(this);
	ASSERT(pClientSocket);

	if (!Accept(*pClientSocket)) {
		delete pClientSocket;
		return;
	}
	pClientSocket->Init();


	if (m_nMaxClients != -1) {
		if (m_nMaxClients <= m_ClientstList.GetCount()) {
			try {
				//send the connection confirmation to the client,add to the list - yh
				CComData ComData;
				ComData.szFrom	  = CString((LPCTSTR)IDS_COM_SERVER);
				ComData.szMessage = CString((LPCTSTR)IDS_COM_MAX_CLIENTS);
				ComData.uMessage  = CComData::COM_CLOSE;
				pClientSocket->SendCom(&ComData);
				delete pClientSocket;

				m_pMainFrame->AddServerCom(CTime::GetCurrentTime(),
											ComData.szFrom,
											SERVER_ICON,
											CString((LPCTSTR)IDS_MAX_CLIENT));	
				return;
			}
			catch(CFileException* e){
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}
		}
	}


	try {
		//send the connection confirmation to the client,add to the list - yh
		CComData ComData;
		ComData.szFrom	  = CString((LPCTSTR)IDS_COM_SERVER);
		ComData.uSignIcon = SERVER_ICON;
		ComData.szMessage = CString((LPCTSTR)IDS_COM_SIGN_IN);
		ComData.uMessage  = CComData::COM_SIGN_IN;
		pClientSocket->SendCom(&ComData);
	}
	catch(CFileException* e){
		TCHAR csError[CHAR_BUFFER_SIZE];
		e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
		AfxMessageBox(csError);
	}

	CString szIPAddress;
	UINT	uPort;
	pClientSocket->GetPeerName(szIPAddress, uPort);	
	sClientComInfos* pClientCom = new sClientComInfos;
	ASSERT(pClientCom);
	pClientCom->ComData.szIPAddress = szIPAddress;
	pClientCom->ComData.uPort = uPort;
	pClientCom->ComData.pSocket = (DWORD)pClientSocket;
	pClientCom->TimeStarted = CTime::GetCurrentTime();

	if(m_ClientstList.IsEmpty()){
		m_ClientstList.AddHead(pClientCom);
	}
	else{
		m_ClientstList.AddTail(pClientCom);
	}
}


void CServerSocket::ProcessClientCom(CClientSocket* pClientSocket)
{
	ASSERT(pClientSocket);

	try {

		CComData ComData;
		pClientSocket->ReceiveCom(&ComData);

		if(ComData.uMessage == CComData::COM_SIGN_IN) {

			if(IsThisLoginBeingUsed(ComData, pClientSocket)) {
				try {
					//send the connection confirmation to the client,add to the list - yh
					CComData ComDataTmp;
					ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
					ComDataTmp.uSignIcon = SERVER_ICON;
					ComDataTmp.szMessage = CString((LPCTSTR)IDS_COM_SIGN_OUT);
					ComDataTmp.uMessage  = CComData::COM_SIGN_OUT;
					pClientSocket->SendCom(&ComDataTmp);
				}
				catch(CFileException* e) {
					TCHAR csError[CHAR_BUFFER_SIZE];
					e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
					AfxMessageBox(csError);
				}
				
				RemoveClient(&ComData, pClientSocket);
				return;
			}

			UpdateClientInfo(&ComData, pClientSocket);
			UpdateClientsList();
			AddToRemoteClientsList();

			m_pMainFrame->AddServerCom(CTime::GetCurrentTime(),
										ComData.szFrom,
										ComData.uSignIcon,
										CString((LPCTSTR)IDS_CLIENT_SIGN_IN));	
		}
		else if(ComData.uMessage == CComData::COM_SIGN_OUT) {

			RemoveClient(&ComData, pClientSocket);
			UpdateClientsList();
			RemoveFromClientsList(ComData.szFrom);
			m_pMainFrame->AddServerCom(CTime::GetCurrentTime(),
										ComData.szFrom,
										ComData.uSignIcon, 
										CString((LPCTSTR)IDS_CLIENT_SIGN_OUT));	
		}
		else if(ComData.uMessage == CComData::COM_PRIVATE_MESSAGE) {

			m_pMainFrame->AddClientsCom(CTime::GetCurrentTime(),
										ComData.szFrom,
										ComData.uSignIcon,
										ComData.szMessage);
			RedirectPrivateMessageTo(&ComData);
		}
		else if(ComData.uMessage == CComData::COM_MESSAGE) {

			CTime Time = CTime::GetCurrentTime();
			m_pMainFrame->AddClientsCom(Time,
										ComData.szFrom,
										ComData.uSignIcon,
										ComData.szMessage);	
			UpdateClientsInfo(Time, &ComData, pClientSocket);
		}
	}
	catch(CFileException* e) {
		TCHAR csError[CHAR_BUFFER_SIZE];
		e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
		AfxMessageBox(csError);
	}
}

BOOL CServerSocket::IsThisLoginBeingUsed(CComData& ComData, CClientSocket* pClientSocket)
{
	ASSERT(pClientSocket);

	if(ComData.szFrom == CString((LPCTSTR)IDS_COM_SERVER))
		return TRUE; // this name is used by server only!
	
	if(m_ClientstList.IsEmpty()) return TRUE;
	

	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {
		
		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if(ComData.szFrom == pComDataTmp->szFrom &&
		   pClientSocket != pClientSocketTmp)
		    return TRUE;
	}

	return FALSE;
}

void CServerSocket::UpdateClientInfo(CComData* pComData, CClientSocket* pClientSocket)
{
	ASSERT(pComData);
	ASSERT(pClientSocket);
	
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if(pClientSocket == pClientSocketTmp) {

			pComDataTmp->szFrom    = pComData->szFrom;
			pComDataTmp->uSignIcon = pComData->uSignIcon;

			try {
				//send the connection confirmation to the client,add to the list - yh
				CComData ComDataTmp;
				CString szBuf;
				szBuf.Format(IDS_COM_SIGN_IN_ACCEPTED, pComDataTmp->szFrom);
				ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp.uSignIcon = SERVER_ICON;
				ComDataTmp.szMessage = szBuf;
				ComDataTmp.uMessage  = CComData::COM_MESSAGE;
				pClientSocket->SendCom(&ComDataTmp);
				Sleep(10);

				CComData ComDataTmp2;
				szBuf.Format(IDS_COM_NEW_CLIENT, pComDataTmp->szFrom);
				ComDataTmp2.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp2.uSignIcon = pComDataTmp->uSignIcon;
				ComDataTmp2.szMessage = szBuf;
				ComDataTmp2.uMessage  = CComData::COM_MESSAGE;
				UpdateClientsInfo(CTime::GetCurrentTime(), &ComDataTmp2, pClientSocket);

			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}
			return;
		}
	}
}

void CServerSocket::UpdateClientsList()
{
	m_pMainFrame->UpdateClientsList(&m_ClientstList);
}

void CServerSocket::UpdateClientsInfo(CTime Time, CComData* pComData, CClientSocket* pClientSocket)
{
	ASSERT(pComData);	
	
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if (pClientSocket == pClientSocketTmp) {

			CString szBuf;
			szBuf.Format("%s;%s", Time.Format(IDS_TIME_FORMAT), pComData->szMessage); 
			if (pClientCom->szMessagesList.IsEmpty())
				pClientCom->szMessagesList.AddHead(szBuf);
			else
				pClientCom->szMessagesList.AddTail(szBuf);
		}
		else {
			try {
				pClientSocketTmp->SendCom(pComData);
			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}		
		}
	}
}

void CServerSocket::RemoveClient(CComData* pComData, CClientSocket* pClientSocket)
{
	ASSERT(pComData);
	
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);
		
		if(pClientSocket == pClientSocketTmp) {

			m_ClientstList.RemoveAt(m_ClientstList.FindIndex(i));

			pClientSocketTmp->Close();
			delete pClientSocketTmp;
			pClientSocketTmp = NULL;

			if (!pComDataTmp->szFrom.IsEmpty()) {
				CComData ComDataTmp;
				CString szBuf;
				szBuf.Format(IDS_COM_CLIENT_QUIT, pComDataTmp->szFrom);
				ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp.uSignIcon = SERVER_ICON;
				ComDataTmp.szMessage = szBuf;
				ComDataTmp.uMessage  = CComData::COM_MESSAGE;
				UpdateClientsInfo(CTime::GetCurrentTime(), &ComDataTmp, pClientSocket);
			}

			pClientCom->szMessagesList.RemoveAll();  
			delete pClientCom;
			pClientCom = NULL;
			return;
		}
	}
}

void CServerSocket::CloseClients()
{
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		try {
			//send the connection confirmation to the client,add to the list - yh
			CComData ComDataTmp;
			ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
			ComDataTmp.uSignIcon = SERVER_ICON;
			ComDataTmp.szMessage = CString((LPCTSTR)IDS_COM_CLOSE);
			ComDataTmp.uMessage  = CComData::COM_CLOSE;
			pClientSocketTmp->SendCom(&ComDataTmp);
		}
		catch(CFileException* e) {
			TCHAR csError[CHAR_BUFFER_SIZE];
			e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
			AfxMessageBox(csError);
		}

		pClientSocketTmp->Close();
		delete pClientSocketTmp;
		pClientSocketTmp = NULL;

		CString szBuf;
		szBuf.Format("%s: %s", pComDataTmp->szFrom, CString((LPCTSTR)IDS_COM_CLOSE)); 
		m_pMainFrame->AddServerCom(CTime::GetCurrentTime(),
									CString((LPCTSTR)IDS_COM_SERVER),
									SERVER_ICON,
									szBuf);	
		pClientCom->szMessagesList.RemoveAll();  
		delete pClientCom;
		pClientCom = NULL;
	}

	m_ClientstList.RemoveAll();
}


int CServerSocket::GetClientsConnectedCount()
{
	return m_ClientstList.GetCount(); 
}

int CServerSocket::GetTotalMessagesCount()
{
	int nMessageCount = 0;
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);

		nMessageCount += pClientCom->szMessagesList.GetCount();  
	}

	return nMessageCount;
}

CPtrList* CServerSocket::GetClientsList()
{
	if (m_ClientstList.IsEmpty())
		return NULL;
	
	return &m_ClientstList;
}

void CServerSocket::AddToRemoteClientsList()
{
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		for (int j = 0; j < nCount; j++) {
		
			sClientComInfos* pClientCom2 = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(j));
			ASSERT(pClientCom2);
			CComData* pComDataTmp2 = (CComData*)&pClientCom2->ComData;
			ASSERT(pComDataTmp2);
			CClientSocket* pClientSocketTmp2 = (CClientSocket*)pComDataTmp2->pSocket;
			ASSERT(pClientSocketTmp2);
		
			if (pClientSocketTmp != pClientSocketTmp2) {
				try {
					CComData ComDataTmp;
					ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
					ComDataTmp.uSignIcon = pComDataTmp2->uSignIcon;
					ComDataTmp.szMessage = pComDataTmp2->szFrom;
					ComDataTmp.uMessage  = CComData::COM_ADD_CLIENT;
					pClientSocketTmp->SendCom(&ComDataTmp);
				}
				catch(CFileException* e) {
					TCHAR csError[CHAR_BUFFER_SIZE];
					e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
					AfxMessageBox(csError);
				}			
			}
		}
	}	
}

void CServerSocket::RemoveFromClientsList(CString szClient)
{
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if (pComDataTmp->szFrom != szClient) {
			try {
				CComData ComDataTmp;
				ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp.uSignIcon = SERVER_ICON;
				ComDataTmp.szMessage = szClient;
				ComDataTmp.uMessage  = CComData::COM_REMOVE_CLIENT;
				pClientSocketTmp->SendCom(&ComDataTmp);	
			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}			
		}
	}	
}

void CServerSocket::KickUser(CString szClient)
{
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if (pComDataTmp->szFrom == szClient) {

			m_ClientstList.RemoveAt(m_ClientstList.FindIndex(i));

			try {
				//send the connection confirmation to the client,add to the list - yh
				CComData ComDataTmp;
				ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp.uSignIcon = SERVER_ICON;
				ComDataTmp.szMessage = CString((LPCTSTR)IDS_COM_CLOSE);
				ComDataTmp.uMessage  = CComData::COM_CLOSE;
				pClientSocketTmp->SendCom(&ComDataTmp);
			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}

			pClientSocketTmp->Close();
			delete pClientSocketTmp;
			pClientSocketTmp = NULL;

			CString szBuf;
			szBuf.Format("%s: %s", pComDataTmp->szFrom, CString((LPCTSTR)IDS_COM_CLOSE)); 
			m_pMainFrame->AddServerCom(CTime::GetCurrentTime(),
										CString((LPCTSTR)IDS_COM_SERVER),
										SERVER_ICON,
										szBuf);	
			pClientCom->szMessagesList.RemoveAll();  
			delete pClientCom;
			pClientCom = NULL;

			UpdateClientsList();
			RemoveFromClientsList(szClient);
			Sleep(10);

			CComData ComDataTmp;
			szBuf.Format(IDS_COM_CLIENT_KICKED, szClient);
			ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
			ComDataTmp.uSignIcon = SERVER_ICON;
			ComDataTmp.szMessage = szBuf;
			ComDataTmp.uMessage  = CComData::COM_MESSAGE;
			UpdateClientsInfo(CTime::GetCurrentTime(), &ComDataTmp, NULL);

			return;
		}
	}
}

void CServerSocket::SendMessageTo(CString szClient, CString szMessage)
{
	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if (pComDataTmp->szFrom == szClient) {

			try {
				//send the connection confirmation to the client,add to the list - yh
				CComData ComDataTmp;
				ComDataTmp.szFrom	 = CString((LPCTSTR)IDS_COM_SERVER);
				ComDataTmp.uSignIcon = SERVER_ICON;
				ComDataTmp.szMessage = szMessage;
				ComDataTmp.uMessage  = CComData::COM_PRIVATE_MESSAGE;
				pClientSocketTmp->SendCom(&ComDataTmp);
			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}

			return;
		}
	}
}

void CServerSocket::RedirectPrivateMessageTo(CComData* pComData)
{
	CString szClient;
	szClient = pComData->szMessage.Mid(0, pComData->szMessage.Find(':'));  

	int nCount = m_ClientstList.GetCount();
	for (int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)m_ClientstList.GetAt(m_ClientstList.FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
		ASSERT(pComDataTmp);
		CClientSocket* pClientSocketTmp = (CClientSocket*)pComDataTmp->pSocket;
		ASSERT(pClientSocketTmp);

		if (pComDataTmp->szFrom == szClient) {

			try {
				//send the connection confirmation to the client,add to the list - yh
				CComData ComDataTmp;
				ComDataTmp.szFrom	 = pComData->szFrom;
				ComDataTmp.uSignIcon = pComData->uSignIcon;
				ComDataTmp.szMessage = pComData->szMessage.Mid(pComData->szMessage.Find(':') + 2);
				ComDataTmp.uMessage  = CComData::COM_PRIVATE_MESSAGE;
				pClientSocketTmp->SendCom(&ComDataTmp);
			}
			catch(CFileException* e) {
				TCHAR csError[CHAR_BUFFER_SIZE];
				e->GetErrorMessage(csError, CHAR_BUFFER_SIZE);
				AfxMessageBox(csError);
			}

			return;
		}
	}
}

