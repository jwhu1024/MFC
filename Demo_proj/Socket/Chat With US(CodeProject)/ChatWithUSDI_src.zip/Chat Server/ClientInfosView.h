#if !defined(AFX_CLIENTINFOSVIEW_H__D7ACCFEF_5926_4687_B096_62EEC351407E__INCLUDED_)
#define AFX_CLIENTINFOSVIEW_H__D7ACCFEF_5926_4687_B096_62EEC351407E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientInfosView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CClientInfosView view

class CClientInfosView : public CListView
{
protected:
	CClientInfosView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CClientInfosView)

// Attributes
public:

private:
	CTimeSpan m_ElapseTime;
	CImageList m_ImgList;

// Operations
public:
	void UpdateCols();
	void AddClientInfo(CString szIPAddresse, CString szPort, CString szMessCount, CTime TimeStarted);
	void ClearView();
	CString GetFormatedClientInfos();

private:
	void OnPaint();      // overridden to draw this view

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientInfosView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CClientInfosView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CClientInfosView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTINFOSVIEW_H__D7ACCFEF_5926_4687_B096_62EEC351407E__INCLUDED_)
