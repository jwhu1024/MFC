// Chat Server.h : main header file for the CHAT SERVER application
//

#if !defined(AFX_CHATSERVER_H__0FF2A886_D28B_40BE_89FC_5F54ED19040C__INCLUDED_)
#define AFX_CHATSERVER_H__0FF2A886_D28B_40BE_89FC_5F54ED19040C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#define MIN_FRAME_WITH 600
#define MIN_FRAME_HEIGTH 400
#define DEFAULT_LANGUAGE_ENGLISH 1
#define TIMER_TIME_VALUE 1000

#define DEFAULT_MIN_PORT_NUMBER 1500
#define DEFAULT_MAX_PORT_NUMBER 65000
#define DEFAULT_UNLIMITED_CLIENTS_NUMBER 0
#define DEFAULT_MIN_CLIENTS_NUMBER 1
#define DEFAULT_MAX_CLIENTS_NUMBER 100000

#define SERVER_ICON -1
//#define TEST_MODE

/////////////////////////////////////////////////////////////////////////////
// CChatServerApp:
// See Chat Server.cpp for the implementation of this class
//

class CChatServerApp : public CWinApp
{
public:
	CChatServerApp();
	HINSTANCE GetEnglishRessource() { return m_hEnglishRessource; }

private:
	HINSTANCE m_hEnglishRessource;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChatServerApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CChatServerApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATSERVER_H__0FF2A886_D28B_40BE_89FC_5F54ED19040C__INCLUDED_)
