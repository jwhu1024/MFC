// ClientMessagesView.cpp : implementation file
//

#include "stdafx.h"
#include "chat server.h"
#include "ClientMessagesView.h"
#include "ClientsListView.h"
#include "..\\Commun\\LCLayout.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

enum eClientMessagesView {
    CLIENTMESSAGESVIEW_COL_TIME = 0,
    CLIENTMESSAGESVIEW_COL_MESSAGE,
};

/////////////////////////////////////////////////////////////////////////////
// CClientMessagesView

IMPLEMENT_DYNCREATE(CClientMessagesView, CListView)

CClientMessagesView::CClientMessagesView()
{
	m_ListView = NULL;
}

CClientMessagesView::~CClientMessagesView()
{
}


BEGIN_MESSAGE_MAP(CClientMessagesView, CListView)
	//{{AFX_MSG_MAP(CClientMessagesView)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_SAVE_AS, OnViewSaveAs)
	ON_WM_DESTROY()
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientMessagesView drawing

void CClientMessagesView::OnPaint()
{
	CListCtrl& lc = GetListCtrl();

	Default();

	if (!lc.GetItemCount()) {

        CDC* pDC = GetDC();
        int nSavedDC = pDC->SaveDC();

        CRect rc;
        GetClientRect(&rc);

        CHeaderCtrl* pHC;
        pHC = lc.GetHeaderCtrl();
        if (pHC != NULL)
        {
            CRect rcH;
            pHC->GetItemRect(0, &rcH);
            rc.top += rcH.bottom;
        }

        pDC->FillRect(rc, &CBrush(::GetSysColor(COLOR_WINDOW)));
		pDC->SetBkMode(TRANSPARENT); 
        pDC->SelectStockObject(ANSI_VAR_FONT);
        pDC->DrawText(CString((LPCSTR)IDS_EMPTY_LIST), rc, 
                      DT_CENTER|DT_WORDBREAK|DT_NOPREFIX|
					  DT_NOCLIP|DT_VCENTER|DT_SINGLELINE);

        pDC->RestoreDC(nSavedDC);
        ReleaseDC(pDC);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CClientsComView printing

BOOL CClientMessagesView::OnPreparePrinting(CPrintInfo* pInfo)
{
    return m_printer.OnPreparePrinting(pInfo, this, &GetListCtrl());
}

void CClientMessagesView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    CTime   oTime   = CTime::GetCurrentTime();
    CString timeStr = oTime.Format(IDS_TIME_FORMAT);
    CString szAppName((LPCTSTR)IDR_MAINFRAME);
	CString szBuf;
	szBuf.Format("%s - Client:%s: %s", szAppName, m_ListView->GetClientName(), m_ListView->GetFormatedClientInfos());

    m_printer.OnBeginPrinting(pDC, pInfo, szBuf, timeStr);
}

void CClientMessagesView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    m_printer.OnEndPrinting(pDC, pInfo);
    CListView::OnEndPrinting(pDC, pInfo);
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientMessagesView::OnFilePrint() 
{
	if (ListIsEmpty()) {
		AfxMessageBox(IDS_PRINT_EMPTY_LIST);
		return;
	}

    CListView::OnFilePrint();
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientMessagesView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
    m_printer.OnPrint(pDC, pInfo);
}

void CClientMessagesView::OnUpdateFilePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());	
}

/////////////////////////////////////////////////////////////////////////////
// CClientMessagesView message handlers

BOOL CClientMessagesView::PreCreateWindow(CREATESTRUCT& cs) 
{
    cs.style |= LVS_REPORT;
    cs.style |= LVS_SHOWSELALWAYS;
    cs.style |= LVS_SINGLESEL;
	
	return CListView::PreCreateWindow(cs);
}

int CClientMessagesView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CString szBuf;
	CListCtrl& lc = GetListCtrl();
	lc.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_SUBITEMIMAGES);
	// insert columns
	szBuf.LoadString(IDS_COL_TIME); 
	lc.InsertColumn(CLIENTMESSAGESVIEW_COL_TIME, szBuf, LVCFMT_LEFT, 130);
	szBuf.LoadString(IDS_COL_MESSAGE); 
	lc.InsertColumn(CLIENTMESSAGESVIEW_COL_MESSAGE, szBuf, LVCFMT_LEFT, 280);
	
	//set imagelist for the listctrl
	m_ImgList.Create(16,16,TRUE,1,1);
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_TIME));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_MESSAGE));
	lc.SetImageList(&m_ImgList, LVSIL_SMALL);

	CLCLayout::RestoreLayout(&lc, "ClientMessagesView");

	return 0;
}

void CClientMessagesView::OnDestroy() 
{
    CLCLayout::SaveLayout(&GetListCtrl(), "ClientMessagesView");
	CListView::OnDestroy();
}

void CClientMessagesView::UpdateCols()
{
	CString szBuf;
	LVCOLUMN pCol;
	CListCtrl& lc = GetListCtrl();

	ZeroMemory(&pCol, sizeof(LVCOLUMN));
	pCol.mask = LVCF_TEXT;

	szBuf.LoadString(IDS_COL_TIME); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTMESSAGESVIEW_COL_TIME, &pCol);

	szBuf.LoadString(IDS_COL_MESSAGE); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTMESSAGESVIEW_COL_MESSAGE, &pCol);

	Invalidate();
}

/*============================================================================

Description:    Save the content of the view to a disk file.

Return:             

============================================================================*/
void CClientMessagesView::OnViewSaveAs() 
{
    CStdioFile		file;
    static CString	szFileName;
    CString			szFileExt;
    CString			szFileFilter;
    CString			szMessage;
	CString         szBuf1;
	CString			szBuf2;
	BOOL            bOpen;

	if (m_ListView->GetClientName() == "" || ListIsEmpty()) {
		AfxMessageBox(IDS_SAVE_EMPTY_LIST);
		return;
	}

    szFileExt.LoadString(IDS_TXT_FILE_EXT);
    szFileFilter.LoadString(IDS_TXT_FILE_FLT);

    CFileDialog Dlg(FALSE, szFileExt, szFileName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFileFilter);

    if (Dlg.DoModal() == IDOK) {
        szFileName = Dlg.GetPathName();
                
        try {
			bOpen = file.Open(szFileName, CFile::modeWrite | CFile::modeCreate);
            if (bOpen) {

				CListCtrl& lc = GetListCtrl();
				szBuf1.LoadString(IDR_MAINFRAME);
				szBuf2.LoadString(IDS_FILE_LOG_HEADER);
				szMessage.Format("%s - Client:%s\n%s", szBuf1, m_ListView->GetClientName(), szBuf2);
                file.WriteString(szMessage);
				szMessage.Format("%s\n", m_ListView->GetFormatedClientInfos());
                file.WriteString(szMessage);
                file.WriteString(szBuf2);

				szBuf1.LoadString(IDS_COL_TIME); 
				szBuf2.LoadString(IDS_COL_MESSAGE); 
                szMessage.Format(_T("%s\t\t    %s\n"), szBuf1, szBuf2);
                file.WriteString(szMessage); 
				szBuf1.LoadString(IDS_FILE_LOG_HEADER);
                file.WriteString(szBuf1);
				
                for (int i = 0; i < lc.GetItemCount(); i++) {
                    szMessage.Format(_T("%s  %s\n"),
									lc.GetItemText(i, CLIENTMESSAGESVIEW_COL_TIME),
									lc.GetItemText(i, CLIENTMESSAGESVIEW_COL_MESSAGE));
                    file.WriteString(szMessage);
                }
            }
        }
        catch (CException *e) {
            e->Delete();
        }
        if (bOpen) {
            file.Close();
        }
        else {
            szBuf1.LoadString(IDS_MSG_SAVE_AS_FAILED);
            szMessage.Format(szBuf1, szFileName);
            AfxMessageBox(szMessage, MB_ICONSTOP);
        }
    }
}

void CClientMessagesView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());	
}


void CClientMessagesView::AddClientMessage(CStringList* pMessageList)
{
	CListCtrl& lc = GetListCtrl();
	lc.DeleteAllItems(); 

	int nCount = pMessageList->GetCount();
	if (!nCount)
		return;

	for (int i = 0; i < nCount; i++) {

		CString szMessage = pMessageList->GetAt(pMessageList->FindIndex(i)); 
		
		if (szMessage.GetLength() > 20) {
			CString szBuf1;
			CString szBuf2;

			szBuf1 = szMessage.Mid(1, szMessage.Find(';') -1);
			szBuf2 = szMessage.Mid(szMessage.Find(';') + 1);
			lc.InsertItem(CLIENTMESSAGESVIEW_COL_TIME, szBuf1, 0);

			LV_ITEM lvi2;
			lvi2.mask = LVIF_TEXT | LVIF_IMAGE; 
			lvi2.iItem = CLIENTMESSAGESVIEW_COL_TIME; //item to set 
			lvi2.iSubItem = CLIENTMESSAGESVIEW_COL_MESSAGE; 
			lvi2.pszText = szBuf2.GetBuffer(szBuf2.GetLength());
			szBuf2.ReleaseBuffer(); 
			lvi2.cchTextMax  = szBuf2.GetLength(); 
			lvi2.iImage = 1; //image index 
			lc.SetItem(&lvi2); 
		}
	}
}


void CClientMessagesView::ClearView()
{
	CListCtrl& lc = GetListCtrl();
	lc.DeleteAllItems();
}
