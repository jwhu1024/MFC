// ClientsListView.cpp : implementation file
//

#include "stdafx.h"
#include "chat server.h"
#include "ClientsListView.h"
#include "..\\Commun\\ComData.h"
#include "..\\Commun\\BCMenu.h"
#include "MainFrm.h"
#include "MessageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


enum eClientsListView {
    CLIENTSLISTVIEW_COL_USER = 0,
};

/////////////////////////////////////////////////////////////////////////////
// CClientsListView

IMPLEMENT_DYNCREATE(CClientsListView, CListView)

CClientsListView::CClientsListView()
{
	m_bSorted = TRUE;
}

CClientsListView::~CClientsListView()
{
}

void CClientsListView::Init(CMainFrame* pMainFrame)
{
	ASSERT(pMainFrame);
	m_pMainFrame = pMainFrame;
}

BEGIN_MESSAGE_MAP(CClientsListView, CListView)
	//{{AFX_MSG_MAP(CClientsListView)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
	ON_WM_LBUTTONDOWN()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_POPUP_SENDMESSAGE, OnPopupSendmessage)
	ON_COMMAND(ID_POPUP_KICKTHISUSER, OnPopupKickthisuser)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientsListView drawing

void CClientsListView::OnPaint()
{
	CListCtrl& lc = GetListCtrl();

	Default();

	if (!lc.GetItemCount()) {

        CDC* pDC = GetDC();
        int nSavedDC = pDC->SaveDC();

        CRect rc;
        GetClientRect(&rc);

        CHeaderCtrl* pHC;
        pHC = lc.GetHeaderCtrl();
        if (pHC != NULL)
        {
            CRect rcH;
            pHC->GetItemRect(0, &rcH);
            rc.top += rcH.bottom;
        }

        pDC->FillRect(rc, &CBrush(::GetSysColor(COLOR_WINDOW)));
		pDC->SetBkMode(TRANSPARENT); 
        pDC->SelectStockObject(ANSI_VAR_FONT);
        pDC->DrawText(CString((LPCSTR)IDS_EMPTY_CLIENTS_LIST), rc, 
                      DT_CENTER|DT_WORDBREAK|DT_NOPREFIX|
					  DT_NOCLIP|DT_VCENTER|DT_SINGLELINE);

        pDC->RestoreDC(nSavedDC);
        ReleaseDC(pDC);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CClientsComView printing

BOOL CClientsListView::OnPreparePrinting(CPrintInfo* pInfo)
{
    return m_printer.OnPreparePrinting(pInfo, this, &GetListCtrl());
}

void CClientsListView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    CTime   oTime   = CTime::GetCurrentTime();
    CString timeStr = oTime.Format(IDS_TIME_FORMAT);
    CString szAppName((LPCTSTR)IDR_MAINFRAME);
    CString szTabName((LPCTSTR)IDS_TAB_CLIENTS);
	CString szBuf;
	szBuf.Format("%s - %s", szAppName, szTabName);

    m_printer.OnBeginPrinting(pDC, pInfo, szBuf, timeStr);
}

void CClientsListView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
    m_printer.OnEndPrinting(pDC, pInfo);
    CListView::OnEndPrinting(pDC, pInfo);
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientsListView::OnFilePrint() 
{
	if (ListIsEmpty()) {
		AfxMessageBox(IDS_PRINT_EMPTY_LIST);
		return;
	}

    CListView::OnFilePrint();
}

/*============================================================================

Description:    See MFC.

Return:         -

============================================================================*/
void CClientsListView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
    m_printer.OnPrint(pDC, pInfo);
}

void CClientsListView::OnUpdateFilePrint(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());	
}

/////////////////////////////////////////////////////////////////////////////
// CClientsListView message handlers

BOOL CClientsListView::PreCreateWindow(CREATESTRUCT& cs) 
{
    cs.style |= LVS_REPORT;
    cs.style |= LVS_SHOWSELALWAYS;
    cs.style |= LVS_SINGLESEL;
    cs.style |= LVS_SORTASCENDING;
	
	return CListView::PreCreateWindow(cs);
}


int CClientsListView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CString szBuf;
	CListCtrl& lc = GetListCtrl();
	lc.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	// insert columns
	szBuf.LoadString(IDS_COL_USERS); 
	lc.InsertColumn(CLIENTSLISTVIEW_COL_USER, szBuf, LVCFMT_LEFT, 130);

	//set imagelist for the listctrl
	m_ImgList.Create(16,16,TRUE,1,1);
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN1));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN2));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN3));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN4));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN5));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN6));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN7));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN8));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN9));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_SIGN10));
	lc.SetImageList(&m_ImgList, LVSIL_SMALL);


#ifdef TEST_MODE
	for (int i = 0; i < 100; i++) {
		szBuf.Format("TheBringToTop%d", i); 
		lc.InsertItem(CLIENTSLISTVIEW_COL_USER, szBuf);
	}
#endif
	
	return 0;
}

void CClientsListView::UpdateCols()
{
	CString szBuf;
	LVCOLUMN pCol;
	CListCtrl& lc = GetListCtrl();

	ZeroMemory(&pCol, sizeof(LVCOLUMN));
	pCol.mask = LVCF_TEXT;

	szBuf.LoadString(IDS_COL_USERS); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTSLISTVIEW_COL_USER, &pCol);
	
	Invalidate();
}

CString CClientsListView::GetClientName()
{
	CListCtrl& lc = GetListCtrl();
	POSITION pos = lc.GetFirstSelectedItemPosition();
	return lc.GetItemText(lc.GetNextSelectedItem(pos), 0);  
}

CString CClientsListView::GetFormatedClientInfos()
{
	return m_pMainFrame->GetFormatedClientInfos();
}

void CClientsListView::OnFileSaveAs() 
{
    CStdioFile		file;
    static CString	szFileName;
    CString			szFileExt;
    CString			szFileFilter;
    CString			szMessage;
	CString         szBuf1;
	CString         szBuf2;
	CString         szBuf3;
	BOOL            bOpen;

	if (ListIsEmpty()) {
		AfxMessageBox(IDS_SAVE_EMPTY_LIST);
		return;
	}

    szFileExt.LoadString(IDS_TXT_FILE_EXT);
    szFileFilter.LoadString(IDS_TXT_FILE_FLT);

    CFileDialog Dlg(FALSE, szFileExt, szFileName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFileFilter);

    if (Dlg.DoModal() == IDOK) {
        szFileName = Dlg.GetPathName();
                
        try {
			bOpen = file.Open(szFileName, CFile::modeWrite | CFile::modeCreate);
            if (bOpen) {

				CListCtrl& lc = GetListCtrl();
				szBuf1.LoadString(IDR_MAINFRAME);
				szBuf2.LoadString(IDS_TAB_CLIENTS);
				szBuf3.LoadString(IDS_FILE_LOG_HEADER);
				szMessage.Format("%s - %s\n%s", szBuf1, szBuf2, szBuf3);
                file.WriteString(szMessage);

				szBuf1.LoadString(IDS_COL_USERS); 
                szMessage.Format(_T("%s\n"), szBuf1);
                file.WriteString(szMessage); 
				szBuf1.LoadString(IDS_FILE_LOG_HEADER);
                file.WriteString(szBuf1);
				
                for (int i = 0; i < lc.GetItemCount(); i++) {
                    szMessage.Format(_T("%s\n"),
									lc.GetItemText(i, CLIENTSLISTVIEW_COL_USER));
                    file.WriteString(szMessage);
                }
            }
        }
        catch (CException *e) {
            e->Delete();
        }
        if (bOpen) {
            file.Close();
        }
        else {
            szBuf1.LoadString(IDS_MSG_SAVE_AS_FAILED);
            szMessage.Format(szBuf1, szFileName);
            AfxMessageBox(szMessage, MB_ICONSTOP);
        }
    }
}

void CClientsListView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!ListIsEmpty());	
}

void CClientsListView::UpdateClientsList(CPtrList* pClientstList)
{
	ASSERT(pClientstList);
	
	CListCtrl& lc = GetListCtrl();
	
	int nSelected = lc.GetNextItem(-1, LVNI_ALL|LVNI_SELECTED);	
	lc.DeleteAllItems();

	int nCount = pClientstList->GetCount();
	for(int i = 0; i < nCount; i++) {

		sClientComInfos* pClientCom = (sClientComInfos*)pClientstList->GetAt(pClientstList->FindIndex(i));
		ASSERT(pClientCom);
		CComData* pComData = (CComData*)&pClientCom->ComData;
		ASSERT(pComData);

		LV_ITEM lvItem;
		ZeroMemory(&lvItem, sizeof(LV_ITEM));
		lvItem.mask = LVIF_TEXT|LVIF_IMAGE;
		lvItem.iImage = pComData->uSignIcon;
		lvItem.pszText = pComData->szFrom.GetBuffer(pComData->szFrom.GetLength());
		lvItem.cchTextMax = pComData->szFrom.GetLength();
		pComData->szFrom.ReleaseBuffer(); 
		lc.InsertItem(&lvItem);
	}


	m_pMainFrame->ClearClientView();

	if (nCount > 0 && nSelected > -1) {

		lc.SetItemState(nSelected, LVIS_SELECTED|LVIS_FOCUSED, 
                                   LVIS_SELECTED|LVIS_FOCUSED);
		ShowClientInfos();
	}
}


void CClientsListView::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CListCtrl&  lc  = GetListCtrl();
	m_bSorted = !m_bSorted;
	lc.ModifyStyle(!m_bSorted?LVS_SORTASCENDING:LVS_SORTDESCENDING,
				   !m_bSorted?LVS_SORTDESCENDING:LVS_SORTASCENDING);  
	
	CPtrList* pClientstList = m_pMainFrame->GetClientsList();
	if (pClientstList)
		UpdateClientsList(pClientstList);

	*pResult = 0;
}



void CClientsListView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CListView::OnLButtonDown(nFlags, point);
	
	ShowClientInfos();
}

void CClientsListView::ShowClientInfos()
{
	CListCtrl&  lc  = GetListCtrl();

	if (!lc.GetItemCount())
		return;

	POSITION pos = lc.GetFirstSelectedItemPosition();
	CString szBuf;
	szBuf = lc.GetItemText(lc.GetNextSelectedItem(pos), 0);  
	
	if (szBuf.IsEmpty())
		return;

	CPtrList* pClientstList = m_pMainFrame->GetClientsList();
	if (pClientstList) {

		int nCount = pClientstList->GetCount();
		for (int i = 0; i < nCount; i++) {
			
			sClientComInfos* pClientCom = (sClientComInfos*)pClientstList->GetAt(pClientstList->FindIndex(i));
			ASSERT(pClientCom);
			CComData* pComDataTmp = (CComData*)&pClientCom->ComData;
			ASSERT(pComDataTmp);

			if(szBuf == pComDataTmp->szFrom) {

				int nMess = pClientCom->szMessagesList.GetCount(); 
				CString szBuf2;
				CString szBuf3;
				szBuf2.Format("%d", pComDataTmp->uPort); 
				szBuf3.Format("%d", nMess); 
				m_pMainFrame->AddClientInfos(pComDataTmp->szIPAddress,
											 szBuf2,
											 szBuf3,
											 pClientCom->TimeStarted);

				m_pMainFrame->AddClientMessage(&(pClientCom->szMessagesList));	
				
				return;
			}
		}
	}
}

void CClientsListView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CListCtrl&  lc  = GetListCtrl();

	if (!lc.GetItemCount())
		return;

	POSITION pos = lc.GetFirstSelectedItemPosition();
	if (!pos)
		return;

	CRect rc;
	lc.GetItemRect(lc.GetNextSelectedItem(pos), rc, LVIR_BOUNDS); 

	CPoint pt(point);
	ScreenToClient(&pt);
	if (!rc.PtInRect(pt))
		return;

    BCMenu cMenu;	
    cMenu.LoadMenu(IDR_CLIENTS_CONTEXTUAL_MENU);
    cMenu.LoadToolbar(IDR_CLIENTS_CONTEXTUAL_TOOLSBAR);
    
    CMenu* pMenu = cMenu.GetSubMenu(0);
    pMenu->TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON, point.x, point.y, (CWnd*)AfxGetMainWnd());    	
    cMenu.DestroyMenu();
}

void CClientsListView::OnPopupSendmessage() 
{
	CListCtrl&  lc  = GetListCtrl();
	POSITION pos = lc.GetFirstSelectedItemPosition();
	CString szBuf;
	CString szBuf2;
	szBuf = lc.GetItemText(lc.GetNextSelectedItem(pos), 0);  
	
	if (szBuf.IsEmpty())
		return;

	CMessageDlg Dlg;
	
	if (Dlg.DoModal() == IDOK) {
		m_pMainFrame->SendMessageTo(szBuf, Dlg.GetMessage());	
	}
}

void CClientsListView::OnPopupKickthisuser() 
{
	CListCtrl&  lc  = GetListCtrl();
	POSITION pos = lc.GetFirstSelectedItemPosition();
	CString szBuf;
	CString szBuf2;
	szBuf = lc.GetItemText(lc.GetNextSelectedItem(pos), 0);  
	
	if (szBuf.IsEmpty())
		return;
	
	szBuf2.Format(IDS_KICK_USER, szBuf); 
	int nRet = AfxMessageBox(szBuf2, MB_YESNO);
	if (nRet == IDYES)
		m_pMainFrame->KickUser(szBuf);	
}
