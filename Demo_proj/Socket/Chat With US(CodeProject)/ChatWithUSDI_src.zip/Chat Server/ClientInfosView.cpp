// ClientInfosView.cpp : implementation file
//

#include "stdafx.h"
#include "chat server.h"
#include "ClientInfosView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


enum eClientInfosView {
    CLIENTINFOSVIEW_COL_IP = 0,
    CLIENTINFOSVIEW_COL_PORT,
    CLIENTINFOSVIEW_COL_NBMESSAGES,
    CLIENTINFOSVIEW_COL_SESSION,
};

/////////////////////////////////////////////////////////////////////////////
// CClientInfosView

IMPLEMENT_DYNCREATE(CClientInfosView, CListView)

CClientInfosView::CClientInfosView()
{
}

CClientInfosView::~CClientInfosView()
{
}


BEGIN_MESSAGE_MAP(CClientInfosView, CListView)
	//{{AFX_MSG_MAP(CClientInfosView)
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientInfosView drawing

void CClientInfosView::OnPaint()
{
	CListCtrl& lc = GetListCtrl();

	Default();

	if (!lc.GetItemCount()) {

        CDC* pDC = GetDC();
        int nSavedDC = pDC->SaveDC();

        CRect rc;
        GetClientRect(&rc);

        CHeaderCtrl* pHC;
        pHC = lc.GetHeaderCtrl();
        if (pHC != NULL)
        {
            CRect rcH;
            pHC->GetItemRect(0, &rcH);
            rc.top += rcH.bottom;
        }

        pDC->FillRect(rc, &CBrush(::GetSysColor(COLOR_WINDOW)));
		pDC->SetBkMode(TRANSPARENT); 
        pDC->SelectStockObject(ANSI_VAR_FONT);
        pDC->DrawText(CString((LPCSTR)IDS_EMPTY_LIST), rc, 
                      DT_CENTER|DT_WORDBREAK|DT_NOPREFIX|
					  DT_NOCLIP|DT_VCENTER|DT_SINGLELINE);

        pDC->RestoreDC(nSavedDC);
        ReleaseDC(pDC);
	}
}


/////////////////////////////////////////////////////////////////////////////
// CClientInfosView message handlers

BOOL CClientInfosView::PreCreateWindow(CREATESTRUCT& cs) 
{
    cs.style |= LVS_REPORT;
    cs.style |= LVS_SHOWSELALWAYS;
    cs.style |= LVS_SINGLESEL;
	
	return CListView::PreCreateWindow(cs);
}

int CClientInfosView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CString szBuf;
	CListCtrl& lc = GetListCtrl();
	lc.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_SUBITEMIMAGES);
	// insert columns
	szBuf.LoadString(IDS_COL_IP); 
	lc.InsertColumn(CLIENTINFOSVIEW_COL_IP, szBuf, LVCFMT_LEFT, 110);
	szBuf.LoadString(IDS_COL_PORT); 
	lc.InsertColumn(CLIENTINFOSVIEW_COL_PORT, szBuf, LVCFMT_LEFT, 60);
	szBuf.LoadString(IDS_COL_NBMESSAGES); 
	lc.InsertColumn(CLIENTINFOSVIEW_COL_NBMESSAGES, szBuf, LVCFMT_CENTER, 110);
	szBuf.LoadString(IDS_COL_SESSION); 
	lc.InsertColumn(CLIENTINFOSVIEW_COL_SESSION, szBuf, LVCFMT_CENTER, 130);
	
	//set imagelist for the listctrl
	m_ImgList.Create(16,16,TRUE,1,1);
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_IP));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_PORT));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_NBMESSAGES));
	m_ImgList.Add(AfxGetApp()->LoadIcon(IDI_ELAPSE));
	lc.SetImageList(&m_ImgList, LVSIL_SMALL);

	return 0;
}

void CClientInfosView::OnDestroy() 
{
	CListView::OnDestroy();
	
	KillTimer(ID_TIMER_ELAPSE);
}

void CClientInfosView::UpdateCols()
{
	CString szBuf;
	LVCOLUMN pCol;
	CListCtrl& lc = GetListCtrl();

	ZeroMemory(&pCol, sizeof(LVCOLUMN));
	pCol.mask = LVCF_TEXT;

	szBuf.LoadString(IDS_COL_IP); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTINFOSVIEW_COL_IP, &pCol);

	szBuf.LoadString(IDS_COL_PORT); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTINFOSVIEW_COL_PORT, &pCol);
	
	szBuf.LoadString(IDS_COL_NBMESSAGES); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTINFOSVIEW_COL_NBMESSAGES, &pCol);

	szBuf.LoadString(IDS_COL_SESSION); 
	pCol.cchTextMax = szBuf.GetLength();
	pCol.pszText = szBuf.GetBuffer(pCol.cchTextMax);
	szBuf.ReleaseBuffer();
	lc.SetColumn(CLIENTINFOSVIEW_COL_SESSION, &pCol);

	Invalidate();
}

void CClientInfosView::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);	
}


void CClientInfosView::AddClientInfo(CString szIPAddresse, CString szPort, CString szMessCount, CTime TimeStarted)
{
	CListCtrl& lc = GetListCtrl();
	lc.DeleteAllItems();
	KillTimer(ID_TIMER_ELAPSE);
	
	m_ElapseTime = CTime::GetCurrentTime() - TimeStarted;
	lc.InsertItem(CLIENTINFOSVIEW_COL_IP, szIPAddresse, 0);

	LV_ITEM lvi2;
	lvi2.mask = LVIF_TEXT | LVIF_IMAGE; 
	lvi2.iItem = CLIENTINFOSVIEW_COL_IP; //item to set 
	lvi2.iSubItem = CLIENTINFOSVIEW_COL_PORT; 
	lvi2.pszText = szPort.GetBuffer(szPort.GetLength());
	szPort.ReleaseBuffer(); 
	lvi2.cchTextMax  = szPort.GetLength(); 
	lvi2.iImage = 1; //image index 
	lc.SetItem(&lvi2); 
	
	LV_ITEM lvi3;
	lvi3.mask = LVIF_TEXT | LVIF_IMAGE; 
	lvi3.iItem = CLIENTINFOSVIEW_COL_IP; //item to set 
	lvi3.iSubItem = CLIENTINFOSVIEW_COL_NBMESSAGES; 
	lvi3.pszText = szMessCount.GetBuffer(szMessCount.GetLength());
	szMessCount.ReleaseBuffer(); 
	lvi3.cchTextMax  = szMessCount.GetLength(); 
	lvi3.iImage = 2; //image index 
	lc.SetItem(&lvi3); 
	

	CString szBuf(m_ElapseTime.Format(IDS_ELAPSE_TIME_FORMAT));
	LV_ITEM lvi4;
	lvi4.mask = LVIF_TEXT | LVIF_IMAGE; 
	lvi4.iItem = CLIENTINFOSVIEW_COL_IP; //item to set 
	lvi4.iSubItem = CLIENTINFOSVIEW_COL_SESSION; 
	lvi4.pszText = szBuf.GetBuffer(szBuf.GetLength());
	szBuf.ReleaseBuffer(); 
	lvi4.cchTextMax  = szBuf.GetLength(); 
	lvi4.iImage = 3; //image index 
	lc.SetItem(&lvi4); 
	
	SetTimer(ID_TIMER_ELAPSE, 1000, NULL);
}

void CClientInfosView::ClearView()
{
	CListCtrl& lc = GetListCtrl();
	lc.DeleteAllItems();
}

void CClientInfosView::OnTimer(UINT nIDEvent) 
{
	if (nIDEvent == ID_TIMER_ELAPSE) {
		m_ElapseTime += CTimeSpan(0, 0, 0, 1);  
		CListCtrl& lc = GetListCtrl();
		lc.SetItemText(CLIENTINFOSVIEW_COL_IP, CLIENTINFOSVIEW_COL_SESSION, m_ElapseTime.Format(IDS_ELAPSE_TIME_FORMAT));
	}
	else {
		CListView::OnTimer(nIDEvent);
	}
}

CString CClientInfosView::GetFormatedClientInfos()
{
	CListCtrl& lc = GetListCtrl();
	CString szBuf;
	CString szBuf2;

	szBuf.LoadString(IDS_COL_IP); 
	szBuf2 = szBuf + ":" + lc.GetItemText(0, CLIENTINFOSVIEW_COL_IP) + ", ";  
	szBuf.LoadString(IDS_COL_PORT); 
	szBuf2 += szBuf + ":" + lc.GetItemText(0, CLIENTINFOSVIEW_COL_PORT) + ", ";  
	szBuf.LoadString(IDS_COL_NBMESSAGES); 
	szBuf2 += szBuf + ":" + lc.GetItemText(0, CLIENTINFOSVIEW_COL_NBMESSAGES) + ", ";  
	szBuf.LoadString(IDS_COL_SESSION); 
	szBuf2 += szBuf + ":" + lc.GetItemText(0, CLIENTINFOSVIEW_COL_SESSION);  
	
	return szBuf2;
}

void CClientInfosView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	//CListView::OnLButtonDown(nFlags, point);
}

void CClientInfosView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	
	//CListView::OnRButtonDown(nFlags, point);
}
