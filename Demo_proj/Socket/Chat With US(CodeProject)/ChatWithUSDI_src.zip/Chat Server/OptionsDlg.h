#if !defined(AFX_OPTIONSDLG_H__E1328733_B027_48C8_9FE0_46B6A46E72EC__INCLUDED_)
#define AFX_OPTIONSDLG_H__E1328733_B027_48C8_9FE0_46B6A46E72EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog

class COptionsDlg : public CDialog
{
// Construction
public:
	COptionsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COptionsDlg)
	enum { IDD = IDD_DIALOG_OPTIONS };
	CButton	m_bSplash;
	CButton	m_bMinimizeToTray;
	CButton	m_bShortcutDesktop;
	CButton	m_bShortcutMenu;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void CreateShortcut(BOOL bAdd, long lWhere);

	// Generated message map functions
	//{{AFX_MSG(COptionsDlg)
	afx_msg void OnCheckMinimizeToTray();
	afx_msg void OnCheckShortcutMenu();
	afx_msg void OnCheckShortcutDesktop();
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnCheckSplash();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSDLG_H__E1328733_B027_48C8_9FE0_46B6A46E72EC__INCLUDED_)
