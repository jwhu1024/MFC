// DialogBarUtil.cpp: implementation of the MyDialogBar class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Chat Server.h"
#include "DialogBarUtil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define REBAR_HEIGTH 27
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
 
/////////////////////////////////////////////////////////////////////////////
// CMyDialogBar

CDialogBarUtil::CDialogBarUtil()
{
	m_pApp	= (CChatServerApp*)AfxGetApp();

}

CDialogBarUtil::~CDialogBarUtil()
{
}


BEGIN_MESSAGE_MAP(CDialogBarUtil,  CDialogBarEx)
	//{{AFX_MSG_MAP(CDialogBarUtil)
	ON_WM_MOVE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_CLIENTS, OnCheckClients)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDialogBarUtil message handlers

void CDialogBarUtil::DoDataExchange(CDataExchange* pDX) 
{
	// TODO: Add your specialized code here and/or call the base class
	DDX_Control(pDX, IDC_EDIT_PORT, m_edtPort);
	DDX_Control(pDX, IDC_SPIN_PORT, m_ctrlSpinPort);
	DDX_Control(pDX, IDC_CHECK_CLIENTS, m_bMaxClients);
	DDX_Control(pDX, IDC_EDIT_CLIENTS, m_edtClients);
	DDX_Control(pDX, IDC_SPIN_CLIENTS, m_ctrlSpinClients);
	CDialogBarEx::DoDataExchange(pDX);
}

void CDialogBarUtil::OnInitDialogBar()
{
	m_ctrlSpinPort.SetRange32(DEFAULT_MIN_PORT_NUMBER, DEFAULT_MAX_PORT_NUMBER);
	m_ctrlSpinPort.SetPos(m_pApp->GetProfileInt("Settings", "PortNumber", DEFAULT_MIN_PORT_NUMBER)); 
	
	m_bMaxClients.SetCheck(m_pApp->GetProfileInt("Settings", "UnlimitedClients", DEFAULT_UNLIMITED_CLIENTS_NUMBER));
	m_edtClients.EnableWindow(m_bMaxClients.GetCheck());
	m_ctrlSpinClients.EnableWindow(m_bMaxClients.GetCheck());
	m_ctrlSpinClients.SetRange32(DEFAULT_MIN_CLIENTS_NUMBER, DEFAULT_MAX_CLIENTS_NUMBER);
	m_ctrlSpinClients.SetPos(m_pApp->GetProfileInt("Settings", "MaxClients", DEFAULT_MIN_CLIENTS_NUMBER)); 
}

void CDialogBarUtil::OnMove(int x, int y) 
{
	CDialogBarEx::OnMove(x, y);
	
	CRect rc;
	GetClientRect(rc);
	SetWindowPos(NULL, 0, 0, rc.Width()-3, REBAR_HEIGTH, SWP_NOMOVE);	
}

void CDialogBarUtil::OnDestroy() 
{
	CDialogBarEx::OnDestroy();

	m_pApp->WriteProfileInt("Settings", "PortNumber", m_ctrlSpinPort.GetPos());
	m_pApp->WriteProfileInt("Settings", "UnlimitedClients", m_bMaxClients.GetCheck());
	m_pApp->WriteProfileInt("Settings", "MaxClients", m_ctrlSpinClients.GetPos());
}

void CDialogBarUtil::OnCheckClients() 
{
	m_edtClients.EnableWindow(m_bMaxClients.GetCheck());
	m_ctrlSpinClients.EnableWindow(m_bMaxClients.GetCheck());	
}

int CDialogBarUtil::GetPort()
{
	return m_ctrlSpinPort.GetPos();
}

int CDialogBarUtil::GetMaxClients()
{
	int nRet = m_ctrlSpinClients.GetPos();
	
	if (!m_bMaxClients.GetCheck()) {
		nRet = -1;
	}
	return nRet;
}

void CDialogBarUtil::BlockConrols(BOOL bNotEnable)
{
	m_edtPort.EnableWindow(!bNotEnable);
	m_ctrlSpinPort.EnableWindow(!bNotEnable);

	m_bMaxClients.EnableWindow(!bNotEnable);
	m_edtClients.EnableWindow(!bNotEnable);
	m_ctrlSpinClients.EnableWindow(!bNotEnable);	
}
