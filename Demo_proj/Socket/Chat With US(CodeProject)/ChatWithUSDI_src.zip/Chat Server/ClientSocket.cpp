// ClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "Chat Server.h"
#include "ClientSocket.h"
#include "ServerSocket.h"
#include "..\\Commun\\ComData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientSocket

CClientSocket::CClientSocket(CServerSocket* pServerSocket)
{
	ASSERT(pServerSocket);
	m_pServerSocket = pServerSocket;
	m_pSocketFile = NULL;
	m_pArchiveIn  = NULL;
	m_pArchiveOut = NULL;
}

void CClientSocket::Init()
{
	m_pSocketFile = new CSocketFile(this);
	m_pArchiveIn  = new CArchive(m_pSocketFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pSocketFile,CArchive::store);
}

CClientSocket::~CClientSocket()
{
	Finalize();
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CClientSocket, CSocket)
	//{{AFX_MSG_MAP(CClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CClientSocket member functions


void CClientSocket::OnReceive(int nErrorCode) 
{
	CSocket::OnReceive(nErrorCode);

	ASSERT(m_pServerSocket);
	m_pServerSocket->ProcessClientCom(this);
}


void CClientSocket::SendCom(CComData* pComData)
{
	ASSERT(pComData);
	try {
		if(m_pArchiveOut != NULL) {
			pComData->Serialize(*m_pArchiveOut);
			m_pArchiveOut->Flush();
		}
	}
	catch(CFileException* e) {
		e->Delete(); 
		m_pArchiveOut->Abort();
	}
}

void CClientSocket::ReceiveCom(CComData* pComData)
{
	ASSERT(pComData);
	try {
		do {
			pComData->Serialize(*m_pArchiveIn);
		}
		while(!m_pArchiveIn->IsBufferEmpty());
	}
	catch(CFileException* e) {
		e->Delete(); 
		m_pArchiveIn->Abort();
	}
}

void CClientSocket::Finalize()
{
	if(m_pArchiveIn != NULL){
		delete m_pArchiveIn;
		m_pArchiveIn = NULL;
	}
	if(m_pArchiveOut != NULL){
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}
	if(m_pSocketFile != NULL){
		delete m_pSocketFile;
		m_pSocketFile = NULL;
	}
	
	Close();
	
	m_pServerSocket = NULL;
}