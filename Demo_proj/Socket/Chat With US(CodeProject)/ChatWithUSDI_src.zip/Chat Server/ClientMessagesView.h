#if !defined(AFX_CLIENTMESSAGESVIEW_H__CABDF19B_67EA_4CAF_A2F0_DBBD0D4C64CF__INCLUDED_)
#define AFX_CLIENTMESSAGESVIEW_H__CABDF19B_67EA_4CAF_A2F0_DBBD0D4C64CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ClientMessagesView.h : header file
//


#include "..\\Commun\\LCPrinter.h"

class CClientsListView;
/////////////////////////////////////////////////////////////////////////////
// CClientMessagesView view

class CClientMessagesView : public CListView
{
protected:
	CClientMessagesView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CClientMessagesView)

// Attributes
public:
	CClientsListView* m_ListView;
	
private:
	CLCPrinter m_printer;
	CImageList m_ImgList;

// Operations
public:
	void UpdateCols();
	void AddClientMessage(CStringList* pMessageList);
	void ClearView();

private:
	void OnPaint();      // overridden to draw this view
	BOOL ListIsEmpty() { return (GetListCtrl().GetItemCount() > 0)?FALSE:TRUE; } 


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientMessagesView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CClientMessagesView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CClientMessagesView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void    OnFilePrint();
    afx_msg void    OnViewSaveAs();
	afx_msg void	OnDestroy();
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTMESSAGESVIEW_H__CABDF19B_67EA_4CAF_A2F0_DBBD0D4C64CF__INCLUDED_)
