// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Chat Server.h"
#include "MainFrm.h"
#include "ServerComView.h"
#include "ClientsComView.h"
#include "ClientsListView.h"
#include "ClientInfosView.h"
#include "ClientMessagesView.h"
#include "ServerSocket.h"
#include "..\\Commun\\IPInfos.h"
#include "OptionsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CMainTray)

BEGIN_MESSAGE_MAP(CMainFrame, CMainTray)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_LANGUAGE_ENGLISH, OnLanguageEnglish)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_ENGLISH, OnUpdateLanguageEnglish)
	ON_COMMAND(ID_LANGUAGE_FRENCH, OnLanguageFrench)
	ON_UPDATE_COMMAND_UI(ID_LANGUAGE_FRENCH, OnUpdateLanguageFrench)
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_OPERATIONS_STARTSERVER, OnOperationsStartserver)
	ON_UPDATE_COMMAND_UI(ID_OPERATIONS_STARTSERVER, OnUpdateOperationsStartserver)
	ON_COMMAND(ID_OPERATIONS_STOPSERVER, OnOperationsStopserver)
	ON_UPDATE_COMMAND_UI(ID_OPERATIONS_STOPSERVER, OnUpdateOperationsStopserver)
	ON_WM_CLOSE()
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_CONNECTION_STATUS, OnUpdateConnectionStatus)         
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_CONNECTION_CLIENTS, OnUpdateConnectionClients)         
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_NBMESSAGES, OnUpdateNbMessages)         
	ON_WM_TIMER()
	ON_COMMAND(ID_INFORMATIONS_VIEWSYSTEMIPS, OnInformationsViewsystemips)
	ON_WM_MENUCHAR()
	ON_WM_INITMENUPOPUP()
	ON_COMMAND(ID_VIEW_PARAMETERS, OnViewParameters)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PARAMETERS, OnUpdateViewParameters)
	ON_COMMAND(ID_TRAYMENU_SHOWCHATWITHUSSERVER, OnTraymenuShowchatwithusserver)
	ON_COMMAND(ID_OPTIONS_PREFERENCES, OnOptionsPreferences)
	ON_COMMAND(ID_OPTIONS_ALWAYSVISIBLE, OnOptionsAlwaysvisible)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_ALWAYSVISIBLE, OnUpdateOptionsAlwaysvisible)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CONNECTION_STATUS,
	ID_INDICATOR_CONNECTION_CLIENTS,
	ID_INDICATOR_NBMESSAGES,
	ID_INDICATOR_TIME,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction
/////////////////////////////////////////////////////////////////////////////


CMainFrame::CMainFrame()
{
	m_pApp					= (CChatServerApp*)AfxGetApp();
	
	m_pTabServerClients		= NULL;
	m_pTabServerClientsCom	= NULL;
	m_pClientsComView		= NULL;
	m_pServerComView		= NULL;
	m_pClientsListView		= NULL;
	m_pClientInfosView		= NULL;
	m_pClientMessagesView	= NULL;

	m_bEnglishLanguage		= m_pApp->GetProfileInt("Settings", "Language", DEFAULT_LANGUAGE_ENGLISH);
	m_pServerSocket         = NULL;
	m_bServerStarted        = FALSE;
	m_bWindowOnTop			= m_pApp->GetProfileInt("Settings", "OnTop", FALSE);
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMainTray::PreCreateWindow(cs) )
		return FALSE;

	cs.style = WS_OVERLAPPEDWINDOW;
	
	return TRUE;
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMainTray::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_DlgBarUtil.Create(this, IDD_DIALOGBAR_UTIL, CBRS_GRIPPER|CBRS_TOOLTIPS|
		CBRS_FLYBY|CBRS_SIZE_DYNAMIC|TBSTYLE_FLAT|CBRS_TOP, IDD_DIALOGBAR_UTIL))
	{
		TRACE0("Failed to create dialog bar from CDialogBarUtil class\n");
		return -1;      // fail to create
	}

	/// Creation de l'INFO BAR  //////////////////////////
	if (!m_InfoBar.Create(NULL, NULL, WS_VISIBLE|WS_CHILD|WS_CLIPSIBLINGS|CBRS_TOP,
		                  CRect(0,0,0,0), this, AFX_IDW_DIALOGBAR))
	{
		 TRACE("Failed to create InfoBar\n");
		 return -1;
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
    m_wndStatusBar.SetPaneInfo(m_wndStatusBar.CommandToIndex(ID_INDICATOR_CONNECTION_STATUS),
								ID_INDICATOR_CONNECTION_STATUS,
								SBPS_POPOUT, 40);


	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	EnableDocking(CBRS_ALIGN_ANY);
	
	CString szBuf((LPCTSTR)IDS_TOOLSBAR_UTIL);
	m_DlgBarUtil.SetWindowText(szBuf);
 	m_DlgBarUtil.EnableDocking(CBRS_ALIGN_ANY);
    DockControlBar(&m_DlgBarUtil);
    RecalcLayout();

	szBuf.LoadString(IDS_TOOLSBAR_MAIN);
	m_wndToolBar.SetWindowText(szBuf); 
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	CRect rc;
    m_DlgBarUtil.GetWindowRect(rc);
    DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP, rc);
    RecalcLayout();

	szBuf.LoadString(AFX_IDS_APP_TITLE);
	m_InfoBar.SetText(szBuf);
	m_InfoBar.SetIcon(IDR_MAINFRAME);
	m_InfoBar.SetBarStyle(CBRS_ALIGN_TOP);

	//Change title caption
	SetWindowText(szBuf);

	//Set window placement
	RestoreWindowPlacement();
 
	//Apply App Language
	SetLanguage(m_bEnglishLanguage);

	LoadBarState("ControlsPos");


// System Tray
	TraySetIcon(IDR_MAINFRAME);
	TraySetToolTip(szBuf);
	TraySetMenu(IDR_TRAY_MENU, IDR_BITMAP_MENU);
	TraySetMinimizeToTray(m_pApp->GetProfileInt("Options", "MinimizeToTray", TRUE));

	m_bWindowOnTop = !m_bWindowOnTop;
	OnOptionsAlwaysvisible();

	SetTimer(ID_TIMER_TIME, TIMER_TIME_VALUE, NULL);
	
	return 0;
}


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	CString szBuf;

	TVisualObject* pTab						= new TVisualObject(1, "", pContext, RUNTIME_CLASS(TTabWnd),TVisualObject::TOS_TABTOP);
	szBuf.LoadString(IDS_TAB_SERVER);
	TVisualObject* pTabServer				= new TVisualObject(2, szBuf, pContext, RUNTIME_CLASS(TTabWnd));
	szBuf.LoadString(IDS_TAB_SERVER_CLIENTSCOM);
	TVisualObject* pTabServerClientsCom		= new TVisualObject(3, szBuf, pContext, RUNTIME_CLASS(CClientsComView));
	szBuf.LoadString(IDS_TAB_SERVER_SERVERCOM);
	TVisualObject* pTabServerServerCom		= new TVisualObject(4, szBuf, pContext, RUNTIME_CLASS(CServerComView));
	szBuf.LoadString(IDS_TAB_CLIENTS);
	TVisualObject* pTabClients				= new TVisualObject(5, szBuf, 1, 2, pContext);
	TVisualObject* pClientsList				= new TVisualObject(7, 0, 0, pContext, RUNTIME_CLASS(CClientsListView),CSize(150,0));
	TVisualObject* pTabClientsSH			= new TVisualObject(8, 0, 1, 2, 1, pContext);
	TVisualObject* pClientInfosView			= new TVisualObject(6, 0, 0, pContext, RUNTIME_CLASS(CClientInfosView),CSize(0,35));
	TVisualObject* pClientMessagesView		= new TVisualObject(9, 1, 0, pContext, RUNTIME_CLASS(CClientMessagesView),CSize(0,0));

	pTabServer->SetIcon(IDI_SERVER);
	pTabClients->SetIcon(IDI_CLIENTS);
	pTabServerClientsCom->SetIcon(IDI_CLIENTSCOM);
	pTabServerServerCom->SetIcon(IDI_SERVERCOM);

	m_Framework.Add(pTab);
	m_Framework.Add(pTab, pTabServer);
	m_Framework.Add(pTabServer, pTabServerClientsCom);
	m_Framework.Add(pTabServer, pTabServerServerCom);
	m_Framework.Add(pTab, pTabClients);
	m_Framework.Add(pTabClients, pClientsList);
	m_Framework.Add(pTabClients, pTabClientsSH);
	m_Framework.Add(pTabClientsSH, pClientInfosView);
	m_Framework.Add(pTabClientsSH, pClientMessagesView);
	m_Framework.Create(this);
 
	m_pTabServerClients		= (TTabWnd*)pTab->GetWnd();
	m_pTabServerClientsCom	= (TTabWnd*)pTabServer->GetWnd();
	m_pClientsComView		= (CClientsComView*)pTabServerClientsCom->GetWnd();
	m_pServerComView		= (CServerComView*)pTabServerServerCom->GetWnd();
	m_pClientsListView		= (CClientsListView*)pClientsList->GetWnd();
	m_pClientInfosView		= (CClientInfosView*)pClientInfosView->GetWnd();
	m_pClientMessagesView	= (CClientMessagesView*)pClientMessagesView->GetWnd();

	m_pClientsListView->Init(this);	
	m_pClientMessagesView->m_ListView = m_pClientsListView;
	
	return TRUE;
}


void CMainFrame::OnClose() 
{
	if (!DisconnectServer())
		return;
	
	KillTimer(ID_TIMER_TIME);
	SetLanguage(DEFAULT_LANGUAGE_ENGLISH, FALSE);
	SaveWindowPlacement();
	SaveBarState("ControlsPos");
	m_pApp->WriteProfileInt("Settings", "OnTop", m_bWindowOnTop);
	
	CMainTray::OnClose();
}

void CMainFrame::OnDestroy() 
{
	CMainTray::OnDestroy();
	
	m_Framework.Destroy();
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

void CMainFrame::UpdateMenu()
{
	CMenu* pMenu = GetMenu();
	if (pMenu)
		pMenu->DestroyMenu();

	m_menu.LoadMenu(IDR_MAINFRAME);  
	m_menu.LoadToolbar(IDR_BITMAP_MENU);
	HMENU hMenu = m_menu.Detach();
	::SetMenu(GetSafeHwnd(), hMenu); 
	m_hMenuDefault = hMenu;
}

void CMainFrame::SaveWindowPlacement()
{
    WINDOWPLACEMENT wp;
    GetWindowPlacement(&wp);
    m_pApp->WriteProfileBinary("Settings", "WindowPos", (LPBYTE)&wp, sizeof(wp));
}

void CMainFrame::RestoreWindowPlacement()
{
    WINDOWPLACEMENT *lwp;
    UINT nl;
    
    if(m_pApp->GetProfileBinary("Settings", "WindowPos", (LPBYTE*)&lwp, &nl))
    {
        SetWindowPlacement(lwp);
        delete [] lwp;
    }
	else {
		CenterWindow(GetDesktopWindow());
	}
}

void CMainFrame::OnLanguageEnglish() 
{
	m_bEnglishLanguage = TRUE;	
	SetLanguage();	
}

void CMainFrame::OnUpdateLanguageEnglish(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bEnglishLanguage); 	
}

void CMainFrame::OnLanguageFrench() 
{ 
	m_bEnglishLanguage = FALSE;
	SetLanguage(m_bEnglishLanguage);
}

void CMainFrame::OnUpdateLanguageFrench(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bEnglishLanguage);
	pCmdUI->Enable(FrenchLibraryExist()); 
}

BOOL CMainFrame::FrenchLibraryExist()
{
	HINSTANCE hFrenchRessource = LoadLibrary("CWUSvrFr.dll");
	if (hFrenchRessource) {
		FreeLibrary(hFrenchRessource);
		return TRUE;
	}

	return FALSE;
}

void CMainFrame::SetLanguage(BOOL bEnglish, BOOL bRestore)
{
	static HINSTANCE hLanguageRessource = NULL;

	if (bRestore)
		m_pApp->WriteProfileInt("Settings", "Language", bEnglish);
	
	if (bEnglish) {
		FreeLibrary(hLanguageRessource);
		hLanguageRessource = m_pApp->GetEnglishRessource();
	}
	else {
		hLanguageRessource = LoadLibrary("CWUSvrFr.dll");
	}

	if (hLanguageRessource) {
		AfxSetResourceHandle(hLanguageRessource);

		UpdateMenu();
		SetMessageText(AFX_IDS_IDLEMESSAGE);
		SetWindowText(CString((LPCTSTR)AFX_IDS_APP_TITLE));

		TraySetToolTip(CString((LPCTSTR)AFX_IDS_APP_TITLE));
		TraySetMenu(IDR_TRAY_MENU, IDR_BITMAP_MENU);

		if (bRestore)
			UpdateAllView();
	}
	else {
		AfxMessageBox(IDS_LANGUAGE_DEFAULT);
		m_bEnglishLanguage = DEFAULT_LANGUAGE_ENGLISH;	
		m_pApp->WriteProfileInt("Settings", "Language", DEFAULT_LANGUAGE_ENGLISH);
	}
}

void CMainFrame::UpdateAllView()
{
	CString szBuf;

	szBuf.LoadString(IDS_TAB_SERVER);
	m_pTabServerClients->SetTabLabel(0, szBuf);
	szBuf.LoadString(IDS_TAB_CLIENTS);
	m_pTabServerClients->SetTabLabel(1, szBuf); 
	szBuf.LoadString(IDS_TAB_SERVER_CLIENTSCOM);
	m_pTabServerClientsCom->SetTabLabel(0, szBuf);
	szBuf.LoadString(IDS_TAB_SERVER_SERVERCOM);
	m_pTabServerClientsCom->SetTabLabel(1, szBuf);

	m_pClientsComView->UpdateCols();
	m_pServerComView->UpdateCols();
	m_pClientsListView->UpdateCols();
	m_pClientInfosView->UpdateCols();
	m_pClientMessagesView->UpdateCols();

	szBuf.LoadString(AFX_IDS_APP_TITLE);
	m_InfoBar.SetText(szBuf);
}

void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{ 
	CMainTray::OnGetMinMaxInfo(lpMMI); 

	CPoint minSize(MIN_FRAME_WITH, MIN_FRAME_HEIGTH); 
//	CPoint maxSize(640, 480); 
	lpMMI->ptMinTrackSize.x = minSize.x; 
	lpMMI->ptMinTrackSize.y = minSize.y; 
//	lpMMI->ptMaxTrackSize.x = maxSize.x; 
//	lpMMI->ptMaxTrackSize.y = maxSize.y; 
} 


void CMainFrame::OnOperationsStartserver() 
{
	CString szBuf;

	UINT uPort = m_DlgBarUtil.GetPort();
	if (uPort < DEFAULT_MIN_PORT_NUMBER || uPort > DEFAULT_MAX_PORT_NUMBER) {
		szBuf.Format(IDS_INVALID_PORT_NUMBER, DEFAULT_MIN_PORT_NUMBER,
											  DEFAULT_MAX_PORT_NUMBER); 
		AfxMessageBox(szBuf);
		return;
	}

	ClearAllViews();

	m_pServerSocket = new CServerSocket(this);
	if (m_pServerSocket->BeginListening(uPort, m_DlgBarUtil.GetMaxClients())) {
		szBuf.Format(IDS_COM_SERVER_CONNECTED, uPort);
		AddServerCom(CTime::GetCurrentTime(),
					CString((LPCTSTR)IDS_COM_SERVER),
					SERVER_ICON,
					szBuf);	
		m_DlgBarUtil.BlockConrols();
		m_bServerStarted = TRUE;
	}
	else {
		DisconnectServer();
	}
}

void CMainFrame::OnUpdateOperationsStartserver(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_bServerStarted);	
}

void CMainFrame::OnOperationsStopserver() 
{
	if (DisconnectServer())
		m_DlgBarUtil.BlockConrols(FALSE);
}

void CMainFrame::OnUpdateOperationsStopserver(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bServerStarted);	
}


BOOL CMainFrame::DisconnectServer()
{
	if (!m_pServerSocket)
		return TRUE;
	
	int nClients = m_pServerSocket->GetClientsConnectedCount();
	if (nClients > 0) {
		CString szBuf;
		szBuf.Format(IDS_STOP_SERVER, nClients);
		int nRet = MessageBox(szBuf, CString((LPCTSTR)IDR_MAINFRAME), MB_ICONQUESTION|MB_YESNO);
		if (nRet == IDNO)
			return FALSE;
	}


	AddServerCom(CTime::GetCurrentTime(),
				CString((LPCTSTR)IDS_COM_SERVER),
				SERVER_ICON,
				CString((LPCTSTR)IDS_COM_SERVER_DISCONNECTED));	

	if (m_pServerSocket) {
		delete m_pServerSocket;
		m_pServerSocket = NULL;
	}

	m_bServerStarted = FALSE;

	return TRUE;
}

void CMainFrame::UpdateClientsList(CPtrList* pClientstList)
{
	m_pClientsListView->UpdateClientsList(pClientstList);
}

void CMainFrame::AddServerCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage)
{
	m_pServerComView->AddMessage(Time.Format(IDS_TIME_FORMAT), szFrom, uSignIcon, szMessage);
}

void CMainFrame::AddClientsCom(CTime Time, CString szFrom, UINT uSignIcon, CString szMessage)
{
	m_pClientsComView->AddMessage(Time.Format(IDS_TIME_FORMAT), szFrom, uSignIcon, szMessage);
}


void CMainFrame::AddClientInfos(CString szIPAddresse, CString szPort, CString szMessCount, CTime TimeStarted)
{
	m_pClientInfosView->AddClientInfo(szIPAddresse, szPort, szMessCount, TimeStarted);
}

CString CMainFrame::GetFormatedClientInfos()
{
	return m_pClientInfosView->GetFormatedClientInfos();
}

void CMainFrame::AddClientMessage(CStringList* pMessageList)
{
	m_pClientMessagesView->AddClientMessage(pMessageList);
}


CPtrList* CMainFrame::GetClientsList()
{
	if (!m_pServerSocket)
		return NULL;
	
	return m_pServerSocket->GetClientsList();
}


/*============================================================================

Description:    Update the status bar connection status indicator

Return:         -

============================================================================*/
void CMainFrame::OnUpdateConnectionStatus(CCmdUI* pCmdUI) 
{
	m_wndStatusBar.SetPaneStyle(m_wndStatusBar.CommandToIndex(ID_INDICATOR_CONNECTION_STATUS),
		                        m_bServerStarted ? SBPS_NORMAL : SBPS_POPOUT);

    pCmdUI->SetText(m_bServerStarted ? CString((LPCTSTR)IDS_SERVER_CONNECTED) : CString((LPCTSTR)IDS_SERVER_DISCONNECTED));
}

/*============================================================================

Description:    Update the status bar connection status indicator

Return:         -

============================================================================*/
void CMainFrame::OnUpdateConnectionClients(CCmdUI* pCmdUI) 
{
	CString szBuf;
	int nClients = m_pServerSocket ? m_pServerSocket->GetClientsConnectedCount() : 0;
	szBuf.Format(IDS_INDICATOR_CONNECTION_CLIENTS, nClients); 

    pCmdUI->SetText(szBuf);
}

/*============================================================================

Description:    Update the status bar connection status indicator

Return:         -

============================================================================*/
void CMainFrame::OnUpdateNbMessages(CCmdUI* pCmdUI) 
{
	CString szBuf;
	int nClients = m_pServerSocket ? m_pServerSocket->GetTotalMessagesCount() : 0;
	szBuf.Format(IDS_INDICATOR_NBMESSAGES, nClients); 

    pCmdUI->SetText(szBuf);
}

void CMainFrame::OnTimer(UINT nIDEvent) 
{
    switch (nIDEvent) {

    case ID_TIMER_TIME:
		m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(ID_INDICATOR_TIME),
			                       CTime::GetCurrentTime().Format(IDS_TIME_FORMAT));
		
		TraySetMinimizeToTray(m_pApp->GetProfileInt("Options", "MinimizeToTray", TRUE));
        break;
    
    default:
	    CMainTray::OnTimer(nIDEvent);
        break;
	} 
}

void CMainFrame::ClearClientView()
{
	m_pClientInfosView->ClearView();
	m_pClientMessagesView->ClearView();
}

void CMainFrame::ClearAllViews()
{
	m_pClientsComView->ClearView();
	m_pServerComView->ClearView();
}

void CMainFrame::OnInformationsViewsystemips() 
{
	CIPInfos InfoIP;
	CString szBuf((LPCTSTR)IDS_LOCAL_IP_HEADER);
	CString szBuf2;

	szBuf += "------------------------\n";

	for (int i = 0; i < InfoIP.GetLocalIPCount(); i++) {
		szBuf2.Format("%d- %s\n", i+1, InfoIP.GetLocalIP(i));
		szBuf += szBuf2; 
	}
	MessageBox(szBuf); 
}


void CMainFrame::KickUser(CString szClient)
{
	AddServerCom(CTime::GetCurrentTime(),
				CString((LPCTSTR)IDS_COM_SERVER),
				SERVER_ICON,
				CString((LPCTSTR)IDS_COM_SERVER_DISCONNECTED));	

	m_pServerSocket->KickUser(szClient);
}

void CMainFrame::SendMessageTo(CString szClient, CString szMessage)
{
	AddServerCom(CTime::GetCurrentTime(),
				CString((LPCTSTR)IDS_COM_SERVER),
				SERVER_ICON,
				szClient + ": " + szMessage);	

	m_pServerSocket->SendMessageTo(szClient, szMessage);
}


//This handler ensures that keyboard shortcuts work
LRESULT CMainFrame::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
	LRESULT lresult;

	if (m_menu.IsMenu(pMenu))
		lresult = BCMenu::FindKeyboardShortcut(nChar, nFlags, pMenu);
	else
		lresult = CMainTray::OnMenuChar(nChar, nFlags, pMenu);
	
	return(lresult);
}

//This handler updates the menus from time to time
void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CMainTray::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	if (!bSysMenu) {
		if (m_menu.IsMenu(pPopupMenu))
			BCMenu::UpdateMenu(pPopupMenu);
	}
}

void CMainFrame::OnViewParameters() 
{
    ShowControlBar(&m_DlgBarUtil, !m_DlgBarUtil.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewParameters(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_DlgBarUtil.IsVisible());
}

void CMainFrame::OnTraymenuShowchatwithusserver() 
{
	TrayShowMainWindow();	
}

void CMainFrame::OnOptionsPreferences() 
{
	COptionsDlg Dlg;
	Dlg.DoModal();
}

void CMainFrame::OnOptionsAlwaysvisible() 
{
	if (!m_bWindowOnTop) {
		SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	}
	else {
		SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	}
	m_bWindowOnTop = !m_bWindowOnTop;
}

void CMainFrame::OnUpdateOptionsAlwaysvisible(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_bWindowOnTop);
}
