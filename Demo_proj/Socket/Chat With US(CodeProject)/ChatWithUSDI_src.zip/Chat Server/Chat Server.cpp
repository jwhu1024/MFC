// Chat Server.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "Chat Server.h"

#include "MainFrm.h"
#include "..\\Commun\\sinstance.h"
#include "..\\Commun\\DocumentHelper.h"
#include "..\\Commun\\SplashScreen.h"
#include "ServerComView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChatServerApp

BEGIN_MESSAGE_MAP(CChatServerApp, CWinApp)
	//{{AFX_MSG_MAP(CChatServerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChatServerApp construction

CChatServerApp::CChatServerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CChatServerApp object

CChatServerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CChatServerApp initialization

BOOL CChatServerApp::InitInstance()
{

	CInstanceChecker instanceChecker;
	if (instanceChecker.PreviousInstanceRunning())
	{
		instanceChecker.ActivatePreviousInstance();
		return FALSE;
	}

	if (!AfxSocketInit())
	{
		AfxMessageBox(IDS_SOCKETS_INIT_FAILED);
		return FALSE;
	}

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	SetRegistryKey(_T("DCUtility"));

	m_hEnglishRessource = AfxGetResourceHandle();

	if (!GetProfileInt("Options", "ShowSplash", FALSE))
		CSplashScreen::Show(IDB_SPLASH, IDR_SPLASH, 3000);

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CDocumentHelper),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CServerComView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	// If this is the first instance of our App then track it so any other instances can find us
	instanceChecker.TrackFirstInstanceRunning();

	return TRUE;
}


// App command to run the dialog
void CChatServerApp::OnAppAbout()
{
	CSplashScreen::Show(IDB_SPLASH, IDR_SPLASH, 5000);
}

/////////////////////////////////////////////////////////////////////////////
// CChatServerApp message handlers


BOOL CChatServerApp::PreTranslateMessage(MSG* pMsg) 
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetMainWnd();
	if (pFrame) {
	if (pFrame->m_Framework.ProcessMessage(pMsg))
		return TRUE;
	}
	return CWinApp::PreTranslateMessage(pMsg);
}


