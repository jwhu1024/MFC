// DocumentHelper.cpp : implementation of the CDocumentHelper class
//

#include "stdafx.h"
#include "DocumentHelper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDocumentHelper

IMPLEMENT_DYNCREATE(CDocumentHelper, CDocument)

BEGIN_MESSAGE_MAP(CDocumentHelper, CDocument)
	//{{AFX_MSG_MAP(CDocumentHelper)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDocumentHelper construction/destruction

CDocumentHelper::CDocumentHelper()
{
	// TODO: add one-time construction code here

}

CDocumentHelper::~CDocumentHelper()
{
}


/////////////////////////////////////////////////////////////////////////////
// CDocumentHelper commands
