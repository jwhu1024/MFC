// IPInfos.h: interface for the CIPInfos class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPINFOS_H__A1E74E5B_165E_4837_98BF_8D7DFB6DCAC9__INCLUDED_)
#define AFX_IPINFOS_H__A1E74E5B_165E_4837_98BF_8D7DFB6DCAC9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIPInfos  
{
public:
	CIPInfos();
	virtual ~CIPInfos();

	int  GetLocalIPCount();
	CString GetLocalIP(int nIndex);
};

#endif // !defined(AFX_IPINFOS_H__A1E74E5B_165E_4837_98BF_8D7DFB6DCAC9__INCLUDED_)
