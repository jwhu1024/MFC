// IPInfos.cpp: implementation of the CIPInfos class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IPInfos.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define CHAR_BUFFER_SIZE 255
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIPInfos::CIPInfos()
{

}

CIPInfos::~CIPInfos()
{

}

int CIPInfos::GetLocalIPCount()
{
	char		csHostName[CHAR_BUFFER_SIZE];
	LPHOSTENT	pHost;
	int			i;
	
	gethostname(csHostName, CHAR_BUFFER_SIZE);
	pHost = gethostbyname(csHostName);
 
	for (i = 0; pHost->h_addr_list[i] != NULL; i++) {}

	return i;
}

CString CIPInfos::GetLocalIP(int nIndex)
{
	char		csHostName[CHAR_BUFFER_SIZE];
	LPHOSTENT	pHost;
	
	gethostname(csHostName, CHAR_BUFFER_SIZE);
	pHost = gethostbyname(csHostName);

	return CString(inet_ntoa(*(struct in_addr*)pHost->h_addr_list[nIndex]));
}