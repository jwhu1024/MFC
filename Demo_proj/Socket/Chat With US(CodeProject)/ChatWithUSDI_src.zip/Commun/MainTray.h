// MainTray.h : interface of the CMainTray class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MainTray_H__C5F08365_270A_4EF7_9ABF_D8AAB5D87788__INCLUDED_)
#define AFX_MainTrayM_H__C5F08365_270A_4EF7_9ABF_D8AAB5D87788__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BCMenu.h"

#define WM_TRAY_ICON_NOTIFY_MESSAGE (WM_APP + 1)

class CMainTray : public CFrameWnd
{
	
protected: // create from serialization only
	CMainTray();
	DECLARE_DYNCREATE(CMainTray)

private:
	BOOL			m_bMinimizeToTray;
	BOOL			m_bTrayIconVisible;
	NOTIFYICONDATA	m_nidIconData;
	BCMenu			m_mnuTrayMenu;
	UINT			m_nDefaultMenuItem;
	// Construction
public:
	void TraySetMinimizeToTray(BOOL bMinimizeToTray = TRUE);
	BOOL TraySetMenu(UINT nResourceID, UINT nToolbarID, UINT nDefaultPos=0);	
	BOOL TrayUpdate();
	BOOL TrayShow();
	BOOL TrayHide();
	void TraySetToolTip(LPCTSTR lpszToolTip);
	void TraySetIcon(HICON hIcon);
	void TraySetIcon(UINT nResourceID);
	void TraySetMenuCaption(UINT nID, LPCTSTR sz);
	void TrayShowMainWindow();

	BOOL TrayIsVisible();

	void OnTrayLButtonDown(CPoint pt);
	void OnTrayLButtonDblClk(CPoint pt);
	
	void OnTrayRButtonDown(CPoint pt);
	void OnTrayRButtonDblClk(CPoint pt);

	void OnTrayMouseMove(CPoint pt);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainTray)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainTray();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members

// Generated message map functions
protected:
	//{{AFX_MSG(CMainTray)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg void OnTrayNotify(WPARAM wParam, LPARAM lParam);
	afx_msg void OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MainTray_H__C5F08365_270A_4EF7_9ABF_D8AAB5D87788__INCLUDED_)
