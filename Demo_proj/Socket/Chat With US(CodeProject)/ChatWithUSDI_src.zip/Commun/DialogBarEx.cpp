// DialogBarEx.cpp : implementation file
//

#include "stdafx.h"
#include "DialogBarEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogBarEx


#define WM_INITDIALOGBAR WM_APP + 1

BEGIN_MESSAGE_MAP(CDialogBarEx,  CDialogBar)
	//{{AFX_MSG_MAP(CDialogBarEx)
	ON_WM_CREATE()
	ON_MESSAGE(WM_INITDIALOGBAR , InitDialogBarHandler )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CDialogBarEx::CDialogBarEx()
{
}

CDialogBarEx::~CDialogBarEx()
{
}

/////////////////////////////////////////////////////////////////////////////
// CDialogBarEx message handlers

int CDialogBarEx::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
		if (CDialogBar::OnCreate(lpCreateStruct) == -1)
		return -1;
 	
	PostMessage(WM_INITDIALOGBAR , 0 , 0 );

	return 0;
}


void CDialogBarEx::InitDialogBarHandler(WORD wParam, DWORD lParam)
{
	UpdateData(FALSE);
	OnInitDialogBar() ;
}

void CDialogBarEx::OnInitDialogBar()
{

}
