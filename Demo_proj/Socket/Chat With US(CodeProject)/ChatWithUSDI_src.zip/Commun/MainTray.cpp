// MainTray.cpp : implementation of the CMainTray class
//

#include "stdafx.h"
#include "MainTray.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainTray

IMPLEMENT_DYNCREATE(CMainTray, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainTray, CFrameWnd)
	//{{AFX_MSG_MAP(CMainTray)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	ON_WM_MEASUREITEM()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_TRAY_ICON_NOTIFY_MESSAGE,OnTrayNotify)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMainTray construction/destruction

CMainTray::CMainTray()
{
	m_nidIconData.cbSize			= sizeof(NOTIFYICONDATA);
	m_nidIconData.hWnd				= 0;
	m_nidIconData.uID				= 1;
	m_nidIconData.uCallbackMessage	= WM_TRAY_ICON_NOTIFY_MESSAGE;
	m_nidIconData.hIcon				= 0;
	m_nidIconData.szTip[0]			= 0;	
	m_nidIconData.uFlags			= NIF_MESSAGE;

	m_bTrayIconVisible				= FALSE;
	m_nDefaultMenuItem				= 0;
	m_bMinimizeToTray				= TRUE;	
}

CMainTray::~CMainTray()
{
}

int CMainTray::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_nidIconData.hWnd = this->m_hWnd;
	m_nidIconData.uID = 1;
	BCMenu::SetMenuDrawMode(BCMENU_DRAWMODE_XP);
	
	return 0;
}

BOOL CMainTray::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainTray diagnostics

#ifdef _DEBUG
void CMainTray::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainTray::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainTray message handlers
void CMainTray::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	
	if(m_nidIconData.hWnd && m_nidIconData.uID>0 && TrayIsVisible())
	{
		Shell_NotifyIcon(NIM_DELETE,&m_nidIconData);
	}	
}

BOOL CMainTray::TrayIsVisible()
{
	return m_bTrayIconVisible;
}

void CMainTray::TraySetIcon(HICON hIcon)
{
	if (!hIcon)
		return;

	HICON hOldIcon = m_nidIconData.hIcon;

	m_nidIconData.hIcon = hIcon;
	m_nidIconData.uFlags |= NIF_ICON;
	TrayUpdate();
	DestroyIcon( hOldIcon );
}

void CMainTray::TraySetIcon(UINT nResourceID)
{
	ASSERT(nResourceID>0);
	TraySetIcon(AfxGetApp()->LoadIcon(nResourceID));
}

void CMainTray::TraySetToolTip(LPCTSTR lpszToolTip)
{
	ASSERT(strlen(lpszToolTip) > 0 && strlen(lpszToolTip) < 64);

	strcpy(m_nidIconData.szTip,lpszToolTip);
	m_nidIconData.uFlags |= NIF_TIP;
	TrayUpdate();
}

BOOL CMainTray::TrayShow()
{
	BOOL bSuccess = FALSE;
	if(!m_bTrayIconVisible)
	{
		bSuccess = Shell_NotifyIcon(NIM_ADD,&m_nidIconData);
		if(bSuccess)
			m_bTrayIconVisible = TRUE;
	}
	else
	{
		TRACE0("ICON ALREADY VISIBLE\n");
	}
	return bSuccess;
}

BOOL CMainTray::TrayHide()
{
	BOOL bSuccess = FALSE;
	if(m_bTrayIconVisible)
	{
		bSuccess = Shell_NotifyIcon(NIM_DELETE,&m_nidIconData);
		if(bSuccess)
			m_bTrayIconVisible= FALSE;
	}
	else
	{
		TRACE0("ICON ALREADY HIDDEN\n");
	}
	return bSuccess;
}

BOOL CMainTray::TrayUpdate()
{
	BOOL bSuccess = FALSE;
	if(m_bTrayIconVisible)
	{
		bSuccess = Shell_NotifyIcon(NIM_MODIFY,&m_nidIconData);
	}
	else
	{
		TRACE0("ICON NOT VISIBLE\n");
	}
	return bSuccess;
}


BOOL CMainTray::TraySetMenu(UINT nResourceID, UINT nToolbarID,UINT nDefaultPos)
{
	BOOL bSuccess;
	
	bSuccess =  m_mnuTrayMenu.DestroyMenu(); 
	bSuccess |= m_mnuTrayMenu.LoadMenu(nResourceID);
	bSuccess |= m_mnuTrayMenu.LoadToolbar(nToolbarID);
	return bSuccess;
}



void CMainTray::OnTrayNotify(WPARAM wParam, LPARAM lParam) 
{ 
    UINT uID; 
    UINT uMsg; 
 
    uID = (UINT) wParam; 
    uMsg = (UINT) lParam; 
 
	if (uID != 1)
		return;
	
	CPoint pt;	

    switch (uMsg ) 
	{ 
	case WM_MOUSEMOVE:
		GetCursorPos(&pt);
		ClientToScreen(&pt);
		OnTrayMouseMove(pt);
		break;
	case WM_LBUTTONDOWN:
		GetCursorPos(&pt);
		ClientToScreen(&pt);
		OnTrayLButtonDown(pt);
		break;
	case WM_LBUTTONDBLCLK:
		GetCursorPos(&pt);
		ClientToScreen(&pt);
		OnTrayLButtonDblClk(pt);
		break;
	
	case WM_RBUTTONDOWN:
	case WM_CONTEXTMENU:
		GetCursorPos(&pt);
		//ClientToScreen(&pt);
		OnTrayRButtonDown(pt);
		break;
	case WM_RBUTTONDBLCLK:
		GetCursorPos(&pt);
		ClientToScreen(&pt);
		OnTrayRButtonDblClk(pt);
		break;
    } 
     return; 
} 

void CMainTray::OnSysCommand(UINT nID, LPARAM lParam)
{
	if(m_bMinimizeToTray)
	{
		if ((nID & 0xFFF0) == SC_MINIMIZE)
		{
		
			TrayShow();
			this->ShowWindow(SW_HIDE);
		}
		else
			CFrameWnd::OnSysCommand(nID, lParam);	
	}
	else
		CFrameWnd::OnSysCommand(nID, lParam);
}
void CMainTray::TraySetMinimizeToTray(BOOL bMinimizeToTray)
{
	m_bMinimizeToTray = bMinimizeToTray;
}

void CMainTray::TraySetMenuCaption(UINT nID, LPCTSTR lpsz)
{
	m_mnuTrayMenu.SetMenuText(nID, lpsz, MF_BYCOMMAND);
}

void CMainTray::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
  BOOL setflag=FALSE;
  if(lpMeasureItemStruct->CtlType==ODT_MENU)
  {
    if(IsMenu((HMENU)lpMeasureItemStruct->itemID))
	{
      CMenu* cmenu=CMenu::FromHandle((HMENU)lpMeasureItemStruct->itemID);
      if(BCMenu::IsMenu(cmenu)){
        cmenu->MeasureItem(lpMeasureItemStruct);
        setflag=TRUE;
      }
    }
  }    
    if(!setflag)CFrameWnd::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
    
}


void CMainTray::OnTrayRButtonDown(CPoint pt)
{

	m_mnuTrayMenu.GetSubMenu(0)->TrackPopupMenu(TPM_BOTTOMALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,pt.x,pt.y,this);
	m_mnuTrayMenu.GetSubMenu(0)->SetDefaultItem(m_nDefaultMenuItem,TRUE);
}

void CMainTray::OnTrayLButtonDown(CPoint pt)
{

}

void CMainTray::OnTrayLButtonDblClk(CPoint pt)
{
	TrayShowMainWindow();
}

void CMainTray::OnTrayRButtonDblClk(CPoint pt)
{
}

void CMainTray::OnTrayMouseMove(CPoint pt)
{
}

void CMainTray::TrayShowMainWindow()
{
	if(m_bMinimizeToTray) {
		this->ShowWindow(SW_SHOW);
		TrayHide();
	}
}
