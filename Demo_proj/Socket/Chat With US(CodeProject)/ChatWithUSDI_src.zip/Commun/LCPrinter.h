/*===========================================================================
====                                                                     ====
====                                                                     ====
=============================================================================
====                                                                     ====
====    File                :  LCPrinter.h                               ====
====    Project name        :                                            ====
====    Project number      :                                            ====
====    Creation date       :  14/10/2000                                ====
====                                                                     ====
====                                                                     ====
=============================================================================
===========================================================================*/

#ifndef LCPRINTER_H
#define LCPRINTER_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


//============================================================================
// Inclusions
//============================================================================


//============================================================================
// Constants
//============================================================================


//============================================================================
//============================================================================
//                  classe CLCPrinter
/*============================================================================

=============================================================================*/
class CLCPrinter
{

//============================================================================
// Data types
//============================================================================
 public:

//============================================================================
// Creators
//============================================================================
 public:
    CLCPrinter();
    
 private:   // Not implemented functions
    CLCPrinter &operator = (const CLCPrinter&);
    CLCPrinter(const CLCPrinter&);

//============================================================================
// Member functions
//============================================================================

// Implementation
 public:
    void            OnBeginPrinting(CDC*           pDC, 
                                    CPrintInfo*    pInfo, 
                                    const CString& titleStr, 
                                    const CString& dateStr);

    void            OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
    BOOL            OnPreparePrinting(CPrintInfo* pInfo, 
                                      CView*      pView, 
                                      CListCtrl*  pLC);
    void            OnPrint(CDC* pDC, CPrintInfo* pInfo);

// Protected functions
 protected:
    void            ComputeMetrics(CDC *pDC);
    void            DrawLineAt(CDC *pDC, unsigned int y);
    void            DrawRow(CDC *pDC, int nItem);
    void            PrintFooter(CDC *pDC, CPrintInfo *pInfo);
    void            PrintHeader(CDC *pDC, CPrintInfo *pInfo);
    void            PrintHeaderControl(CDC *pDC, CPrintInfo *pInfo);

//============================================================================
// Member variables
//============================================================================
protected:
    // List Control Pointer
    CListCtrl*      m_pLC;
    
    CString         m_titleStr;
    CString         m_dateStr;

    // Font stuff
    CFont*          m_pOldFont;
    CFont           m_boldFont;
    CFont           m_lcFont;

    // Scaling Variables
    CRect           m_page_rc;
    int             m_nRowHeight;
    int             m_nRowsPerPage;
    int             m_nMaxRowCount;
    int             m_hcItems;

    // Scaling output to the printer
    unsigned int    m_ratiox;
    unsigned int    m_ratioy;
};

#endif // LCPRINTER_H

