/*===========================================================================
====                                                                     ====
====                                                                     ====
=============================================================================
====                                                                     ====
====    File                :  LCLayout.cpp                             ====
====    Project name        :                                            ====
====    Project number      :                                            ====
====    Creation date       :  10/08/2000                                ====
====                                                                     ====
====                                                                     ====
=============================================================================
===========================================================================*/



//============================================================================
// Inclusions
//============================================================================
#include "stdafx.h"
#include "LCLayout.h"

//============================================================================
// Constants
//============================================================================


//============================================================================
// Data types
//============================================================================


//============================================================================
// Variables
//============================================================================


//============================================================================
// Development tools
//============================================================================


//============================================================================
// Templates and global functions
//============================================================================


//============================================================================
//============================================================================
//                  class CLCLayout
//============================================================================
//============================================================================


/*============================================================================

Description:    Restore each column size from the registry

pLC:            A pointer to the CListCtrl object

regKey:         A string containing the registry key where
                the layout information will be retreive.
  
Retour:         -

============================================================================*/
void CLCLayout::RestoreLayout(CListCtrl* pLC, const CString& regKey)
{
    CWinApp*    pApp  = AfxGetApp();
    int         nCol  = 0;
    int         colCx = 0;
    CString     key;

    /* Get the column quantity */
    nCol = pApp->GetProfileInt(regKey, "Column Count", 0);

    /* Restore each column width */
    for (int i = 0; i < nCol; i++) {

        key.Format("Column %i", i);
        colCx = pApp->GetProfileInt(regKey, key, -1);
        
        if (colCx != -1) {
            pLC->SetColumnWidth(i, colCx);
        }
    }
}


/*============================================================================

Description:    Save each column size to the registry

pLC:            A pointer to the CListCtrl object

regKey:         A string that will be used to create a registry key where
                the layout information will be store.

Retour:         -

============================================================================*/
void CLCLayout::SaveLayout(CListCtrl* pLC, const CString& regKey)
{
    CString         key;
    CWinApp*        pApp    = AfxGetApp();
    CHeaderCtrl*    pHeader = pLC->GetHeaderCtrl();
    int             nCol    = pHeader->GetItemCount();
    int             colCx   = 0;

    /* Store the column quantity */
    pApp->WriteProfileInt(regKey, "Column Count", nCol);

    /* Store each column width */
	CRect rcH;
    for (int i = 0; i < nCol; i++) {
        pHeader->GetItemRect(i, &rcH);
        colCx = rcH.Width();

        key.Format("Column %i", i);
        pApp->WriteProfileInt(regKey, key, colCx);
    }
}


//============================================================================
//============================================================================
// Test section
//============================================================================
//============================================================================
