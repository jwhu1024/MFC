
#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H


// Inclusions
/////////////////////////////////////////////////////////////////////////////


// Constants
/////////////////////////////////////////////////////////////////////////////


// Data types
/////////////////////////////////////////////////////////////////////////////


// Class definitions
/////////////////////////////////////////////////////////////////////////////
#define CX_DESIGN_SMALL 150
#define CY_DESIGN_SMALL 163

class CSplashScreen : public CWnd
{

// Constructors and destructors
protected:
    CSplashScreen(/*UINT nBitmapID, UINT nDuration = 2500*/);
public:
    virtual ~CSplashScreen(); 



// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CSplashScreen)
    public:
    virtual BOOL PreTranslateMessage(MSG* pMsg);
    //}}AFX_VIRTUAL




// Operations
public:
    static bool Show(UINT nBitmapID, UINT nRegionID, UINT nDuration = 2500);
    static bool Kill();                     
    static bool IsVisible();                        

// Implementation
protected:
    // Get the singleton object
    static CSplashScreen& GetSingleton();

    // Creates and displays the Splash Screen
    BOOL Create(UINT nBitmapID, UINT nRegionID, UINT nDuration);
    
    // load the bitmap resource and create a logical palette
    BOOL GetBitmapAndPalette(UINT nIDResource, CBitmap &bitmap, CPalette &pal);

	BOOL CreateRegion(UINT nRegionID);

    // Bitmap ID
    UINT      m_nBitmapID;
    // Duration in millisecondes
    UINT      m_nDuration;
    // The timer identifier of the splash screen window 
    UINT      m_nTimerID;
    // Splash screen bitmap
    CBitmap   m_bitmap;
    // Splash screen palette
    CPalette  m_pal;
    // Invisible parent windows
    CWnd      m_wndInvisible;
    // Creation flag
    bool      m_isVisible;

// Generated message map functions
    //{{AFX_MSG(CSplashScreen)
    afx_msg void OnPaint();
    afx_msg void OnTimer(UINT nIDEvent);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


#endif //SPLASHSCREEN_H
