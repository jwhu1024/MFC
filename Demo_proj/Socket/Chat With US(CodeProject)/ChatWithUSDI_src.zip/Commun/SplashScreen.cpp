
// Inclusions
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h" 
#include "SplashScreen.h"



// Constants
/////////////////////////////////////////////////////////////////////////////
#define SPLASH_SCREEN_TIMER 1



// Data types
/////////////////////////////////////////////////////////////////////////////



// Variables
/////////////////////////////////////////////////////////////////////////////



// Development tools
/////////////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif




// Class implementations
/////////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP(CSplashScreen, CWnd)
    //{{AFX_MSG_MAP(CSplashScreen)
    ON_WM_PAINT()
    ON_WM_TIMER()
    //}}AFX_MSG_MAP
    //ON_WM_DESTROY()
    //ON_WM_NCDESTROY()
END_MESSAGE_MAP()




/*===========================================================================
@mfunc  Constructor.

@parm   Bitmap ID.

@parm   Duration in millisecondes.
===========================================================================*/
//CSplashScreen::CSplashScreen(UINT nBitmapID, UINT nDuration)
CSplashScreen::CSplashScreen()
{
}   




/*===========================================================================
@mfunc  Destructor.
===========================================================================*/
CSplashScreen::~CSplashScreen()
{
}




/*===========================================================================
@mfunc  Creates and displays the Splash Screen.

@rdesc  TRUE if successful, FALSE otherwise
===========================================================================*/
BOOL CSplashScreen::Create(UINT nBitmapID, UINT nRegionID, UINT nDuration) 
{     
    m_nBitmapID     = nBitmapID;
    m_nDuration     = nDuration;

    if (!GetBitmapAndPalette(m_nBitmapID, m_bitmap, m_pal)) {
        TRACE1( "Could not load bitmap resource - %d\n", m_nBitmapID );
        return FALSE;
    }

    BITMAP bm;
    m_bitmap.GetObject(sizeof(BITMAP), &bm);
    
    // First create an invisible window
    m_wndInvisible.CreateEx(WS_EX_TOPMOST, 
                            AfxRegisterWndClass(CS_CLASSDC), 
                            _T(""), 
                            WS_POPUP, 
                            0, 
                            0, 
                            bm.bmWidth, 
                            bm.bmHeight, 
                            NULL, 
                            NULL);

    // Create the the splash window with invisible parent as parent
    BOOL bRetVal = CWnd::CreateEx( WS_EX_TOPMOST, 
                                   AfxRegisterWndClass(CS_CLASSDC), 
                                   _T(""), 
                                   WS_POPUP, 
                                   0, 
                                   0, 
                                   bm.bmWidth, 
                                   bm.bmHeight, 
                                   m_wndInvisible.m_hWnd, 
                                   NULL);

	CreateRegion(nRegionID);
    CenterWindow();
    ShowWindow(SW_SHOW);
    UpdateWindow();
    

    // Create the timer.
    m_nTimerID = SetTimer(SPLASH_SCREEN_TIMER, m_nDuration, NULL);
    ASSERT(m_nTimerID);

    m_isVisible = bRetVal ? true: false;

    return bRetVal;
}


BOOL CSplashScreen::CreateRegion(UINT nRegionID)
{
    HINSTANCE hInst;   
    HRSRC     hRes;
    HGLOBAL   hGlobal; 
    DWORD     dwSize;
    RGNDATA*  pRgnData;

    //Retrive App instance
    hInst   = AfxGetInstanceHandle();
    if (!hInst) {
        return FALSE;
    }
    
    //Find region file
    hRes    = FindResource(hInst, MAKEINTRESOURCE(nRegionID), "RGN");
    if (!hRes) {
        return FALSE;
    }
    
    //Load region file
    hGlobal = LoadResource(hInst, hRes);
    if (!hGlobal) {
        return FALSE;
    }
    
    //Retrive size of region file
    dwSize   = SizeofResource(hInst, hRes);
    
    //Lock region file and retrive pointer to it
    pRgnData = (RGNDATA*)LockResource(hGlobal);       	 
    if (pRgnData) {
        
		CRgn  BackRgn;
        BackRgn.CreateFromData(NULL, dwSize, pRgnData);
        SetWindowRgn((HRGN)BackRgn.Detach(), TRUE);
	}

	return TRUE;
}

/*===========================================================================
@mfunc  Loads the bitmap resource and also creates a logical palette from the 
        color information in the bitmap. 

@parm   Bitmap resource ID.

@parm   Reference to CBitmap Object to be created.

@parm   Reference to CPalette Objet to be created.

@rdesc  TRUE if successful, FALSE otherwise
===========================================================================*/
BOOL CSplashScreen::GetBitmapAndPalette(UINT nIDResource, 
                                        CBitmap &bitmap, 
                                        CPalette &pal)
{
    LPCTSTR lpszResourceName = (LPCTSTR)nIDResource;
    HBITMAP hBmp = (HBITMAP)::LoadImage(AfxGetInstanceHandle(), 
                                        lpszResourceName, 
                                        IMAGE_BITMAP, 
                                        0,
                                        0, 
                                        LR_CREATEDIBSECTION);
    if (hBmp == NULL) {
        return FALSE;
    }

    bitmap.Attach(hBmp);

    // Create a logical palette for the bitmap
    DIBSECTION ds;
    BITMAPINFOHEADER &bmInfo = ds.dsBmih;
    bitmap.GetObject(sizeof(ds), &ds);

    int nColors = bmInfo.biClrUsed ? bmInfo.biClrUsed : 1 << bmInfo.biBitCount;

    // Create a halftone palette if colors > 256. 
    CClientDC dc(NULL);         // Desktop DC
    if (nColors > 256) {
        pal.CreateHalftonePalette(&dc);
    }
    else {
        // Create the palette
        RGBQUAD *pRGB = new RGBQUAD[nColors];
        CDC memDC;
        memDC.CreateCompatibleDC(&dc);

        memDC.SelectObject(&bitmap);
        ::GetDIBColorTable(memDC, 0, nColors, pRGB );

        UINT nSize = sizeof(LOGPALETTE) + (sizeof(PALETTEENTRY) * nColors);
        LOGPALETTE *pLP = (LOGPALETTE *) new BYTE[nSize];

        pLP->palVersion = 0x300;
        pLP->palNumEntries = nColors;

        for (int i=0; i < nColors; i++) {
            pLP->palPalEntry[i].peRed = pRGB[i].rgbRed;
            pLP->palPalEntry[i].peGreen = pRGB[i].rgbGreen;
            pLP->palPalEntry[i].peBlue = pRGB[i].rgbBlue;
            pLP->palPalEntry[i].peFlags = 0;
        }
        pal.CreatePalette(pLP);
        delete[] pLP;
        delete[] pRGB;
    }
    return TRUE;
}




/*===========================================================================
@mfunc  Get the singleton instanciation of this class.

@rdesc  A reference to the singleton static CSplashScreen object
===========================================================================*/
CSplashScreen& CSplashScreen::GetSingleton()
{
    // The unique CSplashScreen object used by this class.
    static CSplashScreen splash;

    return splash;
}




/*===========================================================================
@mfunc  Tells if the Splash Screen is displayed

@rdesc  true if currently displayed, false otherwise
===========================================================================*/
bool CSplashScreen::IsVisible()
{
    return GetSingleton().m_isVisible;
}




/*===========================================================================
@mfunc  Kill the Splash Window

@rdesc  true if the Splash Screen was still visible when the call was made, 
        false otherwise.
===========================================================================*/
bool CSplashScreen::Kill()
{
    bool wasVisible = false;

    if (IsVisible()) {
        GetSingleton().m_wndInvisible.DestroyWindow();
        GetSingleton().m_bitmap.Detach();
        GetSingleton().m_pal.Detach();
        wasVisible = true;
        GetSingleton().m_isVisible = false;
    }

    return wasVisible;
}




/*===========================================================================
@mfunc  Handles paint messages.
===========================================================================*/
void CSplashScreen::OnPaint() 
{
    CPaintDC dc(this); // device context for painting
    
    // Create a memory DC compatible with the paint DC
    CDC memDC;
    memDC.CreateCompatibleDC(&dc);

    CBitmap *pBmpOld = memDC.SelectObject(&m_bitmap);

    // Select and realize the palette
    if (dc.GetDeviceCaps(RASTERCAPS) & RC_PALETTE && m_pal.m_hObject != NULL) {
        dc.SelectPalette( &m_pal, FALSE );
        dc.RealizePalette();
    }

    // Window is same size as bitmap
    CRect rcWnd;
    GetWindowRect(&rcWnd);
    dc.BitBlt(0, 0, rcWnd.Width(), rcWnd.Height(), &memDC, 0, 0,SRCCOPY);

    // Restore bitmap in memDC
    memDC.SelectObject(pBmpOld);
    
    // Do not call CWnd::OnPaint() for painting messages
}




/*===========================================================================
@mfunc  Destroys the splash window (actually the parent, which destroys the 
        splash window in turn), the timer and the object itself. 

@parm   Timer ID.
===========================================================================*/
void CSplashScreen::OnTimer(UINT nIDEvent) 
{
    if (m_nTimerID == nIDEvent) {   
        // Destroy the timer and splash window
        KillTimer(m_nTimerID);
        Kill();
        return;
    }    
    CWnd::OnTimer(nIDEvent);
}




/*===========================================================================
@mfunc  Destroys the splash window when key down or a mouse down event is 
        received. 

@parm   Message received.

@rdesc  See Windows documentation.
===========================================================================*/
BOOL CSplashScreen::PreTranslateMessage(MSG* pMsg) 
{
    ASSERT(pMsg != NULL);
    
    if (
        pMsg->message == WM_KEYDOWN     ||
        pMsg->message == WM_SYSKEYDOWN  ||
        pMsg->message == WM_LBUTTONDOWN ||
        pMsg->message == WM_RBUTTONDOWN ||
        pMsg->message == WM_MBUTTONDOWN 
       )
    {
        // Destroy the timer and splash window
        KillTimer(m_nTimerID);
        Kill();
        return 1;
    }    
    return CWnd::PreTranslateMessage(pMsg);
}




/*===========================================================================
@mfunc  Creates and displays the Splash Screen

@parm   Bitmap ID.

@parm   Duration in millisecondes.

@rdesc  true if the Splash Screen was created,
        false otherwise (if a Splash Screen was already visible when the 
        call was made, we do not create a second one!)
===========================================================================*/
bool CSplashScreen::Show(UINT nBitmapID, UINT nRegionID, UINT nDuration)
{
    bool wasCreated = false;
    
    if (!IsVisible()) {
        GetSingleton().Create(nBitmapID, nRegionID, nDuration);
        GetSingleton().m_isVisible = true;
        wasCreated = true;
    }


    return wasCreated;
}


