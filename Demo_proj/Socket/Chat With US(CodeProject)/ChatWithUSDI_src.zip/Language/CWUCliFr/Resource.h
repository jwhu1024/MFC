//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CWUCliFr.rc
//
#define ID_TIMER_TIME                   101
#define IDD_FORMVIEW                    102
#define IDD_DIALOGBAR_UTIL              103
#define IDP_SOCKETS_INIT_FAILED         104
#define ID_TIMER_INITIALIZATION         105
#define IDR_MAINFRAME                   128
#define IDI_CLIENTSCOM                  130
#define IDI_CLIENT                      134
#define IDR_CLIENTS_CONTEXTUAL_MENU     135
#define IDD_DIALOG_MESSAGE              136
#define IDI_PRIVATECOM                  137
#define IDR_CLIENTS_CONTEXTUAL_TOOLSBAR 138
#define IDD_DIALOG_OPTIONS              139
#define IDR_BITMAP_MENU                 140
#define IDR_TRAY_MENU                   141
#define IDB_SPLASH                      142
#define IDR_SPLASH                      143
#define IDI_SIGN1                       144
#define IDI_SIGN2                       145
#define IDI_SIGN3                       146
#define IDI_SIGN4                       147
#define IDI_SIGN5                       148
#define IDI_SIGN6                       149
#define IDI_SIGN7                       150
#define IDI_SIGN8                       151
#define IDI_SIGN9                       152
#define IDI_SIGN10                      153
#define IDI_PRIVATE_MESSAGE             154
#define IDI_TIME                        155
#define IDI_MESSAGE                     156
#define IDI_SERVER                      157
#define IDC_EDIT_MESSAGE                1000
#define IDC_EDIT_PORT                   1001
#define IDC_BUTTON_SEND                 1002
#define IDC_SPIN_PORT                   1003
#define IDC_EDIT_SIGN_IN_NAME           1004
#define IDC_IPADDRESS                   1005
#define IDC_CAPTION_SIGN_NAME           1007
#define IDC_CHECK_SHORTCUT_MENU         1008
#define IDC_CHECK_SHORTCUT_DESKTOP      1009
#define IDC_COMBO_SIGN_IN_NAME          1009
#define IDC_CHECK_BALLON_ADD_CLIENT     1010
#define IDC_CHECK_BALLON_REMOVE_CLIENT  1011
#define IDC_CHECK_BALLON_PRIVATE_MESSAGE 1012
#define IDC_CHECK_MINIMIZE_TO_TRAY      1013
#define IDC_CHECK_SPLASH                1014
#define ID_OPERATIONS_CONNECTSERVER     32771
#define ID_OPERATIONS_DISCONNECTSERVER  32772
#define ID_INFORMATIONS_VIEWLOCALIPS    32776
#define ID_LANGUAGE_ENGLISH             32777
#define ID_LANGUAGE_FRENCH              32778
#define ID_POPUP_SENDMESSAGE            32779
#define ID_POPUP_OPENPRIVATEROOM        32780
#define IDS_RETRY_CONNECTION            32846
#define IDS_DISCONNECT_CLIENT           32847
#define IDS_TAB_CLIENTS                 32848
#define IDS_TOOLSBAR_MAIN               32849
#define IDS_TAB_CLIENTSCOM              32850
#define IDS_COL_TIME                    32851
#define IDS_COL_MESSAGE                 32852
#define IDS_TXT_FILE_EXT                32859
#define IDS_TXT_FILE_FLT                32860
#define IDS_MSG_SAVE_AS_FAILED          32861
#define IDS_PRINT_EMPTY_LIST            32863
#define IDS_FILE_LOG_HEADER             32864
#define IDS_SAVE_EMPTY_LIST             32865
#define IDS_COL_FROM                    32866
#define IDS_SOCKETS_INIT_FAILED         32868
#define IDS_CLIENT_SIGN_OUT             32869
#define IDS_EMPTY_LIST                  32870
#define IDS_TIME_FORMAT                 32871
#define IDS_MESSAGE_EMPTY               32872
#define IDS_TOOLSBAR_UTIL               32873
#define IDS_EMPTY_SIGN_IN_NAME          32874
#define IDS_INVALID_PORT_NUMBER         32875
#define IDS_INVALID_IP_ADRESS           32876
#define IDS_LOCAL_IP_HEADER             32877
#define ID_INDICATOR_CONNECTION_STATUS  32878
#define IDS_CLIENT_CONNECTED            32879
#define IDS_CLIENT_DISCONNECTED         32880
#define ID_INDICATOR_TIME               32881
#define IDS_LANGUAGE_DEFAULT            32882
#define IDS_TAB_PRIVATE_COM             32883
#define ID_INDICATOR_NBPRIVATE_MESSAGES 32884
#define IDS_NBPRIVATE_MESSAGES          32885
#define IDS_CAPTION_SIGN_NAME           32886
#define IDS_CAPTION_SEND_BUTTON         32887
#define IDS_BALLON_PRIVATE_MESSAGE      32888
#define IDS_BALLON_ADD_USER             32889
#define IDS_BALLON_REMOVE_CLIENT        32890
#define ID_OPTIONS_PREFERENCES          32891
#define ID_VIEW_CLIENTSLIST             32899
#define ID_VIEW_PARAMETERS              32900
#define IDS_SHORTCUT_DESCRIPTION        32901
#define ID_TRAYMENU_SHOWCHATWITHUSCLIENT 32902
#define ID_OPTIONS_ALWAYSVISIBLE        32903

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        159
#define _APS_NEXT_COMMAND_VALUE         32904
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
