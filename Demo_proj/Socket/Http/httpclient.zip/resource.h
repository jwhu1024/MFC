//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HttpClient.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HTTPCLIENT_DIALOG           102
#define IDS_TRUE                        102
#define IDR_HTML_PROGRESSDLG            103
#define IDR_HTML_BASICAUTHDLG           105
#define IDR_MAINFRAME                   128
#define IDD_PROGRESS                    130
#define IDD_BASICAUTH                   131
#define IDD_DIALOG1                     133
#define IDD_IMAGEDLG                    133
#define IDC_URL                         1000
#define IDC_PROXY                       1003
#define IDC_RESPONSE                    1004
#define IDC_PROXYPORT                   1006
#define IDC_CHECK1                      1008
#define IDC_USEPROXY                    1008
#define IDC_CHECK3                      1009
#define IDC_AUTH_NTLM                   1009
#define IDC_PROGRESS_BAR                1009
#define IDC_AUTH_BASIC                  1010
#define IDC_PROGRESS1                   1011
#define IDC_PROGRESSBAR                 1011
#define IDC_PASSWORD                    1012
#define IDC_USERNAME                    1013
#define IDC_PORT_TEXT                   1014
#define IDC_PROXYPORT_TEXT              1014
#define IDC_PROXY_TEXT                  1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
